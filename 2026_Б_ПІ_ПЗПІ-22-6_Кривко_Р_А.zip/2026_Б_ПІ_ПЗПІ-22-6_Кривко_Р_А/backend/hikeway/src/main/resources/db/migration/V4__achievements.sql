CREATE TABLE IF NOT EXISTS achievement (
    id BIGSERIAL PRIMARY KEY,
    code VARCHAR(80) NOT NULL,
    name VARCHAR(160) NOT NULL,
    description VARCHAR(500) NOT NULL,
    trigger_event VARCHAR(255) NOT NULL,
    metric VARCHAR(255) NOT NULL,
    target_value DOUBLE PRECISION NOT NULL,
    CONSTRAINT uk_achievement_code UNIQUE (code)
);

CREATE INDEX IF NOT EXISTS idx_achievement_trigger_event ON achievement(trigger_event);

CREATE TABLE IF NOT EXISTS user_achievement (
    id BIGSERIAL PRIMARY KEY,
    owner_id VARCHAR(255) NOT NULL,
    achievement_id BIGINT NOT NULL REFERENCES achievement(id),
    progress_value DOUBLE PRECISION NOT NULL DEFAULT 0,
    completed_at TIMESTAMPTZ,
    updated_at TIMESTAMPTZ NOT NULL,
    CONSTRAINT uk_user_achievement_owner_achievement UNIQUE (owner_id, achievement_id)
);

CREATE INDEX IF NOT EXISTS idx_user_achievement_owner_id ON user_achievement(owner_id);

INSERT INTO achievement (code, name, description, trigger_event, metric, target_value)
VALUES
    ('FIRST_HIKE', 'First hike', 'Finish your first hike.', 'HIKE_COMPLETED', 'FINISHED_HIKES', 1),
    ('FIRST_10K_HIKE', 'First 10K hike', 'Finish a hike of at least 10 km.', 'HIKE_COMPLETED', 'SINGLE_HIKE_DISTANCE_KM', 10),
    ('TOTAL_50K_HIKED', '50 km hiked', 'Hike 50 km in total.', 'HIKE_COMPLETED', 'TOTAL_DISTANCE_KM', 50),
    ('FIVE_HIKES_FINISHED', 'Five hikes finished', 'Finish five hikes.', 'HIKE_COMPLETED', 'FINISHED_HIKES', 5),
    ('FIRST_ROUTE_CREATED', 'First route created', 'Create your first route.', 'ROUTE_CREATED', 'ROUTES_CREATED', 1)
ON CONFLICT (code) DO UPDATE SET
    name = EXCLUDED.name,
    description = EXCLUDED.description,
    trigger_event = EXCLUDED.trigger_event,
    metric = EXCLUDED.metric,
    target_value = EXCLUDED.target_value;
