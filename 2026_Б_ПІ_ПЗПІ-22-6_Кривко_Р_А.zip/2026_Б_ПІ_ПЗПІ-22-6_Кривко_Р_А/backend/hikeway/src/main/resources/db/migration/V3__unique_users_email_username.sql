CREATE UNIQUE INDEX IF NOT EXISTS ux_user_entity_email_lower
    ON user_entity (lower(email));

CREATE UNIQUE INDEX IF NOT EXISTS ux_user_entity_username_lower
    ON user_entity (lower(username));
