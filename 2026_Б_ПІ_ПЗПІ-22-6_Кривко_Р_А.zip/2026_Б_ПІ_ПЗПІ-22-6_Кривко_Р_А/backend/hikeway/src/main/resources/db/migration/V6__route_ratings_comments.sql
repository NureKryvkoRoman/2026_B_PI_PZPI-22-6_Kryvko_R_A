CREATE TABLE IF NOT EXISTS route_rating (
    id BIGSERIAL PRIMARY KEY,
    route_id BIGINT NOT NULL REFERENCES route(id) ON DELETE CASCADE,
    user_id VARCHAR(255) NOT NULL,
    score INTEGER NOT NULL CHECK (score BETWEEN 1 AND 5),
    updated_at TIMESTAMPTZ NOT NULL,
    CONSTRAINT uk_route_rating_user UNIQUE (route_id, user_id)
);

CREATE INDEX IF NOT EXISTS idx_route_rating_route ON route_rating(route_id);

CREATE TABLE IF NOT EXISTS route_comment (
    id BIGSERIAL PRIMARY KEY,
    route_id BIGINT NOT NULL REFERENCES route(id) ON DELETE CASCADE,
    author_id VARCHAR(255) NOT NULL,
    author_display_name VARCHAR(255) NOT NULL,
    text VARCHAR(2000) NOT NULL,
    created_at TIMESTAMPTZ NOT NULL,
    updated_at TIMESTAMPTZ NOT NULL,
    deleted BOOLEAN NOT NULL DEFAULT FALSE
);

CREATE INDEX IF NOT EXISTS idx_route_comment_route_created ON route_comment(route_id, created_at);
