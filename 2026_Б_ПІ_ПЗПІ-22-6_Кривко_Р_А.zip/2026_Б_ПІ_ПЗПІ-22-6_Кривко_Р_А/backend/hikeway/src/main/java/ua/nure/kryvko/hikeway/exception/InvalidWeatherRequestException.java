package ua.nure.kryvko.hikeway.exception;

public class InvalidWeatherRequestException extends HikewayException {
    public InvalidWeatherRequestException(String message) {
        super(message);
    }
}
