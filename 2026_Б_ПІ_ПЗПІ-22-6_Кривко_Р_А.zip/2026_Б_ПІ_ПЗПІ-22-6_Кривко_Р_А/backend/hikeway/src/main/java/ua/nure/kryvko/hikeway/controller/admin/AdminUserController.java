package ua.nure.kryvko.hikeway.controller.admin;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import ua.nure.kryvko.hikeway.model.request.AdminCreateUserRequest;
import ua.nure.kryvko.hikeway.model.request.UpdateUserProfileRequest;
import ua.nure.kryvko.hikeway.model.response.PageResponse;
import ua.nure.kryvko.hikeway.model.response.UserProfileResponse;
import ua.nure.kryvko.hikeway.service.UserProfileService;

@RestController
@RequestMapping("/admin/users")
public class AdminUserController {
    private final UserProfileService userProfileService;

    @Autowired
    public AdminUserController(UserProfileService userProfileService) {
        this.userProfileService = userProfileService;
    }

    @GetMapping
    public ResponseEntity<PageResponse<UserProfileResponse>> listUsers(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "50") int size
    ) {
        return ResponseEntity.ok(userProfileService.adminList(page, size));
    }

    @PostMapping
    public ResponseEntity<UserProfileResponse> createUser(@RequestBody AdminCreateUserRequest request) {
        return ResponseEntity.ok(userProfileService.adminCreate(request));
    }

    @GetMapping("/{id}")
    public ResponseEntity<UserProfileResponse> getUser(@PathVariable Long id) {
        return ResponseEntity.ok(userProfileService.adminGet(id));
    }

    @PatchMapping("/{id}")
    public ResponseEntity<UserProfileResponse> updateUser(
            @PathVariable Long id,
            @RequestBody UpdateUserProfileRequest request
    ) {
        return ResponseEntity.ok(userProfileService.adminUpdate(id, request));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteUser(@PathVariable Long id) {
        userProfileService.adminDelete(id);
        return ResponseEntity.noContent().build();
    }
}
