package ua.nure.kryvko.hikeway.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import ua.nure.kryvko.hikeway.model.RouteRating;

import java.util.List;
import java.util.Optional;

public interface RouteRatingRepository extends JpaRepository<RouteRating, Long> {
    Optional<RouteRating> findByRouteIdAndUserId(Long routeId, String userId);

    void deleteByRouteId(Long routeId);

    @Query("select coalesce(avg(r.score), 0), count(r) from RouteRating r where r.route.id = :routeId")
    Object[] aggregateForRoute(@Param("routeId") Long routeId);

    List<RouteRating> findByRouteIdInAndUserId(List<Long> routeIds, String userId);

    @Query("""
            select r.route.id, coalesce(avg(r.score), 0), count(r)
            from RouteRating r where r.route.id in :routeIds group by r.route.id
            """)
    List<Object[]> aggregateForRoutes(@Param("routeIds") List<Long> routeIds);
}
