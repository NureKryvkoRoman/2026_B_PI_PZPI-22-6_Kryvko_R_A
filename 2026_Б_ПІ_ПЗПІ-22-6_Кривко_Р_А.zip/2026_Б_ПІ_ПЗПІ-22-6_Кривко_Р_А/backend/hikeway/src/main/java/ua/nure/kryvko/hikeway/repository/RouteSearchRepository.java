package ua.nure.kryvko.hikeway.repository;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import ua.nure.kryvko.hikeway.model.RouteGeometry;
import ua.nure.kryvko.hikeway.model.request.RouteSearchRequest;

import java.util.List;

public interface RouteSearchRepository {
    Page<RouteGeometry> searchPublishedRoutes(RouteSearchRequest request, Pageable pageable);

    Page<RouteGeometry> searchPublishedRoutesByName(String name, Pageable pageable);

    List<RouteGeometry> findRecommendationCandidates(
            Double longitude,
            Double latitude,
            Double maxProximityKm,
            int limit
    );
}
