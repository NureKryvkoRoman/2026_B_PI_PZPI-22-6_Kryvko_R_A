package ua.nure.kryvko.hikeway.model.weather;

public record WeatherRisk(
        WeatherRiskType type,
        WeatherRiskSeverity severity,
        WeatherRiskMessage message
) {
}
