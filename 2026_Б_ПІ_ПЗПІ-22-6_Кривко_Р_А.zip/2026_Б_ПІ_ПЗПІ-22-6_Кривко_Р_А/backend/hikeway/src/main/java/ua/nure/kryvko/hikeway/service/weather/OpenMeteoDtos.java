package ua.nure.kryvko.hikeway.service.weather;

import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.List;

record OpenMeteoDtos() {
    record ForecastResponse(
            Double latitude,
            Double longitude,
            Double elevation,
            String timezone,
            Hourly hourly,
            Daily daily
    ) {
    }

    record Hourly(
            List<String> time,
            @JsonProperty("temperature_2m") List<Double> temperature2m,
            @JsonProperty("apparent_temperature") List<Double> apparentTemperature,
            @JsonProperty("precipitation_probability") List<Integer> precipitationProbability,
            List<Double> precipitation,
            List<Double> rain,
            List<Double> showers,
            List<Double> snowfall,
            @JsonProperty("weather_code") List<Integer> weatherCode,
            @JsonProperty("wind_speed_10m") List<Double> windSpeed10m,
            @JsonProperty("wind_gusts_10m") List<Double> windGusts10m,
            List<Double> visibility,
            @JsonProperty("uv_index") List<Double> uvIndex,
            @JsonProperty("freezing_level_height") List<Double> freezingLevelHeight
    ) {
    }

    record Daily(
            List<String> time,
            @JsonProperty("weather_code") List<Integer> weatherCode,
            @JsonProperty("temperature_2m_max") List<Double> temperature2mMax,
            @JsonProperty("temperature_2m_min") List<Double> temperature2mMin,
            List<String> sunrise,
            List<String> sunset,
            @JsonProperty("daylight_duration") List<Double> daylightDuration,
            @JsonProperty("uv_index_max") List<Double> uvIndexMax,
            @JsonProperty("precipitation_sum") List<Double> precipitationSum,
            @JsonProperty("precipitation_probability_max") List<Integer> precipitationProbabilityMax,
            @JsonProperty("wind_speed_10m_max") List<Double> windSpeed10mMax,
            @JsonProperty("wind_gusts_10m_max") List<Double> windGusts10mMax
    ) {
    }
}
