package ua.nure.kryvko.hikeway.model;

public enum AchievementMetric {
    FINISHED_HIKES,
    TOTAL_DISTANCE_KM,
    SINGLE_HIKE_DISTANCE_KM,
    ROUTES_CREATED
}
