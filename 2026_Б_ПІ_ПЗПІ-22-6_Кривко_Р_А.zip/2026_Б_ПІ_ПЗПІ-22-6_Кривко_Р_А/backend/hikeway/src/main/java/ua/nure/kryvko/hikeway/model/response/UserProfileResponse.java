package ua.nure.kryvko.hikeway.model.response;

public record UserProfileResponse(
        Long id,
        String keycloakId,
        String email,
        String username,
        String firstName,
        String lastName
) {
}
