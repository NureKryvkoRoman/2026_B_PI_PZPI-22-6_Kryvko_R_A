package ua.nure.kryvko.hikeway.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import ua.nure.kryvko.hikeway.model.Achievement;
import ua.nure.kryvko.hikeway.model.AchievementTriggerEvent;

import java.util.List;

public interface AchievementRepository extends JpaRepository<Achievement, Long> {
    List<Achievement> findByTriggerEvent(AchievementTriggerEvent triggerEvent);
}
