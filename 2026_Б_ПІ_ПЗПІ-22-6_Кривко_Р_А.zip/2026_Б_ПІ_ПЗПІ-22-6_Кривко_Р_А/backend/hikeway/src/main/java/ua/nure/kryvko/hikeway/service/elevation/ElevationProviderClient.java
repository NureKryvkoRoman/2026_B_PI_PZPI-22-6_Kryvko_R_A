package ua.nure.kryvko.hikeway.service.elevation;

import org.locationtech.jts.geom.Coordinate;

import java.util.List;

public interface ElevationProviderClient {
    List<Double> elevations(List<Coordinate> coordinates);
}
