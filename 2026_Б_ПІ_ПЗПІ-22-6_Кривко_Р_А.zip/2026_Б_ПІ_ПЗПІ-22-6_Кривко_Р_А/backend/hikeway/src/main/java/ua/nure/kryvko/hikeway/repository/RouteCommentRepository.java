package ua.nure.kryvko.hikeway.repository;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import ua.nure.kryvko.hikeway.model.RouteComment;

import java.util.List;
import java.util.Optional;

public interface RouteCommentRepository extends JpaRepository<RouteComment, Long> {
    Page<RouteComment> findByRouteIdAndDeletedFalse(Long routeId, Pageable pageable);

    List<RouteComment> findByRouteIdAndDeletedFalse(Long routeId);

    Optional<RouteComment> findByIdAndRouteIdAndDeletedFalse(Long id, Long routeId);

    void deleteByRouteId(Long routeId);
}
