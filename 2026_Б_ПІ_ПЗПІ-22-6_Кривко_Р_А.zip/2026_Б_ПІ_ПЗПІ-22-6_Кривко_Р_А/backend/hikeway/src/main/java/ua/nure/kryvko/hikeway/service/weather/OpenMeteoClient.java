package ua.nure.kryvko.hikeway.service.weather;

import org.springframework.stereotype.Component;
import org.springframework.web.util.UriComponentsBuilder;
import tools.jackson.databind.ObjectMapper;
import tools.jackson.databind.json.JsonMapper;
import ua.nure.kryvko.hikeway.config.WeatherProperties;
import ua.nure.kryvko.hikeway.exception.WeatherProviderException;
import ua.nure.kryvko.hikeway.model.weather.WeatherForecast;

import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;

@Component
public class OpenMeteoClient implements WeatherProviderClient {
    private static final String HOURLY_VARIABLES = String.join(",",
            "temperature_2m",
            "apparent_temperature",
            "precipitation_probability",
            "precipitation",
            "rain",
            "showers",
            "snowfall",
            "weather_code",
            "wind_speed_10m",
            "wind_gusts_10m",
            "visibility",
            "uv_index",
            "freezing_level_height"
    );
    private static final String DAILY_VARIABLES = String.join(",",
            "weather_code",
            "temperature_2m_max",
            "temperature_2m_min",
            "sunrise",
            "sunset",
            "daylight_duration",
            "uv_index_max",
            "precipitation_sum",
            "precipitation_probability_max",
            "wind_speed_10m_max",
            "wind_gusts_10m_max"
    );

    private final WeatherProperties properties;
    private final OpenMeteoMapper mapper;
    private final ObjectMapper objectMapper;
    private final HttpClient httpClient;

    public OpenMeteoClient(WeatherProperties properties, OpenMeteoMapper mapper) {
        this.properties = properties;
        this.mapper = mapper;
        this.objectMapper = JsonMapper.builder().findAndAddModules().build();
        this.httpClient = HttpClient.newBuilder()
                .connectTimeout(properties.effectiveRequestTimeout())
                .build();
    }

    @Override
    public WeatherForecast forecast(double latitude, double longitude, Double elevationMeters) {
        URI uri = forecastUri(latitude, longitude, elevationMeters);
        int attempts = properties.effectiveRetryAttempts() + 1;
        WeatherProviderException lastException = null;
        for (int attempt = 1; attempt <= attempts; attempt++) {
            try {
                return fetch(uri);
            } catch (WeatherProviderException exception) {
                lastException = exception;
                if (attempt < attempts) {
                    backoff();
                }
            }
        }
        throw lastException == null
                ? new WeatherProviderException("Weather provider request failed")
                : lastException;
    }

    URI forecastUri(double latitude, double longitude, Double elevationMeters) {
        UriComponentsBuilder builder = UriComponentsBuilder
                .fromUri(properties.openMeteoBaseUrl())
                .path("/forecast")
                .queryParam("latitude", latitude)
                .queryParam("longitude", longitude)
                .queryParam("timezone", "auto")
                .queryParam("forecast_days", 16)
                .queryParam("hourly", HOURLY_VARIABLES)
                .queryParam("daily", DAILY_VARIABLES);
        if (elevationMeters != null) {
            builder.queryParam("elevation", elevationMeters);
        }
        return builder.build().toUri();
    }

    private WeatherForecast fetch(URI uri) {
        HttpRequest request = HttpRequest.newBuilder(uri)
                .timeout(properties.effectiveRequestTimeout())
                .GET()
                .build();
        try {
            HttpResponse<String> response = httpClient.send(request, HttpResponse.BodyHandlers.ofString());
            if (response.statusCode() < 200 || response.statusCode() >= 300) {
                throw new WeatherProviderException("Weather provider returned HTTP " + response.statusCode());
            }
            return mapper.toForecast(objectMapper.readValue(response.body(), OpenMeteoDtos.ForecastResponse.class));
        } catch (IOException exception) {
            throw new WeatherProviderException("Weather provider response could not be read", exception);
        } catch (InterruptedException exception) {
            Thread.currentThread().interrupt();
            throw new WeatherProviderException("Weather provider request was interrupted", exception);
        }
    }

    private void backoff() {
        Duration backoff = properties.effectiveRetryBackoff();
        if (backoff.isZero() || backoff.isNegative()) {
            return;
        }
        try {
            Thread.sleep(backoff.toMillis());
        } catch (InterruptedException exception) {
            Thread.currentThread().interrupt();
            throw new WeatherProviderException("Weather provider retry was interrupted", exception);
        }
    }
}
