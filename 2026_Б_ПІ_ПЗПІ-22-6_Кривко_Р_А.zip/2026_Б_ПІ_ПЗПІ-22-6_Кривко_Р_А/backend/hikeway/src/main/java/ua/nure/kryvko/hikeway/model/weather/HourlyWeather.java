package ua.nure.kryvko.hikeway.model.weather;

import java.time.LocalDateTime;

public record HourlyWeather(
        LocalDateTime time,
        Double temperatureC,
        Double apparentTemperatureC,
        Integer precipitationProbabilityPercent,
        Double precipitationMm,
        Double rainMm,
        Double showersMm,
        Double snowfallCm,
        Integer weatherCode,
        WeatherCondition condition,
        Double windSpeedKmh,
        Double windGustsKmh,
        Double visibilityMeters,
        Double uvIndex,
        Double freezingLevelMeters
) {
}
