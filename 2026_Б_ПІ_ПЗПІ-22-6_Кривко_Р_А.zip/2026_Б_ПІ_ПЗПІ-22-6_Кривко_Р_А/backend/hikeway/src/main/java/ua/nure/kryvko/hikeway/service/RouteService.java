package ua.nure.kryvko.hikeway.service;

import lombok.extern.slf4j.Slf4j;
import org.locationtech.jts.geom.Coordinate;
import org.locationtech.jts.geom.GeometryFactory;
import org.locationtech.jts.geom.LineString;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import ua.nure.kryvko.hikeway.exception.ForbiddenOperationException;
import ua.nure.kryvko.hikeway.exception.InvalidPoiDataException;
import ua.nure.kryvko.hikeway.exception.InvalidRouteGeometryException;
import ua.nure.kryvko.hikeway.exception.PoiContentNotFoundException;
import ua.nure.kryvko.hikeway.exception.RouteNotFoundException;
import ua.nure.kryvko.hikeway.model.*;
import ua.nure.kryvko.hikeway.model.geojson.GeoJsonLineString;
import ua.nure.kryvko.hikeway.model.request.CreateRouteRequest;
import ua.nure.kryvko.hikeway.model.request.RouteRequests;
import ua.nure.kryvko.hikeway.model.request.RouteSearchRequest;
import ua.nure.kryvko.hikeway.model.request.UpdateRouteRequest;
import ua.nure.kryvko.hikeway.model.response.FullRouteResponse;
import ua.nure.kryvko.hikeway.model.response.PageResponse;
import ua.nure.kryvko.hikeway.model.response.RouteContentResponses;
import ua.nure.kryvko.hikeway.model.response.RouteResponse;
import ua.nure.kryvko.hikeway.model.response.RouteSearchResponse;
import ua.nure.kryvko.hikeway.repository.RouteGeometryRepository;
import ua.nure.kryvko.hikeway.repository.RouteCommentRepository;
import ua.nure.kryvko.hikeway.repository.RouteRatingRepository;
import ua.nure.kryvko.hikeway.repository.RouteRepository;
import ua.nure.kryvko.hikeway.service.elevation.ElevationService;
import ua.nure.kryvko.hikeway.service.util.AuthUtils;

import java.time.Instant;
import java.util.Arrays;
import java.util.List;

@Slf4j
@Service
public class RouteService {
    private static final String LINE_STRING_TYPE = "LineString";
    private static final int MAX_PAGE_SIZE = 100;
    private static final double DEFAULT_PROXIMITY_KM = 30.0;
    private final RouteRepository routeRepository;
    private final RouteGeometryRepository routeGeometryRepository;
    private final RoutePoiService routePoiService;
    private final ElevationService elevationService;
    private final RouteRatingRepository routeRatingRepository;
    private final RouteCommentRepository routeCommentRepository;
    private final CurrentUserService currentUser;
    private final GeometryFactory geometryFactory = new GeometryFactory();

    @Autowired
    public RouteService(
            RouteRepository routeRepository,
            RouteGeometryRepository routeGeometryRepository,
            RoutePoiService routePoiService,
            ElevationService elevationService,
            RouteRatingRepository routeRatingRepository,
            RouteCommentRepository routeCommentRepository,
            CurrentUserService currentUser
    ) {
        this.routeRepository = routeRepository;
        this.routeGeometryRepository = routeGeometryRepository;
        this.routePoiService = routePoiService;
        this.elevationService = elevationService;
        this.routeRatingRepository = routeRatingRepository;
        this.routeCommentRepository = routeCommentRepository;
        this.currentUser = currentUser;
    }

    @Transactional(readOnly = true)
    public PageResponse<RouteSearchResponse> searchRoutes(RouteSearchRequest request) {
        request = normalizeSearch(request);
        validateSearch(request);
        var routes = routeRepository.searchPublishedRoutes(
                request,
                PageRequest.of(request.page(), request.size())
        );
        return PageResponse.from(
                routes,
                routes.stream().map(this::toSearchResponse).toList()
        );
    }

    @Transactional(readOnly = true)
    public PageResponse<RouteSearchResponse> searchPublishedRoutesByName(String name, int page, int size) {
        requireSearchName(name);
        requirePage(page, size);
        var routes = routeRepository.searchPublishedRoutesByName(
                name.trim(),
                PageRequest.of(page, size)
        );
        return PageResponse.from(
                routes,
                routes.stream().map(this::toSearchResponse).toList()
        );
    }

    @Transactional(readOnly = true)
    public PageResponse<RouteSearchResponse> currentUserRoutes(int page, int size) {
        requirePage(page, size);
        var routes = routeGeometryRepository.findUserCreatedRoutes(
                AuthUtils.currentUserId(),
                PageRequest.of(page, size)
        );
        return PageResponse.from(
                routes,
                routes.stream().map(this::toSearchResponse).toList()
        );
    }

    private RouteSearchRequest normalizeSearch(RouteSearchRequest request) {
        if (hasLocation(request) && request.maxProximityKm() == null && !hasRouteFilters(request)) {
            return new RouteSearchRequest(
                    request.minDistanceKm(),
                    request.maxDistanceKm(),
                    request.minEstimatedTimeMinutes(),
                    request.maxEstimatedTimeMinutes(),
                    request.difficulties(),
                    request.terrains(),
                    request.longitude(),
                    request.latitude(),
                    DEFAULT_PROXIMITY_KM,
                    request.page(),
                    request.size()
            );
        }
        return request;
    }

    public FullRouteResponse createRoute(CreateRouteRequest request) {
        String createdBy = AuthUtils.currentUserId();

        Route route = new Route();
        route.setName(request.name());
        route.setDescription(request.description());
        route.setDistanceKm(request.distanceKm());
        route.setEstimatedTimeMinutes(request.estimatedTimeMinutes());
        route.setDifficulty(request.difficulty());
        route.setElevationGain(elevationService.estimateGain(request.geometry(), request.elevationGain()));
        route.setCreatedAt(Instant.now());
        route.setCreatedBy(createdBy);

        route = routeRepository.save(route);

        RouteGeometry geometry = null;
        if (request.geometry() != null) {
            geometry = new RouteGeometry();
            geometry.setRoute(route);
            geometry.setLine(createLineString(request.geometry()));
            geometry = routeGeometryRepository.save(geometry);
        }
        routePoiService.replace(route, request.poiIds());

        return toFullRouteResponse(route, geometry);
    }

    public FullRouteResponse getRouteWithGeometry(Long id) {
        Route route = getRouteEntity(id);
        RouteGeometry geometry = routeGeometryRepository.findByRoute(route).orElse(null);
        return toFullRouteResponse(route, geometry);
    }

    public RouteResponse getRoute(Long id) {
        Route route = getRouteEntity(id);
        return toRouteResponse(route);
    }

    public GeoJsonLineString getRouteGeometry(Long routeId) {
        RouteGeometry geometry = routeGeometryRepository.findByRouteId(routeId)
                .orElseThrow(() -> new RouteNotFoundException("Route not found with id: " + routeId));
        return toGeoJson(geometry.getLine());
    }

    public FullRouteResponse updateRoute(Long id, UpdateRouteRequest request) {
        Route route = getRouteEntity(id);

        if (request.name() != null) route.setName(request.name());
        if (request.description() != null) route.setDescription(request.description());
        if (request.distanceKm() != null) route.setDistanceKm(request.distanceKm());
        if (request.estimatedTimeMinutes() != null) route.setEstimatedTimeMinutes(request.estimatedTimeMinutes());
        if (request.difficulty() != null) route.setDifficulty(request.difficulty());

        route = routeRepository.save(route);

        RouteGeometry geometry = routeGeometryRepository.findByRoute(route).orElse(null);
        if (request.geometry() != null) {
            if (geometry == null) {
                geometry = new RouteGeometry();
                geometry.setRoute(route);
            }
            geometry.setLine(createLineString(request.geometry()));
            geometry = routeGeometryRepository.save(geometry);
            route.setElevationGain(elevationService.estimateGain(
                    request.geometry(),
                    request.elevationGain() == null ? route.getElevationGain() : request.elevationGain()
            ));
            route = routeRepository.save(route);
        } else if (request.elevationGain() != null) {
            route.setElevationGain(request.elevationGain());
            route = routeRepository.save(route);
        }
        if (request.poiIds() != null) {
            routePoiService.replace(route, request.poiIds());
        }

        return toFullRouteResponse(route, geometry);
    }

    public void deleteRoute(Long id) {
        Route route = getRouteEntity(id);
        routeCommentRepository.deleteByRouteId(id);
        routeRatingRepository.deleteByRouteId(id);
        routePoiService.deleteForRoute(id);
        routeGeometryRepository.findByRoute(route).ifPresent(routeGeometryRepository::delete);
        routeRepository.delete(route);
    }

    @Transactional
    public RouteContentResponses.Rating rate(long id, RouteRequests.Rating request) {
        Route route = activeRoute(id);
        if (request.score() == null || request.score() < 1 || request.score() > 5) {
            throw invalidRequest("Rating must be between 1 and 5");
        }
        RouteRating rating = routeRatingRepository.findByRouteIdAndUserId(id, currentUser.id())
                .orElseGet(RouteRating::new);
        rating.setRoute(route);
        rating.setUserId(currentUser.id());
        rating.setScore(request.score());
        rating.setUpdatedAt(Instant.now());
        routeRatingRepository.save(rating);
        return ratingResponse(id);
    }

    @Transactional
    public RouteContentResponses.Rating removeRating(long id) {
        activeRoute(id);
        routeRatingRepository.findByRouteIdAndUserId(id, currentUser.id())
                .ifPresent(routeRatingRepository::delete);
        return ratingResponse(id);
    }

    @Transactional(readOnly = true)
    public PageResponse<RouteContentResponses.Comment> comments(long routeId, int page, int size) {
        activeRoute(routeId);
        var comments = routeCommentRepository.findByRouteIdAndDeletedFalse(
                routeId,
                pageRequest(page, size, Sort.by("createdAt").descending())
        );
        String userId = currentUser.id();
        return PageResponse.from(comments, comments.stream()
                .map(comment -> toComment(comment, userId))
                .toList());
    }

    @Transactional
    public RouteContentResponses.Comment addComment(long routeId, RouteRequests.Comment request) {
        Route route = activeRoute(routeId);
        RouteComment comment = new RouteComment();
        comment.setRoute(route);
        comment.setAuthorId(currentUser.id());
        comment.setAuthorDisplayName(currentUser.displayName());
        comment.setText(requiredText(request.text(), "Comment", 2000));
        Instant now = Instant.now();
        comment.setCreatedAt(now);
        comment.setUpdatedAt(now);
        comment = routeCommentRepository.save(comment);
        return toComment(comment, currentUser.id());
    }

    @Transactional
    public RouteContentResponses.Comment updateComment(long routeId, long commentId, RouteRequests.Comment request) {
        activeRoute(routeId);
        RouteComment comment = ownedComment(routeId, commentId);
        comment.setText(requiredText(request.text(), "Comment", 2000));
        comment.setUpdatedAt(Instant.now());
        return toComment(routeCommentRepository.save(comment), currentUser.id());
    }

    @Transactional
    public void deleteComment(long routeId, long commentId) {
        activeRoute(routeId);
        RouteComment comment = ownedComment(routeId, commentId);
        comment.setDeleted(true);
        comment.setUpdatedAt(Instant.now());
        routeCommentRepository.save(comment);
    }

    private Route getRouteEntity(Long id) {
        return routeRepository.findById(id)
                .orElseThrow(() -> new RouteNotFoundException("Route not found with id: " + id));
    }

    private Route activeRoute(Long id) {
        Route route = getRouteEntity(id);
        if (route.isDeleted()) {
            throw new RouteNotFoundException("Route not found with id: " + id);
        }
        return route;
    }

    private FullRouteResponse toFullRouteResponse(Route route, RouteGeometry geometry) {
        RatingAggregate aggregate = aggregate(route.getId());
        return new FullRouteResponse(
                route.getId(),
                route.getName(),
                route.getDescription(),
                route.getDistanceKm(),
                route.getEstimatedTimeMinutes(),
                route.getDifficulty(),
                route.getElevationGain(),
                route.getTerrain(),
                route.getCreatedAt(),
                route.getCreatedBy(),
                geometry == null ? null : toGeoJson(geometry.getLine()),
                routePoiService.summaries(route.getId()),
                aggregate.average(),
                aggregate.count(),
                aggregate.userScore()
        );
    }

    private RouteResponse toRouteResponse(Route route) {
        RatingAggregate aggregate = aggregate(route.getId());
        return new RouteResponse(
                route.getId(),
                route.getName(),
                route.getDescription(),
                route.getDistanceKm(),
                route.getEstimatedTimeMinutes(),
                route.getDifficulty(),
                route.getElevationGain(),
                route.getTerrain(),
                route.getCreatedAt(),
                route.getCreatedBy(),
                routePoiService.summaries(route.getId()),
                route.getClientId(),
                route.getVisibility(),
                aggregate.average(),
                aggregate.count(),
                aggregate.userScore()
        );
    }

    private RouteSearchResponse toSearchResponse(RouteGeometry geometry) {
        Route route = geometry.getRoute();
        RatingAggregate aggregate = aggregate(route.getId());
        return new RouteSearchResponse(
                route.getId(),
                route.getName(),
                route.getDescription(),
                route.getDistanceKm(),
                route.getEstimatedTimeMinutes(),
                route.getDifficulty(),
                route.getElevationGain(),
                route.getTerrain(),
                route.getCreatedAt(),
                route.getCreatedBy(),
                toGeoJson(geometry.getLine()),
                route.getClientId(),
                route.getVisibility(),
                aggregate.average(),
                aggregate.count(),
                aggregate.userScore()
        );
    }

    private RouteContentResponses.Rating ratingResponse(long routeId) {
        RatingAggregate aggregate = aggregate(routeId);
        return new RouteContentResponses.Rating(aggregate.average(), aggregate.count(), aggregate.userScore());
    }

    private RatingAggregate aggregate(long routeId) {
        Object[] result = normalizeAggregateResult(routeRatingRepository.aggregateForRoute(routeId));
        double average = ((Number) result[0]).doubleValue();
        long count = ((Number) result[1]).longValue();
        Integer userScore = routeRatingRepository.findByRouteIdAndUserId(routeId, currentUser.id())
                .map(RouteRating::getScore)
                .orElse(null);
        return new RatingAggregate(average, count, userScore);
    }

    private Object[] normalizeAggregateResult(Object[] result) {
        if (result.length == 1 && result[0] instanceof Object[] nested) {
            return nested;
        }
        return result;
    }

    private RouteContentResponses.Comment toComment(RouteComment comment, String userId) {
        return new RouteContentResponses.Comment(
                comment.getId(),
                comment.getAuthorId(),
                comment.getAuthorDisplayName(),
                comment.getAuthorId().equals(userId),
                comment.getText(),
                comment.getCreatedAt(),
                comment.getUpdatedAt()
        );
    }

    private RouteComment ownedComment(long routeId, long commentId) {
        RouteComment comment = routeCommentRepository.findByIdAndRouteIdAndDeletedFalse(commentId, routeId)
                .orElseThrow(() -> new PoiContentNotFoundException("Comment"));
        requireOwner(comment.getAuthorId());
        return comment;
    }

    private void requireOwner(String ownerId) {
        if (!ownerId.equals(currentUser.id()) && !currentUser.isAdmin()) {
            throw new ForbiddenOperationException();
        }
    }

    private PageRequest pageRequest(int page, int size, Sort sort) {
        requirePage(page, size);
        return PageRequest.of(page, size, sort);
    }

    private String requiredText(String value, String field, int maximumLength) {
        String normalized = optionalText(value, maximumLength);
        if (normalized == null || normalized.isBlank()) {
            throw invalidRequest(field + " is required");
        }
        return normalized;
    }

    private String optionalText(String value, int maximumLength) {
        if (value == null) {
            return null;
        }
        String normalized = value.trim();
        if (normalized.length() > maximumLength) {
            throw invalidRequest("Text exceeds maximum length of " + maximumLength);
        }
        return normalized.isEmpty() ? null : normalized;
    }

    private void validateSearch(RouteSearchRequest request) {
        requirePage(request.page(), request.size());
        requireNonNegative(request.minDistanceKm(), "Minimum distance must be non-negative");
        requireNonNegative(request.maxDistanceKm(), "Maximum distance must be non-negative");
        if (request.minDistanceKm() != null && request.maxDistanceKm() != null &&
                request.minDistanceKm() > request.maxDistanceKm()) {
            throw invalidRequest("Minimum distance must not exceed maximum distance");
        }
        requireNonNegative(request.minEstimatedTimeMinutes(), "Minimum estimated time must be non-negative");
        requireNonNegative(request.maxEstimatedTimeMinutes(), "Maximum estimated time must be non-negative");
        if (request.minEstimatedTimeMinutes() != null && request.maxEstimatedTimeMinutes() != null &&
                request.minEstimatedTimeMinutes() > request.maxEstimatedTimeMinutes()) {
            throw invalidRequest("Minimum estimated time must not exceed maximum estimated time");
        }
        validateProximity(request);
    }

    private void validateProximity(RouteSearchRequest request) {
        boolean hasAnyLocation = hasLocation(request);
        if (!hasAnyLocation && request.maxProximityKm() == null) {
            return;
        }
        if (request.longitude() == null || request.latitude() == null) {
            throw invalidRequest("Longitude and latitude must be provided together");
        }
        requireLongitude(request.longitude());
        requireLatitude(request.latitude());
        if (request.maxProximityKm() != null) {
            requirePositive(request.maxProximityKm(), "Maximum proximity must be greater than 0");
        }
    }

    private boolean hasRouteFilters(RouteSearchRequest request) {
        return request.minDistanceKm() != null ||
                request.maxDistanceKm() != null ||
                request.minEstimatedTimeMinutes() != null ||
                request.maxEstimatedTimeMinutes() != null ||
                (request.difficulties() != null && !request.difficulties().isEmpty()) ||
                (request.terrains() != null && !request.terrains().isEmpty()) ||
                request.maxProximityKm() != null;
    }

    private boolean hasLocation(RouteSearchRequest request) {
        return request.longitude() != null || request.latitude() != null;
    }

    private void requirePage(int page, int size) {
        if (page < 0 || size < 1 || size > MAX_PAGE_SIZE) {
            throw invalidRequest("Page must be non-negative and size must be 1 to 100");
        }
    }

    private void requireSearchName(String value) {
        if (value == null || value.trim().isEmpty()) {
            throw invalidRequest("Name is required");
        }
    }

    private void requireNonNegative(Double value, String message) {
        if (value != null && (!Double.isFinite(value) || value < 0)) {
            throw invalidRequest(message);
        }
    }

    private void requireNonNegative(Integer value, String message) {
        if (value != null && value < 0) {
            throw invalidRequest(message);
        }
    }

    private void requirePositive(Double value, String message) {
        if (!Double.isFinite(value) || value <= 0) {
            throw invalidRequest(message);
        }
    }

    private void requireLongitude(Double value) {
        if (!Double.isFinite(value) || value < -180 || value > 180) {
            throw invalidRequest("Longitude must be between -180 and 180");
        }
    }

    private void requireLatitude(Double value) {
        if (!Double.isFinite(value) || value < -90 || value > 90) {
            throw invalidRequest("Latitude must be between -90 and 90");
        }
    }

    private InvalidPoiDataException invalidRequest(String message) {
        return new InvalidPoiDataException("INVALID_REQUEST", message);
    }

    private record RatingAggregate(double average, long count, Integer userScore) {
    }

    private LineString createLineString(GeoJsonLineString geometry) {
        validateGeoJsonLineString(geometry);
        Coordinate[] coords = geometry.coordinates().stream()
                .map(this::toCoordinate)
                .toArray(Coordinate[]::new);
        return geometryFactory.createLineString(coords);
    }

    private Coordinate toCoordinate(List<Double> coordinate) {
        if (coordinate == null || coordinate.size() < 2) {
            throw new InvalidRouteGeometryException("GeoJSON coordinates must contain longitude and latitude");
        }
        Double longitude = coordinate.get(0);
        Double latitude = coordinate.get(1);
        if (longitude == null || latitude == null) {
            throw new InvalidRouteGeometryException("GeoJSON coordinates must contain longitude and latitude");
        }
        return new Coordinate(longitude, latitude);
    }

    private void validateGeoJsonLineString(GeoJsonLineString geometry) {
        if (!LINE_STRING_TYPE.equals(geometry.type())) {
            throw new InvalidRouteGeometryException("Route geometry must be a GeoJSON LineString");
        }
        if (geometry.coordinates() == null || geometry.coordinates().size() < 2) {
            throw new InvalidRouteGeometryException("Route geometry must contain at least two coordinates");
        }
    }

    private GeoJsonLineString toGeoJson(LineString lineString) {
        List<List<Double>> coordinates = Arrays.stream(lineString.getCoordinates())
                .map(coordinate -> List.of(coordinate.getX(), coordinate.getY()))
                .toList();

        return new GeoJsonLineString(LINE_STRING_TYPE, coordinates);
    }
}
