package ua.nure.kryvko.hikeway.exception;

public class WeatherProviderException extends HikewayException {
    public WeatherProviderException(String message) {
        super(message);
    }

    public WeatherProviderException(String message, Throwable cause) {
        super(message);
        initCause(cause);
    }
}
