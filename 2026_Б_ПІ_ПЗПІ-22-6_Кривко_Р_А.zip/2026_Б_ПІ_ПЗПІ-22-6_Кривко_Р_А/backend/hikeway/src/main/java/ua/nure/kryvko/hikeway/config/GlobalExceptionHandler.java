package ua.nure.kryvko.hikeway.config;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import ua.nure.kryvko.hikeway.exception.InvalidRouteGeometryException;
import ua.nure.kryvko.hikeway.exception.InvalidUserDataException;
import ua.nure.kryvko.hikeway.exception.InvalidWeatherRequestException;
import ua.nure.kryvko.hikeway.exception.KeycloakException;
import ua.nure.kryvko.hikeway.exception.RouteNotFoundException;
import ua.nure.kryvko.hikeway.exception.UserAlreadyExistsException;
import ua.nure.kryvko.hikeway.exception.UserNotFoundException;
import ua.nure.kryvko.hikeway.exception.SyncBatchTooLargeException;
import ua.nure.kryvko.hikeway.exception.ForbiddenOperationException;
import ua.nure.kryvko.hikeway.exception.InvalidPoiDataException;
import ua.nure.kryvko.hikeway.exception.PoiContentNotFoundException;
import ua.nure.kryvko.hikeway.exception.PoiNotFoundException;
import ua.nure.kryvko.hikeway.exception.WeatherProviderException;
import ua.nure.kryvko.hikeway.model.response.ApiError;

@RestControllerAdvice
public class GlobalExceptionHandler {

    @ExceptionHandler(UserAlreadyExistsException.class)
    public ResponseEntity<ApiError> handleUserExists() {
        return ResponseEntity.status(HttpStatus.CONFLICT)
                .body(ApiError.of("USER_ALREADY_EXISTS", "User already exists"));
    }

    @ExceptionHandler(InvalidUserDataException.class)
    public ResponseEntity<ApiError> handleInvalidUserData(InvalidUserDataException exception) {
        return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                .body(ApiError.of("INVALID_REQUEST", exception.getMessage()));
    }

    @ExceptionHandler(KeycloakException.class)
    public ResponseEntity<ApiError> handleKC() {
        return ResponseEntity.status(HttpStatus.BAD_GATEWAY)
                .body(ApiError.of("AUTH_SERVICE_ERROR", "Auth service error"));
    }

    @ExceptionHandler(RouteNotFoundException.class)
    public ResponseEntity<ApiError> handleRouteNotFound() {
        return ResponseEntity.status(HttpStatus.NOT_FOUND)
                .body(ApiError.of("ROUTE_NOT_FOUND", "Route not found"));
    }

    @ExceptionHandler(UserNotFoundException.class)
    public ResponseEntity<ApiError> handleUserNotFound() {
        return ResponseEntity.status(HttpStatus.NOT_FOUND)
                .body(ApiError.of("USER_NOT_FOUND", "User not found"));
    }

    @ExceptionHandler(InvalidRouteGeometryException.class)
    public ResponseEntity<ApiError> handleInvalidRouteGeometry(InvalidRouteGeometryException exception) {
        return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                .body(ApiError.of("INVALID_GEOMETRY", exception.getMessage()));
    }

    @ExceptionHandler(SyncBatchTooLargeException.class)
    public ResponseEntity<ApiError> handleSyncBatchTooLarge(SyncBatchTooLargeException exception) {
        return ResponseEntity.status(HttpStatus.PAYLOAD_TOO_LARGE)
                .body(ApiError.of("SYNC_BATCH_TOO_LARGE", exception.getMessage()));
    }

    @ExceptionHandler(PoiNotFoundException.class)
    public ResponseEntity<ApiError> handlePoiNotFound() {
        return ResponseEntity.status(HttpStatus.NOT_FOUND)
                .body(ApiError.of("POI_NOT_FOUND", "Point of interest not found"));
    }

    @ExceptionHandler(PoiContentNotFoundException.class)
    public ResponseEntity<ApiError> handlePoiContentNotFound(PoiContentNotFoundException exception) {
        String code = exception.getResource().toUpperCase() + "_NOT_FOUND";
        return ResponseEntity.status(HttpStatus.NOT_FOUND)
                .body(ApiError.of(code, exception.getMessage()));
    }

    @ExceptionHandler(ForbiddenOperationException.class)
    public ResponseEntity<ApiError> handleForbidden() {
        return ResponseEntity.status(HttpStatus.FORBIDDEN)
                .body(ApiError.of("FORBIDDEN", "You do not own this resource"));
    }

    @ExceptionHandler(InvalidPoiDataException.class)
    public ResponseEntity<ApiError> handleInvalidPoiData(InvalidPoiDataException exception) {
        return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                .body(ApiError.of(exception.getCode(), exception.getMessage()));
    }

    @ExceptionHandler(InvalidWeatherRequestException.class)
    public ResponseEntity<ApiError> handleInvalidWeatherRequest(InvalidWeatherRequestException exception) {
        return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                .body(ApiError.of("INVALID_REQUEST", exception.getMessage()));
    }

    @ExceptionHandler(WeatherProviderException.class)
    public ResponseEntity<ApiError> handleWeatherProvider() {
        return ResponseEntity.status(HttpStatus.BAD_GATEWAY)
                .body(ApiError.of("WEATHER_PROVIDER_ERROR", "Weather provider error"));
    }
}
