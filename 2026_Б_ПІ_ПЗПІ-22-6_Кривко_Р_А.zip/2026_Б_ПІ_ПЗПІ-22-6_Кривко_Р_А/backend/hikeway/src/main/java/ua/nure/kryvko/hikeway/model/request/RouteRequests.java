package ua.nure.kryvko.hikeway.model.request;

public final class RouteRequests {
    private RouteRequests() {
    }

    public record Rating(Integer score) {
    }

    public record Comment(String text) {
    }
}
