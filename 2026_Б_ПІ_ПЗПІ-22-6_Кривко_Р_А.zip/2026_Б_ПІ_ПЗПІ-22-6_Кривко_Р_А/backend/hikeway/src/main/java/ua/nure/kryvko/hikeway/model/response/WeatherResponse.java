package ua.nure.kryvko.hikeway.model.response;

import ua.nure.kryvko.hikeway.model.weather.DailyWeather;
import ua.nure.kryvko.hikeway.model.weather.DaylightWindow;
import ua.nure.kryvko.hikeway.model.weather.HikeStartRecommendation;
import ua.nure.kryvko.hikeway.model.weather.HourlyWeather;
import ua.nure.kryvko.hikeway.model.weather.WeatherRisk;

import java.time.Instant;
import java.time.LocalDate;
import java.util.List;

public record WeatherResponse(
        long routeId,
        double latitude,
        double longitude,
        Double elevationMeters,
        LocalDate date,
        String timezone,
        DailyWeather summary,
        List<HourlyWeather> hourlyForecast,
        DaylightWindow daylight,
        List<WeatherRisk> risks,
        HikeStartRecommendation recommendation,
        String dataSource,
        Instant lastUpdated
) {
}
