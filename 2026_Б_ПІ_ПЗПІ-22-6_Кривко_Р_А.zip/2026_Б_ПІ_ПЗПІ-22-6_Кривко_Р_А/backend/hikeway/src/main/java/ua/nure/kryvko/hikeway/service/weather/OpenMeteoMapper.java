package ua.nure.kryvko.hikeway.service.weather;

import org.springframework.stereotype.Component;
import ua.nure.kryvko.hikeway.exception.WeatherProviderException;
import ua.nure.kryvko.hikeway.model.weather.DailyWeather;
import ua.nure.kryvko.hikeway.model.weather.HourlyWeather;
import ua.nure.kryvko.hikeway.model.weather.WeatherCondition;
import ua.nure.kryvko.hikeway.model.weather.WeatherForecast;

import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@Component
public class OpenMeteoMapper {
    public WeatherForecast toForecast(OpenMeteoDtos.ForecastResponse response) {
        if (response == null || response.hourly() == null || response.daily() == null) {
            throw new WeatherProviderException("Weather provider returned an incomplete forecast");
        }
        return new WeatherForecast(
                required(response.latitude(), "latitude"),
                required(response.longitude(), "longitude"),
                response.elevation(),
                response.timezone(),
                hourly(response.hourly()),
                daily(response.daily()),
                Instant.now()
        );
    }

    private List<HourlyWeather> hourly(OpenMeteoDtos.Hourly hourly) {
        int size = hourly.time() == null ? 0 : hourly.time().size();
        List<HourlyWeather> result = new ArrayList<>(size);
        for (int i = 0; i < size; i++) {
            Integer weatherCode = value(hourly.weatherCode(), i);
            result.add(new HourlyWeather(
                    LocalDateTime.parse(hourly.time().get(i)),
                    value(hourly.temperature2m(), i),
                    value(hourly.apparentTemperature(), i),
                    value(hourly.precipitationProbability(), i),
                    value(hourly.precipitation(), i),
                    value(hourly.rain(), i),
                    value(hourly.showers(), i),
                    value(hourly.snowfall(), i),
                    weatherCode,
                    WeatherCondition.fromWeatherCode(weatherCode),
                    value(hourly.windSpeed10m(), i),
                    value(hourly.windGusts10m(), i),
                    value(hourly.visibility(), i),
                    value(hourly.uvIndex(), i),
                    value(hourly.freezingLevelHeight(), i)
            ));
        }
        return result;
    }

    private List<DailyWeather> daily(OpenMeteoDtos.Daily daily) {
        int size = daily.time() == null ? 0 : daily.time().size();
        List<DailyWeather> result = new ArrayList<>(size);
        for (int i = 0; i < size; i++) {
            Double daylightDuration = value(daily.daylightDuration(), i);
            Integer weatherCode = value(daily.weatherCode(), i);
            result.add(new DailyWeather(
                    LocalDate.parse(daily.time().get(i)),
                    weatherCode,
                    WeatherCondition.fromWeatherCode(weatherCode),
                    value(daily.temperature2mMax(), i),
                    value(daily.temperature2mMin(), i),
                    parseDateTime(value(daily.sunrise(), i)),
                    parseDateTime(value(daily.sunset(), i)),
                    daylightDuration == null ? null : daylightDuration.longValue(),
                    value(daily.uvIndexMax(), i),
                    value(daily.precipitationSum(), i),
                    value(daily.precipitationProbabilityMax(), i),
                    value(daily.windSpeed10mMax(), i),
                    value(daily.windGusts10mMax(), i)
            ));
        }
        return result;
    }

    private double required(Double value, String name) {
        if (value == null) {
            throw new WeatherProviderException("Weather provider response is missing " + name);
        }
        return value;
    }

    private LocalDateTime parseDateTime(String value) {
        return value == null ? null : LocalDateTime.parse(value);
    }

    private <T> T value(List<T> values, int index) {
        if (values == null || index >= values.size()) {
            return null;
        }
        return values.get(index);
    }
}
