package ua.nure.kryvko.hikeway.model.weather;

import java.time.LocalDateTime;

public record HikeStartRecommendation(
        LocalDateTime recommendedStartTime,
        LocalDateTime expectedReturnTime,
        HikeRecommendationExplanation explanation
) {
}
