package ua.nure.kryvko.hikeway.service;

import org.locationtech.jts.geom.Coordinate;
import org.locationtech.jts.geom.LineString;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import ua.nure.kryvko.hikeway.config.WeatherProperties;
import ua.nure.kryvko.hikeway.exception.InvalidWeatherRequestException;
import ua.nure.kryvko.hikeway.exception.RouteNotFoundException;
import ua.nure.kryvko.hikeway.exception.WeatherProviderException;
import ua.nure.kryvko.hikeway.model.Route;
import ua.nure.kryvko.hikeway.model.RouteGeometry;
import ua.nure.kryvko.hikeway.model.response.WeatherResponse;
import ua.nure.kryvko.hikeway.model.weather.DailyWeather;
import ua.nure.kryvko.hikeway.model.weather.DaylightWindow;
import ua.nure.kryvko.hikeway.model.weather.HikeRecommendationExplanation;
import ua.nure.kryvko.hikeway.model.weather.HikeStartRecommendation;
import ua.nure.kryvko.hikeway.model.weather.HourlyWeather;
import ua.nure.kryvko.hikeway.model.weather.WeatherForecast;
import ua.nure.kryvko.hikeway.model.weather.WeatherRisk;
import ua.nure.kryvko.hikeway.model.weather.WeatherRiskMessage;
import ua.nure.kryvko.hikeway.model.weather.WeatherRiskSeverity;
import ua.nure.kryvko.hikeway.model.weather.WeatherRiskType;
import ua.nure.kryvko.hikeway.repository.RouteGeometryRepository;
import ua.nure.kryvko.hikeway.service.weather.WeatherProviderClient;

import java.time.Clock;
import java.time.Duration;
import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

@Service
public class WeatherService {
    private static final Duration START_AFTER_SUNRISE = Duration.ofMinutes(30);
    private static final Duration SUNSET_RETURN_BUFFER = Duration.ofMinutes(45);
    private static final int MINIMUM_ROUTE_MINUTES = 1;
    private static final double COORDINATE_ROUNDING_FACTOR = 1000.0;
    private static final int ELEVATION_BUCKET_METERS = 100;

    private final RouteGeometryRepository routeGeometryRepository;
    private final WeatherProviderClient weatherProviderClient;
    private final WeatherProperties weatherProperties;
    private final Clock clock;
    private final Map<WeatherCacheKey, CachedForecast> forecastCache = new ConcurrentHashMap<>();

    public WeatherService(
            RouteGeometryRepository routeGeometryRepository,
            WeatherProviderClient weatherProviderClient,
            WeatherProperties weatherProperties,
            Clock clock
    ) {
        this.routeGeometryRepository = routeGeometryRepository;
        this.weatherProviderClient = weatherProviderClient;
        this.weatherProperties = weatherProperties;
        this.clock = clock;
    }

    @Transactional(readOnly = true)
    public WeatherResponse getRouteWeather(long routeId, LocalDate date) {
        RouteGeometry geometry = routeGeometryRepository.findByRouteId(routeId)
                .orElseThrow(() -> new RouteNotFoundException("Route not found with id: " + routeId));
        Route route = geometry.getRoute();
        Coordinate forecastPoint = midpoint(geometry.getLine());
        Double elevation = route.getElevationGain() > 0 ? (double) route.getElevationGain() : null;

        WeatherForecast forecast = getForecast(
                forecastPoint.getY(),
                forecastPoint.getX(),
                elevation,
                date
        );
        validateDate(date, forecast);

        DailyWeather dailyWeather = forecast.daily().stream()
                .filter(daily -> date.equals(daily.date()))
                .findFirst()
                .orElseThrow(() -> new InvalidWeatherRequestException("Forecast is unavailable for date: " + date));
        List<HourlyWeather> dayHours = forecast.hourly().stream()
                .filter(hour -> date.equals(hour.time().toLocalDate()))
                .sorted(Comparator.comparing(HourlyWeather::time))
                .toList();
        List<WeatherRisk> risks = risks(dailyWeather, dayHours, elevation);
        HikeStartRecommendation recommendation = recommendation(route, dailyWeather, dayHours, elevation, forecast.timezone());

        return new WeatherResponse(
                routeId,
                forecastPoint.getY(),
                forecastPoint.getX(),
                elevation,
                date,
                forecast.timezone(),
                dailyWeather,
                dayHours,
                new DaylightWindow(dailyWeather.sunrise(), dailyWeather.sunset(), dailyWeather.daylightDurationSeconds()),
                risks,
                recommendation,
                "open-meteo",
                forecast.lastUpdated()
        );
    }

    private WeatherForecast getForecast(double latitude, double longitude, Double elevation, LocalDate date) {
        WeatherCacheKey key = WeatherCacheKey.from(
                weatherProperties.effectiveProvider(),
                latitude,
                longitude,
                elevation,
                date
        );
        Instant now = clock.instant();
        CachedForecast cached = forecastCache.get(key);
        if (cached != null && cached.expiresAt().isAfter(now)) {
            if (cached.failure() != null) {
                throw cached.failure();
            }
            return cached.forecast();
        }
        if (cached != null) {
            forecastCache.remove(key, cached);
        }

        try {
            WeatherForecast forecast = weatherProviderClient.forecast(latitude, longitude, elevation);
            forecastCache.put(key, CachedForecast.success(forecast, now.plus(successTtl(date))));
            return forecast;
        } catch (WeatherProviderException exception) {
            Duration failureTtl = weatherProperties.effectiveFailureCacheTtl();
            if (!failureTtl.isZero() && !failureTtl.isNegative()) {
                forecastCache.put(key, CachedForecast.failure(exception, now.plus(failureTtl)));
            }
            throw exception;
        }
    }

    private Duration successTtl(LocalDate date) {
        LocalDate today = LocalDate.now(clock);
        return date.equals(today)
                ? weatherProperties.effectiveTodayCacheTtl()
                : weatherProperties.effectiveFutureCacheTtl();
    }

    private Coordinate midpoint(LineString line) {
        if (line == null || line.getNumPoints() == 0) {
            throw new RouteNotFoundException("Route geometry not found");
        }
        return line.getCoordinateN(line.getNumPoints() / 2);
    }

    private void validateDate(LocalDate date, WeatherForecast forecast) {
        if (date == null) {
            throw new InvalidWeatherRequestException("Date is required");
        }
        ZoneId zone = zone(forecast.timezone());
        LocalDate today = LocalDate.now(clock.withZone(zone));
        if (date.isBefore(today)) {
            throw new InvalidWeatherRequestException("Date must not be in the past");
        }
        boolean inForecastRange = forecast.daily().stream().anyMatch(daily -> date.equals(daily.date()));
        if (!inForecastRange) {
            throw new InvalidWeatherRequestException("Forecast is unavailable for date: " + date);
        }
    }

    private List<WeatherRisk> risks(DailyWeather daily, List<HourlyWeather> hours, Double routeElevation) {
        Map<WeatherRiskType, WeatherRisk> risks = new LinkedHashMap<>();
        if (atLeast(daily.precipitationSumMm(), 10.0) || atLeast(daily.precipitationProbabilityMaxPercent(), 70)) {
            risks.put(WeatherRiskType.HEAVY_PRECIPITATION, risk(WeatherRiskType.HEAVY_PRECIPITATION));
        }
        if (atLeast(daily.windGustsMaxKmh(), 50.0)) {
            risks.put(WeatherRiskType.STRONG_WIND, risk(WeatherRiskType.STRONG_WIND));
        }
        if (atLeast(daily.uvIndexMax(), 8.0)) {
            risks.put(WeatherRiskType.HIGH_UV, risk(WeatherRiskType.HIGH_UV));
        }
        if (daily.sunrise() != null && daily.sunset() != null &&
                Duration.between(daily.sunrise(), daily.sunset()).compareTo(Duration.ofHours(8)) < 0) {
            risks.put(WeatherRiskType.SHORT_DAYLIGHT, risk(WeatherRiskType.SHORT_DAYLIGHT));
        }
        for (HourlyWeather hour : hours) {
            if (atLeast(hour.precipitationProbabilityPercent(), 70) || atLeast(hour.precipitationMm(), 2.0)) {
                risks.putIfAbsent(WeatherRiskType.HEAVY_PRECIPITATION, risk(WeatherRiskType.HEAVY_PRECIPITATION));
            }
            if (atLeast(hour.windGustsKmh(), 50.0)) {
                risks.putIfAbsent(WeatherRiskType.STRONG_WIND, risk(WeatherRiskType.STRONG_WIND));
            }
            if (hour.visibilityMeters() != null && hour.visibilityMeters() < 5000.0) {
                risks.putIfAbsent(WeatherRiskType.POOR_VISIBILITY, risk(WeatherRiskType.POOR_VISIBILITY));
            }
            if (hour.apparentTemperatureC() != null && (hour.apparentTemperatureC() <= -10.0 || hour.apparentTemperatureC() >= 35.0)) {
                risks.putIfAbsent(WeatherRiskType.UNSAFE_TEMPERATURE, risk(WeatherRiskType.UNSAFE_TEMPERATURE));
            }
            if (routeElevation != null && hour.freezingLevelMeters() != null && hour.freezingLevelMeters() <= routeElevation + 200.0) {
                risks.putIfAbsent(WeatherRiskType.FREEZING_CONDITIONS, risk(WeatherRiskType.FREEZING_CONDITIONS));
            }
            if (isThunderstorm(hour.weatherCode())) {
                risks.putIfAbsent(WeatherRiskType.THUNDERSTORM, risk(WeatherRiskType.THUNDERSTORM));
            }
        }
        return new ArrayList<>(risks.values());
    }

    private HikeStartRecommendation recommendation(
            Route route,
            DailyWeather daily,
            List<HourlyWeather> hours,
            Double routeElevation,
            String timezone
    ) {
        if (daily.sunrise() == null || daily.sunset() == null) {
            return new HikeStartRecommendation(null, null, HikeRecommendationExplanation.DAYLIGHT_INFORMATION_UNAVAILABLE);
        }
        Duration routeDuration = Duration.ofMinutes(Math.max(route.getEstimatedTimeMinutes(), MINIMUM_ROUTE_MINUTES));
        LocalDateTime earliestStart = daily.sunrise().plus(START_AFTER_SUNRISE);
        LocalDateTime latestReturn = daily.sunset().minus(SUNSET_RETURN_BUFFER);
        LocalDateTime latestStart = latestReturn.minus(routeDuration);
        LocalDateTime now = LocalDateTime.now(clock.withZone(zone(timezone)));
        if (daily.date().equals(now.toLocalDate()) && earliestStart.isBefore(roundUpToNextHour(now))) {
            earliestStart = roundUpToNextHour(now);
        }
        if (latestStart.isBefore(earliestStart)) {
            return new HikeStartRecommendation(null, null, HikeRecommendationExplanation.NO_DAYLIGHT_WINDOW_FITS_ROUTE_DURATION);
        }
        for (LocalDateTime candidate = roundUpToNextHour(earliestStart);
             !candidate.isAfter(latestStart);
             candidate = candidate.plusHours(1)) {
            LocalDateTime expectedReturn = candidate.plus(routeDuration);
            if (isSafeWindow(hours, candidate, expectedReturn, routeElevation)) {
                return new HikeStartRecommendation(
                        candidate,
                        expectedReturn,
                        HikeRecommendationExplanation.RECOMMENDED_WINDOW_AVOIDS_NIGHTTIME_AND_HIGH_RISK_FORECAST_HOURS
                );
            }
        }
        return new HikeStartRecommendation(null, null, HikeRecommendationExplanation.NO_SUITABLE_WEATHER_WINDOW_AVAILABLE);
    }

    private WeatherRisk risk(WeatherRiskType type) {
        return switch (type) {
            case HEAVY_PRECIPITATION -> new WeatherRisk(
                    type,
                    WeatherRiskSeverity.WARNING,
                    WeatherRiskMessage.HIGH_CHANCE_OF_HEAVY_PRECIPITATION
            );
            case STRONG_WIND -> new WeatherRisk(
                    type,
                    WeatherRiskSeverity.WARNING,
                    WeatherRiskMessage.STRONG_WIND_GUSTS_EXPECTED
            );
            case HIGH_UV -> new WeatherRisk(
                    type,
                    WeatherRiskSeverity.CAUTION,
                    WeatherRiskMessage.HIGH_UV_EXPOSURE_EXPECTED
            );
            case SHORT_DAYLIGHT -> new WeatherRisk(
                    type,
                    WeatherRiskSeverity.CAUTION,
                    WeatherRiskMessage.DAYLIGHT_WINDOW_IS_SHORT
            );
            case POOR_VISIBILITY -> new WeatherRisk(
                    type,
                    WeatherRiskSeverity.WARNING,
                    WeatherRiskMessage.VISIBILITY_MAY_BE_POOR
            );
            case UNSAFE_TEMPERATURE -> new WeatherRisk(
                    type,
                    WeatherRiskSeverity.WARNING,
                    WeatherRiskMessage.TEMPERATURE_MAY_BE_UNSAFE_FOR_HIKING
            );
            case FREEZING_CONDITIONS -> new WeatherRisk(
                    type,
                    WeatherRiskSeverity.WARNING,
                    WeatherRiskMessage.FREEZING_CONDITIONS_MAY_AFFECT_ROUTE
            );
            case THUNDERSTORM -> new WeatherRisk(
                    type,
                    WeatherRiskSeverity.WARNING,
                    WeatherRiskMessage.THUNDERSTORM_LIKE_WEATHER_POSSIBLE
            );
        };
    }

    private boolean isSafeWindow(List<HourlyWeather> hours, LocalDateTime start, LocalDateTime expectedReturn, Double routeElevation) {
        List<HourlyWeather> window = hours.stream()
                .filter(hour -> !hour.time().isBefore(start) && hour.time().isBefore(expectedReturn))
                .toList();
        return !window.isEmpty() && window.stream().noneMatch(hour -> isUnsafeHour(hour, routeElevation));
    }

    private boolean isUnsafeHour(HourlyWeather hour, Double routeElevation) {
        return atLeast(hour.precipitationProbabilityPercent(), 70) ||
                atLeast(hour.precipitationMm(), 2.0) ||
                atLeast(hour.windGustsKmh(), 50.0) ||
                (hour.visibilityMeters() != null && hour.visibilityMeters() < 5000.0) ||
                (hour.apparentTemperatureC() != null && (hour.apparentTemperatureC() <= -10.0 || hour.apparentTemperatureC() >= 35.0)) ||
                (routeElevation != null && hour.freezingLevelMeters() != null && hour.freezingLevelMeters() <= routeElevation + 200.0) ||
                isThunderstorm(hour.weatherCode());
    }

    private LocalDateTime roundUpToNextHour(LocalDateTime time) {
        LocalDateTime truncated = time.withMinute(0).withSecond(0).withNano(0);
        return time.equals(truncated) ? time : truncated.plusHours(1);
    }

    private ZoneId zone(String timezone) {
        if (timezone == null || timezone.isBlank()) {
            return ZoneId.systemDefault();
        }
        return ZoneId.of(timezone);
    }

    private boolean isThunderstorm(Integer weatherCode) {
        return weatherCode != null && (weatherCode == 95 || weatherCode == 96 || weatherCode == 99);
    }

    private boolean atLeast(Double value, double threshold) {
        return value != null && value >= threshold;
    }

    private boolean atLeast(Integer value, int threshold) {
        return value != null && value >= threshold;
    }

    private record WeatherCacheKey(
            String provider,
            double latitude,
            double longitude,
            Integer elevationBucketMeters,
            LocalDate forecastDate
    ) {
        private static WeatherCacheKey from(String provider, double latitude, double longitude, Double elevation, LocalDate date) {
            return new WeatherCacheKey(
                    provider,
                    roundCoordinate(latitude),
                    roundCoordinate(longitude),
                    elevationBucket(elevation),
                    date
            );
        }

        private static double roundCoordinate(double value) {
            return Math.round(value * COORDINATE_ROUNDING_FACTOR) / COORDINATE_ROUNDING_FACTOR;
        }

        private static Integer elevationBucket(Double elevation) {
            if (elevation == null) {
                return null;
            }
            return (int) Math.round(elevation / ELEVATION_BUCKET_METERS) * ELEVATION_BUCKET_METERS;
        }
    }

    private record CachedForecast(
            WeatherForecast forecast,
            WeatherProviderException failure,
            Instant expiresAt
    ) {
        private static CachedForecast success(WeatherForecast forecast, Instant expiresAt) {
            return new CachedForecast(forecast, null, expiresAt);
        }

        private static CachedForecast failure(WeatherProviderException failure, Instant expiresAt) {
            return new CachedForecast(null, failure, expiresAt);
        }
    }
}
