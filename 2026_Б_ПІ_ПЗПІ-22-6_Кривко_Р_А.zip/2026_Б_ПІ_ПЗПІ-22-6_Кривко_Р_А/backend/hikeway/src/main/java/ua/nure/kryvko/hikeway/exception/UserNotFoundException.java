package ua.nure.kryvko.hikeway.exception;

public class UserNotFoundException extends HikewayException {
    public UserNotFoundException(String message) {
        super(message);
    }
}
