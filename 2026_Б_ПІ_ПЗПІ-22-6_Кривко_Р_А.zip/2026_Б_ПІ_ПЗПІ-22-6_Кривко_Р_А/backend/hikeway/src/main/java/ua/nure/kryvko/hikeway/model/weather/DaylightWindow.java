package ua.nure.kryvko.hikeway.model.weather;

import java.time.LocalDateTime;

public record DaylightWindow(
        LocalDateTime sunrise,
        LocalDateTime sunset,
        Long daylightDurationSeconds
) {
}
