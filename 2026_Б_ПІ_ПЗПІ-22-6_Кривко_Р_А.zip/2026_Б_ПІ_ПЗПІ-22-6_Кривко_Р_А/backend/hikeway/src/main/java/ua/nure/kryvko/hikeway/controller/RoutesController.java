package ua.nure.kryvko.hikeway.controller;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import ua.nure.kryvko.hikeway.model.Difficulty;
import ua.nure.kryvko.hikeway.model.Terrain;
import ua.nure.kryvko.hikeway.model.request.RouteRequests;
import ua.nure.kryvko.hikeway.model.request.RouteSearchRequest;
import ua.nure.kryvko.hikeway.model.response.PageResponse;
import ua.nure.kryvko.hikeway.model.response.RouteContentResponses;
import ua.nure.kryvko.hikeway.model.response.RouteSearchResponse;
import ua.nure.kryvko.hikeway.service.RouteRecommendationService;
import ua.nure.kryvko.hikeway.service.RouteService;

import java.util.Set;

@RestController
public class RoutesController {
    private final RouteService routeService;
    private final RouteRecommendationService recommendationService;

    public RoutesController(RouteService routeService, RouteRecommendationService recommendationService) {
        this.routeService = routeService;
        this.recommendationService = recommendationService;
    }

    @GetMapping("/routes")
    public PageResponse<RouteSearchResponse> search(
            @RequestParam(required = false) Double minDistanceKm,
            @RequestParam(required = false) Double maxDistanceKm,
            @RequestParam(required = false) Integer minEstimatedTimeMinutes,
            @RequestParam(required = false) Integer maxEstimatedTimeMinutes,
            @RequestParam(required = false) Set<Difficulty> difficulties,
            @RequestParam(required = false) Set<Terrain> terrains,
            @RequestParam(required = false) Double longitude,
            @RequestParam(required = false) Double latitude,
            @RequestParam(required = false) Double maxProximityKm,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "50") int size
    ) {
        return routeService.searchRoutes(new RouteSearchRequest(
                minDistanceKm,
                maxDistanceKm,
                minEstimatedTimeMinutes,
                maxEstimatedTimeMinutes,
                difficulties,
                terrains,
                longitude,
                latitude,
                maxProximityKm,
                page,
                size
        ));
    }

    @GetMapping("/routes/mine")
    public PageResponse<RouteSearchResponse> currentUserRoutes(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "50") int size
    ) {
        return routeService.currentUserRoutes(page, size);
    }

    @GetMapping("/routes/recommended")
    public PageResponse<RouteSearchResponse> recommendedRoutes(
            @RequestParam(required = false) Double longitude,
            @RequestParam(required = false) Double latitude,
            @RequestParam(required = false) Double maxProximityKm,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size
    ) {
        return recommendationService.recommendedRoutes(
                longitude,
                latitude,
                maxProximityKm,
                page,
                size
        );
    }

    @PutMapping("/routes/{id}/rating")
    public RouteContentResponses.Rating rate(@PathVariable long id, @RequestBody RouteRequests.Rating request) {
        return routeService.rate(id, request);
    }

    @DeleteMapping("/routes/{id}/rating")
    public RouteContentResponses.Rating removeRating(@PathVariable long id) {
        return routeService.removeRating(id);
    }

    @GetMapping("/routes/{id}/comments")
    public PageResponse<RouteContentResponses.Comment> comments(
            @PathVariable long id,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "50") int size
    ) {
        return routeService.comments(id, page, size);
    }

    @PostMapping("/routes/{id}/comments")
    public ResponseEntity<RouteContentResponses.Comment> addComment(
            @PathVariable long id,
            @RequestBody RouteRequests.Comment request
    ) {
        return ResponseEntity.status(201).body(routeService.addComment(id, request));
    }

    @PatchMapping("/routes/{id}/comments/{commentId}")
    public RouteContentResponses.Comment updateComment(
            @PathVariable long id,
            @PathVariable long commentId,
            @RequestBody RouteRequests.Comment request
    ) {
        return routeService.updateComment(id, commentId, request);
    }

    @DeleteMapping("/routes/{id}/comments/{commentId}")
    public ResponseEntity<Void> deleteComment(@PathVariable long id, @PathVariable long commentId) {
        routeService.deleteComment(id, commentId);
        return ResponseEntity.noContent().build();
    }
}
