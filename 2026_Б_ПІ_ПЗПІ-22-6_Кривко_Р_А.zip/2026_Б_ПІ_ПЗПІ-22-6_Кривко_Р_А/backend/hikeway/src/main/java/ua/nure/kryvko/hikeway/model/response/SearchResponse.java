package ua.nure.kryvko.hikeway.model.response;

public record SearchResponse(
        PageResponse<RouteSearchResponse> routes,
        PageResponse<PoiResponses.Summary> pois
) {
}
