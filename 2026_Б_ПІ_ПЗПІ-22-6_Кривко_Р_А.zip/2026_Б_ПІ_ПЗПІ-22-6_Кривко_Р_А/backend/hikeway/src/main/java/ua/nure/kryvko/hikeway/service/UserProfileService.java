package ua.nure.kryvko.hikeway.service;

import jakarta.ws.rs.NotFoundException;
import lombok.extern.slf4j.Slf4j;
import org.keycloak.admin.client.CreatedResponseUtil;
import org.keycloak.admin.client.Keycloak;
import org.keycloak.representations.idm.CredentialRepresentation;
import org.keycloak.representations.idm.RoleRepresentation;
import org.keycloak.representations.idm.UserRepresentation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import ua.nure.kryvko.hikeway.exception.InvalidUserDataException;
import ua.nure.kryvko.hikeway.exception.KeycloakException;
import ua.nure.kryvko.hikeway.exception.UserAlreadyExistsException;
import ua.nure.kryvko.hikeway.exception.UserNotFoundException;
import ua.nure.kryvko.hikeway.model.UserEntity;
import ua.nure.kryvko.hikeway.model.UserRole;
import ua.nure.kryvko.hikeway.model.request.AdminCreateUserRequest;
import ua.nure.kryvko.hikeway.model.request.UpdateUserProfileRequest;
import ua.nure.kryvko.hikeway.model.response.PageResponse;
import ua.nure.kryvko.hikeway.model.response.UserProfileResponse;
import ua.nure.kryvko.hikeway.repository.UserRepository;

import java.util.List;
import java.util.Set;

@Slf4j
@Service
public class UserProfileService {
    private static final int MAX_PAGE_SIZE = 100;

    private final Keycloak keycloak;
    private final String realm;
    private final UserRepository userRepository;
    private final CurrentUserService currentUserService;

    @Autowired
    public UserProfileService(
            Keycloak keycloak,
            @Value("${keycloak.target-realm}") String realm,
            UserRepository userRepository,
            CurrentUserService currentUserService
    ) {
        this.keycloak = keycloak;
        this.realm = realm;
        this.userRepository = userRepository;
        this.currentUserService = currentUserService;
    }

    @Transactional(readOnly = true)
    public UserProfileResponse currentProfile() {
        return toResponse(currentUser());
    }

    @Transactional
    public UserProfileResponse updateCurrentProfile(UpdateUserProfileRequest request) {
        UserEntity user = currentUser();
        updateUser(user, request);
        return toResponse(userRepository.save(user));
    }

    @Transactional(readOnly = true)
    public PageResponse<UserProfileResponse> adminList(int page, int size) {
        validatePage(page, size);
        var users = userRepository.findAll(PageRequest.of(page, size));
        return PageResponse.from(users, users.getContent().stream()
                .map(this::toResponse)
                .toList());
    }

    @Transactional(readOnly = true)
    public UserProfileResponse adminGet(Long id) {
        return toResponse(findUser(id));
    }

    @Transactional
    public UserProfileResponse adminCreate(AdminCreateUserRequest request) {
        validateCreateRequest(request);
        if (userRepository.existsByEmail(request.email()) || userRepository.existsByUsername(request.username())) {
            throw new UserAlreadyExistsException("User already exists");
        }

        UserRepresentation keycloakUser = new UserRepresentation();
        keycloakUser.setEmail(request.email());
        keycloakUser.setUsername(request.username());
        keycloakUser.setFirstName(request.firstName());
        keycloakUser.setLastName(request.lastName());
        keycloakUser.setEmailVerified(true);
        keycloakUser.setEnabled(true);

        try (var response = keycloak.realm(realm).users().create(keycloakUser)) {
            switch (response.getStatus()) {
                case 201 -> {
                    String keycloakId = CreatedResponseUtil.getCreatedId(response);
                    setPassword(keycloakId, request.password());
                    assignRoles(keycloakId, request.roles());

                    UserEntity localUser = new UserEntity(
                            request.firstName(),
                            request.lastName(),
                            request.email(),
                            request.username(),
                            keycloakId
                    );
                    try {
                        return toResponse(userRepository.save(localUser));
                    } catch (Exception exception) {
                        try (var deleteResponse = keycloak.realm(realm).users().delete(keycloakId)) {
                            // Keycloak rollback best effort; preserve the DB exception.
                        }
                        throw exception;
                    }
                }
                case 409 -> throw new UserAlreadyExistsException("User already exists " + response.readEntity(String.class));
                case 400 -> throw new InvalidUserDataException("Invalid user data " + response.readEntity(String.class));
                default -> throw new KeycloakException("Keycloak error: " + response.readEntity(String.class));
            }
        }
    }

    @Transactional
    public UserProfileResponse adminUpdate(Long id, UpdateUserProfileRequest request) {
        UserEntity user = findUser(id);
        updateUser(user, request);
        return toResponse(userRepository.save(user));
    }

    @Transactional
    public void adminDelete(Long id) {
        UserEntity user = findUser(id);
        try (var response = keycloak.realm(realm).users().delete(user.getKeycloakId())) {
            if (response.getStatus() == 404) {
                throw new UserNotFoundException("User not found");
            }
            if (response.getStatus() >= 400) {
                throw new KeycloakException("Keycloak error: " + response.readEntity(String.class));
            }
        }
        userRepository.delete(user);
    }

    private UserEntity currentUser() {
        return userRepository.findByKeycloakId(currentUserService.id())
                .orElseThrow(() -> new UserNotFoundException("User not found"));
    }

    private UserEntity findUser(Long id) {
        return userRepository.findById(id)
                .orElseThrow(() -> new UserNotFoundException("User not found"));
    }

    private void updateUser(UserEntity user, UpdateUserProfileRequest request) {
        validateUpdateRequest(request);
        checkUpdateConflicts(user, request);

        try {
            var keycloakUserResource = keycloak.realm(realm).users().get(user.getKeycloakId());
            UserRepresentation keycloakUser = keycloakUserResource.toRepresentation();
            keycloakUser.setEmail(valueOrExisting(request.email(), user.getEmail()));
            keycloakUser.setUsername(valueOrExisting(request.username(), user.getUsername()));
            keycloakUser.setFirstName(valueOrExisting(request.firstName(), user.getFirstName()));
            keycloakUser.setLastName(valueOrExisting(request.lastName(), user.getLastName()));
            keycloakUserResource.update(keycloakUser);
        } catch (NotFoundException exception) {
            throw new UserNotFoundException("User not found");
        } catch (RuntimeException exception) {
            throw new KeycloakException("Keycloak error: " + exception.getMessage());
        }

        if (request.email() != null) {
            user.setEmail(request.email());
        }
        if (request.username() != null) {
            user.setUsername(request.username());
        }
        if (request.firstName() != null) {
            user.setFirstName(request.firstName());
        }
        if (request.lastName() != null) {
            user.setLastName(request.lastName());
        }
    }

    private void setPassword(String keycloakId, String password) {
        CredentialRepresentation credential = new CredentialRepresentation();
        credential.setType(CredentialRepresentation.PASSWORD);
        credential.setValue(password);
        credential.setTemporary(false);
        keycloak.realm(realm).users().get(keycloakId).resetPassword(credential);
    }

    private void assignRoles(String keycloakId, Set<UserRole> roles) {
        if (roles == null || roles.isEmpty()) {
            return;
        }
        List<RoleRepresentation> representations = roles.stream()
                .map(role -> keycloak.realm(realm).roles().get(role.name()).toRepresentation())
                .toList();
        keycloak.realm(realm).users().get(keycloakId).roles().realmLevel().add(representations);
    }

    private void validateCreateRequest(AdminCreateUserRequest request) {
        if (request == null
                || isMissing(request.email())
                || isMissing(request.username())
                || isMissing(request.password())) {
            throw new InvalidUserDataException("Email, username and password are required");
        }
    }

    private void validateUpdateRequest(UpdateUserProfileRequest request) {
        if (request == null) {
            throw new InvalidUserDataException("Request is required");
        }
        if (isBlank(request.email())
                || isBlank(request.username())
                || isBlank(request.firstName())
                || isBlank(request.lastName())) {
            throw new InvalidUserDataException("Profile fields cannot be blank");
        }
    }

    private void validatePage(int page, int size) {
        if (page < 0 || size < 1 || size > MAX_PAGE_SIZE) {
            throw new InvalidUserDataException("Page must be non-negative and size must be between 1 and 100");
        }
    }

    private void checkUpdateConflicts(UserEntity user, UpdateUserProfileRequest request) {
        if (request.email() != null && userRepository.existsByEmailAndIdNot(request.email(), user.getId())) {
            throw new UserAlreadyExistsException("User already exists");
        }
        if (request.username() != null && userRepository.existsByUsernameAndIdNot(request.username(), user.getId())) {
            throw new UserAlreadyExistsException("User already exists");
        }
    }

    private String valueOrExisting(String newValue, String existingValue) {
        return newValue == null ? existingValue : newValue;
    }

    private boolean isBlank(String value) {
        return value != null && value.isBlank();
    }

    private boolean isMissing(String value) {
        return value == null || value.isBlank();
    }

    private UserProfileResponse toResponse(UserEntity user) {
        return new UserProfileResponse(
                user.getId(),
                user.getKeycloakId(),
                user.getEmail(),
                user.getUsername(),
                user.getFirstName(),
                user.getLastName()
        );
    }
}
