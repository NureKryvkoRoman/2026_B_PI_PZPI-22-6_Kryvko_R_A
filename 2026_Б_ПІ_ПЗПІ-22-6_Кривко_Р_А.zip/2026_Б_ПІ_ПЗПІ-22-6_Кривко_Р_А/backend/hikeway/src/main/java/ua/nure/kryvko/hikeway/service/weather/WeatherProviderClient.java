package ua.nure.kryvko.hikeway.service.weather;

import ua.nure.kryvko.hikeway.model.weather.WeatherForecast;

public interface WeatherProviderClient {
    WeatherForecast forecast(double latitude, double longitude, Double elevationMeters);
}
