package ua.nure.kryvko.hikeway.service.elevation;

import java.util.List;

record OpenMeteoElevationDtos() {
    record ElevationResponse(List<Double> elevation) {
    }
}
