package ua.nure.kryvko.hikeway.model.weather;

public enum WeatherRiskSeverity {
    CAUTION,
    WARNING
}
