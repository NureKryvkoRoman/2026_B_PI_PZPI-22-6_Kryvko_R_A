package ua.nure.kryvko.hikeway.model;

import jakarta.persistence.*;
import lombok.Data;

import java.time.Instant;

@Entity
@Table(
        name = "user_achievement",
        uniqueConstraints = @UniqueConstraint(columnNames = {"ownerId", "achievement_id"}),
        indexes = @Index(columnList = "ownerId")
)
@Data
public class UserAchievement {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private String ownerId;

    @ManyToOne(optional = false, fetch = FetchType.LAZY)
    @JoinColumn(name = "achievement_id", nullable = false)
    private Achievement achievement;

    @Column(nullable = false)
    private double progressValue;

    private Instant completedAt;

    @Column(nullable = false)
    private Instant updatedAt;
}
