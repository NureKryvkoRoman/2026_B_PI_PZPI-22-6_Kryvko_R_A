package ua.nure.kryvko.hikeway.service.elevation;

import org.locationtech.jts.geom.Coordinate;
import org.springframework.stereotype.Component;
import org.springframework.web.util.UriComponentsBuilder;
import tools.jackson.databind.ObjectMapper;
import tools.jackson.databind.json.JsonMapper;
import ua.nure.kryvko.hikeway.config.WeatherProperties;
import ua.nure.kryvko.hikeway.exception.WeatherProviderException;

import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;
import java.util.List;
import java.util.stream.Collectors;

@Component
public class OpenMeteoElevationClient implements ElevationProviderClient {
    static final int MAX_COORDINATES_PER_REQUEST = 100;

    private final WeatherProperties properties;
    private final ObjectMapper objectMapper;
    private final HttpClient httpClient;

    public OpenMeteoElevationClient(WeatherProperties properties) {
        this.properties = properties;
        this.objectMapper = JsonMapper.builder().findAndAddModules().build();
        this.httpClient = HttpClient.newBuilder()
                .connectTimeout(properties.effectiveRequestTimeout())
                .build();
    }

    @Override
    public List<Double> elevations(List<Coordinate> coordinates) {
        if (coordinates == null || coordinates.isEmpty()) {
            return List.of();
        }
        if (coordinates.size() > MAX_COORDINATES_PER_REQUEST) {
            throw new IllegalArgumentException("Open-Meteo elevation requests can contain at most 100 coordinates");
        }
        URI uri = elevationUri(coordinates);
        int attempts = properties.effectiveRetryAttempts() + 1;
        WeatherProviderException lastException = null;
        for (int attempt = 1; attempt <= attempts; attempt++) {
            try {
                return fetch(uri);
            } catch (WeatherProviderException exception) {
                lastException = exception;
                if (attempt < attempts) {
                    backoff();
                }
            }
        }
        throw lastException == null
                ? new WeatherProviderException("Elevation provider request failed")
                : lastException;
    }

    URI elevationUri(List<Coordinate> coordinates) {
        return UriComponentsBuilder
                .fromUri(properties.openMeteoBaseUrl())
                .path("/elevation")
                .queryParam("latitude", coordinates.stream()
                        .map(coordinate -> Double.toString(coordinate.getY()))
                        .collect(Collectors.joining(",")))
                .queryParam("longitude", coordinates.stream()
                        .map(coordinate -> Double.toString(coordinate.getX()))
                        .collect(Collectors.joining(",")))
                .build()
                .toUri();
    }

    private List<Double> fetch(URI uri) {
        HttpRequest request = HttpRequest.newBuilder(uri)
                .timeout(properties.effectiveRequestTimeout())
                .GET()
                .build();
        try {
            HttpResponse<String> response = httpClient.send(request, HttpResponse.BodyHandlers.ofString());
            if (response.statusCode() < 200 || response.statusCode() >= 300) {
                throw new WeatherProviderException("Elevation provider returned HTTP " + response.statusCode());
            }
            OpenMeteoElevationDtos.ElevationResponse body =
                    objectMapper.readValue(response.body(), OpenMeteoElevationDtos.ElevationResponse.class);
            return body.elevation() == null ? List.of() : body.elevation();
        } catch (IOException exception) {
            throw new WeatherProviderException("Elevation provider response could not be read", exception);
        } catch (InterruptedException exception) {
            Thread.currentThread().interrupt();
            throw new WeatherProviderException("Elevation provider request was interrupted", exception);
        }
    }

    private void backoff() {
        Duration backoff = properties.effectiveRetryBackoff();
        if (backoff.isZero() || backoff.isNegative()) {
            return;
        }
        try {
            Thread.sleep(backoff.toMillis());
        } catch (InterruptedException exception) {
            Thread.currentThread().interrupt();
            throw new WeatherProviderException("Elevation provider retry was interrupted", exception);
        }
    }
}
