package ua.nure.kryvko.hikeway.service.elevation;

import lombok.extern.slf4j.Slf4j;
import org.locationtech.jts.geom.Coordinate;
import org.locationtech.jts.geom.LineString;
import org.springframework.stereotype.Service;
import ua.nure.kryvko.hikeway.model.geojson.GeoJsonLineString;

import java.util.ArrayList;
import java.util.List;

@Slf4j
@Service
public class ElevationService {
    private static final double SAMPLE_SPACING_METERS = 100.0;
    private static final double GAIN_NOISE_THRESHOLD_METERS = 5.0;
    private static final double EARTH_RADIUS_METERS = 6_371_000.0;

    private final ElevationProviderClient providerClient;

    public ElevationService(ElevationProviderClient providerClient) {
        this.providerClient = providerClient;
    }

    public int estimateGain(GeoJsonLineString geometry, int fallbackGainMeters) {
        if (geometry == null || geometry.coordinates() == null || geometry.coordinates().size() < 2) {
            return fallbackGainMeters;
        }
        try {
            return estimateGain(coordinatesFromGeoJson(geometry));
        } catch (RuntimeException exception) {
            log.warn("Could not estimate route elevation gain from provider: {}", exception.toString());
            return fallbackGainMeters;
        }
    }

    public int estimateGain(LineString line, int fallbackGainMeters) {
        if (line == null || line.getNumPoints() < 2) {
            return fallbackGainMeters;
        }
        try {
            return estimateGain(List.of(line.getCoordinates()));
        } catch (RuntimeException exception) {
            log.warn("Could not estimate route elevation gain from provider: {}", exception.toString());
            return fallbackGainMeters;
        }
    }

    int estimateGain(List<Coordinate> routeCoordinates) {
        List<Coordinate> samples = sample(routeCoordinates);
        if (samples.size() < 2) {
            return 0;
        }
        List<Double> elevations = new ArrayList<>();
        for (int start = 0; start < samples.size(); start += OpenMeteoElevationClient.MAX_COORDINATES_PER_REQUEST) {
            int end = Math.min(start + OpenMeteoElevationClient.MAX_COORDINATES_PER_REQUEST, samples.size());
            elevations.addAll(providerClient.elevations(samples.subList(start, end)));
        }
        return calculateGain(elevations);
    }

    int calculateGain(List<Double> elevations) {
        double gain = 0.0;
        Double previous = null;
        for (Double elevation : elevations) {
            if (elevation == null || !Double.isFinite(elevation)) {
                continue;
            }
            if (previous != null) {
                double delta = elevation - previous;
                if (delta >= GAIN_NOISE_THRESHOLD_METERS) {
                    gain += delta;
                }
            }
            previous = elevation;
        }
        return (int) Math.round(gain);
    }

    List<Coordinate> sample(List<Coordinate> routeCoordinates) {
        List<Coordinate> valid = routeCoordinates.stream()
                .filter(coordinate -> coordinate != null &&
                        Double.isFinite(coordinate.getX()) &&
                        Double.isFinite(coordinate.getY()))
                .toList();
        if (valid.size() < 2) {
            return valid;
        }
        List<Coordinate> samples = new ArrayList<>();
        samples.add(copy(valid.getFirst()));
        for (int index = 1; index < valid.size(); index++) {
            Coordinate from = valid.get(index - 1);
            Coordinate to = valid.get(index);
            double distanceMeters = distanceMeters(from, to);
            int intermediateSamples = (int) Math.floor(distanceMeters / SAMPLE_SPACING_METERS);
            for (int sample = 1; sample <= intermediateSamples; sample++) {
                double fraction = (sample * SAMPLE_SPACING_METERS) / distanceMeters;
                if (fraction < 1.0) {
                    samples.add(interpolate(from, to, fraction));
                }
            }
            if (!same2d(samples.getLast(), to)) {
                samples.add(copy(to));
            }
        }
        return samples;
    }

    private List<Coordinate> coordinatesFromGeoJson(GeoJsonLineString geometry) {
        return geometry.coordinates().stream()
                .filter(coordinate -> coordinate != null && coordinate.size() >= 2)
                .map(coordinate -> new Coordinate(coordinate.get(0), coordinate.get(1)))
                .toList();
    }

    private Coordinate interpolate(Coordinate from, Coordinate to, double fraction) {
        return new Coordinate(
                from.getX() + (to.getX() - from.getX()) * fraction,
                from.getY() + (to.getY() - from.getY()) * fraction
        );
    }

    private Coordinate copy(Coordinate coordinate) {
        return new Coordinate(coordinate.getX(), coordinate.getY());
    }

    private boolean same2d(Coordinate first, Coordinate second) {
        return Double.compare(first.getX(), second.getX()) == 0 &&
                Double.compare(first.getY(), second.getY()) == 0;
    }

    private double distanceMeters(Coordinate from, Coordinate to) {
        double latitudeDelta = Math.toRadians(to.getY() - from.getY());
        double longitudeDelta = Math.toRadians(to.getX() - from.getX());
        double fromLatitude = Math.toRadians(from.getY());
        double toLatitude = Math.toRadians(to.getY());
        double haversine = Math.pow(Math.sin(latitudeDelta / 2), 2) +
                Math.cos(fromLatitude) * Math.cos(toLatitude) * Math.pow(Math.sin(longitudeDelta / 2), 2);
        return EARTH_RADIUS_METERS * 2 * Math.asin(Math.sqrt(haversine));
    }
}
