package ua.nure.kryvko.hikeway.model.weather;

import java.time.LocalDate;
import java.time.LocalDateTime;

public record DailyWeather(
        LocalDate date,
        Integer weatherCode,
        WeatherCondition condition,
        Double temperatureMaxC,
        Double temperatureMinC,
        LocalDateTime sunrise,
        LocalDateTime sunset,
        Long daylightDurationSeconds,
        Double uvIndexMax,
        Double precipitationSumMm,
        Integer precipitationProbabilityMaxPercent,
        Double windSpeedMaxKmh,
        Double windGustsMaxKmh
) {
}
