package ua.nure.kryvko.hikeway.service;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import ua.nure.kryvko.hikeway.model.*;
import ua.nure.kryvko.hikeway.model.response.AchievementResponse;
import ua.nure.kryvko.hikeway.repository.AchievementRepository;
import ua.nure.kryvko.hikeway.repository.CompletedHikeRepository;
import ua.nure.kryvko.hikeway.repository.RouteRepository;
import ua.nure.kryvko.hikeway.repository.UserAchievementRepository;

import java.time.Instant;
import java.util.ArrayList;
import java.util.List;

@Service
public class AchievementService {
    private final AchievementRepository achievementRepository;
    private final UserAchievementRepository userAchievementRepository;
    private final CompletedHikeRepository completedHikeRepository;
    private final RouteRepository routeRepository;

    public AchievementService(
            AchievementRepository achievementRepository,
            UserAchievementRepository userAchievementRepository,
            CompletedHikeRepository completedHikeRepository,
            RouteRepository routeRepository
    ) {
        this.achievementRepository = achievementRepository;
        this.userAchievementRepository = userAchievementRepository;
        this.completedHikeRepository = completedHikeRepository;
        this.routeRepository = routeRepository;
    }

    @Transactional
    public List<AchievementResponse> evaluateAfterHike(String ownerId) {
        return evaluate(ownerId, AchievementTriggerEvent.HIKE_COMPLETED);
    }

    @Transactional
    public List<AchievementResponse> evaluateAfterRoute(String ownerId) {
        return evaluate(ownerId, AchievementTriggerEvent.ROUTE_CREATED);
    }

    private List<AchievementResponse> evaluate(String ownerId, AchievementTriggerEvent triggerEvent) {
        Instant now = Instant.now();
        List<AchievementResponse> completed = new ArrayList<>();
        for (Achievement achievement : achievementRepository.findByTriggerEvent(triggerEvent)) {
            double progress = progressValue(ownerId, achievement.getMetric());
            UserAchievement userAchievement = userAchievementRepository
                    .findByOwnerIdAndAchievementId(ownerId, achievement.getId())
                    .orElseGet(() -> newUserAchievement(ownerId, achievement));
            boolean wasCompleted = userAchievement.getCompletedAt() != null;
            userAchievement.setProgressValue(progress);
            userAchievement.setUpdatedAt(now);
            if (!wasCompleted && progress >= achievement.getTargetValue()) {
                userAchievement.setCompletedAt(now);
                userAchievement = userAchievementRepository.save(userAchievement);
                completed.add(toResponse(userAchievement));
            } else {
                userAchievementRepository.save(userAchievement);
            }
        }
        return completed;
    }

    private UserAchievement newUserAchievement(String ownerId, Achievement achievement) {
        UserAchievement userAchievement = new UserAchievement();
        userAchievement.setOwnerId(ownerId);
        userAchievement.setAchievement(achievement);
        return userAchievement;
    }

    private double progressValue(String ownerId, AchievementMetric metric) {
        return switch (metric) {
            case FINISHED_HIKES -> completedHikeRepository.countByOwnerIdAndDeletedFalse(ownerId);
            case TOTAL_DISTANCE_KM -> completedHikeRepository.sumTotalDistanceKmByOwnerId(ownerId);
            case SINGLE_HIKE_DISTANCE_KM -> completedHikeRepository.maxTotalDistanceKmByOwnerId(ownerId);
            case ROUTES_CREATED -> routeRepository.countByCreatedByAndDeletedFalse(ownerId);
        };
    }

    private AchievementResponse toResponse(UserAchievement userAchievement) {
        Achievement achievement = userAchievement.getAchievement();
        return new AchievementResponse(
                achievement.getId(),
                achievement.getCode(),
                achievement.getName(),
                achievement.getDescription(),
                userAchievement.getProgressValue(),
                achievement.getTargetValue(),
                userAchievement.getCompletedAt()
        );
    }
}
