package ua.nure.kryvko.hikeway.config;

import org.springframework.boot.context.properties.ConfigurationProperties;

import java.net.URI;
import java.time.Duration;

@ConfigurationProperties(prefix = "hikeway.weather")
public record WeatherProperties(
        String provider,
        OpenMeteo openMeteo,
        Duration requestTimeout,
        int retryAttempts,
        Duration retryBackoff,
        Cache cache
) {
    public String effectiveProvider() {
        return provider == null || provider.isBlank() ? "open-meteo" : provider;
    }

    public URI openMeteoBaseUrl() {
        if (openMeteo == null || openMeteo.baseUrl() == null) {
            return URI.create("https://api.open-meteo.com/v1");
        }
        return openMeteo.baseUrl();
    }

    public Duration effectiveRequestTimeout() {
        return requestTimeout == null ? Duration.ofSeconds(5) : requestTimeout;
    }

    public int effectiveRetryAttempts() {
        return Math.max(retryAttempts, 0);
    }

    public Duration effectiveRetryBackoff() {
        return retryBackoff == null ? Duration.ofMillis(250) : retryBackoff;
    }

    public Duration effectiveTodayCacheTtl() {
        return cache == null || cache.todayTtl() == null ? Duration.ofMinutes(45) : cache.todayTtl();
    }

    public Duration effectiveFutureCacheTtl() {
        return cache == null || cache.futureTtl() == null ? Duration.ofHours(4) : cache.futureTtl();
    }

    public Duration effectiveFailureCacheTtl() {
        return cache == null || cache.failureTtl() == null ? Duration.ofMinutes(5) : cache.failureTtl();
    }

    public record OpenMeteo(URI baseUrl) {
    }

    public record Cache(
            Duration todayTtl,
            Duration futureTtl,
            Duration failureTtl
    ) {
    }
}
