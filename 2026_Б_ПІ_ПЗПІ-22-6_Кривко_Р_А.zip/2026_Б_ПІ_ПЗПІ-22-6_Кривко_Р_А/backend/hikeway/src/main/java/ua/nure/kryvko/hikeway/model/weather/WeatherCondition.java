package ua.nure.kryvko.hikeway.model.weather;

public enum WeatherCondition {
    CLEAR,
    PARTLY_CLOUDY,
    FOG,
    DRIZZLE,
    RAIN,
    SNOW,
    THUNDERSTORM,
    FORECAST;

    public static WeatherCondition fromWeatherCode(Integer weatherCode) {
        if (weatherCode == null) {
            return FORECAST;
        }
        return switch (weatherCode) {
            case 0 -> CLEAR;
            case 1, 2, 3 -> PARTLY_CLOUDY;
            case 45, 48 -> FOG;
            case 51, 53, 55, 56, 57 -> DRIZZLE;
            case 61, 63, 65, 66, 67, 80, 81, 82 -> RAIN;
            case 71, 73, 75, 77, 85, 86 -> SNOW;
            case 95, 96, 99 -> THUNDERSTORM;
            default -> FORECAST;
        };
    }
}
