package ua.nure.kryvko.hikeway.model.request;

public record UpdateUserProfileRequest(
        String email,
        String username,
        String firstName,
        String lastName
) {
}
