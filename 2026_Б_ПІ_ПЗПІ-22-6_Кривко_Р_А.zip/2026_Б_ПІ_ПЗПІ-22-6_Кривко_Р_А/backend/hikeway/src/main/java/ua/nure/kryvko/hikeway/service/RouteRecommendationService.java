package ua.nure.kryvko.hikeway.service;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import ua.nure.kryvko.hikeway.exception.InvalidPoiDataException;
import ua.nure.kryvko.hikeway.model.*;
import ua.nure.kryvko.hikeway.model.response.PageResponse;
import ua.nure.kryvko.hikeway.model.response.RouteSearchResponse;
import ua.nure.kryvko.hikeway.repository.CompletedHikeRepository;
import ua.nure.kryvko.hikeway.repository.RouteRatingRepository;
import ua.nure.kryvko.hikeway.repository.RouteRepository;
import ua.nure.kryvko.hikeway.service.util.AuthUtils;

import java.time.Instant;
import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;

@Service
public class RouteRecommendationService {
    private static final int MAX_PAGE_SIZE = 100;
    private static final int CANDIDATE_LIMIT = 500;
    private static final double DEFAULT_PROXIMITY_KM = 30.0;

    private final RouteRepository routeRepository;
    private final CompletedHikeRepository completedHikeRepository;
    private final GeoJsonGeometryMapper geometryMapper;
    private final RouteRatingRepository routeRatingRepository;
    private final CurrentUserService currentUser;

    public RouteRecommendationService(
            RouteRepository routeRepository,
            CompletedHikeRepository completedHikeRepository,
            GeoJsonGeometryMapper geometryMapper,
            RouteRatingRepository routeRatingRepository,
            CurrentUserService currentUser
    ) {
        this.routeRepository = routeRepository;
        this.completedHikeRepository = completedHikeRepository;
        this.geometryMapper = geometryMapper;
        this.routeRatingRepository = routeRatingRepository;
        this.currentUser = currentUser;
    }

    @Transactional(readOnly = true)
    public PageResponse<RouteSearchResponse> recommendedRoutes(
            Double longitude,
            Double latitude,
            Double maxProximityKm,
            int page,
            int size
    ) {
        RecommendationRequest request = normalizeAndValidate(longitude, latitude, maxProximityKm, page, size);
        String userId = AuthUtils.currentUserId();
        List<CompletedHike> hikes = completedHikeRepository.findByOwnerIdAndDeletedFalse(userId);
        CompletedRoutes completedRoutes = completedRoutes(hikes);
        UserPreferenceProfile profile = buildProfile(hikes);

        List<RouteGeometry> candidates = routeRepository.findRecommendationCandidates(
                        request.longitude(),
                        request.latitude(),
                        request.maxProximityKm(),
                        CANDIDATE_LIMIT
                ).stream()
                .filter(geometry -> !completedRoutes.contains(geometry.getRoute()))
                .toList();

        Map<Long, Long> popularity = popularityByRoute(candidates);
        List<RouteGeometry> sorted = profile.hasHistory()
                ? rankPersonalized(candidates, profile, popularity)
                : rankColdStart(candidates, request, popularity);
        return pageResponse(sorted, page, size);
    }

    private RecommendationRequest normalizeAndValidate(
            Double longitude,
            Double latitude,
            Double maxProximityKm,
            int page,
            int size
    ) {
        if (page < 0 || size < 1 || size > MAX_PAGE_SIZE) {
            throw invalidRequest("Page must be non-negative and size must be 1 to 100");
        }
        boolean hasLongitude = longitude != null;
        boolean hasLatitude = latitude != null;
        if (hasLongitude != hasLatitude || (maxProximityKm != null && (!hasLongitude || !hasLatitude))) {
            throw invalidRequest("Longitude and latitude must be provided together");
        }
        if (hasLongitude) {
            requireLongitude(longitude);
            requireLatitude(latitude);
        }
        if (maxProximityKm != null) {
            requirePositive(maxProximityKm, "Maximum proximity must be greater than 0");
        }
        Double normalizedProximity = hasLongitude && maxProximityKm == null
                ? Double.valueOf(DEFAULT_PROXIMITY_KM)
                : maxProximityKm;
        return new RecommendationRequest(longitude, latitude, normalizedProximity);
    }

    private UserPreferenceProfile buildProfile(List<CompletedHike> hikes) {
        if (hikes.isEmpty()) {
            return UserPreferenceProfile.empty();
        }
        double distanceKm = hikes.stream()
                .mapToDouble(CompletedHike::getTotalDistanceKm)
                .average()
                .orElse(0.0);
        double durationMinutes = hikes.stream()
                .mapToDouble(hike -> hike.getActiveDurationMillis() / 60_000.0)
                .average()
                .orElse(0.0);
        double elevationGain = hikes.stream()
                .mapToInt(CompletedHike::getElevationGainMeters)
                .average()
                .orElse(0.0);
        Map<Long, Route> linkedRoutes = linkedRoutes(hikes);
        Difficulty preferredDifficulty = mostCommon(
                linkedRoutes.values(),
                Route::getDifficulty,
                Comparator.comparing(Difficulty::name)
        );
        Terrain preferredTerrain = mostCommon(
                linkedRoutes.values(),
                Route::getTerrain,
                Comparator.comparing(Terrain::name)
        );
        return new UserPreferenceProfile(
                true,
                distanceKm,
                durationMinutes,
                elevationGain,
                preferredDifficulty,
                preferredTerrain
        );
    }

    private Map<Long, Route> linkedRoutes(List<CompletedHike> hikes) {
        Set<Long> routeIds = completedRouteIds(hikes);
        if (routeIds.isEmpty()) {
            return Map.of();
        }
        return routeRepository.findAllById(routeIds).stream()
                .filter(route -> !route.isDeleted())
                .collect(Collectors.toMap(Route::getId, Function.identity()));
    }

    private <T> T mostCommon(Collection<Route> routes, Function<Route, T> mapper, Comparator<T> tieBreaker) {
        return routes.stream()
                .map(mapper)
                .filter(Objects::nonNull)
                .collect(Collectors.groupingBy(Function.identity(), Collectors.counting()))
                .entrySet()
                .stream()
                .max(Map.Entry.<T, Long>comparingByValue().thenComparing(Map.Entry::getKey, tieBreaker.reversed()))
                .map(Map.Entry::getKey)
                .orElse(null);
    }

    private Set<Long> completedRouteIds(List<CompletedHike> hikes) {
        return hikes.stream()
                .map(CompletedHike::getRouteServerId)
                .filter(Objects::nonNull)
                .collect(Collectors.toCollection(HashSet::new));
    }

    private CompletedRoutes completedRoutes(List<CompletedHike> hikes) {
        Set<Long> serverIds = new HashSet<>();
        Set<UUID> clientIds = new HashSet<>();
        hikes.forEach(hike -> {
            if (hike.getRouteServerId() != null) {
                serverIds.add(hike.getRouteServerId());
            }
            if (hike.getRouteClientId() != null) {
                clientIds.add(hike.getRouteClientId());
            }
        });
        return new CompletedRoutes(serverIds, clientIds);
    }

    private Map<Long, Long> popularityByRoute(List<RouteGeometry> candidates) {
        Set<Long> routeIds = candidates.stream()
                .map(geometry -> geometry.getRoute().getId())
                .collect(Collectors.toSet());
        if (routeIds.isEmpty()) {
            return Map.of();
        }
        Map<Long, Long> popularity = new HashMap<>();
        completedHikeRepository.countCompletedHikesByRouteServerIds(routeIds)
                .forEach(row -> popularity.put((Long) row[0], ((Number) row[1]).longValue()));
        return popularity;
    }

    private List<RouteGeometry> rankPersonalized(
            List<RouteGeometry> candidates,
            UserPreferenceProfile profile,
            Map<Long, Long> popularity
    ) {
        long maxPopularity = popularity.values().stream().mapToLong(Long::longValue).max().orElse(0);
        return candidates.stream()
                .map(geometry -> new ScoredRoute(geometry, score(geometry.getRoute(), profile, popularity, maxPopularity)))
                .sorted(Comparator.comparingDouble(ScoredRoute::score)
                        .reversed()
                        .thenComparing(scored -> publishedAt(scored.geometry()), Comparator.nullsLast(Comparator.reverseOrder()))
                        .thenComparing(scored -> scored.geometry().getRoute().getId(), Comparator.reverseOrder()))
                .map(ScoredRoute::geometry)
                .toList();
    }

    private List<RouteGeometry> rankColdStart(
            List<RouteGeometry> candidates,
            RecommendationRequest request,
            Map<Long, Long> popularity
    ) {
        List<RouteGeometry> sorted = new ArrayList<>(candidates);
        sorted.sort(Comparator
                .comparingDouble((RouteGeometry geometry) -> distanceFromRequest(geometry, request))
                .thenComparing((RouteGeometry geometry) -> popularity.getOrDefault(geometry.getRoute().getId(), 0L), Comparator.reverseOrder())
                .thenComparing(this::publishedAt, Comparator.nullsLast(Comparator.reverseOrder()))
                .thenComparing(geometry -> geometry.getRoute().getId(), Comparator.reverseOrder()));
        return sorted;
    }

    private double score(
            Route route,
            UserPreferenceProfile profile,
            Map<Long, Long> popularity,
            long maxPopularity
    ) {
        return similarity(route.getDistanceKm(), profile.distanceKm()) * 25
                + similarity(route.getEstimatedTimeMinutes(), profile.durationMinutes()) * 20
                + similarity(route.getElevationGain(), profile.elevationGainMeters()) * 15
                + difficultyScore(route.getDifficulty(), profile.difficulty()) * 15
                + terrainScore(route.getTerrain(), profile.terrain()) * 15
                + popularityScore(route.getId(), popularity, maxPopularity) * 10;
    }

    private double similarity(double routeValue, double preferredValue) {
        if (preferredValue <= 0) {
            return 0.5;
        }
        double differenceRatio = Math.abs(routeValue - preferredValue) / preferredValue;
        return Math.max(0.0, 1.0 - differenceRatio);
    }

    private double difficultyScore(Difficulty routeDifficulty, Difficulty preferredDifficulty) {
        if (routeDifficulty == null || preferredDifficulty == null) {
            return 0.5;
        }
        int difference = Math.abs(routeDifficulty.ordinal() - preferredDifficulty.ordinal());
        return switch (difference) {
            case 0 -> 1.0;
            case 1 -> 0.6;
            default -> 0.0;
        };
    }

    private double terrainScore(Terrain routeTerrain, Terrain preferredTerrain) {
        if (routeTerrain == null || preferredTerrain == null) {
            return 0.5;
        }
        return routeTerrain == preferredTerrain ? 1.0 : 0.0;
    }

    private double popularityScore(Long routeId, Map<Long, Long> popularity, long maxPopularity) {
        if (maxPopularity <= 0) {
            return 0.0;
        }
        return popularity.getOrDefault(routeId, 0L) / (double) maxPopularity;
    }

    private double distanceFromRequest(RouteGeometry geometry, RecommendationRequest request) {
        if (request.longitude() == null || geometry.getLine() == null || geometry.getLine().isEmpty()) {
            return 0.0;
        }
        var start = geometry.getLine().getCoordinateN(0);
        double latitudeDeltaKm = (start.getY() - request.latitude()) * 111.32;
        double longitudeDeltaKm = (start.getX() - request.longitude())
                * 111.32
                * Math.cos(Math.toRadians(request.latitude()));
        return Math.hypot(latitudeDeltaKm, longitudeDeltaKm);
    }

    private PageResponse<RouteSearchResponse> pageResponse(List<RouteGeometry> sorted, int page, int size) {
        int from = Math.min(page * size, sorted.size());
        int to = Math.min(from + size, sorted.size());
        List<RouteSearchResponse> items = sorted.subList(from, to)
                .stream()
                .map(this::toSearchResponse)
                .toList();
        int totalPages = sorted.isEmpty() ? 0 : (int) Math.ceil(sorted.size() / (double) size);
        return new PageResponse<>(items, page, size, sorted.size(), totalPages);
    }

    private RouteSearchResponse toSearchResponse(RouteGeometry geometry) {
        Route route = geometry.getRoute();
        RatingAggregate aggregate = aggregate(route.getId());
        return new RouteSearchResponse(
                route.getId(),
                route.getName(),
                route.getDescription(),
                route.getDistanceKm(),
                route.getEstimatedTimeMinutes(),
                route.getDifficulty(),
                route.getElevationGain(),
                route.getTerrain(),
                route.getCreatedAt(),
                route.getCreatedBy(),
                geometryMapper.toGeoJson(geometry.getLine()),
                route.getClientId(),
                route.getVisibility(),
                aggregate.average(),
                aggregate.count(),
                aggregate.userScore()
        );
    }

    private RatingAggregate aggregate(long routeId) {
        Object[] result = normalizeAggregateResult(routeRatingRepository.aggregateForRoute(routeId));
        double average = ((Number) result[0]).doubleValue();
        long count = ((Number) result[1]).longValue();
        Integer userScore = routeRatingRepository.findByRouteIdAndUserId(routeId, currentUser.id())
                .map(RouteRating::getScore)
                .orElse(null);
        return new RatingAggregate(average, count, userScore);
    }

    private Object[] normalizeAggregateResult(Object[] result) {
        if (result.length == 1 && result[0] instanceof Object[] nested) {
            return nested;
        }
        return result;
    }

    private Instant publishedAt(RouteGeometry geometry) {
        return geometry.getRoute().getPublishedAt();
    }

    private void requirePositive(Double value, String message) {
        if (!Double.isFinite(value) || value <= 0) {
            throw invalidRequest(message);
        }
    }

    private void requireLongitude(Double value) {
        if (!Double.isFinite(value) || value < -180 || value > 180) {
            throw invalidRequest("Longitude must be between -180 and 180");
        }
    }

    private void requireLatitude(Double value) {
        if (!Double.isFinite(value) || value < -90 || value > 90) {
            throw invalidRequest("Latitude must be between -90 and 90");
        }
    }

    private InvalidPoiDataException invalidRequest(String message) {
        return new InvalidPoiDataException("INVALID_REQUEST", message);
    }

    private record RecommendationRequest(Double longitude, Double latitude, Double maxProximityKm) {
    }

    private record CompletedRoutes(Set<Long> serverIds, Set<UUID> clientIds) {
        boolean contains(Route route) {
            return serverIds.contains(route.getId()) || clientIds.contains(route.getClientId());
        }
    }

    private record UserPreferenceProfile(
            boolean hasHistory,
            double distanceKm,
            double durationMinutes,
            double elevationGainMeters,
            Difficulty difficulty,
            Terrain terrain
    ) {
        static UserPreferenceProfile empty() {
            return new UserPreferenceProfile(false, 0.0, 0.0, 0.0, null, null);
        }
    }

    private record ScoredRoute(RouteGeometry geometry, double score) {
    }

    private record RatingAggregate(double average, long count, Integer userScore) {
    }
}
