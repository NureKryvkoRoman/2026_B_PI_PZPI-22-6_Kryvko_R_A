package ua.nure.kryvko.hikeway.model.weather;

import java.time.Instant;
import java.util.List;

public record WeatherForecast(
        double latitude,
        double longitude,
        Double elevationMeters,
        String timezone,
        List<HourlyWeather> hourly,
        List<DailyWeather> daily,
        Instant lastUpdated
) {
}
