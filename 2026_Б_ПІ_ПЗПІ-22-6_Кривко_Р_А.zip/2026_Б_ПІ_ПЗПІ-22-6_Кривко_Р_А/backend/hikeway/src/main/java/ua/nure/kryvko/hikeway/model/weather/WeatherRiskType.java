package ua.nure.kryvko.hikeway.model.weather;

public enum WeatherRiskType {
    HEAVY_PRECIPITATION,
    STRONG_WIND,
    HIGH_UV,
    SHORT_DAYLIGHT,
    POOR_VISIBILITY,
    UNSAFE_TEMPERATURE,
    FREEZING_CONDITIONS,
    THUNDERSTORM
}
