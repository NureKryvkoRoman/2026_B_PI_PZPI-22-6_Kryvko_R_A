package ua.nure.kryvko.hikeway.model;

import jakarta.persistence.*;
import lombok.Data;

import java.time.Instant;

@Entity
@Table(
        uniqueConstraints = @UniqueConstraint(name = "uk_route_rating_user", columnNames = {"route_id", "userId"}),
        indexes = @Index(name = "idx_route_rating_route", columnList = "route_id")
)
@Data
public class RouteRating {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(optional = false, fetch = FetchType.LAZY)
    @JoinColumn(name = "route_id", nullable = false)
    private Route route;

    @Column(nullable = false)
    private String userId;

    @Column(nullable = false)
    private int score;

    @Column(nullable = false)
    private Instant updatedAt;
}
