package ua.nure.kryvko.hikeway.model;

public enum AchievementTriggerEvent {
    HIKE_COMPLETED,
    ROUTE_CREATED
}
