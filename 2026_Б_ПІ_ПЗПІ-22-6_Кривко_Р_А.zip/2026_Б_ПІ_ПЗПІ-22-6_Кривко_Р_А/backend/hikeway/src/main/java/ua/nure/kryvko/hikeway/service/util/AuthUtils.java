package ua.nure.kryvko.hikeway.service.util;

import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.oauth2.jwt.Jwt;

public class AuthUtils {
    private AuthUtils() {}

    public static String currentUserId() {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        assert authentication != null;
        assert authentication.getPrincipal() != null;
        return ((Jwt) authentication.getPrincipal()).getSubject();
    }
}
