package ua.nure.kryvko.hikeway.model.request;

import ua.nure.kryvko.hikeway.model.UserRole;

import java.util.Set;

public record AdminCreateUserRequest(
        String email,
        String username,
        String firstName,
        String lastName,
        String password,
        Set<UserRole> roles
) {
}
