package ua.nure.kryvko.hikeway.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import ua.nure.kryvko.hikeway.model.CompletedHike;

import java.util.Collection;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

public interface CompletedHikeRepository extends JpaRepository<CompletedHike, Long> {
    Optional<CompletedHike> findByOwnerIdAndClientId(String ownerId, UUID clientId);

    List<CompletedHike> findByOwnerIdAndDeletedFalse(String ownerId);

    long countByOwnerIdAndDeletedFalse(String ownerId);

    @Query("select coalesce(sum(h.totalDistanceKm), 0) from CompletedHike h where h.ownerId = :ownerId and h.deleted = false")
    double sumTotalDistanceKmByOwnerId(String ownerId);

    @Query("select coalesce(max(h.totalDistanceKm), 0) from CompletedHike h where h.ownerId = :ownerId and h.deleted = false")
    double maxTotalDistanceKmByOwnerId(String ownerId);

    @Query("""
            select h.routeServerId, count(h)
            from CompletedHike h
            where h.deleted = false
              and h.routeServerId in :routeIds
            group by h.routeServerId
            """)
    List<Object[]> countCompletedHikesByRouteServerIds(Collection<Long> routeIds);
}
