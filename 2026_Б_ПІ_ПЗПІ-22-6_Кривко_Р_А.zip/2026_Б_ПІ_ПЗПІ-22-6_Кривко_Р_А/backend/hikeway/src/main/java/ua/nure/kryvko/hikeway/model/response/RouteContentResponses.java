package ua.nure.kryvko.hikeway.model.response;

import java.time.Instant;

public final class RouteContentResponses {
    private RouteContentResponses() {
    }

    public record Rating(double averageRating, long ratingCount, Integer userRating) {
    }

    public record Comment(
            long id,
            String authorId,
            String authorDisplayName,
            boolean ownedByCurrentUser,
            String text,
            Instant createdAt,
            Instant updatedAt
    ) {
    }
}
