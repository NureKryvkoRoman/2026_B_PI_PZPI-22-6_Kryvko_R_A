package ua.nure.kryvko.hikeway.service;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import ua.nure.kryvko.hikeway.exception.InvalidPoiDataException;
import ua.nure.kryvko.hikeway.model.response.SearchResponse;

@Service
public class SearchService {
    private static final int MAX_PAGE_SIZE = 100;

    private final RouteService routeService;
    private final PointOfInterestService poiService;

    public SearchService(RouteService routeService, PointOfInterestService poiService) {
        this.routeService = routeService;
        this.poiService = poiService;
    }

    @Transactional(readOnly = true)
    public SearchResponse search(String name, int page, int size) {
        String validName = requireName(name);
        requirePage(page, size);
        return new SearchResponse(
                routeService.searchPublishedRoutesByName(validName, page, size),
                poiService.searchByName(validName, page, size)
        );
    }

    private String requireName(String value) {
        if (value == null || value.trim().isEmpty()) {
            throw invalidRequest("Name is required");
        }
        return value.trim();
    }

    private void requirePage(int page, int size) {
        if (page < 0 || size < 1 || size > MAX_PAGE_SIZE) {
            throw invalidRequest("Page must be non-negative and size must be 1 to 100");
        }
    }

    private InvalidPoiDataException invalidRequest(String message) {
        return new InvalidPoiDataException("INVALID_REQUEST", message);
    }
}
