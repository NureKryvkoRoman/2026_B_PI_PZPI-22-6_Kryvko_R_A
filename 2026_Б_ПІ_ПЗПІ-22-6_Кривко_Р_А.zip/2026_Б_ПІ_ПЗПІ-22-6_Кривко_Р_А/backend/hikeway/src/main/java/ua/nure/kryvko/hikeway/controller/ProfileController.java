package ua.nure.kryvko.hikeway.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import ua.nure.kryvko.hikeway.model.request.UpdateUserProfileRequest;
import ua.nure.kryvko.hikeway.model.response.UserProfileResponse;
import ua.nure.kryvko.hikeway.service.UserProfileService;

@RestController
@RequestMapping("/profile")
public class ProfileController {
    private final UserProfileService userProfileService;

    @Autowired
    public ProfileController(UserProfileService userProfileService) {
        this.userProfileService = userProfileService;
    }

    @GetMapping("/me")
    public ResponseEntity<UserProfileResponse> currentProfile() {
        return ResponseEntity.ok(userProfileService.currentProfile());
    }

    @PatchMapping("/me")
    public ResponseEntity<UserProfileResponse> updateCurrentProfile(@RequestBody UpdateUserProfileRequest request) {
        return ResponseEntity.ok(userProfileService.updateCurrentProfile(request));
    }
}
