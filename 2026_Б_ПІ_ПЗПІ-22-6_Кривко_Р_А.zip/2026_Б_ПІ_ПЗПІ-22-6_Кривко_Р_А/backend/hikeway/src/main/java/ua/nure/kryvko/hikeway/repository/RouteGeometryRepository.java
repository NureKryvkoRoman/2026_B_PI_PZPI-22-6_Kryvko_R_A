package ua.nure.kryvko.hikeway.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import ua.nure.kryvko.hikeway.model.Route;
import ua.nure.kryvko.hikeway.model.RouteGeometry;

import java.util.Optional;

public interface RouteGeometryRepository extends JpaRepository<RouteGeometry, Long> {
    Optional<RouteGeometry> findByRoute(Route route);
    Optional<RouteGeometry> findByRouteId(Long id);
    @Query("""
            SELECT geometry
            FROM RouteGeometry geometry
            WHERE geometry.route.createdBy = :createdBy
              AND geometry.route.deleted = false
            ORDER BY geometry.route.id DESC
            """)
    Page<RouteGeometry> findUserCreatedRoutes(@Param("createdBy") String createdBy, Pageable pageable);
}
