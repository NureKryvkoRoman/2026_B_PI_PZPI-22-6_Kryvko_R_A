package ua.nure.kryvko.hikeway.config;

import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.time.Clock;

@Configuration
@EnableConfigurationProperties(WeatherProperties.class)
public class WeatherConfig {
    @Bean
    Clock clock() {
        return Clock.systemDefaultZone();
    }
}
