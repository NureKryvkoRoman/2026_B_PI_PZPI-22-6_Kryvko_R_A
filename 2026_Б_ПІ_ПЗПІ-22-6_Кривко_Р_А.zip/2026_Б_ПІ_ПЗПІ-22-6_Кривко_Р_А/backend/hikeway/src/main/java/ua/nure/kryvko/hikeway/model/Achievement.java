package ua.nure.kryvko.hikeway.model;

import jakarta.persistence.*;
import lombok.Data;

@Entity
@Table(
        name = "achievement",
        uniqueConstraints = @UniqueConstraint(columnNames = "code"),
        indexes = @Index(columnList = "triggerEvent")
)
@Data
public class Achievement {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, length = 80)
    private String code;

    @Column(nullable = false, length = 160)
    private String name;

    @Column(nullable = false, length = 500)
    private String description;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private AchievementTriggerEvent triggerEvent;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private AchievementMetric metric;

    @Column(nullable = false)
    private double targetValue;
}
