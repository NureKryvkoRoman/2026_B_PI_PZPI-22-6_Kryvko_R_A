package ua.nure.kryvko.hikeway.service;

import lombok.extern.slf4j.Slf4j;
import org.keycloak.admin.client.CreatedResponseUtil;
import org.keycloak.admin.client.Keycloak;
import org.keycloak.representations.idm.CredentialRepresentation;
import org.keycloak.representations.idm.UserRepresentation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Service;
import ua.nure.kryvko.hikeway.exception.InvalidUserDataException;
import ua.nure.kryvko.hikeway.exception.KeycloakException;
import ua.nure.kryvko.hikeway.exception.UserAlreadyExistsException;
import ua.nure.kryvko.hikeway.model.UserEntity;
import ua.nure.kryvko.hikeway.model.request.SignUpRequest;
import ua.nure.kryvko.hikeway.repository.UserRepository;

import java.util.List;

@Slf4j
@Service
public class AuthService {
    private final Keycloak keycloak;
    private final String realm;
    private final UserRepository userRepository;

    @Autowired
    public AuthService(Keycloak keycloak, @Value("${keycloak.target-realm}") String realm, UserRepository userRepository) {
        this.keycloak = keycloak;
        this.realm = realm;
        this.userRepository = userRepository;
    }

    public UserEntity signUp(SignUpRequest request) {
        if (request == null
                || isMissing(request.email())
                || isMissing(request.username())
                || isMissing(request.password())
                || isMissing(request.firstName())
                || isMissing(request.lastName())) {
            throw new InvalidUserDataException("Email, username, password, first name and last name are required");
        }
        String email = request.email().trim();
        String username = request.username().trim();
        String firstName = request.firstName().trim();
        String lastName = request.lastName().trim();

        if (userRepository.existsByEmailIgnoreCase(email)
                || userRepository.existsByUsernameIgnoreCase(username)) {
            throw new UserAlreadyExistsException("User already exists");
        }

        var password = new CredentialRepresentation();
        password.setType(CredentialRepresentation.PASSWORD);
        password.setValue(request.password());
        password.setTemporary(false);

        var user = new UserRepresentation();
        user.setEmail(email);
        user.setUsername(username);
        user.setCredentials(List.of(password));
        user.setFirstName(firstName);
        user.setLastName(lastName);
        user.setEmailVerified(true); //FIXME: skipped for simplicity now, enable later
        user.setEnabled(true);

        try (var response = keycloak.realm(realm).users().create(user)) {
            switch (response.getStatus()) {
                case 201 -> {
                    String userId = CreatedResponseUtil.getCreatedId(response);

                    var userEntity = new UserEntity(
                            user.getFirstName(),
                            user.getLastName(),
                            user.getEmail(),
                            user.getUsername(),
                            userId
                    );

                    try {
                        return userRepository.save(userEntity);
                    } catch (DataIntegrityViolationException e) {
                        // Rollback in Keycloak
                        var delResponse = keycloak.realm(realm).users().delete(userId);
                        delResponse.close();
                        throw new UserAlreadyExistsException("User already exists");
                    } catch (Exception e) {
                        // Rollback in Keycloak
                        var delResponse = keycloak.realm(realm).users().delete(userId);
                        delResponse.close();
                        throw e;
                    }
                }
                case 409 -> {
                    throw new UserAlreadyExistsException("User already exists " + response.readEntity(String.class));
                }
                case 400 -> {
                    throw new InvalidUserDataException("Invalid user data " + response.readEntity(String.class));
                }
            }
            throw new KeycloakException("Keycloak error: " + response.readEntity(String.class));
        }
    }

    private boolean isMissing(String value) {
        return value == null || value.isBlank();
    }
}
