package ua.nure.kryvko.hikeway.model.response;

import java.time.Instant;

public record AchievementResponse(
        Long id,
        String code,
        String name,
        String description,
        double progressValue,
        double targetValue,
        Instant completedAt
) {
}
