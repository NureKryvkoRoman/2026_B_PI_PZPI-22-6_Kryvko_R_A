package ua.nure.kryvko.hikeway.controller;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import ua.nure.kryvko.hikeway.controller.admin.AdminUserController;
import ua.nure.kryvko.hikeway.model.UserRole;
import ua.nure.kryvko.hikeway.model.request.AdminCreateUserRequest;
import ua.nure.kryvko.hikeway.model.request.UpdateUserProfileRequest;
import ua.nure.kryvko.hikeway.model.response.PageResponse;
import ua.nure.kryvko.hikeway.model.response.UserProfileResponse;
import ua.nure.kryvko.hikeway.service.UserProfileService;

import java.util.List;
import java.util.Set;

import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.patch;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

class AdminUserControllerTest {
    private UserProfileService service;
    private MockMvc mockMvc;

    @BeforeEach
    void setUp() {
        service = mock(UserProfileService.class);
        mockMvc = MockMvcBuilders.standaloneSetup(new AdminUserController(service)).build();
    }

    @Test
    void listsUsersWithPagination() throws Exception {
        when(service.adminList(2, 25)).thenReturn(new PageResponse<>(List.of(response()), 2, 25, 1, 1));

        mockMvc.perform(get("/admin/users")
                        .param("page", "2")
                        .param("size", "25"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.items[0].id").value(1))
                .andExpect(jsonPath("$.page").value(2))
                .andExpect(jsonPath("$.size").value(25));

        verify(service).adminList(2, 25);
    }

    @Test
    void createsUser() throws Exception {
        var request = new AdminCreateUserRequest(
                "user@example.com",
                "user",
                "First",
                "Last",
                "secret",
                Set.of(UserRole.USER)
        );
        when(service.adminCreate(eq(request))).thenReturn(response());

        mockMvc.perform(post("/admin/users")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("""
                                {
                                  "email": "user@example.com",
                                  "username": "user",
                                  "firstName": "First",
                                  "lastName": "Last",
                                  "password": "secret",
                                  "roles": ["USER"]
                                }
                                """))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.keycloakId").value("kc-1"));

        verify(service).adminCreate(request);
    }

    @Test
    void getsUpdatesAndDeletesUser() throws Exception {
        var request = new UpdateUserProfileRequest(null, "newname", null, null);
        when(service.adminGet(1L)).thenReturn(response());
        when(service.adminUpdate(eq(1L), eq(request))).thenReturn(new UserProfileResponse(
                1L,
                "kc-1",
                "user@example.com",
                "newname",
                "First",
                "Last"
        ));

        mockMvc.perform(get("/admin/users/1"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.email").value("user@example.com"));
        mockMvc.perform(patch("/admin/users/1")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("""
                                {
                                  "username": "newname"
                                }
                                """))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.username").value("newname"));
        mockMvc.perform(delete("/admin/users/1"))
                .andExpect(status().isNoContent());

        verify(service).adminGet(1L);
        verify(service).adminUpdate(1L, request);
        verify(service).adminDelete(1L);
    }

    private UserProfileResponse response() {
        return new UserProfileResponse(1L, "kc-1", "user@example.com", "user", "First", "Last");
    }
}
