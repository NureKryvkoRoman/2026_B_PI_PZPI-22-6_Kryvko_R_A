package ua.nure.kryvko.hikeway.service;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import ua.nure.kryvko.hikeway.model.*;
import ua.nure.kryvko.hikeway.repository.AchievementRepository;
import ua.nure.kryvko.hikeway.repository.CompletedHikeRepository;
import ua.nure.kryvko.hikeway.repository.RouteRepository;
import ua.nure.kryvko.hikeway.repository.UserAchievementRepository;

import java.time.Instant;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

class AchievementServiceTest {
    private AchievementRepository achievementRepository;
    private UserAchievementRepository userAchievementRepository;
    private CompletedHikeRepository completedHikeRepository;
    private RouteRepository routeRepository;
    private AchievementService service;

    @BeforeEach
    void setUp() {
        achievementRepository = mock(AchievementRepository.class);
        userAchievementRepository = mock(UserAchievementRepository.class);
        completedHikeRepository = mock(CompletedHikeRepository.class);
        routeRepository = mock(RouteRepository.class);
        service = new AchievementService(
                achievementRepository,
                userAchievementRepository,
                completedHikeRepository,
                routeRepository
        );
        when(userAchievementRepository.save(any(UserAchievement.class)))
                .thenAnswer(invocation -> invocation.getArgument(0));
    }

    @Test
    void awardsFirstHikeAfterCompletedHike() {
        Achievement achievement = achievement(
                1L,
                "FIRST_HIKE",
                AchievementTriggerEvent.HIKE_COMPLETED,
                AchievementMetric.FINISHED_HIKES,
                1
        );
        when(achievementRepository.findByTriggerEvent(AchievementTriggerEvent.HIKE_COMPLETED))
                .thenReturn(List.of(achievement));
        when(userAchievementRepository.findByOwnerIdAndAchievementId("user-1", 1L))
                .thenReturn(Optional.empty());
        when(completedHikeRepository.countByOwnerIdAndDeletedFalse("user-1")).thenReturn(1L);

        var completed = service.evaluateAfterHike("user-1");

        assertEquals(1, completed.size());
        assertEquals("FIRST_HIKE", completed.getFirst().code());
        assertEquals(1, completed.getFirst().progressValue());
    }

    @Test
    void awardsTotalDistanceAchievementFromAggregateDistance() {
        Achievement achievement = achievement(
                2L,
                "TOTAL_50K_HIKED",
                AchievementTriggerEvent.HIKE_COMPLETED,
                AchievementMetric.TOTAL_DISTANCE_KM,
                50
        );
        when(achievementRepository.findByTriggerEvent(AchievementTriggerEvent.HIKE_COMPLETED))
                .thenReturn(List.of(achievement));
        when(userAchievementRepository.findByOwnerIdAndAchievementId("user-1", 2L))
                .thenReturn(Optional.empty());
        when(completedHikeRepository.sumTotalDistanceKmByOwnerId("user-1")).thenReturn(50.5);

        var completed = service.evaluateAfterHike("user-1");

        assertEquals(1, completed.size());
        assertEquals(50.5, completed.getFirst().progressValue());
    }

    @Test
    void awardsSingleHikeDistanceAchievementFromMaxDistance() {
        Achievement achievement = achievement(
                3L,
                "FIRST_10K_HIKE",
                AchievementTriggerEvent.HIKE_COMPLETED,
                AchievementMetric.SINGLE_HIKE_DISTANCE_KM,
                10
        );
        when(achievementRepository.findByTriggerEvent(AchievementTriggerEvent.HIKE_COMPLETED))
                .thenReturn(List.of(achievement));
        when(userAchievementRepository.findByOwnerIdAndAchievementId("user-1", 3L))
                .thenReturn(Optional.empty());
        when(completedHikeRepository.maxTotalDistanceKmByOwnerId("user-1")).thenReturn(12.1);

        var completed = service.evaluateAfterHike("user-1");

        assertEquals(1, completed.size());
        assertEquals("FIRST_10K_HIKE", completed.getFirst().code());
    }

    @Test
    void awardsCreatedRouteAchievementFromRouteCount() {
        Achievement achievement = achievement(
                4L,
                "FIRST_ROUTE_CREATED",
                AchievementTriggerEvent.ROUTE_CREATED,
                AchievementMetric.ROUTES_CREATED,
                1
        );
        when(achievementRepository.findByTriggerEvent(AchievementTriggerEvent.ROUTE_CREATED))
                .thenReturn(List.of(achievement));
        when(userAchievementRepository.findByOwnerIdAndAchievementId("user-1", 4L))
                .thenReturn(Optional.empty());
        when(routeRepository.countByCreatedByAndDeletedFalse("user-1")).thenReturn(1L);

        var completed = service.evaluateAfterRoute("user-1");

        assertEquals(1, completed.size());
        assertEquals("FIRST_ROUTE_CREATED", completed.getFirst().code());
    }

    @Test
    void awardsFiveFinishedHikesAchievementFromHikeCount() {
        Achievement achievement = achievement(
                5L,
                "FIVE_HIKES_FINISHED",
                AchievementTriggerEvent.HIKE_COMPLETED,
                AchievementMetric.FINISHED_HIKES,
                5
        );
        when(achievementRepository.findByTriggerEvent(AchievementTriggerEvent.HIKE_COMPLETED))
                .thenReturn(List.of(achievement));
        when(userAchievementRepository.findByOwnerIdAndAchievementId("user-1", 5L))
                .thenReturn(Optional.empty());
        when(completedHikeRepository.countByOwnerIdAndDeletedFalse("user-1")).thenReturn(5L);

        var completed = service.evaluateAfterHike("user-1");

        assertEquals(1, completed.size());
        assertEquals("FIVE_HIKES_FINISHED", completed.getFirst().code());
    }

    @Test
    void updatesProgressWithoutDuplicatingCompletedAchievement() {
        Achievement achievement = achievement(
                6L,
                "FIVE_HIKES_FINISHED",
                AchievementTriggerEvent.HIKE_COMPLETED,
                AchievementMetric.FINISHED_HIKES,
                5
        );
        UserAchievement userAchievement = new UserAchievement();
        userAchievement.setOwnerId("user-1");
        userAchievement.setAchievement(achievement);
        userAchievement.setProgressValue(5);
        userAchievement.setCompletedAt(Instant.parse("2026-07-06T10:00:00Z"));
        userAchievement.setUpdatedAt(Instant.parse("2026-07-06T10:00:00Z"));
        when(achievementRepository.findByTriggerEvent(AchievementTriggerEvent.HIKE_COMPLETED))
                .thenReturn(List.of(achievement));
        when(userAchievementRepository.findByOwnerIdAndAchievementId("user-1", 6L))
                .thenReturn(Optional.of(userAchievement));
        when(completedHikeRepository.countByOwnerIdAndDeletedFalse("user-1")).thenReturn(6L);

        var completed = service.evaluateAfterHike("user-1");

        assertTrue(completed.isEmpty());
        assertEquals(6, userAchievement.getProgressValue());
        verify(userAchievementRepository).save(userAchievement);
    }

    private Achievement achievement(
            Long id,
            String code,
            AchievementTriggerEvent triggerEvent,
            AchievementMetric metric,
            double targetValue
    ) {
        Achievement achievement = new Achievement();
        achievement.setId(id);
        achievement.setCode(code);
        achievement.setName(code);
        achievement.setDescription("Description");
        achievement.setTriggerEvent(triggerEvent);
        achievement.setMetric(metric);
        achievement.setTargetValue(targetValue);
        return achievement;
    }
}
