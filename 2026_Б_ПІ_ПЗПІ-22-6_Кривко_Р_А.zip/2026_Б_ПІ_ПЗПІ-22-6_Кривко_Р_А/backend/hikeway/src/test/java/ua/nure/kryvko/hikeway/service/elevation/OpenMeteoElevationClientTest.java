package ua.nure.kryvko.hikeway.service.elevation;

import org.locationtech.jts.geom.Coordinate;
import org.junit.jupiter.api.Test;
import ua.nure.kryvko.hikeway.config.WeatherProperties;

import java.net.URI;
import java.time.Duration;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertTrue;

class OpenMeteoElevationClientTest {
    @Test
    void buildsElevationRequestForMultipleCoordinates() {
        var properties = new WeatherProperties(
                "open-meteo",
                new WeatherProperties.OpenMeteo(URI.create("https://example.test/v1")),
                Duration.ofSeconds(5),
                2,
                Duration.ZERO,
                null
        );
        var client = new OpenMeteoElevationClient(properties);

        String uri = client.elevationUri(List.of(
                new Coordinate(24.03, 49.84),
                new Coordinate(24.10, 49.90)
        )).toString();

        assertTrue(uri.startsWith("https://example.test/v1/elevation?"));
        assertTrue(uri.contains("latitude=49.84,49.9"));
        assertTrue(uri.contains("longitude=24.03,24.1"));
    }
}
