package ua.nure.kryvko.hikeway.controller;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import ua.nure.kryvko.hikeway.model.Difficulty;
import ua.nure.kryvko.hikeway.model.RouteVisibility;
import ua.nure.kryvko.hikeway.model.Terrain;
import ua.nure.kryvko.hikeway.model.geojson.GeoJsonLineString;
import ua.nure.kryvko.hikeway.model.response.PageResponse;
import ua.nure.kryvko.hikeway.model.response.PoiResponses;
import ua.nure.kryvko.hikeway.model.response.RouteSearchResponse;
import ua.nure.kryvko.hikeway.model.response.SearchResponse;
import ua.nure.kryvko.hikeway.service.SearchService;

import java.time.Instant;
import java.util.List;
import java.util.UUID;

import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

class SearchControllerTest {
    private SearchService service;
    private MockMvc mockMvc;

    @BeforeEach
    void setUp() {
        service = mock(SearchService.class);
        mockMvc = MockMvcBuilders.standaloneSetup(new SearchController(service)).build();
    }

    @Test
    void searchesRoutesAndPoisWithDefaultPagination() throws Exception {
        when(service.search("castle", 0, 20)).thenReturn(response());

        mockMvc.perform(get("/search").param("name", "castle"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.routes.items[0].id").value(7))
                .andExpect(jsonPath("$.routes.items[0].name").value("High Castle Loop"))
                .andExpect(jsonPath("$.routes.page").value(0))
                .andExpect(jsonPath("$.routes.size").value(20))
                .andExpect(jsonPath("$.pois.items[0].id").value(3))
                .andExpect(jsonPath("$.pois.items[0].name").value("High Castle Viewpoint"))
                .andExpect(jsonPath("$.pois.page").value(0))
                .andExpect(jsonPath("$.pois.size").value(20));

        verify(service).search("castle", 0, 20);
    }

    @Test
    void parsesPagination() throws Exception {
        when(service.search("spring", 2, 10)).thenReturn(new SearchResponse(
                new PageResponse<>(List.of(), 2, 10, 0, 0),
                new PageResponse<>(List.of(), 2, 10, 0, 0)
        ));

        mockMvc.perform(get("/search")
                        .param("name", "spring")
                        .param("page", "2")
                        .param("size", "10"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.routes.page").value(2))
                .andExpect(jsonPath("$.pois.size").value(10));

        verify(service).search("spring", 2, 10);
    }

    private SearchResponse response() {
        return new SearchResponse(
                new PageResponse<>(List.of(route()), 0, 20, 1, 1),
                new PageResponse<>(List.of(poi()), 0, 20, 1, 1)
        );
    }

    private RouteSearchResponse route() {
        return new RouteSearchResponse(
                7L,
                "High Castle Loop",
                "Public route",
                8.5,
                120,
                Difficulty.EASY,
                180,
                Terrain.FOREST,
                Instant.parse("2026-06-25T10:00:00Z"),
                "user-1",
                new GeoJsonLineString(
                        "LineString",
                        List.of(List.of(24.1, 49.8), List.of(24.2, 49.9))
                ),
                UUID.fromString("11111111-1111-1111-1111-111111111111"),
                RouteVisibility.PUBLIC,
                0.0,
                0L,
                null
        );
    }

    private PoiResponses.Summary poi() {
        return new PoiResponses.Summary(
                3L,
                "High Castle Viewpoint",
                "Scenic lookout",
                24.1,
                49.8,
                "user-1",
                "Hiker",
                true,
                0.0,
                0L,
                null,
                List.of()
        );
    }
}
