package ua.nure.kryvko.hikeway.service;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.locationtech.jts.geom.Coordinate;
import org.locationtech.jts.geom.GeometryFactory;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.oauth2.jwt.Jwt;
import ua.nure.kryvko.hikeway.exception.InvalidPoiDataException;
import ua.nure.kryvko.hikeway.model.CompletedHike;
import ua.nure.kryvko.hikeway.model.Difficulty;
import ua.nure.kryvko.hikeway.model.Route;
import ua.nure.kryvko.hikeway.model.RouteGeometry;
import ua.nure.kryvko.hikeway.model.RouteVisibility;
import ua.nure.kryvko.hikeway.model.Terrain;
import ua.nure.kryvko.hikeway.repository.CompletedHikeRepository;
import ua.nure.kryvko.hikeway.repository.RouteRatingRepository;
import ua.nure.kryvko.hikeway.repository.RouteRepository;

import java.time.Instant;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.anyCollection;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

class RouteRecommendationServiceTest {
    private final GeometryFactory geometryFactory = new GeometryFactory();
    private RouteRepository routeRepository;
    private CompletedHikeRepository completedHikeRepository;
    private RouteRatingRepository routeRatingRepository;
    private CurrentUserService currentUser;
    private RouteRecommendationService service;

    @BeforeEach
    void setUp() {
        routeRepository = mock(RouteRepository.class);
        completedHikeRepository = mock(CompletedHikeRepository.class);
        routeRatingRepository = mock(RouteRatingRepository.class);
        currentUser = mock(CurrentUserService.class);
        when(routeRatingRepository.aggregateForRoute(org.mockito.ArgumentMatchers.anyLong())).thenReturn(new Object[]{0.0, 0L});
        when(routeRatingRepository.findByRouteIdAndUserId(org.mockito.ArgumentMatchers.anyLong(), org.mockito.ArgumentMatchers.anyString()))
                .thenReturn(Optional.empty());
        when(currentUser.id()).thenReturn("user-1");
        service = new RouteRecommendationService(
                routeRepository,
                completedHikeRepository,
                new GeoJsonGeometryMapper(),
                routeRatingRepository,
                currentUser
        );
        Jwt jwt = new Jwt(
                "token",
                Instant.now(),
                Instant.now().plusSeconds(60),
                Map.of("alg", "none"),
                Map.of("sub", "user-1")
        );
        SecurityContextHolder.getContext().setAuthentication(
                new UsernamePasswordAuthenticationToken(jwt, null)
        );
    }

    @AfterEach
    void tearDown() {
        SecurityContextHolder.clearContext();
    }

    @Test
    void ranksRoutesAgainstCompletedHikeProfileAndExcludesCompletedRoutes() {
        CompletedHike hike = hike(99L, 10.0, 120, 300);
        Route profileRoute = route(99L, 10.0, 120, 300, Difficulty.MEDIUM, Terrain.FOREST);
        RouteGeometry completedCandidate = routeGeometry(profileRoute, 24.0, 49.0);
        RouteGeometry closeMatch = routeGeometry(
                route(1L, 10.5, 125, 320, Difficulty.MEDIUM, Terrain.FOREST),
                24.0,
                49.0
        );
        RouteGeometry weakMatch = routeGeometry(
                route(2L, 20.0, 240, 900, Difficulty.HARD, Terrain.ROCKY),
                24.0,
                49.0
        );
        when(completedHikeRepository.findByOwnerIdAndDeletedFalse("user-1")).thenReturn(List.of(hike));
        when(routeRepository.findAllById(any())).thenReturn(List.of(profileRoute));
        when(routeRepository.findRecommendationCandidates(null, null, null, 500))
                .thenReturn(List.of(weakMatch, completedCandidate, closeMatch));
        when(completedHikeRepository.countCompletedHikesByRouteServerIds(anyCollection()))
                .thenReturn(List.of(new Object[]{2L, 5L}, new Object[]{1L, 1L}));

        var response = service.recommendedRoutes(null, null, null, 0, 10);

        assertEquals(2, response.items().size());
        assertEquals(1L, response.items().getFirst().id());
        assertEquals(2L, response.items().get(1).id());
        verify(completedHikeRepository).countCompletedHikesByRouteServerIds(java.util.Set.of(1L, 2L));
    }

    @Test
    void excludesCompletedRoutesMatchedByRouteClientId() {
        UUID completedRouteClientId = UUID.fromString("11111111-1111-1111-1111-111111111111");
        CompletedHike hike = hike(null, 8.0, 100, 200);
        hike.setRouteClientId(completedRouteClientId);
        Route completedRoute = route(7L, 8.0, 100, 200, Difficulty.EASY, Terrain.FOREST);
        completedRoute.setClientId(completedRouteClientId);
        RouteGeometry completedCandidate = routeGeometry(completedRoute, 24.0, 49.0);
        RouteGeometry availableCandidate = routeGeometry(
                route(8L, 9.0, 120, 240, Difficulty.EASY, Terrain.FOREST),
                24.0,
                49.0
        );
        when(completedHikeRepository.findByOwnerIdAndDeletedFalse("user-1")).thenReturn(List.of(hike));
        when(routeRepository.findRecommendationCandidates(null, null, null, 500))
                .thenReturn(List.of(completedCandidate, availableCandidate));
        when(completedHikeRepository.countCompletedHikesByRouteServerIds(anyCollection()))
                .thenReturn(List.of());

        var response = service.recommendedRoutes(null, null, null, 0, 10);

        assertEquals(1, response.items().size());
        assertEquals(8L, response.items().getFirst().id());
        verify(completedHikeRepository).countCompletedHikesByRouteServerIds(java.util.Set.of(8L));
    }


    @Test
    void usesColdStartFallbackWithDefaultLocationProximity() {
        RouteGeometry far = routeGeometry(
                route(1L, 12.0, 140, 300, Difficulty.MEDIUM, Terrain.MIXED),
                24.5,
                49.5
        );
        RouteGeometry near = routeGeometry(
                route(2L, 12.0, 140, 300, Difficulty.MEDIUM, Terrain.MIXED),
                24.01,
                49.01
        );
        when(completedHikeRepository.findByOwnerIdAndDeletedFalse("user-1")).thenReturn(List.of());
        when(routeRepository.findRecommendationCandidates(24.0, 49.0, 30.0, 500))
                .thenReturn(List.of(far, near));
        when(completedHikeRepository.countCompletedHikesByRouteServerIds(anyCollection()))
                .thenReturn(List.of());

        var response = service.recommendedRoutes(24.0, 49.0, null, 0, 10);

        assertEquals(2L, response.items().getFirst().id());
        verify(routeRepository).findRecommendationCandidates(24.0, 49.0, 30.0, 500);
    }

    @Test
    void rejectsInvalidRecommendationRequests() {
        assertThrows(InvalidPoiDataException.class, () ->
                service.recommendedRoutes(24.0, null, null, 0, 10));
        assertThrows(InvalidPoiDataException.class, () ->
                service.recommendedRoutes(null, null, -1.0, 0, 10));
        assertThrows(InvalidPoiDataException.class, () ->
                service.recommendedRoutes(null, null, null, -1, 10));
        assertThrows(InvalidPoiDataException.class, () ->
                service.recommendedRoutes(null, null, null, 0, 101));
    }

    private CompletedHike hike(Long routeServerId, double distanceKm, int durationMinutes, int elevationGainMeters) {
        CompletedHike hike = new CompletedHike();
        hike.setOwnerId("user-1");
        hike.setClientId(UUID.randomUUID());
        hike.setRouteServerId(routeServerId);
        hike.setRouteName("Completed route");
        hike.setStartedAt(Instant.parse("2026-07-07T08:00:00Z"));
        hike.setFinishedAt(Instant.parse("2026-07-07T10:00:00Z"));
        hike.setActiveDurationMillis(durationMinutes * 60_000L);
        hike.setWallClockDurationMillis(durationMinutes * 60_000L);
        hike.setTotalDistanceKm(distanceKm);
        hike.setElevationGainMeters(elevationGainMeters);
        return hike;
    }

    private Route route(
            Long id,
            double distanceKm,
            int estimatedTimeMinutes,
            int elevationGain,
            Difficulty difficulty,
            Terrain terrain
    ) {
        Route route = new Route();
        route.setId(id);
        route.setClientId(UUID.randomUUID());
        route.setName("Route " + id);
        route.setDescription("Description");
        route.setDistanceKm(distanceKm);
        route.setEstimatedTimeMinutes(estimatedTimeMinutes);
        route.setDifficulty(difficulty);
        route.setElevationGain(elevationGain);
        route.setTerrain(terrain);
        route.setCreatedAt(Instant.parse("2026-06-25T10:00:00Z"));
        route.setPublishedAt(Instant.parse("2026-06-25T10:00:00Z"));
        route.setCreatedBy("user-2");
        route.setVisibility(RouteVisibility.PUBLIC);
        return route;
    }

    private RouteGeometry routeGeometry(Route route, double longitude, double latitude) {
        var line = geometryFactory.createLineString(new Coordinate[]{
                new Coordinate(longitude, latitude),
                new Coordinate(longitude + 0.01, latitude + 0.01),
        });
        line.setSRID(4326);
        RouteGeometry geometry = new RouteGeometry();
        geometry.setRoute(route);
        geometry.setLine(line);
        return geometry;
    }
}
