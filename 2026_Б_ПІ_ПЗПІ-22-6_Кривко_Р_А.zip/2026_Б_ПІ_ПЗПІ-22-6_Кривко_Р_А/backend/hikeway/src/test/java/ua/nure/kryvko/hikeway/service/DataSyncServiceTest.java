package ua.nure.kryvko.hikeway.service;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.locationtech.jts.geom.LineString;
import org.springframework.data.domain.Pageable;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.oauth2.jwt.Jwt;
import ua.nure.kryvko.hikeway.model.*;
import ua.nure.kryvko.hikeway.model.geojson.GeoJsonLineString;
import ua.nure.kryvko.hikeway.model.request.SyncRequest;
import ua.nure.kryvko.hikeway.model.response.AchievementResponse;
import ua.nure.kryvko.hikeway.repository.CompletedHikeRepository;
import ua.nure.kryvko.hikeway.repository.RouteGeometryRepository;
import ua.nure.kryvko.hikeway.repository.RouteRepository;
import ua.nure.kryvko.hikeway.repository.SyncChangeRepository;
import ua.nure.kryvko.hikeway.service.elevation.ElevationService;

import java.time.Instant;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

class DataSyncServiceTest {
    private RouteRepository routeRepository;
    private RouteGeometryRepository geometryRepository;
    private CompletedHikeRepository hikeRepository;
    private SyncChangeRepository changeRepository;
    private RoutePoiService routePoiService;
    private AchievementService achievementService;
    private ElevationService elevationService;
    private DataSyncService service;

    @BeforeEach
    void setUp() {
        routeRepository = mock(RouteRepository.class);
        geometryRepository = mock(RouteGeometryRepository.class);
        hikeRepository = mock(CompletedHikeRepository.class);
        changeRepository = mock(SyncChangeRepository.class);
        routePoiService = mock(RoutePoiService.class);
        achievementService = mock(AchievementService.class);
        elevationService = mock(ElevationService.class);
        service = new DataSyncService(
                routeRepository,
                geometryRepository,
                hikeRepository,
                changeRepository,
                new GeoJsonGeometryMapper(),
                routePoiService,
                achievementService,
                elevationService
        );
        Jwt jwt = new Jwt(
                "token",
                Instant.now(),
                Instant.now().plusSeconds(60),
                Map.of("alg", "none"),
                Map.of("sub", "user-1")
        );
        SecurityContextHolder.getContext().setAuthentication(
                new UsernamePasswordAuthenticationToken(jwt, null)
        );
        when(changeRepository.findByOwnerIdAndIdGreaterThanOrderByIdAsc(
                anyString(),
                anyLong(),
                any(Pageable.class)
        )).thenReturn(List.of());
        when(achievementService.evaluateAfterRoute(anyString())).thenReturn(List.of());
        when(achievementService.evaluateAfterHike(anyString())).thenReturn(List.of());
        when(routeRepository.findById(anyLong())).thenReturn(Optional.empty());
        when(elevationService.estimateGain(any(GeoJsonLineString.class), anyInt()))
                .thenAnswer(invocation -> invocation.getArgument(1));
        when(elevationService.estimateGain(any(LineString.class), anyInt()))
                .thenAnswer(invocation -> invocation.getArgument(1));
    }

    @AfterEach
    void tearDown() {
        SecurityContextHolder.clearContext();
    }

    @Test
    void createsRouteUsingClientId() {
        UUID clientId = UUID.randomUUID();
        when(routeRepository.findByCreatedByAndClientId("user-1", clientId))
                .thenReturn(Optional.empty());
        when(routeRepository.save(any(Route.class))).thenAnswer(invocation -> {
            Route route = invocation.getArgument(0);
            route.setId(42L);
            return route;
        });
        when(geometryRepository.findByRoute(any(Route.class))).thenReturn(Optional.empty());
        SyncRequest request = new SyncRequest(
                null,
                UUID.randomUUID(),
                List.of(new SyncRequest.Mutation<>(
                        SyncRequest.Operation.UPSERT,
                        clientId,
                        0,
                        routePayload()
                )),
                List.of()
        );

        var response = service.synchronize(request);

        assertEquals(1, response.accepted().size());
        assertEquals(42L, response.accepted().getFirst().serverId());
        assertEquals(1L, response.accepted().getFirst().version());
        verify(routeRepository).save(any(Route.class));
        verify(geometryRepository).save(any(RouteGeometry.class));
        verify(routePoiService).replace(any(Route.class), eq(List.of()));
        verify(changeRepository).save(any(SyncChange.class));
        verify(achievementService).evaluateAfterRoute("user-1");
    }

    @Test
    void staleRouteMutationReturnsConflictWithoutOverwrite() {
        UUID clientId = UUID.randomUUID();
        Route existing = new Route();
        existing.setId(42L);
        existing.setClientId(clientId);
        existing.setCreatedBy("user-1");
        existing.setSyncVersion(3);
        existing.setName("Server route");
        existing.setDescription("Server description");
        existing.setDifficulty(Difficulty.EASY);
        existing.setTerrain(Terrain.FOREST);
        existing.setVisibility(RouteVisibility.PRIVATE);
        existing.setCreatedAt(Instant.now());
        existing.setUpdatedAt(Instant.now());
        when(routeRepository.findByCreatedByAndClientId("user-1", clientId))
                .thenReturn(Optional.of(existing));
        when(geometryRepository.findByRoute(existing)).thenReturn(Optional.empty());
        SyncRequest request = new SyncRequest(
                null,
                UUID.randomUUID(),
                List.of(new SyncRequest.Mutation<>(
                        SyncRequest.Operation.UPSERT,
                        clientId,
                        2,
                        routePayload()
                )),
                List.of()
        );

        var response = service.synchronize(request);

        assertTrue(response.accepted().isEmpty());
        assertEquals(1, response.conflicts().size());
        assertEquals(3, response.conflicts().getFirst().serverVersion());
        verify(routeRepository, never()).save(any(Route.class));
        verify(achievementService, never()).evaluateAfterRoute(anyString());
    }

    @Test
    void routeUpsertUsesComputedElevationGain() {
        UUID clientId = UUID.randomUUID();
        when(routeRepository.findByCreatedByAndClientId("user-1", clientId))
                .thenReturn(Optional.empty());
        when(routeRepository.save(any(Route.class))).thenAnswer(invocation -> {
            Route route = invocation.getArgument(0);
            route.setId(42L);
            return route;
        });
        when(geometryRepository.findByRoute(any(Route.class))).thenReturn(Optional.empty());
        when(elevationService.estimateGain(any(GeoJsonLineString.class), eq(460))).thenReturn(735);
        SyncRequest request = new SyncRequest(
                null,
                UUID.randomUUID(),
                List.of(new SyncRequest.Mutation<>(
                        SyncRequest.Operation.UPSERT,
                        clientId,
                        0,
                        routePayload()
                )),
                List.of()
        );

        service.synchronize(request);

        verify(routeRepository).save(argThat(route -> route.getElevationGain() == 735));
    }

    @Test
    void idempotentRouteMutationIgnoresServerComputedElevationDifference() {
        UUID clientId = UUID.randomUUID();
        Route existing = new Route();
        existing.setId(42L);
        existing.setClientId(clientId);
        existing.setCreatedBy("user-1");
        existing.setSyncVersion(1);
        existing.setName("Forest Loop");
        existing.setDescription("Description");
        existing.setDistanceKm(8.4);
        existing.setEstimatedTimeMinutes(175);
        existing.setDifficulty(Difficulty.MEDIUM);
        existing.setElevationGain(735);
        existing.setTerrain(Terrain.FOREST);
        existing.setVisibility(RouteVisibility.PRIVATE);
        existing.setCreatedAt(Instant.now());
        existing.setUpdatedAt(Instant.now());
        RouteGeometry geometry = new RouteGeometry();
        geometry.setRoute(existing);
        geometry.setLine(new GeoJsonGeometryMapper().toLineString(routePayload().geometry(), false));
        when(routeRepository.findByCreatedByAndClientId("user-1", clientId))
                .thenReturn(Optional.of(existing));
        when(geometryRepository.findByRoute(existing)).thenReturn(Optional.of(geometry));
        when(routePoiService.ids(42L)).thenReturn(List.of());
        SyncRequest request = new SyncRequest(
                null,
                UUID.randomUUID(),
                List.of(new SyncRequest.Mutation<>(
                        SyncRequest.Operation.UPSERT,
                        clientId,
                        0,
                        routePayload()
                )),
                List.of()
        );

        var response = service.synchronize(request);

        assertEquals(1, response.accepted().size());
        assertTrue(response.conflicts().isEmpty());
        verify(routeRepository, never()).save(any(Route.class));
    }

    @Test
    void hikeUpsertReturnsNewlyCompletedAchievements() {
        UUID clientId = UUID.randomUUID();
        AchievementResponse achievement = new AchievementResponse(
                1L,
                "FIRST_HIKE",
                "First hike",
                "Finish your first hike.",
                1,
                1,
                Instant.parse("2026-07-07T10:00:00Z")
        );
        when(hikeRepository.findByOwnerIdAndClientId("user-1", clientId))
                .thenReturn(Optional.empty());
        when(hikeRepository.save(any(CompletedHike.class))).thenAnswer(invocation -> {
            CompletedHike hike = invocation.getArgument(0);
            hike.setId(100L);
            return hike;
        });
        when(achievementService.evaluateAfterHike("user-1")).thenReturn(List.of(achievement));
        SyncRequest request = new SyncRequest(
                null,
                UUID.randomUUID(),
                List.of(),
                List.of(new SyncRequest.Mutation<>(
                        SyncRequest.Operation.UPSERT,
                        clientId,
                        0,
                        hikePayload()
                ))
        );

        var response = service.synchronize(request);

        assertEquals(1, response.accepted().size());
        assertEquals(1, response.newlyCompletedAchievements().size());
        assertEquals("FIRST_HIKE", response.newlyCompletedAchievements().getFirst().code());
        verify(achievementService).evaluateAfterHike("user-1");
    }

    @Test
    void hikeUpsertStoresComputedElevationGainWithRouteFallback() {
        UUID clientId = UUID.randomUUID();
        SyncRequest.HikePayload payload = hikePayload();
        Route route = new Route();
        route.setId(42L);
        route.setCreatedBy("user-1");
        route.setElevationGain(460);
        when(routeRepository.findById(42L)).thenReturn(Optional.of(route));
        when(elevationService.estimateGain(any(LineString.class), eq(460))).thenReturn(735);
        when(hikeRepository.findByOwnerIdAndClientId("user-1", clientId))
                .thenReturn(Optional.empty());
        when(hikeRepository.save(any(CompletedHike.class))).thenAnswer(invocation -> {
            CompletedHike hike = invocation.getArgument(0);
            hike.setId(100L);
            return hike;
        });
        SyncRequest request = new SyncRequest(
                null,
                UUID.randomUUID(),
                List.of(),
                List.of(new SyncRequest.Mutation<>(
                        SyncRequest.Operation.UPSERT,
                        clientId,
                        0,
                        payload
                ))
        );

        service.synchronize(request);

        verify(hikeRepository).save(argThat(hike -> hike.getElevationGainMeters() == 735));
        verify(elevationService).estimateGain(any(LineString.class), eq(460));
    }

    @Test
    void acceptedHikeUpsertReturnsCanonicalHikeChangeWithComputedElevation() {
        UUID clientId = UUID.randomUUID();
        when(elevationService.estimateGain(any(LineString.class), anyInt())).thenReturn(735);
        when(hikeRepository.findByOwnerIdAndClientId("user-1", clientId))
                .thenReturn(Optional.empty())
                .thenAnswer(invocation -> Optional.of(savedHike(clientId, 735)));
        when(hikeRepository.save(any(CompletedHike.class))).thenAnswer(invocation -> {
            CompletedHike hike = invocation.getArgument(0);
            hike.setId(100L);
            return hike;
        });
        SyncRequest request = new SyncRequest(
                null,
                UUID.randomUUID(),
                List.of(),
                List.of(new SyncRequest.Mutation<>(
                        SyncRequest.Operation.UPSERT,
                        clientId,
                        0,
                        hikePayload()
                ))
        );

        var response = service.synchronize(request);

        assertEquals(1, response.accepted().size());
        assertEquals(1, response.hikeChanges().size());
        assertEquals(clientId, response.hikeChanges().getFirst().clientId());
        assertEquals(735, response.hikeChanges().getFirst().elevationGainMeters());
    }

    @Test
    void idempotentHikeMutationDoesNotReevaluateAchievements() {
        UUID clientId = UUID.randomUUID();
        SyncRequest.HikePayload payload = hikePayload();
        CompletedHike existing = new CompletedHike();
        existing.setId(100L);
        existing.setClientId(clientId);
        existing.setOwnerId("user-1");
        existing.setSyncVersion(1);
        apply(existing, payload);
        when(hikeRepository.findByOwnerIdAndClientId("user-1", clientId))
                .thenReturn(Optional.of(existing));
        SyncRequest request = new SyncRequest(
                null,
                UUID.randomUUID(),
                List.of(),
                List.of(new SyncRequest.Mutation<>(
                        SyncRequest.Operation.UPSERT,
                        clientId,
                        0,
                        payload
                ))
        );

        var response = service.synchronize(request);

        assertEquals(1, response.accepted().size());
        assertTrue(response.newlyCompletedAchievements().isEmpty());
        verify(achievementService, never()).evaluateAfterHike(anyString());
    }

    private SyncRequest.RoutePayload routePayload() {
        return new SyncRequest.RoutePayload(
                "Forest Loop",
                "Description",
                8.4,
                175,
                Difficulty.MEDIUM,
                460,
                Terrain.FOREST,
                new GeoJsonLineString(
                        "LineString",
                        List.of(List.of(24.0, 49.0), List.of(24.1, 49.1))
                ),
                List.of()
        );
    }

    private SyncRequest.HikePayload hikePayload() {
        return new SyncRequest.HikePayload(
                UUID.randomUUID(),
                42L,
                "Forest Loop",
                Instant.parse("2026-07-07T08:00:00Z"),
                Instant.parse("2026-07-07T10:00:00Z"),
                6_600_000,
                7_200_000,
                8.4,
                new GeoJsonLineString(
                        "LineString",
                        List.of(List.of(24.0, 49.0), List.of(24.1, 49.1))
                )
        );
    }

    private void apply(CompletedHike hike, SyncRequest.HikePayload payload) {
        hike.setRouteClientId(payload.routeClientId());
        hike.setRouteServerId(payload.routeServerId());
        hike.setRouteName(payload.routeName());
        hike.setStartedAt(payload.startedAt());
        hike.setFinishedAt(payload.finishedAt());
        hike.setActiveDurationMillis(payload.activeDurationMillis());
        hike.setWallClockDurationMillis(payload.wallClockDurationMillis());
        hike.setTotalDistanceKm(payload.totalDistanceKm());
        hike.setPath(new GeoJsonGeometryMapper().toLineString(payload.path(), true));
    }

    private CompletedHike savedHike(UUID clientId, int elevationGainMeters) {
        CompletedHike hike = new CompletedHike();
        hike.setId(100L);
        hike.setClientId(clientId);
        hike.setOwnerId("user-1");
        hike.setSyncVersion(1);
        hike.setCreatedAt(Instant.parse("2026-07-07T10:00:00Z"));
        hike.setUpdatedAt(Instant.parse("2026-07-07T10:00:00Z"));
        apply(hike, hikePayload());
        hike.setElevationGainMeters(elevationGainMeters);
        return hike;
    }
}
