package ua.nure.kryvko.hikeway.service;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.locationtech.jts.geom.Coordinate;
import org.locationtech.jts.geom.GeometryFactory;
import ua.nure.kryvko.hikeway.config.WeatherProperties;
import ua.nure.kryvko.hikeway.exception.InvalidWeatherRequestException;
import ua.nure.kryvko.hikeway.exception.WeatherProviderException;
import ua.nure.kryvko.hikeway.model.Route;
import ua.nure.kryvko.hikeway.model.RouteGeometry;
import ua.nure.kryvko.hikeway.model.weather.DailyWeather;
import ua.nure.kryvko.hikeway.model.weather.HikeRecommendationExplanation;
import ua.nure.kryvko.hikeway.model.weather.HourlyWeather;
import ua.nure.kryvko.hikeway.model.weather.WeatherCondition;
import ua.nure.kryvko.hikeway.model.weather.WeatherForecast;
import ua.nure.kryvko.hikeway.model.weather.WeatherRiskType;
import ua.nure.kryvko.hikeway.repository.RouteGeometryRepository;
import ua.nure.kryvko.hikeway.service.weather.WeatherProviderClient;

import java.time.Clock;
import java.time.Duration;
import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

class WeatherServiceTest {
    private final GeometryFactory geometryFactory = new GeometryFactory();
    private RouteGeometryRepository routeGeometryRepository;
    private WeatherProviderClient weatherProviderClient;
    private WeatherService service;

    @BeforeEach
    void setUp() {
        routeGeometryRepository = mock(RouteGeometryRepository.class);
        weatherProviderClient = mock(WeatherProviderClient.class);
        service = new WeatherService(
                routeGeometryRepository,
                weatherProviderClient,
                weatherProperties(),
                Clock.fixed(Instant.parse("2026-07-09T06:00:00Z"), ZoneId.of("UTC"))
        );
    }

    @Test
    void usesRouteMidpointAndReturnsRecommendedWindow() {
        when(routeGeometryRepository.findByRouteId(7L)).thenReturn(Optional.of(routeGeometry(120, 180)));
        when(weatherProviderClient.forecast(49.9, 24.2, 180.0)).thenReturn(forecast(goodHours()));

        var response = service.getRouteWeather(7L, LocalDate.parse("2026-07-10"));

        assertEquals(49.9, response.latitude());
        assertEquals(24.2, response.longitude());
        assertEquals(180.0, response.elevationMeters());
        assertEquals(WeatherCondition.PARTLY_CLOUDY, response.summary().condition());
        assertEquals(LocalDateTime.parse("2026-07-10T07:00"), response.recommendation().recommendedStartTime());
        assertEquals(LocalDateTime.parse("2026-07-10T09:00"), response.recommendation().expectedReturnTime());
        assertEquals(
                HikeRecommendationExplanation.RECOMMENDED_WINDOW_AVOIDS_NIGHTTIME_AND_HIGH_RISK_FORECAST_HOURS,
                response.recommendation().explanation()
        );
        verify(weatherProviderClient).forecast(49.9, 24.2, 180.0);
    }

    @Test
    void cachesForecastByRoundedLocationElevationBucketAndDate() {
        when(routeGeometryRepository.findByRouteId(7L)).thenReturn(Optional.of(routeGeometry(120, 180)));
        when(weatherProviderClient.forecast(49.9, 24.2, 180.0)).thenReturn(forecast(goodHours()));

        service.getRouteWeather(7L, LocalDate.parse("2026-07-10"));
        service.getRouteWeather(7L, LocalDate.parse("2026-07-10"));

        verify(weatherProviderClient, times(1)).forecast(49.9, 24.2, 180.0);
    }

    @Test
    void cachesProviderFailuresBriefly() {
        when(routeGeometryRepository.findByRouteId(7L)).thenReturn(Optional.of(routeGeometry(120, 180)));
        when(weatherProviderClient.forecast(49.9, 24.2, 180.0))
                .thenThrow(new WeatherProviderException("Provider unavailable"));

        assertThrows(WeatherProviderException.class, () -> service.getRouteWeather(7L, LocalDate.parse("2026-07-10")));
        assertThrows(WeatherProviderException.class, () -> service.getRouteWeather(7L, LocalDate.parse("2026-07-10")));

        verify(weatherProviderClient, times(1)).forecast(49.9, 24.2, 180.0);
    }

    @Test
    void reportsRisksAndNoWindowWhenForecastHoursAreUnsafe() {
        when(routeGeometryRepository.findByRouteId(7L)).thenReturn(Optional.of(routeGeometry(120, 180)));
        when(weatherProviderClient.forecast(49.9, 24.2, 180.0)).thenReturn(forecast(unsafeHours()));

        var response = service.getRouteWeather(7L, LocalDate.parse("2026-07-10"));

        assertNull(response.recommendation().recommendedStartTime());
        assertNotNull(response.risks().stream().filter(risk -> risk.type().equals(WeatherRiskType.HEAVY_PRECIPITATION)).findFirst().orElse(null));
        assertNotNull(response.risks().stream().filter(risk -> risk.type().equals(WeatherRiskType.STRONG_WIND)).findFirst().orElse(null));
        assertNotNull(response.risks().stream().filter(risk -> risk.type().equals(WeatherRiskType.POOR_VISIBILITY)).findFirst().orElse(null));
        assertNotNull(response.risks().stream().filter(risk -> risk.type().equals(WeatherRiskType.THUNDERSTORM)).findFirst().orElse(null));
    }

    @Test
    void rejectsDateOutsideForecastRange() {
        when(routeGeometryRepository.findByRouteId(7L)).thenReturn(Optional.of(routeGeometry(120, 180)));
        when(weatherProviderClient.forecast(49.9, 24.2, 180.0)).thenReturn(forecast(goodHours()));

        assertThrows(
                InvalidWeatherRequestException.class,
                () -> service.getRouteWeather(7L, LocalDate.parse("2026-07-20"))
        );
    }

    private RouteGeometry routeGeometry(int estimatedTimeMinutes, int elevationGain) {
        Route route = new Route();
        route.setId(7L);
        route.setEstimatedTimeMinutes(estimatedTimeMinutes);
        route.setElevationGain(elevationGain);

        var line = geometryFactory.createLineString(new Coordinate[]{
                new Coordinate(24.1, 49.8),
                new Coordinate(24.2, 49.9),
                new Coordinate(24.3, 50.0),
        });
        RouteGeometry geometry = new RouteGeometry();
        geometry.setRoute(route);
        geometry.setLine(line);
        return geometry;
    }

    private WeatherProperties weatherProperties() {
        return new WeatherProperties(
                "open-meteo",
                null,
                null,
                0,
                null,
                new WeatherProperties.Cache(
                        Duration.ofMinutes(45),
                        Duration.ofHours(4),
                        Duration.ofMinutes(5)
                )
        );
    }

    private WeatherForecast forecast(List<HourlyWeather> hours) {
        return new WeatherForecast(
                49.9,
                24.2,
                180.0,
                "Europe/Kyiv",
                hours,
                List.of(new DailyWeather(
                        LocalDate.parse("2026-07-10"),
                        1,
                        WeatherCondition.PARTLY_CLOUDY,
                        24.0,
                        14.0,
                        LocalDateTime.parse("2026-07-10T06:00"),
                        LocalDateTime.parse("2026-07-10T21:00"),
                        54000L,
                        4.0,
                        0.0,
                        10,
                        12.0,
                        20.0
                )),
                Instant.parse("2026-07-09T06:00:00Z")
        );
    }

    private List<HourlyWeather> goodHours() {
        return List.of(
                hour("2026-07-10T07:00", 10, 0.0, 20.0, 10000.0, 1),
                hour("2026-07-10T08:00", 10, 0.0, 20.0, 10000.0, 1),
                hour("2026-07-10T09:00", 10, 0.0, 20.0, 10000.0, 1)
        );
    }

    private List<HourlyWeather> unsafeHours() {
        return List.of(
                hour("2026-07-10T07:00", 80, 3.0, 60.0, 4000.0, 95),
                hour("2026-07-10T08:00", 80, 3.0, 60.0, 4000.0, 95),
                hour("2026-07-10T09:00", 80, 3.0, 60.0, 4000.0, 95)
        );
    }

    private HourlyWeather hour(
            String time,
            int precipitationProbability,
            double precipitation,
            double gusts,
            double visibility,
            int weatherCode
    ) {
        return new HourlyWeather(
                LocalDateTime.parse(time),
                18.0,
                18.0,
                precipitationProbability,
                precipitation,
                precipitation,
                0.0,
                0.0,
                weatherCode,
                WeatherCondition.fromWeatherCode(weatherCode),
                10.0,
                gusts,
                visibility,
                2.0,
                2500.0
        );
    }
}
