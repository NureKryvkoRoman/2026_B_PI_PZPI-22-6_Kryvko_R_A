package ua.nure.kryvko.hikeway.service.weather;

import org.junit.jupiter.api.Test;
import ua.nure.kryvko.hikeway.model.weather.WeatherCondition;

import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;

class OpenMeteoMapperTest {
    private final OpenMeteoMapper mapper = new OpenMeteoMapper();

    @Test
    void mapsHourlyAndDailyArraysByIndex() {
        var response = new OpenMeteoDtos.ForecastResponse(
                49.84,
                24.03,
                300.0,
                "Europe/Kyiv",
                new OpenMeteoDtos.Hourly(
                        List.of("2026-07-10T07:00", "2026-07-10T08:00"),
                        List.of(18.0, 19.0),
                        List.of(17.0, 18.0),
                        List.of(10, 20),
                        List.of(0.0, 0.1),
                        List.of(0.0, 0.1),
                        List.of(0.0, 0.0),
                        List.of(0.0, 0.0),
                        List.of(1, 2),
                        List.of(8.0, 9.0),
                        List.of(20.0, 21.0),
                        List.of(10000.0, 9000.0),
                        List.of(2.0, 3.0),
                        List.of(2000.0, 2100.0)
                ),
                new OpenMeteoDtos.Daily(
                        List.of("2026-07-10"),
                        List.of(2),
                        List.of(24.0),
                        List.of(14.0),
                        List.of("2026-07-10T05:20"),
                        List.of("2026-07-10T21:10"),
                        List.of(57000.0),
                        List.of(6.0),
                        List.of(2.5),
                        List.of(40),
                        List.of(18.0),
                        List.of(35.0)
                )
        );

        var forecast = mapper.toForecast(response);

        assertEquals(49.84, forecast.latitude());
        assertEquals("Europe/Kyiv", forecast.timezone());
        assertEquals(2, forecast.hourly().size());
        assertEquals(19.0, forecast.hourly().get(1).temperatureC());
        assertEquals(WeatherCondition.PARTLY_CLOUDY, forecast.hourly().get(1).condition());
        assertEquals(21.0, forecast.hourly().get(1).windGustsKmh());
        assertEquals(1, forecast.daily().size());
        assertEquals(WeatherCondition.PARTLY_CLOUDY, forecast.daily().getFirst().condition());
        assertEquals(57000L, forecast.daily().getFirst().daylightDurationSeconds());
    }

    @Test
    void mapsMissingOptionalArraysToNull() {
        var response = new OpenMeteoDtos.ForecastResponse(
                49.84,
                24.03,
                null,
                "Europe/Kyiv",
                new OpenMeteoDtos.Hourly(
                        List.of("2026-07-10T07:00"),
                        null,
                        null,
                        null,
                        null,
                        null,
                        null,
                        null,
                        null,
                        null,
                        null,
                        null,
                        null,
                        null
                ),
                new OpenMeteoDtos.Daily(
                        List.of("2026-07-10"),
                        null,
                        null,
                        null,
                        null,
                        null,
                        null,
                        null,
                        null,
                        null,
                        null,
                        null
                )
        );

        var forecast = mapper.toForecast(response);

        assertNull(forecast.elevationMeters());
        assertNull(forecast.hourly().getFirst().temperatureC());
        assertEquals(WeatherCondition.FORECAST, forecast.hourly().getFirst().condition());
        assertNull(forecast.daily().getFirst().sunrise());
        assertEquals(WeatherCondition.FORECAST, forecast.daily().getFirst().condition());
    }

    @Test
    void mapsProviderWeatherCodesToConditionEnums() {
        assertEquals(WeatherCondition.CLEAR, WeatherCondition.fromWeatherCode(0));
        assertEquals(WeatherCondition.RAIN, WeatherCondition.fromWeatherCode(61));
        assertEquals(WeatherCondition.SNOW, WeatherCondition.fromWeatherCode(71));
        assertEquals(WeatherCondition.THUNDERSTORM, WeatherCondition.fromWeatherCode(95));
        assertEquals(WeatherCondition.FORECAST, WeatherCondition.fromWeatherCode(999));
    }
}
