package ua.nure.kryvko.hikeway.service;

import jakarta.ws.rs.core.Response;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.keycloak.admin.client.Keycloak;
import org.keycloak.admin.client.resource.RealmResource;
import org.keycloak.admin.client.resource.RoleMappingResource;
import org.keycloak.admin.client.resource.RoleResource;
import org.keycloak.admin.client.resource.RoleScopeResource;
import org.keycloak.admin.client.resource.RolesResource;
import org.keycloak.admin.client.resource.UserResource;
import org.keycloak.admin.client.resource.UsersResource;
import org.keycloak.representations.idm.CredentialRepresentation;
import org.keycloak.representations.idm.RoleRepresentation;
import org.keycloak.representations.idm.UserRepresentation;
import org.springframework.dao.DataAccessResourceFailureException;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import ua.nure.kryvko.hikeway.exception.InvalidUserDataException;
import ua.nure.kryvko.hikeway.exception.UserAlreadyExistsException;
import ua.nure.kryvko.hikeway.exception.UserNotFoundException;
import ua.nure.kryvko.hikeway.model.UserEntity;
import ua.nure.kryvko.hikeway.model.UserRole;
import ua.nure.kryvko.hikeway.model.request.AdminCreateUserRequest;
import ua.nure.kryvko.hikeway.model.request.UpdateUserProfileRequest;
import ua.nure.kryvko.hikeway.repository.UserRepository;

import java.net.URI;
import java.util.List;
import java.util.Optional;
import java.util.Set;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoInteractions;
import static org.mockito.Mockito.when;

class UserProfileServiceTest {
    private Keycloak keycloak;
    private RealmResource realm;
    private UsersResource users;
    private UserResource userResource;
    private RolesResource roles;
    private UserRepository userRepository;
    private CurrentUserService currentUserService;
    private UserProfileService service;

    @BeforeEach
    void setUp() {
        keycloak = mock(Keycloak.class);
        realm = mock(RealmResource.class);
        users = mock(UsersResource.class);
        userResource = mock(UserResource.class);
        roles = mock(RolesResource.class);
        userRepository = mock(UserRepository.class);
        currentUserService = mock(CurrentUserService.class);
        service = new UserProfileService(keycloak, "hikeway-keycloak", userRepository, currentUserService);

        when(keycloak.realm("hikeway-keycloak")).thenReturn(realm);
        when(realm.users()).thenReturn(users);
        when(realm.roles()).thenReturn(roles);
        when(users.get("kc-1")).thenReturn(userResource);
        when(users.get("kc-2")).thenReturn(userResource);
        when(userResource.toRepresentation()).thenReturn(new UserRepresentation());
    }

    @Test
    void loadsCurrentProfileByJwtSubject() {
        UserEntity user = user(1L, "kc-1", "old@example.com", "oldname");
        when(currentUserService.id()).thenReturn("kc-1");
        when(userRepository.findByKeycloakId("kc-1")).thenReturn(Optional.of(user));

        var response = service.currentProfile();

        assertEquals(1L, response.id());
        assertEquals("kc-1", response.keycloakId());
        assertEquals("old@example.com", response.email());
        verify(userRepository).findByKeycloakId("kc-1");
    }

    @Test
    void missingCurrentLocalUserThrowsNotFound() {
        when(currentUserService.id()).thenReturn("kc-missing");
        when(userRepository.findByKeycloakId("kc-missing")).thenReturn(Optional.empty());

        assertThrows(UserNotFoundException.class, () -> service.currentProfile());
    }

    @Test
    void updatesOnlyCurrentUser() {
        UserEntity current = user(1L, "kc-1", "old@example.com", "oldname");
        when(currentUserService.id()).thenReturn("kc-1");
        when(userRepository.findByKeycloakId("kc-1")).thenReturn(Optional.of(current));
        when(userRepository.save(current)).thenReturn(current);

        var response = service.updateCurrentProfile(new UpdateUserProfileRequest(
                "new@example.com",
                "newname",
                "New",
                "Name"
        ));

        assertEquals("new@example.com", response.email());
        assertEquals("newname", current.getUsername());
        verify(users).get("kc-1");
        verify(userRepository).save(current);
    }

    @Test
    void duplicateEmailOnUpdateThrowsConflictBeforeKeycloakUpdate() {
        UserEntity user = user(1L, "kc-1", "old@example.com", "oldname");
        when(userRepository.findById(1L)).thenReturn(Optional.of(user));
        when(userRepository.existsByEmailAndIdNot("taken@example.com", 1L)).thenReturn(true);

        assertThrows(UserAlreadyExistsException.class, () -> service.adminUpdate(
                1L,
                new UpdateUserProfileRequest("taken@example.com", null, null, null)
        ));
        verifyNoInteractions(keycloak);
    }

    @Test
    void adminListsUsersWithValidatedPagination() {
        var pageable = PageRequest.of(0, 25);
        when(userRepository.findAll(pageable))
                .thenReturn(new PageImpl<>(List.of(user(1L, "kc-1", "one@example.com", "one")), pageable, 1));

        var response = service.adminList(0, 25);

        assertEquals(1, response.items().size());
        assertEquals(25, response.size());
        verify(userRepository).findAll(pageable);
        assertThrows(InvalidUserDataException.class, () -> service.adminList(0, 101));
    }

    @Test
    void adminCanGetUpdateAndDeleteUser() {
        UserEntity user = user(1L, "kc-1", "old@example.com", "oldname");
        when(userRepository.findById(1L)).thenReturn(Optional.of(user));
        when(userRepository.save(user)).thenReturn(user);
        Response deleteResponse = mock(Response.class);
        when(deleteResponse.getStatus()).thenReturn(204);
        when(users.delete("kc-1")).thenReturn(deleteResponse);

        assertEquals("old@example.com", service.adminGet(1L).email());
        var updated = service.adminUpdate(1L, new UpdateUserProfileRequest(null, "newname", null, null));
        service.adminDelete(1L);

        assertEquals("newname", updated.username());
        verify(users).get("kc-1");
        verify(users).delete("kc-1");
        verify(userRepository).delete(user);
    }

    @Test
    void adminCreateCreatesKeycloakUserSetsPasswordAssignsRolesAndSavesLocalUser() {
        Response createResponse = createdResponse("kc-2");
        when(users.create(any(UserRepresentation.class))).thenReturn(createResponse);
        mockRole(UserRole.ADMIN);
        when(userRepository.save(any(UserEntity.class))).thenAnswer(invocation -> {
            UserEntity saved = invocation.getArgument(0);
            saved.setId(7L);
            return saved;
        });

        var response = service.adminCreate(new AdminCreateUserRequest(
                "admin@example.com",
                "admin",
                "Admin",
                "User",
                "secret",
                Set.of(UserRole.ADMIN)
        ));

        assertEquals(7L, response.id());
        assertEquals("kc-2", response.keycloakId());
        verify(userResource).resetPassword(any(CredentialRepresentation.class));
        verify(userRepository).save(any(UserEntity.class));
    }

    @Test
    void adminCreateRollsBackKeycloakUserWhenLocalSaveFails() {
        Response createResponse = createdResponse("kc-2");
        Response deleteResponse = mock(Response.class);
        when(users.create(any(UserRepresentation.class))).thenReturn(createResponse);
        when(users.delete("kc-2")).thenReturn(deleteResponse);
        when(userRepository.save(any(UserEntity.class)))
                .thenThrow(new DataAccessResourceFailureException("db down"));

        assertThrows(DataAccessResourceFailureException.class, () -> service.adminCreate(new AdminCreateUserRequest(
                "user@example.com",
                "user",
                "User",
                "Name",
                "secret",
                Set.of()
        )));

        verify(users).delete("kc-2");
    }

    @Test
    void adminCreateRejectsDuplicateLocalUserBeforeKeycloakCreate() {
        when(userRepository.existsByEmail("taken@example.com")).thenReturn(true);

        assertThrows(UserAlreadyExistsException.class, () -> service.adminCreate(new AdminCreateUserRequest(
                "taken@example.com",
                "user",
                "User",
                "Name",
                "secret",
                Set.of()
        )));
        verifyNoInteractions(keycloak);
    }

    @Test
    void adminCreateRejectsMissingRequiredFields() {
        assertThrows(InvalidUserDataException.class, () -> service.adminCreate(new AdminCreateUserRequest(
                null,
                "user",
                "User",
                "Name",
                "secret",
                Set.of()
        )));
        verifyNoInteractions(keycloak);
    }

    private UserEntity user(Long id, String keycloakId, String email, String username) {
        UserEntity user = new UserEntity("First", "Last", email, username, keycloakId);
        user.setId(id);
        return user;
    }

    private Response createdResponse(String keycloakId) {
        return Response.created(URI.create("http://localhost/admin/realms/hikeway/users/" + keycloakId)).build();
    }

    private void mockRole(UserRole role) {
        RoleResource roleResource = mock(RoleResource.class);
        RoleMappingResource roleMapping = mock(RoleMappingResource.class);
        RoleScopeResource realmLevel = mock(RoleScopeResource.class);
        RoleRepresentation representation = new RoleRepresentation();
        representation.setName(role.name());
        when(roles.get(role.name())).thenReturn(roleResource);
        when(roleResource.toRepresentation()).thenReturn(representation);
        when(userResource.roles()).thenReturn(roleMapping);
        when(roleMapping.realmLevel()).thenReturn(realmLevel);
    }
}
