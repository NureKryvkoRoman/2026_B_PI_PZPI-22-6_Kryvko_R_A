package ua.nure.kryvko.hikeway.controller;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import ua.nure.kryvko.hikeway.model.Difficulty;
import ua.nure.kryvko.hikeway.model.RouteVisibility;
import ua.nure.kryvko.hikeway.model.Terrain;
import ua.nure.kryvko.hikeway.model.geojson.GeoJsonLineString;
import ua.nure.kryvko.hikeway.model.request.RouteRequests;
import ua.nure.kryvko.hikeway.model.request.RouteSearchRequest;
import ua.nure.kryvko.hikeway.model.response.PageResponse;
import ua.nure.kryvko.hikeway.model.response.RouteContentResponses;
import ua.nure.kryvko.hikeway.model.response.RouteSearchResponse;
import ua.nure.kryvko.hikeway.service.RouteRecommendationService;
import ua.nure.kryvko.hikeway.service.RouteService;

import java.time.Instant;
import java.util.List;
import java.util.Set;
import java.util.UUID;

import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.patch;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

class RoutesControllerTest {
    private RouteService service;
    private RouteRecommendationService recommendationService;
    private MockMvc mockMvc;

    @BeforeEach
    void setUp() {
        service = mock(RouteService.class);
        recommendationService = mock(RouteRecommendationService.class);
        mockMvc = MockMvcBuilders.standaloneSetup(new RoutesController(service, recommendationService)).build();
    }

    @Test
    void searchesRoutesWithDefaultPagination() throws Exception {
        var request = new RouteSearchRequest(
                null,
                null,
                null,
                null,
                null,
                null,
                null,
                null,
                null,
                0,
                50
        );
        when(service.searchRoutes(eq(request)))
                .thenReturn(new PageResponse<>(List.of(response()), 0, 50, 1, 1));

        mockMvc.perform(get("/routes"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.items[0].id").value(7))
                .andExpect(jsonPath("$.items[0].terrain").value("FOREST"))
                .andExpect(jsonPath("$.items[0].geometry.type").value("LineString"))
                .andExpect(jsonPath("$.page").value(0))
                .andExpect(jsonPath("$.size").value(50));

        verify(service).searchRoutes(request);
    }

    @Test
    void parsesAllFilters() throws Exception {
        var request = new RouteSearchRequest(
                5.0,
                12.0,
                60,
                180,
                Set.of(Difficulty.EASY, Difficulty.HARD),
                Set.of(Terrain.FOREST, Terrain.MIXED),
                24.1,
                49.8,
                15.0,
                2,
                25
        );
        when(service.searchRoutes(eq(request)))
                .thenReturn(new PageResponse<>(List.of(), 2, 25, 0, 0));

        mockMvc.perform(get("/routes")
                        .param("minDistanceKm", "5")
                        .param("maxDistanceKm", "12")
                        .param("minEstimatedTimeMinutes", "60")
                        .param("maxEstimatedTimeMinutes", "180")
                        .param("difficulties", "EASY", "HARD")
                        .param("terrains", "FOREST", "MIXED")
                        .param("longitude", "24.1")
                        .param("latitude", "49.8")
                        .param("maxProximityKm", "15")
                        .param("page", "2")
                        .param("size", "25"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.page").value(2))
                .andExpect(jsonPath("$.size").value(25));

        verify(service).searchRoutes(request);
    }

    @Test
    void parsesLocationWithoutExplicitProximity() throws Exception {
        var request = new RouteSearchRequest(
                null,
                null,
                null,
                null,
                null,
                null,
                24.0316,
                49.8429,
                null,
                0,
                50
        );
        when(service.searchRoutes(eq(request)))
                .thenReturn(new PageResponse<>(List.of(), 0, 50, 0, 0));

        mockMvc.perform(get("/routes")
                        .param("longitude", "24.0316")
                        .param("latitude", "49.8429"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.page").value(0))
                .andExpect(jsonPath("$.size").value(50));

        verify(service).searchRoutes(request);
    }

    @Test
    void loadsCurrentUserRoutes() throws Exception {
        when(service.currentUserRoutes(1, 25))
                .thenReturn(new PageResponse<>(List.of(response()), 1, 25, 1, 1));

        mockMvc.perform(get("/routes/mine")
                        .param("page", "1")
                        .param("size", "25"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.items[0].id").value(7))
                .andExpect(jsonPath("$.items[0].visibility").value("PUBLIC"))
                .andExpect(jsonPath("$.page").value(1))
                .andExpect(jsonPath("$.size").value(25));

        verify(service).currentUserRoutes(1, 25);
    }

    @Test
    void loadsRecommendedRoutesWithDefaultPagination() throws Exception {
        when(recommendationService.recommendedRoutes(null, null, null, 0, 10))
                .thenReturn(new PageResponse<>(List.of(response()), 0, 10, 1, 1));

        mockMvc.perform(get("/routes/recommended"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.items[0].id").value(7))
                .andExpect(jsonPath("$.page").value(0))
                .andExpect(jsonPath("$.size").value(10));

        verify(recommendationService).recommendedRoutes(null, null, null, 0, 10);
    }

    @Test
    void parsesRecommendedRouteLocationParams() throws Exception {
        when(recommendationService.recommendedRoutes(24.1, 49.8, 15.0, 1, 5))
                .thenReturn(new PageResponse<>(List.of(), 1, 5, 0, 0));

        mockMvc.perform(get("/routes/recommended")
                        .param("longitude", "24.1")
                        .param("latitude", "49.8")
                        .param("maxProximityKm", "15")
                        .param("page", "1")
                        .param("size", "5"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.page").value(1))
                .andExpect(jsonPath("$.size").value(5));

        verify(recommendationService).recommendedRoutes(24.1, 49.8, 15.0, 1, 5);
    }

    @Test
    void ratesRoute() throws Exception {
        when(service.rate(7L, new RouteRequests.Rating(4)))
                .thenReturn(new RouteContentResponses.Rating(4.0, 1L, 4));

        mockMvc.perform(put("/routes/7/rating")
                        .contentType("application/json")
                        .content("{\"score\":4}"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.averageRating").value(4.0))
                .andExpect(jsonPath("$.ratingCount").value(1))
                .andExpect(jsonPath("$.userRating").value(4));

        verify(service).rate(7L, new RouteRequests.Rating(4));
    }

    @Test
    void removesRouteRating() throws Exception {
        when(service.removeRating(7L)).thenReturn(new RouteContentResponses.Rating(0.0, 0L, null));

        mockMvc.perform(delete("/routes/7/rating"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.ratingCount").value(0));

        verify(service).removeRating(7L);
    }

    @Test
    void listsRouteCommentsWithDefaultPagination() throws Exception {
        RouteContentResponses.Comment comment = comment();
        when(service.comments(7L, 0, 50)).thenReturn(new PageResponse<>(List.of(comment), 0, 50, 1, 1));

        mockMvc.perform(get("/routes/7/comments"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.items[0].id").value(3))
                .andExpect(jsonPath("$.items[0].text").value("Useful route"))
                .andExpect(jsonPath("$.page").value(0))
                .andExpect(jsonPath("$.size").value(50));

        verify(service).comments(7L, 0, 50);
    }

    @Test
    void addsRouteCommentAndReturnsCreated() throws Exception {
        when(service.addComment(7L, new RouteRequests.Comment("Useful route"))).thenReturn(comment());

        mockMvc.perform(post("/routes/7/comments")
                        .contentType("application/json")
                        .content("{\"text\":\"Useful route\"}"))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.id").value(3))
                .andExpect(jsonPath("$.text").value("Useful route"));

        verify(service).addComment(7L, new RouteRequests.Comment("Useful route"));
    }

    @Test
    void updatesRouteComment() throws Exception {
        when(service.updateComment(7L, 3L, new RouteRequests.Comment("Changed")))
                .thenReturn(new RouteContentResponses.Comment(
                        3L,
                        "user-1",
                        "Hiker",
                        true,
                        "Changed",
                        Instant.parse("2026-06-25T10:00:00Z"),
                        Instant.parse("2026-06-25T11:00:00Z")
                ));

        mockMvc.perform(patch("/routes/7/comments/3")
                        .contentType("application/json")
                        .content("{\"text\":\"Changed\"}"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.text").value("Changed"));

        verify(service).updateComment(7L, 3L, new RouteRequests.Comment("Changed"));
    }

    @Test
    void deletesRouteCommentWithNoContent() throws Exception {
        mockMvc.perform(delete("/routes/7/comments/3"))
                .andExpect(status().isNoContent())
                .andExpect(content().string(""));

        verify(service).deleteComment(7L, 3L);
    }

    private RouteSearchResponse response() {
        return new RouteSearchResponse(
                7L,
                "Forest Trail",
                "Public route",
                8.5,
                120,
                Difficulty.EASY,
                180,
                Terrain.FOREST,
                Instant.parse("2026-06-25T10:00:00Z"),
                "user-1",
                new GeoJsonLineString(
                        "LineString",
                        List.of(List.of(24.1, 49.8), List.of(24.2, 49.9))
                ),
                UUID.fromString("11111111-1111-1111-1111-111111111111"),
                RouteVisibility.PUBLIC,
                0.0,
                0L,
                null
        );
    }

    private RouteContentResponses.Comment comment() {
        return new RouteContentResponses.Comment(
                3L,
                "user-1",
                "Hiker",
                true,
                "Useful route",
                Instant.parse("2026-06-25T10:00:00Z"),
                Instant.parse("2026-06-25T10:00:00Z")
        );
    }
}
