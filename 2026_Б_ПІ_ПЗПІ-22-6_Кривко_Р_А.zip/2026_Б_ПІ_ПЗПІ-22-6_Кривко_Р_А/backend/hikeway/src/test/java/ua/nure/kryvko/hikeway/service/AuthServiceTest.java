package ua.nure.kryvko.hikeway.service;

import jakarta.ws.rs.core.Response;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.keycloak.admin.client.Keycloak;
import org.keycloak.admin.client.resource.RealmResource;
import org.keycloak.admin.client.resource.UsersResource;
import org.springframework.dao.DataIntegrityViolationException;
import ua.nure.kryvko.hikeway.exception.InvalidUserDataException;
import ua.nure.kryvko.hikeway.exception.UserAlreadyExistsException;
import ua.nure.kryvko.hikeway.model.UserEntity;
import ua.nure.kryvko.hikeway.model.request.SignUpRequest;
import ua.nure.kryvko.hikeway.repository.UserRepository;

import java.net.URI;

import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

class AuthServiceTest {
    private Keycloak keycloak;
    private RealmResource realm;
    private UsersResource users;
    private UserRepository userRepository;
    private AuthService service;

    @BeforeEach
    void setUp() {
        keycloak = mock(Keycloak.class);
        realm = mock(RealmResource.class);
        users = mock(UsersResource.class);
        userRepository = mock(UserRepository.class);
        service = new AuthService(keycloak, "hikeway-keycloak", userRepository);

        when(keycloak.realm("hikeway-keycloak")).thenReturn(realm);
        when(realm.users()).thenReturn(users);
    }

    @Test
    void signUpRejectsDuplicateEmailBeforeCreatingKeycloakUser() {
        when(userRepository.existsByEmailIgnoreCase("roman@example.com")).thenReturn(true);

        assertThrows(UserAlreadyExistsException.class, () -> service.signUp(request()));

        verify(users, never()).create(any());
    }

    @Test
    void signUpTrimsEmailAndUsernameBeforeDuplicateCheck() {
        when(userRepository.existsByUsernameIgnoreCase("roman")).thenReturn(true);

        assertThrows(UserAlreadyExistsException.class, () -> service.signUp(new SignUpRequest(
                " roman@example.com ",
                "Password1",
                " Roman ",
                " Kryvko ",
                " roman "
        )));

        verify(userRepository).existsByEmailIgnoreCase("roman@example.com");
        verify(userRepository).existsByUsernameIgnoreCase("roman");
        verify(users, never()).create(any());
    }

    @Test
    void signUpRejectsMissingRequiredFields() {
        assertThrows(InvalidUserDataException.class, () -> service.signUp(new SignUpRequest(
                "",
                "Password1",
                "Roman",
                "Kryvko",
                "roman"
        )));

        verify(users, never()).create(any());
    }

    @Test
    void signUpRejectsDuplicateUsernameBeforeCreatingKeycloakUser() {
        when(userRepository.existsByUsernameIgnoreCase("roman")).thenReturn(true);

        assertThrows(UserAlreadyExistsException.class, () -> service.signUp(request()));

        verify(users, never()).create(any());
    }

    @Test
    void signUpRollsBackKeycloakUserWhenDatabaseUniquenessFails() {
        when(users.create(any())).thenReturn(createdResponse("keycloak-user"));
        when(users.delete("keycloak-user")).thenReturn(mock(Response.class));
        when(userRepository.save(any(UserEntity.class)))
                .thenThrow(new DataIntegrityViolationException("duplicate"));

        assertThrows(UserAlreadyExistsException.class, () -> service.signUp(request()));

        verify(users).delete("keycloak-user");
    }

    private SignUpRequest request() {
        return new SignUpRequest(
                "roman@example.com",
                "Password1",
                "Roman",
                "Kryvko",
                "roman"
        );
    }

    private Response createdResponse(String keycloakId) {
        return Response.created(URI.create("http://localhost/admin/realms/hikeway/users/" + keycloakId)).build();
    }
}
