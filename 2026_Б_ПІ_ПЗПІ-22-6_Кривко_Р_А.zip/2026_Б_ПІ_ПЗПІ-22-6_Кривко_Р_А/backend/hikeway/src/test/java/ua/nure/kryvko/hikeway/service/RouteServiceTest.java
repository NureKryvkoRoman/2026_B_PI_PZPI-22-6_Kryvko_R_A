package ua.nure.kryvko.hikeway.service;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.locationtech.jts.geom.Coordinate;
import org.locationtech.jts.geom.GeometryFactory;
import org.mockito.ArgumentCaptor;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.oauth2.jwt.Jwt;
import ua.nure.kryvko.hikeway.exception.InvalidPoiDataException;
import ua.nure.kryvko.hikeway.exception.ForbiddenOperationException;
import ua.nure.kryvko.hikeway.model.*;
import ua.nure.kryvko.hikeway.model.geojson.GeoJsonLineString;
import ua.nure.kryvko.hikeway.model.request.CreateRouteRequest;
import ua.nure.kryvko.hikeway.model.request.RouteRequests;
import ua.nure.kryvko.hikeway.model.request.RouteSearchRequest;
import ua.nure.kryvko.hikeway.repository.RouteGeometryRepository;
import ua.nure.kryvko.hikeway.repository.RouteCommentRepository;
import ua.nure.kryvko.hikeway.repository.RouteRatingRepository;
import ua.nure.kryvko.hikeway.repository.RouteRepository;
import ua.nure.kryvko.hikeway.service.elevation.ElevationService;

import java.time.Instant;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.argThat;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

class RouteServiceTest {
    private final GeometryFactory geometryFactory = new GeometryFactory();
    private RouteRepository routeRepository;
    private RouteGeometryRepository geometryRepository;
    private RoutePoiService routePoiService;
    private ElevationService elevationService;
    private RouteRatingRepository routeRatingRepository;
    private RouteCommentRepository routeCommentRepository;
    private CurrentUserService currentUser;
    private RouteService service;

    @BeforeEach
    void setUp() {
        routeRepository = mock(RouteRepository.class);
        geometryRepository = mock(RouteGeometryRepository.class);
        routePoiService = mock(RoutePoiService.class);
        elevationService = mock(ElevationService.class);
        routeRatingRepository = mock(RouteRatingRepository.class);
        routeCommentRepository = mock(RouteCommentRepository.class);
        currentUser = mock(CurrentUserService.class);
        when(currentUser.id()).thenReturn("user-1");
        when(currentUser.displayName()).thenReturn("Hiker");
        when(routeRatingRepository.aggregateForRoute(anyLong())).thenReturn(new Object[]{0.0, 0L});
        when(routeRatingRepository.findByRouteIdAndUserId(anyLong(), anyString())).thenReturn(Optional.empty());
        service = new RouteService(
                routeRepository,
                geometryRepository,
                routePoiService,
                elevationService,
                routeRatingRepository,
                routeCommentRepository,
                currentUser
        );
        Jwt jwt = new Jwt(
                "token",
                Instant.now(),
                Instant.now().plusSeconds(60),
                Map.of("alg", "none"),
                Map.of("sub", "user-1")
        );
        SecurityContextHolder.getContext().setAuthentication(
                new UsernamePasswordAuthenticationToken(jwt, null)
        );
    }

    @AfterEach
    void tearDown() {
        SecurityContextHolder.clearContext();
    }

    @Test
    void searchesPublishedRoutesAndMapsGeometry() {
        var request = new RouteSearchRequest(
                5.0,
                12.0,
                60,
                180,
                Set.of(Difficulty.EASY),
                Set.of(Terrain.FOREST),
                24.1,
                49.8,
                15.0,
                0,
                50
        );
        when(routeRepository.searchPublishedRoutes(request, PageRequest.of(0, 50)))
                .thenReturn(new PageImpl<>(List.of(routeGeometry()), PageRequest.of(0, 50), 1));

        var response = service.searchRoutes(request);

        assertEquals(1, response.items().size());
        assertEquals(7L, response.items().getFirst().id());
        assertEquals(Terrain.FOREST, response.items().getFirst().terrain());
        assertEquals("LineString", response.items().getFirst().geometry().type());
        assertEquals(List.of(24.1, 49.8), response.items().getFirst().geometry().coordinates().getFirst());
        assertEquals(1, response.totalElements());
        verify(routeRepository).searchPublishedRoutes(request, PageRequest.of(0, 50));
    }

    @Test
    void routeSearchResponseIncludesCurrentUserRatingAggregate() {
        when(routeRepository.searchPublishedRoutes(any(RouteSearchRequest.class), any(PageRequest.class)))
                .thenReturn(new PageImpl<>(List.of(routeGeometry()), PageRequest.of(0, 50), 1));
        when(routeRatingRepository.aggregateForRoute(7L)).thenReturn(new Object[]{4.5, 2L});
        RouteRating rating = new RouteRating();
        rating.setScore(4);
        when(routeRatingRepository.findByRouteIdAndUserId(7L, "user-1")).thenReturn(Optional.of(rating));

        var response = service.searchRoutes(new RouteSearchRequest(
                null,
                null,
                null,
                null,
                null,
                null,
                null,
                null,
                null,
                0,
                50
        ));

        assertEquals(4.5, response.items().getFirst().averageRating());
        assertEquals(2L, response.items().getFirst().ratingCount());
        assertEquals(4, response.items().getFirst().userRating());
    }

    @Test
    void rejectsIncompleteProximityFilter() {
        var request = new RouteSearchRequest(
                null,
                null,
                null,
                null,
                null,
                null,
                24.1,
                null,
                15.0,
                0,
                50
        );

        assertThrows(InvalidPoiDataException.class, () -> service.searchRoutes(request));
    }

    @Test
    void appliesDefaultThirtyKmProximityWhenOnlyLocationIsProvided() {
        var request = new RouteSearchRequest(
                null,
                null,
                null,
                null,
                null,
                null,
                24.0316,
                49.8429,
                null,
                0,
                50
        );
        when(routeRepository.searchPublishedRoutes(
                org.mockito.ArgumentMatchers.any(RouteSearchRequest.class),
                eq(PageRequest.of(0, 50))
        )).thenReturn(new PageImpl<>(List.of(routeGeometry()), PageRequest.of(0, 50), 1));

        service.searchRoutes(request);

        ArgumentCaptor<RouteSearchRequest> requestCaptor = ArgumentCaptor.forClass(RouteSearchRequest.class);
        verify(routeRepository).searchPublishedRoutes(requestCaptor.capture(), eq(PageRequest.of(0, 50)));
        assertEquals(24.0316, requestCaptor.getValue().longitude());
        assertEquals(49.8429, requestCaptor.getValue().latitude());
        assertEquals(30.0, requestCaptor.getValue().maxProximityKm());
    }

    @Test
    void doesNotApplyDefaultProximityWhenOtherFiltersAreProvided() {
        var request = new RouteSearchRequest(
                null,
                null,
                null,
                null,
                Set.of(Difficulty.EASY),
                null,
                24.0316,
                49.8429,
                null,
                0,
                50
        );
        when(routeRepository.searchPublishedRoutes(request, PageRequest.of(0, 50)))
                .thenReturn(new PageImpl<>(List.of(), PageRequest.of(0, 50), 0));

        service.searchRoutes(request);

        verify(routeRepository).searchPublishedRoutes(request, PageRequest.of(0, 50));
    }

    @Test
    void loadsCurrentUserRoutesRegardlessOfVisibility() {
        RouteGeometry privateRoute = routeGeometry(7L, RouteVisibility.PRIVATE);
        RouteGeometry publicRoute = routeGeometry(8L, RouteVisibility.PUBLIC);
        when(geometryRepository.findUserCreatedRoutes("user-1", PageRequest.of(0, 50)))
                .thenReturn(new PageImpl<>(List.of(publicRoute, privateRoute), PageRequest.of(0, 50), 2));

        var response = service.currentUserRoutes(0, 50);

        assertEquals(2, response.items().size());
        assertEquals(RouteVisibility.PUBLIC, response.items().get(0).visibility());
        assertEquals(RouteVisibility.PRIVATE, response.items().get(1).visibility());
        verify(geometryRepository).findUserCreatedRoutes("user-1", PageRequest.of(0, 50));
    }

    @Test
    void rejectsInvalidRangesAndPagination() {
        assertThrows(InvalidPoiDataException.class, () -> service.searchRoutes(new RouteSearchRequest(
                12.0,
                5.0,
                null,
                null,
                null,
                null,
                null,
                null,
                null,
                0,
                50
        )));
        assertThrows(InvalidPoiDataException.class, () -> service.searchRoutes(new RouteSearchRequest(
                null,
                null,
                180,
                60,
                null,
                null,
                null,
                null,
                null,
                0,
                50
        )));
        assertThrows(InvalidPoiDataException.class, () -> service.searchRoutes(new RouteSearchRequest(
                null,
                null,
                null,
                null,
                null,
                null,
                null,
                null,
                null,
                -1,
                50
        )));
    }

    @Test
    void createRouteComputesElevationGainFromGeometry() {
        GeoJsonLineString geometry = new GeoJsonLineString(
                "LineString",
                List.of(List.of(24.0, 49.0), List.of(24.1, 49.1))
        );
        when(elevationService.estimateGain(geometry, 0)).thenReturn(420);
        when(routeRepository.save(any(Route.class))).thenAnswer(invocation -> {
            Route route = invocation.getArgument(0);
            route.setId(9L);
            return route;
        });
        when(geometryRepository.save(any(RouteGeometry.class))).thenAnswer(invocation -> invocation.getArgument(0));
        CreateRouteRequest request = new CreateRouteRequest(
                "Forest Loop",
                "Description",
                8.4,
                175,
                Difficulty.MEDIUM,
                0,
                geometry,
                List.of()
        );

        var response = service.createRoute(request);

        assertEquals(420, response.elevationGain());
        verify(routeRepository).save(argThat(route -> route.getElevationGain() == 420));
        verify(geometryRepository).save(any(RouteGeometry.class));
    }

    @Test
    void ratingUpsertIsPerCurrentUser() {
        Route route = routeGeometry().getRoute();
        when(routeRepository.findById(7L)).thenReturn(Optional.of(route));
        when(routeRatingRepository.aggregateForRoute(7L)).thenReturn(new Object[]{4.0, 1L});
        when(routeRatingRepository.findByRouteIdAndUserId(7L, "user-1"))
                .thenReturn(Optional.empty())
                .thenAnswer(invocation -> {
                    RouteRating rating = new RouteRating();
                    rating.setScore(4);
                    return Optional.of(rating);
                });

        var response = service.rate(7L, new RouteRequests.Rating(4));

        assertEquals(4, response.userRating());
        verify(routeRatingRepository).save(argThat(rating ->
                rating.getRoute() == route && rating.getScore() == 4 && rating.getUserId().equals("user-1")
        ));
    }

    @Test
    void rejectsInvalidRatingBeforePersistence() {
        when(routeRepository.findById(7L)).thenReturn(Optional.of(routeGeometry().getRoute()));

        assertThrows(
                InvalidPoiDataException.class,
                () -> service.rate(7L, new RouteRequests.Rating(6))
        );
        verify(routeRatingRepository, org.mockito.Mockito.never()).save(any());
    }

    @Test
    void removesCurrentUserRatingAndReturnsAggregate() {
        Route route = routeGeometry().getRoute();
        RouteRating rating = new RouteRating();
        when(routeRepository.findById(7L)).thenReturn(Optional.of(route));
        when(routeRatingRepository.findByRouteIdAndUserId(7L, "user-1")).thenReturn(Optional.of(rating));
        when(routeRatingRepository.aggregateForRoute(7L)).thenReturn(new Object[]{0.0, 0L});

        var response = service.removeRating(7L);

        assertEquals(0L, response.ratingCount());
        verify(routeRatingRepository).delete(rating);
    }

    @Test
    void createsTrimmedCommentForCurrentUser() {
        Route route = routeGeometry().getRoute();
        when(routeRepository.findById(7L)).thenReturn(Optional.of(route));
        when(routeCommentRepository.save(any(RouteComment.class))).thenAnswer(invocation -> {
            RouteComment comment = invocation.getArgument(0);
            comment.setId(3L);
            return comment;
        });

        var response = service.addComment(7L, new RouteRequests.Comment("  Useful route  "));

        assertEquals(3L, response.id());
        assertEquals("Useful route", response.text());
        verify(routeCommentRepository).save(argThat(comment ->
                comment.getRoute() == route &&
                        comment.getAuthorId().equals("user-1") &&
                        comment.getAuthorDisplayName().equals("Hiker")
        ));
    }

    @Test
    void rejectsBlankCommentBeforePersistence() {
        when(routeRepository.findById(7L)).thenReturn(Optional.of(routeGeometry().getRoute()));

        assertThrows(
                InvalidPoiDataException.class,
                () -> service.addComment(7L, new RouteRequests.Comment("  "))
        );
        verify(routeCommentRepository, org.mockito.Mockito.never()).save(any());
    }

    @Test
    void listsCommentsNewestFirstThroughRepositorySort() {
        Route route = routeGeometry().getRoute();
        RouteComment comment = routeComment(route, "user-1");
        when(routeRepository.findById(7L)).thenReturn(Optional.of(route));
        when(routeCommentRepository.findByRouteIdAndDeletedFalse(eq(7L), any(PageRequest.class)))
                .thenReturn(new PageImpl<>(List.of(comment), PageRequest.of(0, 50), 1));

        var response = service.comments(7L, 0, 50);

        assertEquals(1, response.items().size());
        assertEquals("Useful route", response.items().getFirst().text());
        verify(routeCommentRepository).findByRouteIdAndDeletedFalse(
                eq(7L),
                argThat(pageable -> pageable.getSort().getOrderFor("createdAt").isDescending())
        );
    }

    @Test
    void rejectsCommentEditByAnotherAuthor() {
        Route route = routeGeometry().getRoute();
        RouteComment comment = routeComment(route, "other-user");
        when(routeRepository.findById(7L)).thenReturn(Optional.of(route));
        when(routeCommentRepository.findByIdAndRouteIdAndDeletedFalse(3L, 7L)).thenReturn(Optional.of(comment));

        assertThrows(
                ForbiddenOperationException.class,
                () -> service.updateComment(7L, 3L, new RouteRequests.Comment("Changed"))
        );
        verify(routeCommentRepository, org.mockito.Mockito.never()).save(any());
    }

    @Test
    void allowsAdminToDeleteAnotherUsersComment() {
        Route route = routeGeometry().getRoute();
        RouteComment comment = routeComment(route, "other-user");
        when(currentUser.isAdmin()).thenReturn(true);
        when(routeRepository.findById(7L)).thenReturn(Optional.of(route));
        when(routeCommentRepository.findByIdAndRouteIdAndDeletedFalse(3L, 7L)).thenReturn(Optional.of(comment));

        service.deleteComment(7L, 3L);

        assertEquals(true, comment.isDeleted());
        verify(routeCommentRepository).save(comment);
    }

    @Test
    void deleteRouteDeletesRatingsAndComments() {
        Route route = routeGeometry().getRoute();
        when(routeRepository.findById(7L)).thenReturn(Optional.of(route));
        when(geometryRepository.findByRoute(route)).thenReturn(Optional.empty());

        service.deleteRoute(7L);

        verify(routeCommentRepository).deleteByRouteId(7L);
        verify(routeRatingRepository).deleteByRouteId(7L);
        verify(routeRepository).delete(route);
    }

    private RouteGeometry routeGeometry() {
        return routeGeometry(7L, RouteVisibility.PUBLIC);
    }

    private RouteGeometry routeGeometry(Long routeId, RouteVisibility visibility) {
        Route route = new Route();
        route.setId(routeId);
        route.setName("Forest Trail");
        route.setDescription("Public route");
        route.setDistanceKm(8.5);
        route.setEstimatedTimeMinutes(120);
        route.setDifficulty(Difficulty.EASY);
        route.setElevationGain(180);
        route.setTerrain(Terrain.FOREST);
        route.setCreatedAt(Instant.parse("2026-06-25T10:00:00Z"));
        route.setCreatedBy("user-1");
        route.setVisibility(visibility);

        var line = geometryFactory.createLineString(new Coordinate[]{
                new Coordinate(24.1, 49.8),
                new Coordinate(24.2, 49.9),
        });
        line.setSRID(4326);

        RouteGeometry geometry = new RouteGeometry();
        geometry.setId(3L);
        geometry.setRoute(route);
        geometry.setLine(line);
        return geometry;
    }

    private RouteComment routeComment(Route route, String authorId) {
        RouteComment comment = new RouteComment();
        comment.setId(3L);
        comment.setRoute(route);
        comment.setAuthorId(authorId);
        comment.setAuthorDisplayName("Author");
        comment.setText("Useful route");
        comment.setCreatedAt(Instant.parse("2026-06-25T10:00:00Z"));
        comment.setUpdatedAt(Instant.parse("2026-06-25T10:00:00Z"));
        return comment;
    }
}
