package ua.nure.kryvko.hikeway.controller;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import ua.nure.kryvko.hikeway.model.request.UpdateUserProfileRequest;
import ua.nure.kryvko.hikeway.model.response.UserProfileResponse;
import ua.nure.kryvko.hikeway.service.UserProfileService;

import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.patch;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

class ProfileControllerTest {
    private UserProfileService service;
    private MockMvc mockMvc;

    @BeforeEach
    void setUp() {
        service = mock(UserProfileService.class);
        mockMvc = MockMvcBuilders.standaloneSetup(new ProfileController(service)).build();
    }

    @Test
    void returnsCurrentProfile() throws Exception {
        when(service.currentProfile()).thenReturn(response());

        mockMvc.perform(get("/profile/me"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id").value(1))
                .andExpect(jsonPath("$.keycloakId").value("kc-1"))
                .andExpect(jsonPath("$.email").value("user@example.com"));
    }

    @Test
    void updatesCurrentProfile() throws Exception {
        var request = new UpdateUserProfileRequest("new@example.com", "newname", "New", "Name");
        when(service.updateCurrentProfile(eq(request))).thenReturn(new UserProfileResponse(
                1L,
                "kc-1",
                "new@example.com",
                "newname",
                "New",
                "Name"
        ));

        mockMvc.perform(patch("/profile/me")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("""
                                {
                                  "email": "new@example.com",
                                  "username": "newname",
                                  "firstName": "New",
                                  "lastName": "Name"
                                }
                                """))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.email").value("new@example.com"))
                .andExpect(jsonPath("$.username").value("newname"));

        verify(service).updateCurrentProfile(request);
    }

    private UserProfileResponse response() {
        return new UserProfileResponse(1L, "kc-1", "user@example.com", "user", "First", "Last");
    }
}
