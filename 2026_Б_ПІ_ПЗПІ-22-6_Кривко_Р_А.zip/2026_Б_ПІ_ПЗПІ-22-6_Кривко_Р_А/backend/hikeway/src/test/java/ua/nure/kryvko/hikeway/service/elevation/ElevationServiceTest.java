package ua.nure.kryvko.hikeway.service.elevation;

import org.locationtech.jts.geom.Coordinate;
import org.junit.jupiter.api.Test;
import ua.nure.kryvko.hikeway.model.geojson.GeoJsonLineString;

import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;

class ElevationServiceTest {
    @Test
    void computesGainWithNoiseThreshold() {
        ElevationService service = new ElevationService(coordinates -> List.of());

        int gain = service.calculateGain(List.of(100.0, 103.0, 110.0, 108.0, 114.0));

        assertEquals(13, gain);
    }

    @Test
    void samplesLongSegmentsAtAboutHundredMetersAndKeepsEndpoint() {
        ElevationService service = new ElevationService(coordinates -> List.of());

        List<Coordinate> samples = service.sample(List.of(
                new Coordinate(24.0, 49.0),
                new Coordinate(24.01, 49.0)
        ));

        assertEquals(new Coordinate(24.0, 49.0), samples.getFirst());
        assertEquals(new Coordinate(24.01, 49.0), samples.getLast());
        assertEquals(true, samples.size() > 2);
    }

    @Test
    void batchesProviderRequestsAndComputesGain() {
        List<Integer> batchSizes = new ArrayList<>();
        ElevationService service = new ElevationService(coordinates -> {
            batchSizes.add(coordinates.size());
            return coordinates.stream()
                    .map(coordinate -> (double) batchSizes.stream().mapToInt(Integer::intValue).sum())
                    .toList();
        });
        List<Coordinate> coordinates = new ArrayList<>();
        for (int index = 0; index < 101; index++) {
            coordinates.add(new Coordinate(24.0 + index * 0.001, 49.0));
        }

        service.estimateGain(coordinates);

        assertEquals(true, batchSizes.size() > 1);
        assertEquals(true, batchSizes.stream().allMatch(size -> size <= 100));
    }

    @Test
    void fallsBackWhenProviderFails() {
        ElevationService service = new ElevationService(coordinates -> {
            throw new RuntimeException("offline");
        });

        int gain = service.estimateGain(
                new GeoJsonLineString(
                        "LineString",
                        List.of(List.of(24.0, 49.0), List.of(24.1, 49.1))
                ),
                42
        );

        assertEquals(42, gain);
    }
}
