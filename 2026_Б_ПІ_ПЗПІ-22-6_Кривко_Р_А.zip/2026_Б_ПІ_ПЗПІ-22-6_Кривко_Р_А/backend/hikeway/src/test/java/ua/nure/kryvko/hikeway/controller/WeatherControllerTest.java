package ua.nure.kryvko.hikeway.controller;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import ua.nure.kryvko.hikeway.model.response.WeatherResponse;
import ua.nure.kryvko.hikeway.model.weather.DailyWeather;
import ua.nure.kryvko.hikeway.model.weather.DaylightWindow;
import ua.nure.kryvko.hikeway.model.weather.HikeRecommendationExplanation;
import ua.nure.kryvko.hikeway.model.weather.HikeStartRecommendation;
import ua.nure.kryvko.hikeway.model.weather.WeatherCondition;
import ua.nure.kryvko.hikeway.service.WeatherService;

import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

class WeatherControllerTest {
    private WeatherService weatherService;
    private MockMvc mockMvc;

    @BeforeEach
    void setUp() {
        weatherService = mock(WeatherService.class);
        mockMvc = MockMvcBuilders.standaloneSetup(new WeatherController(weatherService)).build();
    }

    @Test
    void returnsRouteWeather() throws Exception {
        when(weatherService.getRouteWeather(7L, LocalDate.parse("2026-07-10"))).thenReturn(response());

        mockMvc.perform(get("/weather")
                        .param("routeId", "7")
                        .param("date", "2026-07-10"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.routeId").value(7))
                .andExpect(jsonPath("$.date").value("2026-07-10"))
                .andExpect(jsonPath("$.timezone").value("Europe/Kyiv"))
                .andExpect(jsonPath("$.summary.weatherCode").value(1))
                .andExpect(jsonPath("$.summary.condition").value("PARTLY_CLOUDY"))
                .andExpect(jsonPath("$.daylight.sunrise").value("2026-07-10T06:00:00"))
                .andExpect(jsonPath("$.recommendation.recommendedStartTime").value("2026-07-10T07:00:00"))
                .andExpect(jsonPath("$.recommendation.explanation")
                        .value("RECOMMENDED_WINDOW_AVOIDS_NIGHTTIME_AND_HIGH_RISK_FORECAST_HOURS"))
                .andExpect(jsonPath("$.dataSource").value("open-meteo"));

        verify(weatherService).getRouteWeather(7L, LocalDate.parse("2026-07-10"));
    }

    private WeatherResponse response() {
        DailyWeather daily = new DailyWeather(
                LocalDate.parse("2026-07-10"),
                1,
                WeatherCondition.PARTLY_CLOUDY,
                24.0,
                14.0,
                LocalDateTime.parse("2026-07-10T06:00"),
                LocalDateTime.parse("2026-07-10T21:00"),
                54000L,
                4.0,
                0.0,
                10,
                12.0,
                20.0
        );
        return new WeatherResponse(
                7L,
                49.9,
                24.2,
                180.0,
                LocalDate.parse("2026-07-10"),
                "Europe/Kyiv",
                daily,
                List.of(),
                new DaylightWindow(daily.sunrise(), daily.sunset(), daily.daylightDurationSeconds()),
                List.of(),
                new HikeStartRecommendation(
                        LocalDateTime.parse("2026-07-10T07:00"),
                        LocalDateTime.parse("2026-07-10T09:00"),
                        HikeRecommendationExplanation.RECOMMENDED_WINDOW_AVOIDS_NIGHTTIME_AND_HIGH_RISK_FORECAST_HOURS
                ),
                "open-meteo",
                Instant.parse("2026-07-09T06:00:00Z")
        );
    }
}
