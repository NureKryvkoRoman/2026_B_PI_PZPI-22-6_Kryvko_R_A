package ua.nure.kryvko.hikeway.service.weather;

import org.junit.jupiter.api.Test;
import ua.nure.kryvko.hikeway.config.WeatherProperties;

import java.net.URI;
import java.time.Duration;

import static org.junit.jupiter.api.Assertions.assertTrue;

class OpenMeteoClientTest {
    @Test
    void buildsForecastRequestWithRequiredVariablesAndElevation() {
        var properties = new WeatherProperties(
                "open-meteo",
                new WeatherProperties.OpenMeteo(URI.create("https://example.test/v1")),
                Duration.ofSeconds(5),
                2,
                Duration.ZERO,
                null
        );
        var client = new OpenMeteoClient(properties, new OpenMeteoMapper());

        String uri = client.forecastUri(49.84, 24.03, 300.0).toString();

        assertTrue(uri.startsWith("https://example.test/v1/forecast?"));
        assertTrue(uri.contains("latitude=49.84"));
        assertTrue(uri.contains("longitude=24.03"));
        assertTrue(uri.contains("timezone=auto"));
        assertTrue(uri.contains("forecast_days=16"));
        assertTrue(uri.contains("elevation=300.0"));
        assertTrue(uri.contains("temperature_2m"));
        assertTrue(uri.contains("freezing_level_height"));
        assertTrue(uri.contains("sunrise"));
        assertTrue(uri.contains("wind_gusts_10m_max"));
    }
}
