package ua.nure.kryvko.hikeway.service;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import ua.nure.kryvko.hikeway.exception.InvalidPoiDataException;
import ua.nure.kryvko.hikeway.model.response.PageResponse;
import ua.nure.kryvko.hikeway.model.response.PoiResponses;
import ua.nure.kryvko.hikeway.model.response.RouteSearchResponse;

import java.util.List;

import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

class SearchServiceTest {
    private RouteService routeService;
    private PointOfInterestService poiService;
    private SearchService service;

    @BeforeEach
    void setUp() {
        routeService = mock(RouteService.class);
        poiService = mock(PointOfInterestService.class);
        service = new SearchService(routeService, poiService);
    }

    @Test
    void trimsNameAndSearchesBothResourceTypes() {
        PageResponse<RouteSearchResponse> routePage = new PageResponse<>(List.of(), 0, 20, 0, 0);
        PageResponse<PoiResponses.Summary> poiPage = new PageResponse<>(List.of(), 0, 20, 0, 0);
        when(routeService.searchPublishedRoutesByName("castle", 0, 20)).thenReturn(routePage);
        when(poiService.searchByName("castle", 0, 20)).thenReturn(poiPage);

        service.search("  castle  ", 0, 20);

        verify(routeService).searchPublishedRoutesByName("castle", 0, 20);
        verify(poiService).searchByName("castle", 0, 20);
    }

    @Test
    void rejectsBlankName() {
        assertThrows(InvalidPoiDataException.class, () -> service.search("   ", 0, 20));
    }

    @Test
    void rejectsInvalidPagination() {
        assertThrows(InvalidPoiDataException.class, () -> service.search("castle", -1, 20));
        assertThrows(InvalidPoiDataException.class, () -> service.search("castle", 0, 0));
        assertThrows(InvalidPoiDataException.class, () -> service.search("castle", 0, 101));
    }
}
