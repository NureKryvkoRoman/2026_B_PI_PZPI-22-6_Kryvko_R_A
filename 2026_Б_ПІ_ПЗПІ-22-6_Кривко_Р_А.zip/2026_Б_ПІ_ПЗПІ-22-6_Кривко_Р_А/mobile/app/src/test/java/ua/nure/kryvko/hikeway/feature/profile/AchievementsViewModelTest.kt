package ua.nure.kryvko.hikeway.feature.profile

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.launch
import kotlinx.coroutines.test.StandardTestDispatcher
import kotlinx.coroutines.test.advanceUntilIdle
import kotlinx.coroutines.test.resetMain
import kotlinx.coroutines.test.runCurrent
import kotlinx.coroutines.test.runTest
import kotlinx.coroutines.test.setMain
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Before
import org.junit.Test
import ua.nure.kryvko.hikeway.R
import ua.nure.kryvko.hikeway.data.sync.AchievementDto
import ua.nure.kryvko.hikeway.data.sync.SyncCoordinator
import ua.nure.kryvko.hikeway.data.sync.SyncLocalDataSource
import ua.nure.kryvko.hikeway.data.sync.SyncMetadataStore
import ua.nure.kryvko.hikeway.data.sync.SyncRequestDto
import ua.nure.kryvko.hikeway.data.sync.SyncResponseDto
import ua.nure.kryvko.hikeway.data.sync.SyncTransport
import ua.nure.kryvko.hikeway.domain.achievements.Achievement
import ua.nure.kryvko.hikeway.domain.achievements.AchievementProgressKind
import ua.nure.kryvko.hikeway.domain.achievements.AchievementRepository

@OptIn(ExperimentalCoroutinesApi::class)
class AchievementsViewModelTest {
    private val dispatcher = StandardTestDispatcher()

    @Before
    fun setUp() {
        Dispatchers.setMain(dispatcher)
    }

    @After
    fun tearDown() {
        Dispatchers.resetMain()
    }

    @Test
    fun loadForUserCollectsAchievements() = runTest(dispatcher) {
        val repository = FakeAchievementRepository()
        val viewModel = AchievementsViewModel(repository, syncCoordinator())

        viewModel.loadForUser("user-1")
        advanceUntilIdle()

        assertEquals("user-1", viewModel.uiState.value.activeUserId)
        assertEquals(1, viewModel.uiState.value.achievements.size)
        assertEquals("FIRST_HIKE", viewModel.uiState.value.achievements.first().code)
    }

    @Test
    fun syncAwardsEmitToastEvents() = runTest(dispatcher) {
        val coordinator = syncCoordinator(
            response = response(
                newlyCompletedAchievements = listOf(
                    AchievementDto(
                        id = 1,
                        code = "FIRST_HIKE",
                        name = "First hike",
                        description = "Finish your first hike.",
                        progressValue = 1.0,
                        targetValue = 1.0,
                        completedAt = "2026-07-07T10:00:00Z",
                    )
                )
            )
        )
        val viewModel = AchievementsViewModel(FakeAchievementRepository(), coordinator)
        val events = mutableListOf<AchievementToastEvent>()
        val job = launch {
            viewModel.toastEvents.collect { events += it }
        }
        runCurrent()

        coordinator.synchronize("user-1")
        advanceUntilIdle()

        assertEquals(listOf(AchievementToastEvent(R.string.achievement_first_hike_title)), events)
        job.cancel()
    }
}

private class FakeAchievementRepository : AchievementRepository {
    override fun observeAchievements() = flowOf(
        listOf(
            Achievement(
                code = "FIRST_HIKE",
                titleResId = R.string.achievement_first_hike_title,
                descriptionResId = R.string.achievement_first_hike_description,
                progressValue = 1.0,
                targetValue = 1.0,
                kind = AchievementProgressKind.COUNT,
                completedAtEpochMillis = null,
            )
        )
    )
}

private fun syncCoordinator(
    response: SyncResponseDto = response(),
): SyncCoordinator {
    return SyncCoordinator(
        transport = object : SyncTransport {
            override suspend fun exchange(request: SyncRequestDto): SyncResponseDto = response
        },
        localDataSource = object : SyncLocalDataSource {
            override suspend fun createRequest(cursor: String?, deviceId: String): SyncRequestDto {
                return SyncRequestDto(cursor, deviceId, emptyList(), emptyList())
            }

            override suspend fun apply(response: SyncResponseDto) = Unit
        },
        metadataStore = object : SyncMetadataStore {
            override fun cursor(userId: String): String? = null
            override fun saveCursor(userId: String, cursor: String) = Unit
            override fun deviceId(): String = "device-1"
        },
    )
}

private fun response(
    newlyCompletedAchievements: List<AchievementDto>? = null,
) = SyncResponseDto(
    cursor = "cursor",
    hasMore = false,
    accepted = emptyList(),
    conflicts = emptyList(),
    routeChanges = emptyList(),
    hikeChanges = emptyList(),
    newlyCompletedAchievements = newlyCompletedAchievements,
)
