package ua.nure.kryvko.hikeway.data.hikeplans.reminders

import java.time.LocalDate
import java.time.LocalTime
import java.time.ZoneId
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class HikePlanReminderSchedulerTest {
    @Test
    fun workNameIsStableForPlanId() {
        assertEquals("hike-plan-reminder-42", reminderWorkName(42))
    }

    @Test
    fun delayTargetsEightAmOnPlannedDate() {
        val zone = ZoneId.of("Europe/Berlin")
        val plannedDate = LocalDate.of(2026, 7, 5)
        val now = plannedDate.minusDays(1).atTime(LocalTime.of(8, 0)).atZone(zone).toInstant().toEpochMilli()
        val target = plannedDate.atTime(LocalTime.of(8, 0)).atZone(zone).toInstant().toEpochMilli()

        assertEquals(
            target - now,
            reminderDelayMillis(plannedDate.toEpochDay(), now, zone),
        )
    }

    @Test
    fun delayIsImmediateWhenEightAmAlreadyPassed() {
        val zone = ZoneId.of("Europe/Berlin")
        val plannedDate = LocalDate.of(2026, 7, 5)
        val now = plannedDate.atTime(LocalTime.of(9, 0)).atZone(zone).toInstant().toEpochMilli()

        assertTrue(reminderDelayMillis(plannedDate.toEpochDay(), now, zone) <= 1_000L)
    }
}
