package ua.nure.kryvko.hikeway.domain.safety

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import ua.nure.kryvko.hikeway.core.model.Difficulty
import ua.nure.kryvko.hikeway.core.model.GeoPoint
import ua.nure.kryvko.hikeway.core.model.Route
import ua.nure.kryvko.hikeway.core.model.RouteGeometry
import ua.nure.kryvko.hikeway.core.model.Terrain

class SafetyTest {
    private val buildMessage = BuildSosSmsMessageUseCase()

    @Test
    fun sosMessageIncludesRouteCoordinatesAndMapLink() {
        val message = buildMessage(
            contact = EmergencyContact(name = "Alex", phoneNumber = "+380501112233"),
            username = "roman",
            route = route(),
            location = GeoPoint(longitude = 24.0316, latitude = 49.8429),
        )

        assertEquals("+380501112233", message.phoneNumber)
        assertTrue(message.body.contains("SOS signal from HikeWay."))
        assertTrue(message.body.contains("User: roman"))
        assertTrue(message.body.contains("Route: High Castle Loop"))
        assertTrue(message.body.contains("49.8429, 24.0316"))
        assertTrue(message.body.contains("https://maps.google.com/?q=49.8429,24.0316"))
    }

    @Test
    fun sosMessageHandlesUnavailableLocation() {
        val message = buildMessage(
            contact = EmergencyContact(phoneNumber = "5556", name = null),
            username = "",
            route = route(),
            location = null,
        )

        assertTrue(message.body.contains("User: Unknown user"))
        assertTrue(message.body.contains("Location is unavailable."))
    }
}

private fun route() = Route(
    id = 1,
    name = "High Castle Loop",
    description = "A short loop.",
    distanceKm = 4.8,
    estimatedTimeMinutes = 95,
    difficulty = Difficulty.EASY,
    elevationGainMeters = 140,
    terrain = Terrain.FOREST,
    geometry = RouteGeometry(
        listOf(
            GeoPoint(longitude = 24.0316, latitude = 49.8429),
            GeoPoint(longitude = 24.0394, latitude = 49.8461),
        )
    ),
)
