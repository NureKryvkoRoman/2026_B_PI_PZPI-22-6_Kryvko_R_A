package ua.nure.kryvko.hikeway.data.sync

import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.test.runTest
import org.junit.Assert.assertEquals
import org.junit.Test
import ua.nure.kryvko.hikeway.core.model.RouteVisibility
import ua.nure.kryvko.hikeway.data.achievements.local.AchievementDao
import ua.nure.kryvko.hikeway.data.achievements.local.AchievementEntity
import ua.nure.kryvko.hikeway.data.hikelogging.local.HikeLogDao
import ua.nure.kryvko.hikeway.data.hikelogging.local.HikeLogEntity
import ua.nure.kryvko.hikeway.data.routes.local.RouteDao
import ua.nure.kryvko.hikeway.data.routes.local.RouteEntity
import ua.nure.kryvko.hikeway.domain.auth.CurrentUserProvider

class RoomSyncLocalDataSourceTest {
    @Test
    fun applyRemovesPublishedRoutesFromLocalStorage() = runTest {
        val routeDao = FakeRouteDao()
        routeDao.rows += RouteEntity(
            id = 7,
            ownerUserId = "user-1",
            name = "Local route",
            description = "Created locally",
            distanceKm = 0.5,
            estimatedTimeMinutes = 8,
            difficulty = "EASY",
            elevationGainMeters = 0,
            terrain = "FOREST",
            geometryGeoJson = """{"type":"LineString","coordinates":[[24.0,49.0],[24.1,49.1]]}""",
            clientId = "route-client-1",
            serverId = 42,
            visibility = RouteVisibility.PRIVATE.name,
            syncVersion = 1,
            updatedAtEpochMillis = 1,
            syncState = SyncState.SYNCED.name,
        )
        val dataSource = RoomSyncLocalDataSource(
            routeDao = routeDao,
            hikeLogDao = FakeHikeLogDao(),
            conflictDao = FakeSyncConflictDao(),
            achievementDao = FakeAchievementDao(),
            currentUserProvider = FakeCurrentUserProvider("user-1"),
        )

        dataSource.apply(
            SyncResponseDto(
                cursor = "cursor",
                hasMore = false,
                accepted = emptyList(),
                conflicts = emptyList(),
                routeChanges = listOf(
                    RouteChangeDto(
                        clientId = "route-client-1",
                        serverId = 42,
                        version = 2,
                        name = "Local route",
                        description = "Created locally",
                        distanceKm = 0.5,
                        estimatedTimeMinutes = 8,
                        difficulty = "EASY",
                        elevationGainMeters = 0,
                        terrain = "FOREST",
                        geometry = GeoJsonLineStringDto(
                            coordinates = listOf(
                                listOf(24.0, 49.0),
                                listOf(24.1, 49.1),
                            )
                        ),
                        visibility = RouteVisibility.PUBLIC.name,
                        updatedAt = "2026-07-08T10:00:00Z",
                        deleted = false,
                    )
                ),
                hikeChanges = emptyList(),
                newlyCompletedAchievements = emptyList(),
            )
        )

        assertEquals(emptyList<RouteEntity>(), routeDao.rows)
    }

    @Test
    fun applyStoresCompletedHikeElevationGainFromServer() = runTest {
        val hikeLogDao = FakeHikeLogDao()
        val dataSource = RoomSyncLocalDataSource(
            routeDao = FakeRouteDao(),
            hikeLogDao = hikeLogDao,
            conflictDao = FakeSyncConflictDao(),
            achievementDao = FakeAchievementDao(),
            currentUserProvider = FakeCurrentUserProvider("user-1"),
        )

        dataSource.apply(
            SyncResponseDto(
                cursor = "cursor",
                hasMore = false,
                accepted = emptyList(),
                conflicts = emptyList(),
                routeChanges = emptyList(),
                hikeChanges = listOf(
                    HikeChangeDto(
                        clientId = "hike-client-1",
                        serverId = 100,
                        version = 1,
                        routeClientId = "route-client-1",
                        routeServerId = 42,
                        routeName = "Forest Loop",
                        startedAt = "2026-07-07T08:00:00Z",
                        finishedAt = "2026-07-07T10:00:00Z",
                        activeDurationMillis = 6_600_000,
                        wallClockDurationMillis = 7_200_000,
                        totalDistanceKm = 8.4,
                        elevationGainMeters = 735,
                        path = GeoJsonLineStringDto(
                            coordinates = listOf(
                                listOf(24.0, 49.0),
                                listOf(24.1, 49.1),
                            )
                        ),
                        updatedAt = "2026-07-07T10:00:00Z",
                        deleted = false,
                    )
                ),
                newlyCompletedAchievements = emptyList(),
            )
        )

        val stored = hikeLogDao.rows.single()
        assertEquals("user-1", stored.ownerUserId)
        assertEquals(735, stored.elevationGainMeters)
    }

    @Test
    fun applyStoresNewlyCompletedAchievements() = runTest {
        val achievementDao = FakeAchievementDao()
        val dataSource = RoomSyncLocalDataSource(
            routeDao = FakeRouteDao(),
            hikeLogDao = FakeHikeLogDao(),
            conflictDao = FakeSyncConflictDao(),
            achievementDao = achievementDao,
            currentUserProvider = FakeCurrentUserProvider("user-1"),
        )

        dataSource.apply(
            SyncResponseDto(
                cursor = "cursor",
                hasMore = false,
                accepted = emptyList(),
                conflicts = emptyList(),
                routeChanges = emptyList(),
                hikeChanges = emptyList(),
                newlyCompletedAchievements = listOf(
                    AchievementDto(
                        id = 1,
                        code = "FIRST_HIKE",
                        name = "First hike",
                        description = "Finish your first hike.",
                        progressValue = 1.0,
                        targetValue = 1.0,
                        completedAt = "2026-07-07T10:00:00Z",
                    )
                ),
            )
        )

        val stored = achievementDao.rows.single()
        assertEquals("user-1", stored.ownerUserId)
        assertEquals("FIRST_HIKE", stored.code)
        assertEquals(1.0, stored.progressValue, 0.0)
        assertEquals(1_783_418_400_000, stored.completedAtEpochMillis)
    }
}

private class FakeAchievementDao : AchievementDao {
    val rows = mutableListOf<AchievementEntity>()

    override fun observeAll(ownerUserId: String): Flow<List<AchievementEntity>> {
        return flowOf(rows.filter { it.ownerUserId == ownerUserId })
    }

    override suspend fun upsert(achievement: AchievementEntity): Long {
        rows.removeAll { it.ownerUserId == achievement.ownerUserId && it.code == achievement.code }
        rows += achievement
        return achievement.id
    }

    override suspend fun findByCode(ownerUserId: String, code: String): AchievementEntity? {
        return rows.firstOrNull { it.ownerUserId == ownerUserId && it.code == code }
    }
}

private class FakeRouteDao : RouteDao {
    val rows = mutableListOf<RouteEntity>()

    override suspend fun insert(route: RouteEntity): Long {
        rows += route
        return route.id
    }
    override suspend fun getAll(ownerUserId: String): List<RouteEntity> {
        return rows.filter { it.ownerUserId == ownerUserId }
    }
    override fun observeAll(ownerUserId: String): Flow<List<RouteEntity>> {
        return flowOf(rows.filter { it.ownerUserId == ownerUserId })
    }
    override fun observeCreatedCount(ownerUserId: String): Flow<Int> = flowOf(0)
    override suspend fun getPending(ownerUserId: String): List<RouteEntity> {
        return rows.filter { it.ownerUserId == ownerUserId && it.syncState != SyncState.SYNCED.name }
    }
    override suspend fun findByClientId(ownerUserId: String, clientId: String): RouteEntity? {
        return rows.firstOrNull { it.ownerUserId == ownerUserId && it.clientId == clientId }
    }
    override suspend fun findByServerId(ownerUserId: String, serverId: Long): RouteEntity? {
        return rows.firstOrNull { it.ownerUserId == ownerUserId && it.serverId == serverId }
    }
    override suspend fun findById(ownerUserId: String, id: Long): RouteEntity? {
        return rows.firstOrNull { it.ownerUserId == ownerUserId && it.id == id }
    }
    override suspend fun hardDeleteById(ownerUserId: String, id: Long) {
        rows.removeAll { it.ownerUserId == ownerUserId && it.id == id }
    }
    override suspend fun upsert(route: RouteEntity): Long {
        rows.removeAll { it.ownerUserId == route.ownerUserId && it.clientId == route.clientId }
        rows += route
        return route.id
    }
    override suspend fun update(route: RouteEntity) {
        rows.removeAll { it.ownerUserId == route.ownerUserId && it.id == route.id }
        rows += route
    }
}

private class FakeHikeLogDao : HikeLogDao {
    val rows = mutableListOf<HikeLogEntity>()

    override suspend fun insert(log: HikeLogEntity): Long = log.id
    override fun observeAll(ownerUserId: String): Flow<List<HikeLogEntity>> {
        return flowOf(rows.filter { it.ownerUserId == ownerUserId })
    }
    override suspend fun getAll(ownerUserId: String): List<HikeLogEntity> {
        return rows.filter { it.ownerUserId == ownerUserId }
    }
    override fun observeFinishedCount(ownerUserId: String): Flow<Int> = flowOf(0)
    override fun observeTotalDistanceKm(ownerUserId: String): Flow<Double> = flowOf(0.0)
    override fun observeMaxDistanceKm(ownerUserId: String): Flow<Double> = flowOf(0.0)
    override suspend fun getPending(ownerUserId: String): List<HikeLogEntity> = emptyList()
    override suspend fun findByClientId(ownerUserId: String, clientId: String): HikeLogEntity? {
        return rows.firstOrNull { it.ownerUserId == ownerUserId && it.clientId == clientId }
    }
    override suspend fun upsert(log: HikeLogEntity): Long {
        rows.removeAll { it.ownerUserId == log.ownerUserId && it.clientId == log.clientId }
        rows += log
        return log.id
    }
    override suspend fun update(log: HikeLogEntity) {
        rows.removeAll { it.ownerUserId == log.ownerUserId && it.clientId == log.clientId }
        rows += log
    }
}

private class FakeSyncConflictDao : SyncConflictDao {
    override suspend fun upsert(conflict: SyncConflictEntity) = Unit
    override suspend fun delete(ownerUserId: String, resourceType: String, clientId: String) = Unit
    override suspend fun getAll(ownerUserId: String): List<SyncConflictEntity> = emptyList()
}

private class FakeCurrentUserProvider(userId: String) : CurrentUserProvider {
    override val currentUserId = MutableStateFlow<String?>(userId)
}
