package ua.nure.kryvko.hikeway.feature.saved

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.test.StandardTestDispatcher
import kotlinx.coroutines.test.advanceUntilIdle
import kotlinx.coroutines.test.resetMain
import kotlinx.coroutines.test.runTest
import kotlinx.coroutines.test.setMain
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Before
import org.junit.Test
import ua.nure.kryvko.hikeway.core.model.Difficulty
import ua.nure.kryvko.hikeway.core.model.GeoPoint
import ua.nure.kryvko.hikeway.core.model.Route
import ua.nure.kryvko.hikeway.core.model.RouteGeometry
import ua.nure.kryvko.hikeway.core.model.Terrain
import ua.nure.kryvko.hikeway.domain.offlinemaps.DeleteRouteMapDownloadUseCase
import ua.nure.kryvko.hikeway.domain.offlinemaps.EstimateRouteMapDownloadUseCase
import ua.nure.kryvko.hikeway.domain.offlinemaps.ObserveRouteMapDownloadUseCase
import ua.nure.kryvko.hikeway.domain.offlinemaps.ObserveRouteMapDownloadsUseCase
import ua.nure.kryvko.hikeway.domain.offlinemaps.RefreshRouteMapDownloadsUseCase
import ua.nure.kryvko.hikeway.domain.offlinemaps.RouteMapDownload
import ua.nure.kryvko.hikeway.domain.offlinemaps.RouteMapDownloadEstimate
import ua.nure.kryvko.hikeway.domain.offlinemaps.RouteMapDownloadRepository
import ua.nure.kryvko.hikeway.domain.offlinemaps.StartRouteMapDownloadUseCase
import ua.nure.kryvko.hikeway.domain.offlinemaps.estimateRouteMapDownload

@OptIn(ExperimentalCoroutinesApi::class)
class SavedMapsViewModelTest {
    private val dispatcher = StandardTestDispatcher()
    private lateinit var repository: FakeRouteMapDownloadRepository

    @Before
    fun setUp() {
        Dispatchers.setMain(dispatcher)
        repository = FakeRouteMapDownloadRepository()
    }

    @After
    fun tearDown() {
        Dispatchers.resetMain()
    }

    @Test
    fun preparesEstimateAndStartsDownload() = runTest(dispatcher) {
        val viewModel = viewModel()
        val route = route()
        advanceUntilIdle()

        viewModel.observeRoute(route)
        viewModel.prepareDownload(route)

        assertNotNull(viewModel.uiState.value.pendingEstimate)

        viewModel.confirmDownload()
        advanceUntilIdle()

        assertEquals(listOf(route.id), repository.startedRouteIds)
        assertEquals(null, viewModel.uiState.value.pendingEstimate)
    }

    @Test
    fun deletesDownload() = runTest(dispatcher) {
        val download = fakeDownload(route())
        repository.downloads.value = listOf(download)
        val viewModel = viewModel()
        advanceUntilIdle()

        viewModel.delete(download)
        advanceUntilIdle()

        assertEquals(emptyList<RouteMapDownload>(), repository.downloads.value)
    }

    private fun viewModel() = SavedMapsViewModel(
        observeDownloads = ObserveRouteMapDownloadsUseCase(repository),
        observeDownload = ObserveRouteMapDownloadUseCase(repository),
        estimateDownload = EstimateRouteMapDownloadUseCase(repository),
        startDownload = StartRouteMapDownloadUseCase(repository),
        deleteDownload = DeleteRouteMapDownloadUseCase(repository),
        refreshDownloads = RefreshRouteMapDownloadsUseCase(repository),
    )
}

private class FakeRouteMapDownloadRepository : RouteMapDownloadRepository {
    val downloads = MutableStateFlow<List<RouteMapDownload>>(emptyList())
    val startedRouteIds = mutableListOf<Long>()

    override fun observeAll(): Flow<List<RouteMapDownload>> = downloads

    override fun observeByRoute(route: Route): Flow<RouteMapDownload?> {
        return MutableStateFlow(downloads.value.firstOrNull { it.routeId == route.id })
    }

    override fun estimate(route: Route): RouteMapDownloadEstimate = estimateRouteMapDownload(route)

    override suspend fun start(route: Route) {
        startedRouteIds += route.id
    }

    override suspend fun delete(download: RouteMapDownload) {
        downloads.value = downloads.value.filterNot { it.id == download.id }
    }

    override suspend fun refreshStatuses() = Unit
}

private fun route() = Route(
    id = 1L,
    name = "High Castle Loop",
    description = "A short city-edge climb with a panoramic viewpoint.",
    distanceKm = 4.8,
    estimatedTimeMinutes = 95,
    difficulty = Difficulty.EASY,
    elevationGainMeters = 140,
    terrain = Terrain.FOREST,
    geometry = RouteGeometry(
        listOf(
            GeoPoint(longitude = 24.0316, latitude = 49.8429),
            GeoPoint(longitude = 24.0394, latitude = 49.8461),
        )
    ),
)

private fun fakeDownload(route: Route): RouteMapDownload {
    val estimate = estimateRouteMapDownload(route)
    return RouteMapDownload(
        id = 1L,
        routeKey = "route",
        routeId = route.id,
        routeName = route.name,
        routeGeometry = route.geometry.points,
        bounds = estimate.bounds,
        minZoom = estimate.minZoom,
        maxZoom = estimate.maxZoom,
        mapLibreRegionId = 10L,
        status = ua.nure.kryvko.hikeway.domain.offlinemaps.RouteMapDownloadStatus.READY,
        completedResourceCount = 1L,
        requiredResourceCount = 1L,
        completedResourceSizeBytes = 1L,
        completedTileCount = 1L,
        completedTileSizeBytes = 1L,
        estimatedMinBytes = estimate.minBytes,
        estimatedMaxBytes = estimate.maxBytes,
        errorMessage = null,
        createdAtEpochMillis = 1L,
        updatedAtEpochMillis = 1L,
    )
}
