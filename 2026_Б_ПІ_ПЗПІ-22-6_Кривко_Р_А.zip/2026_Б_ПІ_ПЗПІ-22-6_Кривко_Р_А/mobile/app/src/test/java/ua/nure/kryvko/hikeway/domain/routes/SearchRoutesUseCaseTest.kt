package ua.nure.kryvko.hikeway.domain.routes

import kotlinx.coroutines.test.runTest
import org.junit.Assert.assertEquals
import org.junit.Test
import ua.nure.kryvko.hikeway.core.location.LocationProvider
import ua.nure.kryvko.hikeway.core.model.GeoPoint
import ua.nure.kryvko.hikeway.core.model.Route

class SearchRoutesUseCaseTest {
    @Test
    fun usesCurrentLocationWhenOriginOverrideIsMissing() = runTest {
        val currentLocation = GeoPoint(longitude = 24.0316, latitude = 49.8429)
        val repository = RecordingRouteRepository()
        val useCase = SearchRoutesUseCase(repository, FakeLocationProvider(currentLocation))

        useCase(RouteSearchCriteria())

        assertEquals(currentLocation, repository.origins.single())
    }

    @Test
    fun usesOriginOverrideWhenProvided() = runTest {
        val currentLocation = GeoPoint(longitude = 24.0316, latitude = 49.8429)
        val contextPoint = GeoPoint(longitude = 24.1290, latitude = 49.8170)
        val repository = RecordingRouteRepository()
        val useCase = SearchRoutesUseCase(repository, FakeLocationProvider(currentLocation))

        useCase(RouteSearchCriteria(), originOverride = contextPoint)

        assertEquals(contextPoint, repository.origins.single())
    }

    @Test
    fun recommendedRoutesUseCurrentLocationWhenAvailable() = runTest {
        val currentLocation = GeoPoint(longitude = 24.0316, latitude = 49.8429)
        val repository = RecordingRecommendedRouteRepository()
        val useCase = GetRecommendedRoutesUseCase(repository, FakeLocationProvider(currentLocation))

        useCase()

        assertEquals(currentLocation, repository.origins.single())
    }

    @Test
    fun recommendedRoutesFallbackToNoOriginWhenLocationFails() = runTest {
        val repository = RecordingRecommendedRouteRepository()
        val useCase = GetRecommendedRoutesUseCase(
            repository,
            object : LocationProvider {
                override suspend fun getCurrentLocation(): GeoPoint {
                    error("Location unavailable")
                }
            },
        )

        useCase()

        assertEquals(listOf<GeoPoint?>(null), repository.origins)
    }
}

private class RecordingRouteRepository : RouteRepository {
    val origins = mutableListOf<GeoPoint>()

    override suspend fun search(criteria: RouteSearchCriteria, origin: GeoPoint): List<Route> {
        origins += origin
        return emptyList()
    }
}

private class RecordingRecommendedRouteRepository : RecommendedRouteRepository {
    val origins = mutableListOf<GeoPoint?>()

    override suspend fun recommended(origin: GeoPoint?): List<Route> {
        origins += origin
        return emptyList()
    }
}

private class FakeLocationProvider(
    private val location: GeoPoint,
) : LocationProvider {
    override suspend fun getCurrentLocation(): GeoPoint = location
}
