package ua.nure.kryvko.hikeway.data.routes.remote

import com.google.gson.Gson
import kotlinx.coroutines.test.runTest
import okhttp3.mockwebserver.MockResponse
import okhttp3.mockwebserver.MockWebServer
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import ua.nure.kryvko.hikeway.core.model.Difficulty
import ua.nure.kryvko.hikeway.core.model.GeoPoint
import ua.nure.kryvko.hikeway.core.model.RouteVisibility
import ua.nure.kryvko.hikeway.core.model.Terrain
import ua.nure.kryvko.hikeway.data.services.backend.RouteService
import ua.nure.kryvko.hikeway.data.services.network.ApiException
import ua.nure.kryvko.hikeway.data.services.network.RetrofitFactory
import ua.nure.kryvko.hikeway.domain.routes.RouteSearchCriteria

class RemoteRouteRepositoryTest {
    private lateinit var server: MockWebServer
    private lateinit var repository: RemoteRouteRepository

    @Before
    fun setUp() {
        server = MockWebServer()
        server.start()
        val gson = Gson()
        val service = RetrofitFactory.create(server.url("/").toString(), gson)
            .create(RouteService::class.java)
        repository = RemoteRouteRepository(service, gson)
    }

    @After
    fun tearDown() {
        server.shutdown()
    }

    @Test
    fun searchesRoutesAndMapsGeoJsonCoordinates() = runTest {
        server.enqueue(
            MockResponse().setResponseCode(200).setBody(
                """
                {
                  "items": [
                    {
                      "id": 7,
                      "name": "Forest Trail",
                      "description": "Public route",
                      "distanceKm": 8.5,
                      "estimatedTimeMinutes": 120,
                      "difficulty": "EASY",
                      "elevationGain": 180,
                      "terrain": "FOREST",
                      "createdAt": "2026-06-25T10:00:00Z",
                      "createdBy": "seed-route-owner",
                      "geometry": {
                        "type": "LineString",
                        "coordinates": [[24.1, 49.8], [24.2, 49.9]]
                      }
                    }
                  ],
                  "page": 0,
                  "size": 50,
                  "totalElements": 1,
                  "totalPages": 1
                }
                """.trimIndent()
            )
        )

        val routes = repository.search(
            RouteSearchCriteria(
                distanceKm = 5.0..12.0,
                estimatedTimeMinutes = 60..180,
                difficulties = setOf(Difficulty.EASY, Difficulty.HARD),
                terrains = setOf(Terrain.FOREST, Terrain.MIXED),
                maxProximityKm = 15.0,
            ),
            GeoPoint(longitude = 24.1, latitude = 49.8),
        )

        assertEquals(1, routes.size)
        assertEquals("Forest Trail", routes.single().name)
        assertEquals(Terrain.FOREST, routes.single().terrain)
        assertEquals(180, routes.single().elevationGainMeters)
        assertEquals(GeoPoint(24.1, 49.8), routes.single().geometry.points.first())
        assertEquals(
            "/routes?minDistanceKm=5.0&maxDistanceKm=12.0&minEstimatedTimeMinutes=60" +
                "&maxEstimatedTimeMinutes=180&difficulties=EASY&difficulties=HARD" +
                "&terrains=FOREST&terrains=MIXED&longitude=24.1&latitude=49.8" +
                "&maxProximityKm=15.0&page=0&size=50",
            server.takeRequest().path,
        )
    }

    @Test
    fun sendsLocationWithoutProximityFilter() = runTest {
        server.enqueue(
            MockResponse().setResponseCode(200).setBody(
                """{"items":[],"page":0,"size":50,"totalElements":0,"totalPages":0}"""
            )
        )

        repository.search(RouteSearchCriteria(), GeoPoint(longitude = 24.1, latitude = 49.8))

        assertEquals("/routes?longitude=24.1&latitude=49.8&page=0&size=50", server.takeRequest().path)
    }

    @Test
    fun loadsRecommendedRoutesWithLocation() = runTest {
        server.enqueue(
            MockResponse().setResponseCode(200).setBody(
                """
                {
                  "items": [
                    {
                      "id": 7,
                      "name": "Forest Trail",
                      "description": "Public route",
                      "distanceKm": 8.5,
                      "estimatedTimeMinutes": 120,
                      "difficulty": "EASY",
                      "elevationGain": 180,
                      "terrain": "FOREST",
                      "createdAt": "2026-06-25T10:00:00Z",
                      "createdBy": "seed-route-owner",
                      "geometry": {
                        "type": "LineString",
                        "coordinates": [[24.1, 49.8], [24.2, 49.9]]
                      }
                    }
                  ],
                  "page": 0,
                  "size": 10,
                  "totalElements": 1,
                  "totalPages": 1
                }
                """.trimIndent()
            )
        )

        val routes = repository.recommended(GeoPoint(longitude = 24.1, latitude = 49.8))

        assertEquals(listOf("Forest Trail"), routes.map { it.name })
        assertEquals("/routes/recommended?longitude=24.1&latitude=49.8&page=0&size=10", server.takeRequest().path)
    }

    @Test
    fun loadsRecommendedRoutesWithoutLocation() = runTest {
        server.enqueue(
            MockResponse().setResponseCode(200).setBody(
                """{"items":[],"page":0,"size":10,"totalElements":0,"totalPages":0}"""
            )
        )

        val routes = repository.recommended(null)

        assertTrue(routes.isEmpty())
        assertEquals("/routes/recommended?page=0&size=10", server.takeRequest().path)
    }

    @Test
    fun loadsCurrentUserRoutesAcrossPages() = runTest {
        server.enqueue(
            MockResponse().setResponseCode(200).setBody(
                """
                {
                  "items": [
                    {
                      "id": 9,
                      "name": "Published Ridge",
                      "description": "Visible to everyone",
                      "distanceKm": 10.0,
                      "estimatedTimeMinutes": 180,
                      "difficulty": "MEDIUM",
                      "elevationGain": 420,
                      "terrain": "MOUNTAIN",
                      "createdAt": "2026-06-25T10:00:00Z",
                      "createdBy": "user-1",
                      "clientId": "11111111-1111-1111-1111-111111111111",
                      "visibility": "PUBLIC",
                      "geometry": {
                        "type": "LineString",
                        "coordinates": [[24.1, 49.8], [24.2, 49.9]]
                      }
                    }
                  ],
                  "page": 0,
                  "size": 100,
                  "totalElements": 2,
                  "totalPages": 2
                }
                """.trimIndent()
            )
        )
        server.enqueue(
            MockResponse().setResponseCode(200).setBody(
                """
                {
                  "items": [
                    {
                      "id": 7,
                      "name": "Private Forest",
                      "description": "Only mine",
                      "distanceKm": 4.0,
                      "estimatedTimeMinutes": 70,
                      "difficulty": "EASY",
                      "elevationGain": 120,
                      "terrain": "FOREST",
                      "createdAt": "2026-06-25T10:00:00Z",
                      "createdBy": "user-1",
                      "clientId": "22222222-2222-2222-2222-222222222222",
                      "visibility": "PRIVATE",
                      "geometry": {
                        "type": "LineString",
                        "coordinates": [[24.3, 49.7], [24.4, 49.8]]
                      }
                    }
                  ],
                  "page": 1,
                  "size": 100,
                  "totalElements": 2,
                  "totalPages": 2
                }
                """.trimIndent()
            )
        )

        val routes = repository.currentUserRoutes()

        assertEquals(listOf("Published Ridge", "Private Forest"), routes.map { it.name })
        assertEquals(RouteVisibility.PUBLIC, routes.first().visibility)
        assertEquals(RouteVisibility.PRIVATE, routes.last().visibility)
        assertEquals("/routes/mine?page=0&size=100", server.takeRequest().path)
        assertEquals("/routes/mine?page=1&size=100", server.takeRequest().path)
    }

    @Test
    fun convertsApiFailures() = runTest {
        server.enqueue(MockResponse().setResponseCode(500).setBody("""{"code":"SERVER_ERROR"}"""))

        val error = runCatching {
            repository.search(RouteSearchCriteria(), GeoPoint(longitude = 24.1, latitude = 49.8))
        }.exceptionOrNull()

        assertTrue(error is ApiException)
    }

    @Test
    fun convertsUnauthenticatedResponsesToApiFailures() = runTest {
        server.enqueue(MockResponse().setResponseCode(401).setBody(""))

        val error = runCatching {
            repository.search(RouteSearchCriteria(), GeoPoint(longitude = 24.1, latitude = 49.8))
        }.exceptionOrNull()

        assertTrue(error is ApiException)
        assertEquals(401, (error as ApiException).statusCode)
    }

    @Test
    fun convertsRecommendedRouteFailuresToApiFailures() = runTest {
        server.enqueue(MockResponse().setResponseCode(500).setBody("""{"code":"SERVER_ERROR"}"""))

        val error = runCatching {
            repository.recommended(GeoPoint(longitude = 24.1, latitude = 49.8))
        }.exceptionOrNull()

        assertTrue(error is ApiException)
    }

    @Test
    fun submitsRouteRating() = runTest {
        server.enqueue(
            MockResponse().setResponseCode(200).setBody(
                """{"averageRating":4.0,"ratingCount":1,"userRating":4}"""
            )
        )

        val rating = repository.submitRating(7L, 4)

        assertEquals(4.0, rating.averageRating, 0.0)
        assertEquals(1L, rating.ratingCount)
        assertEquals(4, rating.userRating)
        val request = server.takeRequest()
        assertEquals("/routes/7/rating", request.path)
        assertEquals("PUT", request.method)
        assertEquals("""{"score":4}""", request.body.readUtf8())
    }

    @Test
    fun loadsRouteComments() = runTest {
        server.enqueue(
            MockResponse().setResponseCode(200).setBody(
                """
                {
                  "items": [
                    {
                      "id": 3,
                      "authorId": "user-1",
                      "authorDisplayName": "Hiker",
                      "ownedByCurrentUser": true,
                      "text": "Useful route",
                      "createdAt": "2026-07-08T10:00:00Z",
                      "updatedAt": "2026-07-08T10:00:00Z"
                    }
                  ],
                  "page": 0,
                  "size": 50,
                  "totalElements": 1,
                  "totalPages": 1
                }
                """.trimIndent()
            )
        )

        val comments = repository.getComments(7L)

        assertEquals(listOf("Useful route"), comments.map { it.text })
        assertEquals("/routes/7/comments?page=0&size=50", server.takeRequest().path)
    }

    @Test
    fun addsUpdatesAndDeletesRouteComment() = runTest {
        server.enqueue(
            MockResponse().setResponseCode(201).setBody(
                """{"id":3,"authorId":"user-1","authorDisplayName":"Hiker","ownedByCurrentUser":true,"text":"Useful route","createdAt":null,"updatedAt":null}"""
            )
        )
        server.enqueue(
            MockResponse().setResponseCode(200).setBody(
                """{"id":3,"authorId":"user-1","authorDisplayName":"Hiker","ownedByCurrentUser":true,"text":"Changed","createdAt":null,"updatedAt":null}"""
            )
        )
        server.enqueue(MockResponse().setResponseCode(204))

        val created = repository.addComment(7L, "Useful route")
        val updated = repository.updateComment(7L, 3L, "Changed")
        repository.deleteComment(7L, 3L)

        assertEquals("Useful route", created.text)
        assertEquals("Changed", updated.text)
        val addRequest = server.takeRequest()
        val updateRequest = server.takeRequest()
        val deleteRequest = server.takeRequest()
        assertEquals("/routes/7/comments", addRequest.path)
        assertEquals("POST", addRequest.method)
        assertEquals("""{"text":"Useful route"}""", addRequest.body.readUtf8())
        assertEquals("/routes/7/comments/3", updateRequest.path)
        assertEquals("PATCH", updateRequest.method)
        assertEquals("""{"text":"Changed"}""", updateRequest.body.readUtf8())
        assertEquals("/routes/7/comments/3", deleteRequest.path)
        assertEquals("DELETE", deleteRequest.method)
    }
}
