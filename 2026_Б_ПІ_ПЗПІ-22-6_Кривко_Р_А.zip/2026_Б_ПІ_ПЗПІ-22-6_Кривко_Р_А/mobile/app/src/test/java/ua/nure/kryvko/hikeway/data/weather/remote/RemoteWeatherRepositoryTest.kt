package ua.nure.kryvko.hikeway.data.weather.remote

import com.google.gson.Gson
import java.time.LocalDate
import kotlinx.coroutines.test.runTest
import okhttp3.mockwebserver.MockResponse
import okhttp3.mockwebserver.MockWebServer
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import ua.nure.kryvko.hikeway.data.services.backend.WeatherService
import ua.nure.kryvko.hikeway.data.services.network.ApiException
import ua.nure.kryvko.hikeway.data.services.network.RetrofitFactory

class RemoteWeatherRepositoryTest {
    private lateinit var server: MockWebServer
    private lateinit var repository: RemoteWeatherRepository

    @Before
    fun setUp() {
        server = MockWebServer()
        server.start()
        val gson = Gson()
        val service = RetrofitFactory.create(server.url("/").toString(), gson)
            .create(WeatherService::class.java)
        repository = RemoteWeatherRepository(service, gson)
    }

    @After
    fun tearDown() {
        server.shutdown()
    }

    @Test
    fun loadsWeatherAndMapsBackendResponse() = runTest {
        server.enqueue(
            MockResponse().setResponseCode(200).setBody(
                """
                {
                  "routeId": 1,
                  "latitude": 49.9,
                  "longitude": 24.2,
                  "elevationMeters": 180.0,
                  "date": "2026-07-05",
                  "timezone": "Europe/Kyiv",
                  "summary": {
                    "date": "2026-07-05",
                    "weatherCode": 61,
                    "condition": "RAIN",
                    "temperatureMaxC": 21.0,
                    "temperatureMinC": 12.0,
                    "sunrise": "2026-07-05T06:00",
                    "sunset": "2026-07-05T20:00",
                    "daylightDurationSeconds": 50400,
                    "uvIndexMax": 5.0,
                    "precipitationSumMm": 2.5,
                    "precipitationProbabilityMaxPercent": 40,
                    "windSpeedMaxKmh": 12.0,
                    "windGustsMaxKmh": 28.0
                  },
                  "hourlyForecast": [
                    {
                      "time": "2026-07-05T08:00",
                      "temperatureC": 16.0,
                      "apparentTemperatureC": 15.0,
                      "precipitationProbabilityPercent": 20,
                      "precipitationMm": 0.1,
                      "weatherCode": 61,
                      "condition": "RAIN",
                      "windGustsKmh": 20.0
                    }
                  ],
                  "risks": [
                    {
                      "type": "HEAVY_PRECIPITATION",
                      "severity": "WARNING",
                      "message": "HIGH_CHANCE_OF_HEAVY_PRECIPITATION"
                    }
                  ],
                  "recommendation": {
                    "recommendedStartTime": "2026-07-05T08:00",
                    "expectedReturnTime": "2026-07-05T10:00",
                    "explanation": "RECOMMENDED_WINDOW_AVOIDS_NIGHTTIME_AND_HIGH_RISK_FORECAST_HOURS"
                  },
                  "dataSource": "open-meteo",
                  "lastUpdated": "2026-07-05T06:00:00Z"
                }
                """.trimIndent()
            )
        )

        val weather = repository.getHikePlanWeather(1, LocalDate.parse("2026-07-05"))

        assertEquals("/weather?routeId=1&date=2026-07-05", server.takeRequest().path)
        assertEquals("RAIN", weather.summary.condition)
        assertEquals(21.0, weather.summary.temperatureMaxC)
        assertEquals(1, weather.hourlyForecast.size)
        assertEquals("RAIN", weather.hourlyForecast.single().condition)
        assertEquals("HEAVY_PRECIPITATION", weather.risks.single().type)
        assertEquals("HIGH_CHANCE_OF_HEAVY_PRECIPITATION", weather.risks.single().message)
        assertEquals("open-meteo", weather.dataSource)
        assertEquals("2026-07-05T08:00", weather.recommendation.recommendedStartTime.toString())
        assertEquals(
            "RECOMMENDED_WINDOW_AVOIDS_NIGHTTIME_AND_HIGH_RISK_FORECAST_HOURS",
            weather.recommendation.explanation
        )
    }

    @Test
    fun convertsApiFailures() = runTest {
        server.enqueue(MockResponse().setResponseCode(502).setBody("""{"code":"WEATHER_PROVIDER_ERROR"}"""))

        val error = runCatching {
            repository.getHikePlanWeather(1, LocalDate.parse("2026-07-05"))
        }.exceptionOrNull()

        assertTrue(error is ApiException)
        assertEquals(502, (error as ApiException).statusCode)
    }
}
