package ua.nure.kryvko.hikeway.feature.safety

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.test.StandardTestDispatcher
import kotlinx.coroutines.test.advanceUntilIdle
import kotlinx.coroutines.test.resetMain
import kotlinx.coroutines.test.runTest
import kotlinx.coroutines.test.setMain
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Before
import org.junit.Test
import ua.nure.kryvko.hikeway.core.location.LocationProvider
import ua.nure.kryvko.hikeway.core.location.StubLocationProvider
import ua.nure.kryvko.hikeway.core.model.Difficulty
import ua.nure.kryvko.hikeway.core.model.GeoPoint
import ua.nure.kryvko.hikeway.core.model.Route
import ua.nure.kryvko.hikeway.core.model.RouteGeometry
import ua.nure.kryvko.hikeway.core.model.Terrain
import ua.nure.kryvko.hikeway.domain.routes.GetCurrentLocationUseCase
import ua.nure.kryvko.hikeway.domain.safety.BuildSosSmsMessageUseCase
import ua.nure.kryvko.hikeway.domain.safety.DeletePrimaryEmergencyContactUseCase
import ua.nure.kryvko.hikeway.domain.safety.EmergencyContact
import ua.nure.kryvko.hikeway.domain.safety.EmergencyContactRepository
import ua.nure.kryvko.hikeway.domain.safety.ObservePrimaryEmergencyContactUseCase
import ua.nure.kryvko.hikeway.domain.safety.SavePrimaryEmergencyContactUseCase

@OptIn(ExperimentalCoroutinesApi::class)
class EmergencyContactsViewModelTest {
    private val dispatcher = StandardTestDispatcher()

    @Before
    fun setUp() {
        Dispatchers.setMain(dispatcher)
    }

    @After
    fun tearDown() {
        Dispatchers.resetMain()
    }

    @Test
    fun saveRejectsBlankPhoneNumber() = runTest(dispatcher) {
        val viewModel = viewModel()
        advanceUntilIdle()

        viewModel.save()
        advanceUntilIdle()

        assertEquals("Phone number is required.", viewModel.uiState.value.validationError)
    }

    @Test
    fun saveStoresTrimmedContact() = runTest(dispatcher) {
        val repository = FakeEmergencyContactRepository()
        val viewModel = viewModel(repository = repository)
        advanceUntilIdle()

        viewModel.updateName(" Alex ")
        viewModel.updatePhoneNumber(" 5556 ")
        viewModel.save()
        advanceUntilIdle()

        assertEquals("Alex", repository.contact.value?.name)
        assertEquals("5556", repository.contact.value?.phoneNumber)
    }

    @Test
    fun sosWithoutContactShowsMissingContactMessage() = runTest(dispatcher) {
        val viewModel = viewModel()
        advanceUntilIdle()

        viewModel.requestSosConfirmation()

        assertEquals(
            "Add an emergency contact in Profile before sending SOS.",
            viewModel.uiState.value.message,
        )
    }

    @Test
    fun confirmSosBuildsPendingSmsFromCurrentPosition() = runTest(dispatcher) {
        val repository = FakeEmergencyContactRepository(
            initialContact = EmergencyContact(name = "Alex", phoneNumber = "5556"),
        )
        val viewModel = viewModel(repository = repository)
        advanceUntilIdle()

        viewModel.requestSosConfirmation()
        viewModel.confirmSos(
            username = "roman",
            route = route(),
            currentPosition = GeoPoint(longitude = 24.1, latitude = 49.9),
        )
        advanceUntilIdle()

        val message = viewModel.uiState.value.pendingSosMessage
        assertNotNull(message)
        assertEquals("5556", message?.phoneNumber)
        assertEquals(false, viewModel.uiState.value.isSosConfirmationVisible)
        assertEquals(true, message?.body?.contains("User: roman"))
        assertEquals(true, message?.body?.contains("49.9, 24.1"))
    }

    @Test
    fun confirmSosFallsBackToLocationUseCase() = runTest(dispatcher) {
        val repository = FakeEmergencyContactRepository(
            initialContact = EmergencyContact(name = null, phoneNumber = "5556"),
        )
        val viewModel = viewModel(
            repository = repository,
            locationProvider = StubLocationProvider(GeoPoint(longitude = 30.5, latitude = 50.4)),
        )
        advanceUntilIdle()

        viewModel.confirmSos(username = "roman", route = route(), currentPosition = null)
        advanceUntilIdle()

        assertEquals(true, viewModel.uiState.value.pendingSosMessage?.body?.contains("50.4, 30.5"))
    }

    private fun viewModel(
        repository: FakeEmergencyContactRepository = FakeEmergencyContactRepository(),
        locationProvider: LocationProvider = StubLocationProvider(),
    ) = EmergencyContactsViewModel(
        observePrimaryContact = ObservePrimaryEmergencyContactUseCase(repository),
        savePrimaryContact = SavePrimaryEmergencyContactUseCase(repository),
        deletePrimaryContact = DeletePrimaryEmergencyContactUseCase(repository),
        getCurrentLocation = GetCurrentLocationUseCase(locationProvider),
        buildSosSmsMessage = BuildSosSmsMessageUseCase(),
    )
}

private class FakeEmergencyContactRepository(
    initialContact: EmergencyContact? = null,
) : EmergencyContactRepository {
    val contact = MutableStateFlow(initialContact)

    override fun observePrimaryContact(): Flow<EmergencyContact?> = contact

    override suspend fun savePrimaryContact(name: String?, phoneNumber: String): EmergencyContact {
        return EmergencyContact(id = 1, name = name, phoneNumber = phoneNumber)
            .also { contact.value = it }
    }

    override suspend fun deletePrimaryContact() {
        contact.value = null
    }
}

private fun route() = Route(
    id = 1,
    name = "High Castle Loop",
    description = "A short loop.",
    distanceKm = 4.8,
    estimatedTimeMinutes = 95,
    difficulty = Difficulty.EASY,
    elevationGainMeters = 140,
    terrain = Terrain.FOREST,
    geometry = RouteGeometry(
        listOf(
            GeoPoint(longitude = 24.0316, latitude = 49.8429),
            GeoPoint(longitude = 24.0394, latitude = 49.8461),
        )
    ),
)
