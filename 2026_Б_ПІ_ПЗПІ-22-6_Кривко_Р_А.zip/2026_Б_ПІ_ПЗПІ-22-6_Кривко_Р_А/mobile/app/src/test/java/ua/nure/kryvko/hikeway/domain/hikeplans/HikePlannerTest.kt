package ua.nure.kryvko.hikeway.domain.hikeplans

import java.time.LocalDate
import java.time.LocalTime
import java.time.ZoneId
import java.time.ZonedDateTime
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import ua.nure.kryvko.hikeway.core.model.Difficulty
import ua.nure.kryvko.hikeway.core.model.GeoPoint
import ua.nure.kryvko.hikeway.core.model.Route
import ua.nure.kryvko.hikeway.core.model.RouteGeometry
import ua.nure.kryvko.hikeway.core.model.Terrain
import ua.nure.kryvko.hikeway.domain.hikelogging.TimeProvider

class HikePlannerTest {
    @Test
    fun daylightCalculatorReturnsPlausibleSunriseAndSunset() {
        val daylight = DaylightCalculator().daylightFor(route(), LocalDate.of(2026, 7, 5))

        assertTrue(daylight.sunrise.isBefore(daylight.sunset))
        assertTrue(daylight.sunrise.hour in 3..9)
        assertTrue(daylight.sunset.hour in 16..22)
    }

    @Test
    fun recommendationForTodayIsNotBeforeCurrentTime() {
        val now = ZonedDateTime.of(
            2026,
            7,
            5,
            10,
            0,
            0,
            0,
            ZoneId.systemDefault(),
        ).toInstant().toEpochMilli()
        val recommendation = StartTimeRecommendationCalculator(FakeTimeProvider(now)).recommend(
            route(),
            LocalDate.of(2026, 7, 5),
            DaylightSummary(
                sunrise = LocalTime.of(6, 0),
                sunset = LocalTime.of(20, 0),
            ),
            PlannerWeatherSummary(
                condition = "Good hiking weather",
                temperatureCelsius = 20,
                precipitationRiskPercent = 10,
            ),
        )

        assertNotNull(recommendation.time)
        assertTrue(!recommendation.time!!.isBefore(LocalTime.of(10, 0)))
    }

    @Test
    fun recommendationWarnsWhenRouteDoesNotFitBeforeSunset() {
        val now = ZonedDateTime.of(
            2026,
            7,
            5,
            17,
            30,
            0,
            0,
            ZoneId.systemDefault(),
        ).toInstant().toEpochMilli()
        val recommendation = StartTimeRecommendationCalculator(FakeTimeProvider(now)).recommend(
            route(estimatedTimeMinutes = 180),
            LocalDate.of(2026, 7, 5),
            DaylightSummary(
                sunrise = LocalTime.of(6, 0),
                sunset = LocalTime.of(20, 0),
            ),
            PlannerWeatherSummary(
                condition = "Good hiking weather",
                temperatureCelsius = 20,
                precipitationRiskPercent = 10,
            ),
        )

        assertNull(recommendation.time)
        assertEquals(RecommendedStartWarning.RouteDoesNotFitBeforeSunset, recommendation.warning)
    }

    @Test
    fun recommendationWarnsForHighPrecipitation() {
        val now = ZonedDateTime.of(
            2026,
            7,
            5,
            8,
            0,
            0,
            0,
            ZoneId.systemDefault(),
        ).toInstant().toEpochMilli()
        val recommendation = StartTimeRecommendationCalculator(FakeTimeProvider(now)).recommend(
            route(),
            LocalDate.of(2026, 7, 5),
            DaylightSummary(
                sunrise = LocalTime.of(6, 0),
                sunset = LocalTime.of(20, 0),
            ),
            PlannerWeatherSummary(
                condition = "Rain likely",
                temperatureCelsius = 18,
                precipitationRiskPercent = 80,
                warning = "High precipitation risk.",
            ),
        )

        assertNull(recommendation.time)
        assertEquals(RecommendedStartWarning.Weather("High precipitation risk."), recommendation.warning)
    }

    private fun route(estimatedTimeMinutes: Int = 95) = Route(
        id = 1,
        name = "High Castle Loop",
        description = "A short city-edge climb with a panoramic viewpoint.",
        distanceKm = 4.8,
        estimatedTimeMinutes = estimatedTimeMinutes,
        difficulty = Difficulty.EASY,
        elevationGainMeters = 140,
        terrain = Terrain.FOREST,
        geometry = RouteGeometry(
            listOf(
                GeoPoint(longitude = 24.0316, latitude = 49.8429),
                GeoPoint(longitude = 24.0394, latitude = 49.8461),
            )
        ),
    )
}

private class FakeTimeProvider(private val now: Long) : TimeProvider {
    override fun currentTimeMillis(): Long = now
}
