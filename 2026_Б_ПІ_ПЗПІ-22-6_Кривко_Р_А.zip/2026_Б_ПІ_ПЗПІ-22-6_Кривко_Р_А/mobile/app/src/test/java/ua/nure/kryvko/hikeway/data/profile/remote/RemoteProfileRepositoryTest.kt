package ua.nure.kryvko.hikeway.data.profile.remote

import com.google.gson.Gson
import kotlinx.coroutines.test.runTest
import okhttp3.mockwebserver.MockResponse
import okhttp3.mockwebserver.MockWebServer
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import ua.nure.kryvko.hikeway.data.services.backend.ProfileService
import ua.nure.kryvko.hikeway.data.services.network.ApiException
import ua.nure.kryvko.hikeway.data.services.network.RetrofitFactory
import ua.nure.kryvko.hikeway.domain.profile.UpdateUserProfileRequest

class RemoteProfileRepositoryTest {
    private lateinit var server: MockWebServer
    private lateinit var repository: RemoteProfileRepository

    @Before
    fun setUp() {
        server = MockWebServer()
        server.start()
        val gson = Gson()
        val service = RetrofitFactory.create(server.url("/").toString(), gson)
            .create(ProfileService::class.java)
        repository = RemoteProfileRepository(service, gson)
    }

    @After
    fun tearDown() {
        server.shutdown()
    }

    @Test
    fun loadsCurrentProfile() = runTest {
        server.enqueue(MockResponse().setResponseCode(200).setBody(profileJson(username = "roman")))

        val profile = repository.currentProfile()

        assertEquals(1L, profile.id)
        assertEquals("keycloak-user", profile.keycloakId)
        assertEquals("roman@example.com", profile.email)
        assertEquals("Roman Kryvko", profile.fullName)
        assertEquals("/profile/me", server.takeRequest().path)
    }

    @Test
    fun updatesProfile() = runTest {
        server.enqueue(MockResponse().setResponseCode(200).setBody(profileJson(username = "newroman")))

        val profile = repository.updateProfile(
            UpdateUserProfileRequest(
                email = "new@example.com",
                username = "newroman",
                firstName = "New",
                lastName = "Name",
            )
        )

        val request = server.takeRequest()
        assertEquals("PATCH", request.method)
        assertEquals("/profile/me", request.path)
        assertTrue(request.body.readUtf8().contains("\"username\":\"newroman\""))
        assertEquals("newroman", profile.username)
    }

    @Test
    fun convertsApiFailure() = runTest {
        server.enqueue(
            MockResponse()
                .setResponseCode(409)
                .setBody("""{"code":"USER_ALREADY_EXISTS","message":"User already exists"}""")
        )

        val error = runCatching {
            repository.updateProfile(
                UpdateUserProfileRequest(
                    email = "taken@example.com",
                    username = "taken",
                    firstName = "Roman",
                    lastName = "Kryvko",
                )
            )
        }.exceptionOrNull()

        assertTrue(error is ApiException)
        assertEquals("USER_ALREADY_EXISTS", (error as ApiException).code)
    }
}

private fun profileJson(username: String) = """
    {
      "id": 1,
      "keycloakId": "keycloak-user",
      "email": "roman@example.com",
      "username": "$username",
      "firstName": "Roman",
      "lastName": "Kryvko"
    }
""".trimIndent()
