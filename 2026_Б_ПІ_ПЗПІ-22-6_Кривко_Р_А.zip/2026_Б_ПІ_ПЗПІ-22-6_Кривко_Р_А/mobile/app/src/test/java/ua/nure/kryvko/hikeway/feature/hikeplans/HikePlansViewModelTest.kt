package ua.nure.kryvko.hikeway.feature.hikeplans

import java.time.LocalDate
import java.time.Instant
import java.time.LocalDateTime
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.test.StandardTestDispatcher
import kotlinx.coroutines.test.advanceUntilIdle
import kotlinx.coroutines.test.resetMain
import kotlinx.coroutines.test.runTest
import kotlinx.coroutines.test.setMain
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Before
import org.junit.Test
import ua.nure.kryvko.hikeway.core.model.Difficulty
import ua.nure.kryvko.hikeway.core.model.GeoPoint
import ua.nure.kryvko.hikeway.core.model.Route
import ua.nure.kryvko.hikeway.core.model.RouteGeometry
import ua.nure.kryvko.hikeway.core.model.Terrain
import ua.nure.kryvko.hikeway.domain.hikelogging.TimeProvider
import ua.nure.kryvko.hikeway.domain.hikeplans.DeleteHikePlanUseCase
import ua.nure.kryvko.hikeway.domain.hikeplans.HikePlan
import ua.nure.kryvko.hikeway.domain.hikeplans.HikePlanReminderScheduler
import ua.nure.kryvko.hikeway.domain.hikeplans.HikePlanRepository
import ua.nure.kryvko.hikeway.domain.hikeplans.ObserveHikePlansUseCase
import ua.nure.kryvko.hikeway.domain.hikeplans.SaveHikePlanUseCase
import ua.nure.kryvko.hikeway.domain.weather.DailyPlanWeather
import ua.nure.kryvko.hikeway.domain.weather.GetHikePlanWeatherUseCase
import ua.nure.kryvko.hikeway.domain.weather.HikePlanWeather
import ua.nure.kryvko.hikeway.domain.weather.StartTimeRecommendation
import ua.nure.kryvko.hikeway.domain.weather.WeatherRepository

@OptIn(ExperimentalCoroutinesApi::class)
class HikePlansViewModelTest {
    private val dispatcher = StandardTestDispatcher()
    private lateinit var repository: FakeHikePlanRepository
    private lateinit var weatherRepository: FakeWeatherRepository
    private lateinit var reminderScheduler: FakeHikePlanReminderScheduler

    @Before
    fun setUp() {
        Dispatchers.setMain(dispatcher)
        repository = FakeHikePlanRepository()
        weatherRepository = FakeWeatherRepository()
        reminderScheduler = FakeHikePlanReminderScheduler()
    }

    @After
    fun tearDown() {
        Dispatchers.resetMain()
    }

    @Test
    fun saveDraftSchedulesReminderForSavedPlan() = runTest(dispatcher) {
        val viewModel = viewModel()
        advanceUntilIdle()

        viewModel.openNewPlan(route())
        viewModel.saveDraft()
        advanceUntilIdle()

        assertEquals(1L, reminderScheduler.scheduled.single().id)
        assertEquals("High Castle Loop", reminderScheduler.scheduled.single().routeName)
    }

    @Test
    fun deleteCancelsReminder() = runTest(dispatcher) {
        repository.plans.value = listOf(plan(id = 7))
        val viewModel = viewModel()
        advanceUntilIdle()

        viewModel.delete(7)
        advanceUntilIdle()

        assertEquals(listOf(7L), reminderScheduler.cancelled)
    }

    @Test
    fun openNewPlanLoadsWeather() = runTest(dispatcher) {
        val viewModel = viewModel()
        advanceUntilIdle()

        viewModel.openNewPlan(route())
        advanceUntilIdle()

        val weatherState = viewModel.draftState.value.weatherState as HikePlanWeatherState.Loaded
        assertEquals(1L, weatherState.weather.routeId)
        assertEquals("CLEAR", weatherState.weather.summary.condition)
    }

    @Test
    fun failedWeatherLoadDoesNotBlockSaving() = runTest(dispatcher) {
        weatherRepository.error = RuntimeException("weather failed")
        val viewModel = viewModel()
        advanceUntilIdle()

        viewModel.openNewPlan(route())
        advanceUntilIdle()
        viewModel.saveDraft()
        advanceUntilIdle()

        assertEquals(true, viewModel.draftState.value.weatherState is HikePlanWeatherState.Error)
        assertEquals(1L, reminderScheduler.scheduled.single().id)
    }

    private fun viewModel() = HikePlansViewModel(
        observeHikePlans = ObserveHikePlansUseCase(repository),
        saveHikePlan = SaveHikePlanUseCase(repository),
        deleteHikePlan = DeleteHikePlanUseCase(repository),
        getHikePlanWeather = GetHikePlanWeatherUseCase(weatherRepository),
        timeProvider = FakeTimeProvider(),
        reminderScheduler = reminderScheduler,
    )
}

private class FakeWeatherRepository : WeatherRepository {
    var error: Throwable? = null

    override suspend fun getHikePlanWeather(routeId: Long, date: LocalDate): HikePlanWeather {
        error?.let { throw it }
        return HikePlanWeather(
            routeId = routeId,
            date = date,
            timezone = "Europe/Kyiv",
            summary = DailyPlanWeather(
                weatherCode = 0,
                condition = "CLEAR",
                temperatureMaxC = 22.0,
                temperatureMinC = 12.0,
                sunrise = null,
                sunset = null,
                daylightDurationSeconds = null,
                uvIndexMax = null,
                precipitationSumMm = null,
                precipitationProbabilityMaxPercent = 10,
                windSpeedMaxKmh = null,
                windGustsMaxKmh = null,
            ),
            hourlyForecast = emptyList(),
            risks = emptyList(),
            recommendation = StartTimeRecommendation(
                recommendedStartTime = LocalDateTime.parse("${date}T08:00"),
                expectedReturnTime = LocalDateTime.parse("${date}T10:00"),
                explanation = "RECOMMENDED_WINDOW_AVOIDS_NIGHTTIME_AND_HIGH_RISK_FORECAST_HOURS",
            ),
            dataSource = "open-meteo",
            lastUpdated = Instant.parse("2026-07-05T06:00:00Z"),
        )
    }
}

private class FakeHikePlanRepository : HikePlanRepository {
    val plans = MutableStateFlow<List<HikePlan>>(emptyList())

    override fun observeAll(): Flow<List<HikePlan>> = plans

    override fun observeById(id: Long): Flow<HikePlan?> {
        return MutableStateFlow(plans.value.firstOrNull { it.id == id })
    }

    override suspend fun save(plan: HikePlan): Long {
        val saved = plan.copy(id = if (plan.id == 0L) 1L else plan.id)
        plans.value = plans.value.filterNot { it.id == saved.id } + saved
        return saved.id
    }

    override suspend fun delete(id: Long) {
        plans.value = plans.value.filterNot { it.id == id }
    }
}

private class FakeHikePlanReminderScheduler : HikePlanReminderScheduler {
    val scheduled = mutableListOf<HikePlan>()
    val cancelled = mutableListOf<Long>()

    override fun schedule(plan: HikePlan) {
        scheduled += plan
    }

    override fun cancel(planId: Long) {
        cancelled += planId
    }
}

private class FakeTimeProvider : TimeProvider {
    override fun currentTimeMillis(): Long = 1_783_382_400_000L
}

private fun plan(id: Long) = HikePlan(
    id = id,
    routeId = 1,
    routeName = "High Castle Loop",
    plannedDateEpochDay = LocalDate.of(2026, 7, 5).toEpochDay(),
    checklist = emptyList(),
    routeSnapshot = route(),
)

private fun route() = Route(
    id = 1,
    name = "High Castle Loop",
    description = "A short city-edge climb with a panoramic viewpoint.",
    distanceKm = 4.8,
    estimatedTimeMinutes = 95,
    difficulty = Difficulty.EASY,
    elevationGainMeters = 140,
    terrain = Terrain.FOREST,
    geometry = RouteGeometry(
        listOf(
            GeoPoint(longitude = 24.0316, latitude = 49.8429),
            GeoPoint(longitude = 24.0394, latitude = 49.8461),
        )
    ),
)
