package ua.nure.kryvko.hikeway.data.search.remote

import com.google.gson.Gson
import kotlinx.coroutines.test.runTest
import okhttp3.mockwebserver.MockResponse
import okhttp3.mockwebserver.MockWebServer
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import ua.nure.kryvko.hikeway.core.model.Terrain
import ua.nure.kryvko.hikeway.data.services.backend.SearchService
import ua.nure.kryvko.hikeway.data.services.network.ApiException
import ua.nure.kryvko.hikeway.data.services.network.RetrofitFactory

class RemoteSearchRepositoryTest {
    private lateinit var server: MockWebServer
    private lateinit var repository: RemoteSearchRepository

    @Before
    fun setUp() {
        server = MockWebServer()
        server.start()
        val gson = Gson()
        val service = RetrofitFactory.create(server.url("/").toString(), gson)
            .create(SearchService::class.java)
        repository = RemoteSearchRepository(service, gson)
    }

    @After
    fun tearDown() {
        server.shutdown()
    }

    @Test
    fun searchesRoutesAndPois() = runTest {
        server.enqueue(
            MockResponse().setResponseCode(200).setBody(
                """
                {
                  "routes": {
                    "items": [
                      {
                        "id": 7,
                        "name": "Forest Trail",
                        "description": "Public route",
                        "distanceKm": 8.5,
                        "estimatedTimeMinutes": 120,
                        "difficulty": "EASY",
                        "elevationGain": 180,
                        "terrain": "FOREST",
                        "createdBy": "seed-route-owner",
                        "geometry": {
                          "type": "LineString",
                          "coordinates": [[24.1, 49.8], [24.2, 49.9]]
                        }
                      }
                    ],
                    "page": 0,
                    "size": 20,
                    "totalElements": 1,
                    "totalPages": 1
                  },
                  "pois": {
                    "items": [
                      {
                        "id": 3,
                        "name": "Forest Spring",
                        "description": "Fresh water",
                        "longitude": 24.3,
                        "latitude": 49.7,
                        "ownerId": "owner",
                        "ownerDisplayName": "Owner",
                        "ownedByCurrentUser": false,
                        "averageRating": 4.5,
                        "ratingCount": 2,
                        "userRating": null,
                        "photos": []
                      }
                    ],
                    "page": 0,
                    "size": 20,
                    "totalElements": 1,
                    "totalPages": 1
                  }
                }
                """.trimIndent()
            )
        )

        val results = repository.search("forest")

        assertEquals(1, results.routes.size)
        assertEquals("Forest Trail", results.routes.single().name)
        assertEquals(Terrain.FOREST, results.routes.single().terrain)
        assertEquals(1, results.pointsOfInterest.size)
        assertEquals("Forest Spring", results.pointsOfInterest.single().name)
        assertEquals("/search?name=forest&page=0&size=20", server.takeRequest().path)
    }

    @Test
    fun convertsApiFailures() = runTest {
        server.enqueue(MockResponse().setResponseCode(500).setBody("""{"code":"SERVER_ERROR"}"""))

        val error = runCatching { repository.search("forest") }.exceptionOrNull()

        assertTrue(error is ApiException)
    }
}
