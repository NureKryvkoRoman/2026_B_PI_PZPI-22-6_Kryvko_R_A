package ua.nure.kryvko.hikeway.feature.search

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.test.StandardTestDispatcher
import kotlinx.coroutines.test.advanceUntilIdle
import kotlinx.coroutines.test.resetMain
import kotlinx.coroutines.test.runTest
import kotlinx.coroutines.test.setMain
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Before
import org.junit.Test
import ua.nure.kryvko.hikeway.core.model.Difficulty
import ua.nure.kryvko.hikeway.core.model.GeoPoint
import ua.nure.kryvko.hikeway.core.model.PointOfInterest
import ua.nure.kryvko.hikeway.core.model.Route
import ua.nure.kryvko.hikeway.core.model.RouteGeometry
import ua.nure.kryvko.hikeway.core.model.Terrain
import ua.nure.kryvko.hikeway.domain.search.SearchHikeContentUseCase
import ua.nure.kryvko.hikeway.domain.search.SearchRepository
import ua.nure.kryvko.hikeway.domain.search.SearchResults

@OptIn(ExperimentalCoroutinesApi::class)
class SearchResultsViewModelTest {
    private val dispatcher = StandardTestDispatcher()

    @Before
    fun setUp() {
        Dispatchers.setMain(dispatcher)
    }

    @After
    fun tearDown() {
        Dispatchers.resetMain()
    }

    @Test
    fun searchesAndPublishesResults() = runTest(dispatcher) {
        val repository = FakeSearchRepository()
        val viewModel = viewModel(repository)

        viewModel.search("  forest  ")
        advanceUntilIdle()

        assertEquals("forest", repository.queries.single())
        assertEquals("forest", viewModel.uiState.value.query)
        assertEquals(listOf("Forest Trail"), viewModel.uiState.value.routes.map { it.name })
        assertEquals(listOf("Forest Spring"), viewModel.uiState.value.pointsOfInterest.map { it.name })
        assertFalse(viewModel.uiState.value.isLoading)
    }

    @Test
    fun ignoresBlankSearch() = runTest(dispatcher) {
        val repository = FakeSearchRepository()
        val viewModel = viewModel(repository)

        viewModel.search("   ")
        advanceUntilIdle()

        assertEquals(emptyList<String>(), repository.queries)
        assertEquals(emptyList<Route>(), viewModel.uiState.value.routes)
    }

    @Test
    fun exposesFailureMessage() = runTest(dispatcher) {
        val viewModel = viewModel(FailingSearchRepository())

        viewModel.search("forest")
        advanceUntilIdle()

        assertFalse(viewModel.uiState.value.isLoading)
        assertEquals("Search is unavailable.", viewModel.uiState.value.errorMessage)
    }

    private fun viewModel(repository: SearchRepository): SearchResultsViewModel {
        return SearchResultsViewModel(SearchHikeContentUseCase(repository))
    }

    private class FakeSearchRepository : SearchRepository {
        val queries = mutableListOf<String>()

        override suspend fun search(name: String): SearchResults {
            queries += name
            return SearchResults(
                routes = listOf(route()),
                pointsOfInterest = listOf(poi()),
            )
        }
    }

    private class FailingSearchRepository : SearchRepository {
        override suspend fun search(name: String): SearchResults {
            error("Search is unavailable.")
        }
    }

    private companion object {
        fun route() = Route(
            id = 7,
            name = "Forest Trail",
            description = "Public route",
            distanceKm = 8.5,
            estimatedTimeMinutes = 120,
            difficulty = Difficulty.EASY,
            elevationGainMeters = 180,
            terrain = Terrain.FOREST,
            geometry = RouteGeometry(
                listOf(
                    GeoPoint(24.1, 49.8),
                    GeoPoint(24.2, 49.9),
                )
            ),
        )

        fun poi() = PointOfInterest(
            id = 3,
            name = "Forest Spring",
            description = "Fresh water",
            location = GeoPoint(24.3, 49.7),
        )
    }
}
