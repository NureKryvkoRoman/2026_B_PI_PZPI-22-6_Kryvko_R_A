package ua.nure.kryvko.hikeway.feature.profile

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.test.StandardTestDispatcher
import kotlinx.coroutines.test.advanceUntilIdle
import kotlinx.coroutines.test.resetMain
import kotlinx.coroutines.test.runTest
import kotlinx.coroutines.test.setMain
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Before
import org.junit.Test
import ua.nure.kryvko.hikeway.data.services.network.ApiException
import ua.nure.kryvko.hikeway.domain.profile.GetCurrentProfileUseCase
import ua.nure.kryvko.hikeway.domain.profile.ProfileRepository
import ua.nure.kryvko.hikeway.domain.profile.UpdateCurrentProfileUseCase
import ua.nure.kryvko.hikeway.domain.profile.UpdateUserProfileRequest
import ua.nure.kryvko.hikeway.domain.profile.UserProfile

@OptIn(ExperimentalCoroutinesApi::class)
class ProfileViewModelTest {
    private val dispatcher = StandardTestDispatcher()

    @Before
    fun setUp() {
        Dispatchers.setMain(dispatcher)
    }

    @After
    fun tearDown() {
        Dispatchers.resetMain()
    }

    @Test
    fun loadForUserLoadsProfileIntoDisplayAndEditState() = runTest(dispatcher) {
        val viewModel = viewModel()

        viewModel.loadForUser("keycloak-user")
        advanceUntilIdle()

        val state = viewModel.uiState.value
        assertEquals("roman", state.displayUsername)
        assertEquals("roman@example.com", state.displayEmail)
        assertEquals("Roman Kryvko", state.displayFullName)
        assertEquals("Roman", state.firstName)
    }

    @Test
    fun saveValidatesFieldsBeforeRepositoryCall() = runTest(dispatcher) {
        val repository = FakeProfileRepository()
        val viewModel = viewModel(repository)

        viewModel.loadForUser("keycloak-user")
        advanceUntilIdle()
        viewModel.updateEmail("bad-email")
        viewModel.updateFirstName("")
        viewModel.save()
        advanceUntilIdle()

        assertEquals("Email is invalid.", viewModel.uiState.value.fieldErrors.email)
        assertEquals("First name is required.", viewModel.uiState.value.fieldErrors.firstName)
        assertEquals(null, repository.lastUpdate)
    }

    @Test
    fun saveUpdatesProfileStateFromRepositoryResponse() = runTest(dispatcher) {
        val repository = FakeProfileRepository()
        val viewModel = viewModel(repository)
        var navigatedBack = false

        viewModel.loadForUser("keycloak-user")
        advanceUntilIdle()
        viewModel.updateUsername("newroman")
        viewModel.updateEmail("new@example.com")
        viewModel.save { navigatedBack = true }
        advanceUntilIdle()

        assertEquals(true, navigatedBack)
        assertEquals("newroman", repository.lastUpdate?.username)
        assertEquals("newroman", viewModel.uiState.value.displayUsername)
        assertEquals("Profile saved.", viewModel.uiState.value.successMessage)
    }

    @Test
    fun duplicateConflictShowsUserMessage() = runTest(dispatcher) {
        val repository = FakeProfileRepository(
            updateError = ApiException("User already exists", code = "USER_ALREADY_EXISTS", statusCode = 409)
        )
        val viewModel = viewModel(repository)

        viewModel.loadForUser("keycloak-user")
        advanceUntilIdle()
        viewModel.save()
        advanceUntilIdle()

        assertEquals("Email or username is already in use.", viewModel.uiState.value.errorMessage)
        assertEquals(false, viewModel.uiState.value.isSaving)
    }

    @Test
    fun loadFailureDoesNotClearExistingProfile() = runTest(dispatcher) {
        val repository = FakeProfileRepository()
        val viewModel = viewModel(repository)
        viewModel.loadForUser("keycloak-user")
        advanceUntilIdle()
        repository.loadError = RuntimeException("offline")

        viewModel.refresh()
        advanceUntilIdle()

        assertEquals("roman", viewModel.uiState.value.profile?.username)
        assertEquals("offline", viewModel.uiState.value.errorMessage)
    }

    private fun viewModel(
        repository: FakeProfileRepository = FakeProfileRepository(),
    ) = ProfileViewModel(
        getCurrentProfile = GetCurrentProfileUseCase(repository),
        updateCurrentProfile = UpdateCurrentProfileUseCase(repository),
    )
}

private class FakeProfileRepository(
    var updateError: Throwable? = null,
) : ProfileRepository {
    var profile = UserProfile(
        id = 1,
        keycloakId = "keycloak-user",
        email = "roman@example.com",
        username = "roman",
        firstName = "Roman",
        lastName = "Kryvko",
    )
    var loadError: Throwable? = null
    var lastUpdate: UpdateUserProfileRequest? = null

    override suspend fun currentProfile(): UserProfile {
        loadError?.let { throw it }
        return profile
    }

    override suspend fun updateProfile(request: UpdateUserProfileRequest): UserProfile {
        updateError?.let { throw it }
        lastUpdate = request
        profile = UserProfile(
            id = profile.id,
            keycloakId = profile.keycloakId,
            email = request.email,
            username = request.username,
            firstName = request.firstName,
            lastName = request.lastName,
        )
        return profile
    }
}
