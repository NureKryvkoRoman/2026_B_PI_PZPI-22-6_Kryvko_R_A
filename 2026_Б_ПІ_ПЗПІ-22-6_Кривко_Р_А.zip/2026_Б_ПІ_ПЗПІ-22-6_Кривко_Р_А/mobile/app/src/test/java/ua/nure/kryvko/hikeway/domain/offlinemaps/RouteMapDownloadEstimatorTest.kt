package ua.nure.kryvko.hikeway.domain.offlinemaps

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import ua.nure.kryvko.hikeway.core.model.Difficulty
import ua.nure.kryvko.hikeway.core.model.GeoPoint
import ua.nure.kryvko.hikeway.core.model.Route
import ua.nure.kryvko.hikeway.core.model.RouteGeometry
import ua.nure.kryvko.hikeway.core.model.Terrain

class RouteMapDownloadEstimatorTest {
    @Test
    fun estimatesPaddedBoundsAndSizeRange() {
        val estimate = estimateRouteMapDownload(route())

        assertEquals(10.0, estimate.minZoom, 0.0)
        assertEquals(15.0, estimate.maxZoom, 0.0)
        assertTrue(estimate.bounds.north > 49.8461)
        assertTrue(estimate.bounds.south < 49.8429)
        assertTrue(estimate.bounds.east > 24.0394)
        assertTrue(estimate.bounds.west < 24.0316)
        assertTrue(estimate.tileCount > 0L)
        assertTrue(estimate.minBytes < estimate.maxBytes)
    }
}

private fun route() = Route(
    id = 1L,
    name = "High Castle Loop",
    description = "A short city-edge climb with a panoramic viewpoint.",
    distanceKm = 4.8,
    estimatedTimeMinutes = 95,
    difficulty = Difficulty.EASY,
    elevationGainMeters = 140,
    terrain = Terrain.FOREST,
    geometry = RouteGeometry(
        listOf(
            GeoPoint(longitude = 24.0316, latitude = 49.8429),
            GeoPoint(longitude = 24.0394, latitude = 49.8461),
        )
    ),
)
