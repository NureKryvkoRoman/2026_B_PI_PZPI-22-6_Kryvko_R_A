package ua.nure.kryvko.hikeway.feature.saved

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.test.StandardTestDispatcher
import kotlinx.coroutines.test.advanceUntilIdle
import kotlinx.coroutines.test.resetMain
import kotlinx.coroutines.test.runTest
import kotlinx.coroutines.test.setMain
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Before
import org.junit.Test
import ua.nure.kryvko.hikeway.core.model.Difficulty
import ua.nure.kryvko.hikeway.core.model.GeoPoint
import ua.nure.kryvko.hikeway.core.model.Route
import ua.nure.kryvko.hikeway.core.model.RouteGeometry
import ua.nure.kryvko.hikeway.core.model.Terrain
import ua.nure.kryvko.hikeway.domain.routes.CustomRouteRepository
import ua.nure.kryvko.hikeway.domain.routes.ObserveUserCreatedRoutesUseCase

@OptIn(ExperimentalCoroutinesApi::class)
class UserCreatedRoutesViewModelTest {
    private val dispatcher = StandardTestDispatcher()

    @Before
    fun setUp() {
        Dispatchers.setMain(dispatcher)
    }

    @After
    fun tearDown() {
        Dispatchers.resetMain()
    }

    @Test
    fun observesUserCreatedRoutes() = runTest(dispatcher) {
        val routes = MutableStateFlow(listOf(route()))
        val viewModel = viewModel(FakeCustomRouteRepository(routes))
        advanceUntilIdle()

        assertFalse(viewModel.uiState.value.isLoading)
        assertEquals(listOf(route()), viewModel.uiState.value.routes)
        assertEquals(null, viewModel.uiState.value.errorMessage)
    }

    @Test
    fun exposesErrorWhenRoutesCannotLoad() = runTest(dispatcher) {
        val viewModel = viewModel(FailingCustomRouteRepository())
        advanceUntilIdle()

        assertFalse(viewModel.uiState.value.isLoading)
        assertEquals("Could not load user-created routes.", viewModel.uiState.value.errorMessage)
    }

    private fun viewModel(repository: CustomRouteRepository) = UserCreatedRoutesViewModel(
        observeUserCreatedRoutes = ObserveUserCreatedRoutesUseCase(repository),
    )
}

private class FakeCustomRouteRepository(
    private val routes: MutableStateFlow<List<Route>>,
) : CustomRouteRepository {
    override fun observeAll(): Flow<List<Route>> = routes

    override suspend fun save(route: Route): Long = error("Not used")

    override suspend fun publish(route: Route): Route = error("Not used")

    override suspend fun delete(route: Route) = error("Not used")
}

private class FailingCustomRouteRepository : CustomRouteRepository {
    override fun observeAll(): Flow<List<Route>> = flow { throw IllegalStateException("failed") }

    override suspend fun save(route: Route): Long = error("Not used")

    override suspend fun publish(route: Route): Route = error("Not used")

    override suspend fun delete(route: Route) = error("Not used")
}

private fun route() = Route(
    id = 1,
    name = "High Castle Loop",
    description = "A short city-edge climb with a panoramic viewpoint.",
    distanceKm = 4.8,
    estimatedTimeMinutes = 95,
    difficulty = Difficulty.EASY,
    elevationGainMeters = 140,
    terrain = Terrain.FOREST,
    geometry = RouteGeometry(
        listOf(
            GeoPoint(longitude = 24.0316, latitude = 49.8429),
            GeoPoint(longitude = 24.0394, latitude = 49.8461),
        )
    ),
)
