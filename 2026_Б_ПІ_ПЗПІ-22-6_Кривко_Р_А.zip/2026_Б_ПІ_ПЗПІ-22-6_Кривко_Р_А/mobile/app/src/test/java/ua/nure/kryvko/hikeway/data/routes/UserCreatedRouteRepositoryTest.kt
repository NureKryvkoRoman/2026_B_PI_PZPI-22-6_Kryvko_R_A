package ua.nure.kryvko.hikeway.data.routes

import kotlinx.coroutines.test.runTest
import org.junit.Assert.assertEquals
import org.junit.Test
import ua.nure.kryvko.hikeway.core.model.Difficulty
import ua.nure.kryvko.hikeway.core.model.GeoPoint
import ua.nure.kryvko.hikeway.core.model.Route
import ua.nure.kryvko.hikeway.core.model.RouteGeometry
import ua.nure.kryvko.hikeway.core.model.RouteVisibility
import ua.nure.kryvko.hikeway.core.model.Terrain

class UserCreatedRouteRepositoryTest {
    @Test
    fun mergesRemoteAndLocalRoutesAndDeduplicatesByClientId() = runTest {
        val routes = mergeRoutes(
            remoteRoutes = listOf(
                route(
                    id = 9,
                    name = "Published route",
                    clientId = "remote-client",
                    serverId = 9,
                    visibility = RouteVisibility.PUBLIC,
                ),
                route(
                    id = 10,
                    name = "Stale synced route",
                    clientId = "shared-client",
                    serverId = 10,
                    visibility = RouteVisibility.PRIVATE,
                ),
            ),
            localRoutes = listOf(
                route(id = 1, name = "Local draft"),
                route(
                    id = 2,
                    name = "Fresh synced route",
                    clientId = "shared-client",
                    serverId = 10,
                    visibility = RouteVisibility.PRIVATE,
                )
            ),
        )

        assertEquals(
            listOf("Published route", "Fresh synced route", "Local draft"),
            routes.map { it.name },
        )
    }
}

private fun route(
    id: Long,
    name: String,
    clientId: String? = null,
    serverId: Long? = null,
    visibility: RouteVisibility = RouteVisibility.PRIVATE,
) = Route(
    id = id,
    name = name,
    description = name,
    distanceKm = 1.0,
    estimatedTimeMinutes = 15,
    difficulty = Difficulty.EASY,
    elevationGainMeters = 0,
    terrain = Terrain.FOREST,
    geometry = RouteGeometry(listOf(GeoPoint(longitude = 24.0, latitude = 49.0))),
    clientId = clientId,
    serverId = serverId,
    visibility = visibility,
)
