package ua.nure.kryvko.hikeway.feature.saved

import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onNodeWithContentDescription
import androidx.compose.ui.test.onNodeWithText
import androidx.compose.ui.test.performClick
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import java.time.LocalDate
import java.time.Instant
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import org.junit.Assert.assertEquals
import org.junit.Rule
import org.junit.Test
import ua.nure.kryvko.hikeway.core.model.Difficulty
import ua.nure.kryvko.hikeway.core.model.GeoPoint
import ua.nure.kryvko.hikeway.core.model.Route
import ua.nure.kryvko.hikeway.core.model.RouteGeometry
import ua.nure.kryvko.hikeway.core.model.Terrain
import ua.nure.kryvko.hikeway.domain.hikelogging.HikeLog
import ua.nure.kryvko.hikeway.domain.hikelogging.HikeLogRepository
import ua.nure.kryvko.hikeway.domain.hikelogging.ObserveCompletedHikesUseCase
import ua.nure.kryvko.hikeway.domain.hikelogging.TimeProvider
import ua.nure.kryvko.hikeway.domain.hikeplans.DeleteHikePlanUseCase
import ua.nure.kryvko.hikeway.domain.hikeplans.HikePlan
import ua.nure.kryvko.hikeway.domain.hikeplans.HikePlanChecklistItem
import ua.nure.kryvko.hikeway.domain.hikeplans.HikePlanRepository
import ua.nure.kryvko.hikeway.domain.hikeplans.HikePlanReminderScheduler
import ua.nure.kryvko.hikeway.domain.hikeplans.ObserveHikePlansUseCase
import ua.nure.kryvko.hikeway.domain.hikeplans.SaveHikePlanUseCase
import ua.nure.kryvko.hikeway.domain.weather.DailyPlanWeather
import ua.nure.kryvko.hikeway.domain.weather.GetHikePlanWeatherUseCase
import ua.nure.kryvko.hikeway.domain.weather.HikePlanWeather
import ua.nure.kryvko.hikeway.domain.weather.StartTimeRecommendation
import ua.nure.kryvko.hikeway.domain.weather.WeatherRepository
import ua.nure.kryvko.hikeway.domain.offlinemaps.DeleteRouteMapDownloadUseCase
import ua.nure.kryvko.hikeway.domain.offlinemaps.EstimateRouteMapDownloadUseCase
import ua.nure.kryvko.hikeway.domain.offlinemaps.ObserveRouteMapDownloadUseCase
import ua.nure.kryvko.hikeway.domain.offlinemaps.ObserveRouteMapDownloadsUseCase
import ua.nure.kryvko.hikeway.domain.offlinemaps.RefreshRouteMapDownloadsUseCase
import ua.nure.kryvko.hikeway.domain.offlinemaps.RouteMapBounds
import ua.nure.kryvko.hikeway.domain.offlinemaps.RouteMapDownload
import ua.nure.kryvko.hikeway.domain.offlinemaps.RouteMapDownloadEstimate
import ua.nure.kryvko.hikeway.domain.offlinemaps.RouteMapDownloadRepository
import ua.nure.kryvko.hikeway.domain.offlinemaps.RouteMapDownloadStatus
import ua.nure.kryvko.hikeway.domain.offlinemaps.StartRouteMapDownloadUseCase
import ua.nure.kryvko.hikeway.domain.offlinemaps.estimateRouteMapDownload
import ua.nure.kryvko.hikeway.domain.savedroutes.ObserveSavedRoutesUseCase
import ua.nure.kryvko.hikeway.domain.savedroutes.RemoveSavedRouteUseCase
import ua.nure.kryvko.hikeway.domain.savedroutes.SavedRouteRepository
import ua.nure.kryvko.hikeway.domain.savedroutes.ToggleSavedRouteUseCase
import ua.nure.kryvko.hikeway.domain.savedroutes.savedRouteKey
import ua.nure.kryvko.hikeway.domain.routes.CustomRouteRepository
import ua.nure.kryvko.hikeway.domain.routes.GetRouteUseCase
import ua.nure.kryvko.hikeway.domain.routes.ObserveUserCreatedRoutesUseCase
import ua.nure.kryvko.hikeway.domain.routes.RouteDetailRepository
import ua.nure.kryvko.hikeway.feature.completedhikes.CompletedHikesViewModel
import ua.nure.kryvko.hikeway.feature.hikeplans.HikePlansViewModel
import ua.nure.kryvko.hikeway.ui.theme.HikeWayTheme

class SavedScreenTest {
    @get:Rule
    val composeRule = createComposeRule()

    @Test
    fun switchesSubmenusAndOpensSavedRoute() {
        val savedRepository = FakeSavedRouteRepository(listOf(route()))
        val userCreatedRouteRepository = FakeCustomRouteRepository(listOf(route(name = "My Ridge Route")))
        val hikePlanRepository = FakeHikePlanRepository()
        var openedRoute: Route? = null

        composeRule.setContent {
            HikeWayTheme {
                var selectedTab by remember { mutableStateOf(SavedTab.FINISHED_HIKES) }
                SavedScreen(
                    completedHikesViewModel = CompletedHikesViewModel(
                        ObserveCompletedHikesUseCase(FakeHikeLogRepository()),
                        GetRouteUseCase(FakeRouteDetailRepository()),
                    ),
                    savedRoutesViewModel = SavedRoutesViewModel(
                        observeSavedRoutes = ObserveSavedRoutesUseCase(savedRepository),
                        toggleSavedRoute = ToggleSavedRouteUseCase(savedRepository),
                        removeSavedRoute = RemoveSavedRouteUseCase(savedRepository),
                    ),
                    userCreatedRoutesViewModel = UserCreatedRoutesViewModel(
                        observeUserCreatedRoutes = ObserveUserCreatedRoutesUseCase(userCreatedRouteRepository),
                    ),
                    savedMapsViewModel = savedMapsViewModel(FakeRouteMapDownloadRepository()),
                    hikePlansViewModel = HikePlansViewModel(
                        observeHikePlans = ObserveHikePlansUseCase(hikePlanRepository),
                        saveHikePlan = SaveHikePlanUseCase(hikePlanRepository),
                        deleteHikePlan = DeleteHikePlanUseCase(hikePlanRepository),
                        getHikePlanWeather = GetHikePlanWeatherUseCase(FakeWeatherRepository()),
                        timeProvider = FakeTimeProvider(),
                        reminderScheduler = FakeHikePlanReminderScheduler(),
                    ),
                    selectedTab = selectedTab,
                    onTabSelected = { selectedTab = it },
                    onRouteClick = { openedRoute = it },
                    onHikePlanClick = {},
                )
            }
        }

        composeRule.onNodeWithText("Finished hikes").assertIsDisplayed()
        composeRule.onNodeWithText("User-created routes").performClick()
        composeRule.onNodeWithText("My Ridge Route").assertIsDisplayed()
        composeRule.onNodeWithText("Private").assertIsDisplayed()
        composeRule.onNodeWithText("My Ridge Route").performClick()
        composeRule.runOnIdle {
            assertEquals("My Ridge Route", openedRoute?.name)
        }

        composeRule.onNodeWithText("Saved routes").performClick()
        composeRule.onNodeWithText("High Castle Loop").assertIsDisplayed()
        composeRule.onNodeWithText("High Castle Loop").performClick()
        composeRule.runOnIdle {
            assertEquals("High Castle Loop", openedRoute?.name)
        }

        composeRule.onNodeWithContentDescription("Remove saved route").performClick()
        composeRule.onNodeWithText("No saved routes yet.").assertIsDisplayed()
    }

    @Test
    fun showsOpensAndDeletesHikePlans() {
        val savedRepository = FakeSavedRouteRepository()
        val hikePlanRepository = FakeHikePlanRepository(listOf(hikePlan()))
        var openedPlan: HikePlan? = null

        composeRule.setContent {
            HikeWayTheme {
                var selectedTab by remember { mutableStateOf(SavedTab.FINISHED_HIKES) }
                SavedScreen(
                    completedHikesViewModel = CompletedHikesViewModel(
                        ObserveCompletedHikesUseCase(FakeHikeLogRepository()),
                        GetRouteUseCase(FakeRouteDetailRepository()),
                    ),
                    savedRoutesViewModel = SavedRoutesViewModel(
                        observeSavedRoutes = ObserveSavedRoutesUseCase(savedRepository),
                        toggleSavedRoute = ToggleSavedRouteUseCase(savedRepository),
                        removeSavedRoute = RemoveSavedRouteUseCase(savedRepository),
                    ),
                    userCreatedRoutesViewModel = UserCreatedRoutesViewModel(
                        observeUserCreatedRoutes = ObserveUserCreatedRoutesUseCase(FakeCustomRouteRepository()),
                    ),
                    savedMapsViewModel = savedMapsViewModel(FakeRouteMapDownloadRepository()),
                    hikePlansViewModel = HikePlansViewModel(
                        observeHikePlans = ObserveHikePlansUseCase(hikePlanRepository),
                        saveHikePlan = SaveHikePlanUseCase(hikePlanRepository),
                        deleteHikePlan = DeleteHikePlanUseCase(hikePlanRepository),
                        getHikePlanWeather = GetHikePlanWeatherUseCase(FakeWeatherRepository()),
                        timeProvider = FakeTimeProvider(),
                        reminderScheduler = FakeHikePlanReminderScheduler(),
                    ),
                    selectedTab = selectedTab,
                    onTabSelected = { selectedTab = it },
                    onRouteClick = {},
                    onHikePlanClick = { openedPlan = it },
                )
            }
        }

        composeRule.onNodeWithText("Hike plans").performClick()
        composeRule.onNodeWithText("High Castle Loop").assertIsDisplayed()
        composeRule.onNodeWithText("Planned date: 2026-07-05").assertIsDisplayed()
        composeRule.onNodeWithText("1/2 packed").assertIsDisplayed()

        composeRule.onNodeWithText("High Castle Loop").performClick()
        composeRule.runOnIdle {
            assertEquals("High Castle Loop", openedPlan?.routeName)
        }

        composeRule.onNodeWithContentDescription("Delete hike plan").performClick()
        composeRule.onNodeWithText("No hike plans yet.").assertIsDisplayed()
    }

    @Test
    fun showsSavedMapsAndDeletesDownload() {
        val savedRepository = FakeSavedRouteRepository()
        val hikePlanRepository = FakeHikePlanRepository()
        val mapRepository = FakeRouteMapDownloadRepository(listOf(routeMapDownload()))

        composeRule.setContent {
            HikeWayTheme {
                var selectedTab by remember { mutableStateOf(SavedTab.FINISHED_HIKES) }
                SavedScreen(
                    completedHikesViewModel = CompletedHikesViewModel(
                        ObserveCompletedHikesUseCase(FakeHikeLogRepository()),
                        GetRouteUseCase(FakeRouteDetailRepository()),
                    ),
                    savedRoutesViewModel = SavedRoutesViewModel(
                        observeSavedRoutes = ObserveSavedRoutesUseCase(savedRepository),
                        toggleSavedRoute = ToggleSavedRouteUseCase(savedRepository),
                        removeSavedRoute = RemoveSavedRouteUseCase(savedRepository),
                    ),
                    userCreatedRoutesViewModel = UserCreatedRoutesViewModel(
                        observeUserCreatedRoutes = ObserveUserCreatedRoutesUseCase(FakeCustomRouteRepository()),
                    ),
                    savedMapsViewModel = savedMapsViewModel(mapRepository),
                    hikePlansViewModel = HikePlansViewModel(
                        observeHikePlans = ObserveHikePlansUseCase(hikePlanRepository),
                        saveHikePlan = SaveHikePlanUseCase(hikePlanRepository),
                        deleteHikePlan = DeleteHikePlanUseCase(hikePlanRepository),
                        getHikePlanWeather = GetHikePlanWeatherUseCase(FakeWeatherRepository()),
                        timeProvider = FakeTimeProvider(),
                        reminderScheduler = FakeHikePlanReminderScheduler(),
                    ),
                    selectedTab = selectedTab,
                    onTabSelected = { selectedTab = it },
                    onRouteClick = {},
                    onHikePlanClick = {},
                )
            }
        }

        composeRule.onNodeWithText("Saved maps").performClick()
        composeRule.onNodeWithText("High Castle Loop").assertIsDisplayed()
        composeRule.onNodeWithText("Ready").assertIsDisplayed()
        composeRule.onNodeWithText("Downloaded: 8.0 MB").assertIsDisplayed()

        composeRule.onNodeWithContentDescription("Delete saved map").performClick()
        composeRule.onNodeWithText("No saved maps yet.").assertIsDisplayed()
    }
}

private fun savedMapsViewModel(repository: FakeRouteMapDownloadRepository): SavedMapsViewModel {
    return SavedMapsViewModel(
        observeDownloads = ObserveRouteMapDownloadsUseCase(repository),
        observeDownload = ObserveRouteMapDownloadUseCase(repository),
        estimateDownload = EstimateRouteMapDownloadUseCase(repository),
        startDownload = StartRouteMapDownloadUseCase(repository),
        deleteDownload = DeleteRouteMapDownloadUseCase(repository),
        refreshDownloads = RefreshRouteMapDownloadsUseCase(repository),
    )
}

private class FakeHikeLogRepository : HikeLogRepository {
    override suspend fun save(log: HikeLog): Long = error("Not used")

    override fun observeAll(): Flow<List<HikeLog>> = MutableStateFlow(emptyList())
}

private class FakeTimeProvider : TimeProvider {
    override fun currentTimeMillis(): Long = 1_783_382_400_000L
}

private class FakeHikePlanReminderScheduler : HikePlanReminderScheduler {
    override fun schedule(plan: HikePlan) = Unit
    override fun cancel(planId: Long) = Unit
}

private class FakeWeatherRepository : WeatherRepository {
    override suspend fun getHikePlanWeather(routeId: Long, date: LocalDate): HikePlanWeather {
        return HikePlanWeather(
            routeId = routeId,
            date = date,
            timezone = "Europe/Kyiv",
            summary = DailyPlanWeather(
                weatherCode = 0,
                condition = "CLEAR",
                temperatureMaxC = 20.0,
                temperatureMinC = 10.0,
                sunrise = null,
                sunset = null,
                daylightDurationSeconds = null,
                uvIndexMax = null,
                precipitationSumMm = null,
                precipitationProbabilityMaxPercent = 10,
                windSpeedMaxKmh = null,
                windGustsMaxKmh = null,
            ),
            hourlyForecast = emptyList(),
            risks = emptyList(),
            recommendation = StartTimeRecommendation(null, null, null),
            dataSource = "open-meteo",
            lastUpdated = Instant.parse("2026-07-05T06:00:00Z"),
        )
    }
}

private class FakeSavedRouteRepository(routes: List<Route> = emptyList()) : SavedRouteRepository {
    private val routes = MutableStateFlow(routes)

    override fun observeAll(): Flow<List<Route>> = routes

    override suspend fun save(route: Route) {
        if (!isSaved(route)) {
            routes.value += route
        }
    }

    override suspend fun remove(route: Route) {
        routes.value = routes.value.filterNot { it.savedRouteKey() == route.savedRouteKey() }
    }

    override suspend fun isSaved(route: Route): Boolean {
        return routes.value.any { it.savedRouteKey() == route.savedRouteKey() }
    }
}

private class FakeCustomRouteRepository(routes: List<Route> = emptyList()) : CustomRouteRepository {
    private val routes = MutableStateFlow(routes)

    override fun observeAll(): Flow<List<Route>> = routes

    override suspend fun save(route: Route): Long {
        val savedRoute = route.copy(id = (routes.value.maxOfOrNull { it.id } ?: 0L) + 1L)
        routes.value += savedRoute
        return savedRoute.id
    }

    override suspend fun publish(route: Route): Route = route

    override suspend fun delete(route: Route) {
        routes.value = routes.value.filterNot { it.id == route.id }
    }
}

private class FakeRouteDetailRepository(routes: List<Route> = emptyList()) : RouteDetailRepository {
    private val routes = MutableStateFlow(routes)

    override suspend fun findById(id: Long): Route? = routes.value.firstOrNull { it.id == id }

    override suspend fun findByClientId(clientId: String): Route? {
        return routes.value.firstOrNull { it.clientId == clientId }
    }

    override suspend fun findByServerId(serverId: Long): Route? {
        return routes.value.firstOrNull { it.serverId == serverId }
    }
}

private class FakeHikePlanRepository(plans: List<HikePlan> = emptyList()) : HikePlanRepository {
    private val plans = MutableStateFlow(plans)

    override fun observeAll(): Flow<List<HikePlan>> = plans

    override fun observeById(id: Long): Flow<HikePlan?> {
        return MutableStateFlow(plans.value.firstOrNull { it.id == id })
    }

    override suspend fun save(plan: HikePlan): Long {
        val savedPlan = if (plan.id == 0L) {
            plan.copy(id = ((plans.value.maxOfOrNull { it.id } ?: 0L) + 1L))
        } else {
            plan
        }
        plans.value = plans.value.filterNot { it.id == savedPlan.id } + savedPlan
        return savedPlan.id
    }

    override suspend fun delete(id: Long) {
        plans.value = plans.value.filterNot { it.id == id }
    }
}

private class FakeRouteMapDownloadRepository(
    downloads: List<RouteMapDownload> = emptyList(),
) : RouteMapDownloadRepository {
    private val downloads = MutableStateFlow(downloads)

    override fun observeAll(): Flow<List<RouteMapDownload>> = downloads

    override fun observeByRoute(route: Route): Flow<RouteMapDownload?> {
        return MutableStateFlow(downloads.value.firstOrNull { it.routeId == route.id })
    }

    override fun estimate(route: Route): RouteMapDownloadEstimate = estimateRouteMapDownload(route)

    override suspend fun start(route: Route) = Unit

    override suspend fun delete(download: RouteMapDownload) {
        downloads.value = downloads.value.filterNot { it.id == download.id }
    }

    override suspend fun refreshStatuses() = Unit
}

private fun route(name: String = "High Castle Loop") = Route(
    id = 1,
    name = name,
    description = "A short city-edge climb with a panoramic viewpoint.",
    distanceKm = 4.8,
    estimatedTimeMinutes = 95,
    difficulty = Difficulty.EASY,
    elevationGainMeters = 140,
    terrain = Terrain.FOREST,
    geometry = RouteGeometry(
        listOf(
            GeoPoint(longitude = 24.0316, latitude = 49.8429),
            GeoPoint(longitude = 24.0394, latitude = 49.8461),
        )
    ),
)

private fun hikePlan() = HikePlan(
    id = 10,
    routeId = 1,
    routeName = "High Castle Loop",
    plannedDateEpochDay = LocalDate.of(2026, 7, 5).toEpochDay(),
    checklist = listOf(
        HikePlanChecklistItem(id = "water", text = "Water", checked = true),
        HikePlanChecklistItem(id = "map", text = "Offline map", checked = false),
    ),
    routeSnapshot = route(),
)

private fun routeMapDownload() = RouteMapDownload(
    id = 20L,
    routeKey = route().savedRouteKey(),
    routeId = 1L,
    routeName = "High Castle Loop",
    routeGeometry = route().geometry.points,
    bounds = RouteMapBounds(north = 49.9, east = 24.1, south = 49.8, west = 24.0),
    minZoom = 10.0,
    maxZoom = 15.0,
    mapLibreRegionId = 30L,
    status = RouteMapDownloadStatus.READY,
    completedResourceCount = 10L,
    requiredResourceCount = 10L,
    completedResourceSizeBytes = 8L * 1024L * 1024L,
    completedTileCount = 8L,
    completedTileSizeBytes = 7L * 1024L * 1024L,
    estimatedMinBytes = 6L * 1024L * 1024L,
    estimatedMaxBytes = 12L * 1024L * 1024L,
    errorMessage = null,
    createdAtEpochMillis = 1_000L,
    updatedAtEpochMillis = 2_000L,
)
