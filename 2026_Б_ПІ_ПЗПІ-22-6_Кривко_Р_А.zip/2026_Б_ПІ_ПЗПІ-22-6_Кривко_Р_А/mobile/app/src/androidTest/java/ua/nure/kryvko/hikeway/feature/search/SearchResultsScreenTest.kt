package ua.nure.kryvko.hikeway.feature.search

import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onNodeWithContentDescription
import androidx.compose.ui.test.onNodeWithText
import androidx.compose.ui.test.performClick
import org.junit.Assert.assertEquals
import org.junit.Rule
import org.junit.Test
import ua.nure.kryvko.hikeway.core.model.Difficulty
import ua.nure.kryvko.hikeway.core.model.GeoPoint
import ua.nure.kryvko.hikeway.core.model.PointOfInterest
import ua.nure.kryvko.hikeway.core.model.Route
import ua.nure.kryvko.hikeway.core.model.RouteGeometry
import ua.nure.kryvko.hikeway.core.model.Terrain
import ua.nure.kryvko.hikeway.ui.theme.HikeWayTheme

class SearchResultsScreenTest {
    @get:Rule
    val composeRule = createComposeRule()

    @Test
    fun showsResultsAndHandlesClicks() {
        var backClicks = 0
        val routeClicks = mutableListOf<Route>()
        val poiClicks = mutableListOf<PointOfInterest>()

        composeRule.setContent {
            HikeWayTheme {
                SearchResultsScreen(
                    state = SearchResultsUiState(
                        query = "forest",
                        routes = listOf(route()),
                        pointsOfInterest = listOf(poi()),
                    ),
                    savedRouteKeys = emptySet(),
                    onQueryChange = {},
                    onSubmit = {},
                    onBack = { backClicks++ },
                    onRouteClick = routeClicks::add,
                    onPoiClick = poiClicks::add,
                    onToggleSavedRoute = {},
                )
            }
        }

        composeRule.onNodeWithText("forest").assertIsDisplayed()
        composeRule.onNodeWithText("Routes").assertIsDisplayed()
        composeRule.onNodeWithText("Forest Trail").assertIsDisplayed()
        composeRule.onNodeWithText("Points of interest").assertIsDisplayed()
        composeRule.onNodeWithText("Forest Spring").assertIsDisplayed()

        composeRule.onNodeWithText("Forest Trail").performClick()
        composeRule.onNodeWithText("Forest Spring").performClick()
        composeRule.onNodeWithContentDescription("Back").performClick()

        composeRule.runOnIdle {
            assertEquals(listOf("Forest Trail"), routeClicks.map { it.name })
            assertEquals(listOf("Forest Spring"), poiClicks.map { it.name })
            assertEquals(1, backClicks)
        }
    }

    @Test
    fun showsEmptyState() {
        composeRule.setContent {
            HikeWayTheme {
                SearchResultsScreen(
                    state = SearchResultsUiState(query = "unknown"),
                    savedRouteKeys = emptySet(),
                    onQueryChange = {},
                    onSubmit = {},
                    onBack = {},
                    onRouteClick = {},
                    onPoiClick = {},
                    onToggleSavedRoute = {},
                )
            }
        }

        composeRule.onNodeWithText("No routes or points of interest match your search.").assertIsDisplayed()
    }

    private fun route() = Route(
        id = 7,
        name = "Forest Trail",
        description = "Public route",
        distanceKm = 8.5,
        estimatedTimeMinutes = 120,
        difficulty = Difficulty.EASY,
        elevationGainMeters = 180,
        terrain = Terrain.FOREST,
        geometry = RouteGeometry(
            listOf(
                GeoPoint(24.1, 49.8),
                GeoPoint(24.2, 49.9),
            )
        ),
    )

    private fun poi() = PointOfInterest(
        id = 3,
        name = "Forest Spring",
        description = "Fresh water",
        location = GeoPoint(24.3, 49.7),
    )
}
