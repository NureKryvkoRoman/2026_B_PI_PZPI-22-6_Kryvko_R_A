package ua.nure.kryvko.hikeway.data.savedroutes.local

import androidx.room.Room
import androidx.test.platform.app.InstrumentationRegistry
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import ua.nure.kryvko.hikeway.core.model.Difficulty
import ua.nure.kryvko.hikeway.core.model.GeoPoint
import ua.nure.kryvko.hikeway.core.model.Route
import ua.nure.kryvko.hikeway.core.model.RouteGeometry
import ua.nure.kryvko.hikeway.core.model.Terrain
import ua.nure.kryvko.hikeway.data.hikelogging.local.HikeWayDatabase
import ua.nure.kryvko.hikeway.domain.auth.MutableCurrentUserProvider

class SavedRouteDaoTest {
    private lateinit var database: HikeWayDatabase
    private lateinit var repository: RoomSavedRouteRepository
    private lateinit var currentUserProvider: MutableCurrentUserProvider

    @Before
    fun setUp() {
        database = Room.inMemoryDatabaseBuilder(
            InstrumentationRegistry.getInstrumentation().targetContext,
            HikeWayDatabase::class.java,
        ).allowMainThreadQueries().build()
        currentUserProvider = MutableCurrentUserProvider()
        currentUserProvider.setCurrentUserId("user-1")
        repository = RoomSavedRouteRepository(database.savedRouteDao(), currentUserProvider)
    }

    @After
    fun tearDown() {
        database.close()
    }

    @Test
    fun savesObservesAndRemovesRouteForCurrentUser() = runBlocking {
        val route = route()

        repository.save(route)

        assertTrue(repository.isSaved(route))
        assertEquals("High Castle Loop", repository.observeAll().first().single().name)

        repository.remove(route)

        assertFalse(repository.isSaved(route))
        assertEquals(emptyList<Route>(), repository.observeAll().first())
    }

    @Test
    fun savedRoutesAreScopedToCurrentUser() = runBlocking {
        val route = route()
        repository.save(route)

        currentUserProvider.setCurrentUserId("user-2")

        assertFalse(repository.isSaved(route))
        assertEquals(emptyList<Route>(), repository.observeAll().first())
    }

    @Test
    fun duplicateSavesReplaceExistingSnapshot() = runBlocking {
        repository.save(route(name = "High Castle Loop"))
        repository.save(route(name = "High Castle Loop"))

        assertEquals(1, repository.observeAll().first().size)
    }

    private fun route(name: String = "High Castle Loop") = Route(
        id = 1,
        name = name,
        description = "A short city-edge climb with a panoramic viewpoint.",
        distanceKm = 4.8,
        estimatedTimeMinutes = 95,
        difficulty = Difficulty.EASY,
        elevationGainMeters = 140,
        terrain = Terrain.FOREST,
        geometry = RouteGeometry(
            listOf(
                GeoPoint(longitude = 24.0316, latitude = 49.8429),
                GeoPoint(longitude = 24.0394, latitude = 49.8461),
            )
        ),
    )
}
