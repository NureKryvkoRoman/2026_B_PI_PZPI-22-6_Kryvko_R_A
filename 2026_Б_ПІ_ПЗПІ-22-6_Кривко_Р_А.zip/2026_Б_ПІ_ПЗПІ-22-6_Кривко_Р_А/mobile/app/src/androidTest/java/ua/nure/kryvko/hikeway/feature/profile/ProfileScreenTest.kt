package ua.nure.kryvko.hikeway.feature.profile

import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onNodeWithContentDescription
import androidx.compose.ui.test.onNodeWithText
import androidx.compose.ui.test.performClick
import androidx.compose.ui.test.performTextInput
import org.junit.Assert.assertEquals
import org.junit.Rule
import org.junit.Test
import ua.nure.kryvko.hikeway.domain.profile.UserProfile
import ua.nure.kryvko.hikeway.domain.safety.EmergencyContact
import ua.nure.kryvko.hikeway.domain.achievements.Achievement
import ua.nure.kryvko.hikeway.domain.achievements.AchievementProgressKind
import ua.nure.kryvko.hikeway.feature.safety.EmergencyContactsUiState
import ua.nure.kryvko.hikeway.ui.theme.HikeWayTheme

class ProfileScreenTest {
    @get:Rule
    val composeRule = createComposeRule()

    @Test
    fun profileShowsHeaderAndInvokesActions() {
        var editOpened = false
        var emergencyOpened = false
        var achievementsOpened = false
        var loggedOut = false
        composeRule.setContent {
            HikeWayTheme {
                ProfileScreen(
                    username = "roman",
                    email = "roman@example.com",
                    fullName = "Roman Kryvko",
                    onEditProfileClick = { editOpened = true },
                    onEmergencyContactClick = { emergencyOpened = true },
                    onAchievementsClick = { achievementsOpened = true },
                    onLogOut = { loggedOut = true },
                )
            }
        }

        composeRule.onNodeWithText("roman").assertIsDisplayed()
        composeRule.onNodeWithText("roman@example.com").assertIsDisplayed()
        composeRule.onNodeWithText("Roman Kryvko").assertIsDisplayed()
        composeRule.onNodeWithContentDescription("Edit profile").performClick()
        composeRule.onNodeWithText("Language").assertIsDisplayed()
        composeRule.onNodeWithText("Emergency contact").performClick()
        composeRule.onNodeWithText("My achievements").performClick()
        composeRule.onNodeWithContentDescription("Log out").performClick()

        assertEquals(true, editOpened)
        assertEquals(true, emergencyOpened)
        assertEquals(true, achievementsOpened)
        assertEquals(true, loggedOut)
    }

    @Test
    fun languageMenuShowsCurrentAndAvailableLanguages() {
        var selectedLanguageTag: String? = null
        composeRule.setContent {
            HikeWayTheme {
                ProfileScreen(
                    username = "roman",
                    email = "roman@example.com",
                    fullName = "Roman Kryvko",
                    onLanguageSelected = { selectedLanguageTag = it },
                    onEditProfileClick = {},
                    onEmergencyContactClick = {},
                    onAchievementsClick = {},
                    onLogOut = {},
                )
            }
        }

        composeRule.onNodeWithText("Current: English").assertIsDisplayed()
        composeRule.onNodeWithContentDescription("Language menu").performClick()

        composeRule.onNodeWithText("English").assertIsDisplayed()
        composeRule.onNodeWithText("Українська").performClick()

        assertEquals("uk", selectedLanguageTag)
    }

    @Test
    fun editProfileScreenEditsProfileAndBackCallback() {
        var wentBack = false
        var username = ""
        var email = ""
        var firstName = ""
        var lastName = ""
        var saved = false
        composeRule.setContent {
            HikeWayTheme {
                EditProfileScreen(
                    state = ProfileUiState(
                        profile = UserProfile(
                            id = 1,
                            keycloakId = "keycloak-user",
                            email = "roman@example.com",
                            username = "roman",
                            firstName = "Roman",
                            lastName = "Kryvko",
                        ),
                    ),
                    onUsernameChange = { username = it },
                    onEmailChange = { email = it },
                    onFirstNameChange = { firstName = it },
                    onLastNameChange = { lastName = it },
                    onSave = { saved = true },
                    onBack = { wentBack = true },
                )
            }
        }

        composeRule.onNodeWithText("Edit profile").assertIsDisplayed()
        composeRule.onNodeWithText("Username").performTextInput("newroman")
        composeRule.onNodeWithText("Email").performTextInput("new@example.com")
        composeRule.onNodeWithText("First name").performTextInput("New")
        composeRule.onNodeWithText("Last name").performTextInput("Name")
        composeRule.onNodeWithText("Save").performClick()
        composeRule.onNodeWithContentDescription("Back").performClick()

        assertEquals("newroman", username)
        assertEquals("new@example.com", email)
        assertEquals("New", firstName)
        assertEquals("Name", lastName)
        assertEquals(true, saved)
        assertEquals(true, wentBack)
    }

    @Test
    fun achievementsScreenShowsUnavailableStateAndBackCallback() {
        var wentBack = false
        composeRule.setContent {
            HikeWayTheme {
                AchievementsScreen(
                    state = AchievementsUiState(),
                    onBack = { wentBack = true },
                )
            }
        }

        composeRule.onNodeWithText("My achievements").assertIsDisplayed()
        composeRule.onNodeWithContentDescription("Back").performClick()

        assertEquals(true, wentBack)
    }

    @Test
    fun achievementsScreenShowsProgressAndCompletedCards() {
        composeRule.setContent {
            HikeWayTheme {
                AchievementsScreen(
                    state = AchievementsUiState(
                        achievements = listOf(
                            Achievement(
                                code = "FIRST_HIKE",
                                titleResId = ua.nure.kryvko.hikeway.R.string.achievement_first_hike_title,
                                descriptionResId = ua.nure.kryvko.hikeway.R.string.achievement_first_hike_description,
                                progressValue = 1.0,
                                targetValue = 1.0,
                                kind = AchievementProgressKind.COUNT,
                                completedAtEpochMillis = 1_788_788_800_000,
                            ),
                            Achievement(
                                code = "TOTAL_50K_HIKED",
                                titleResId = ua.nure.kryvko.hikeway.R.string.achievement_total_50k_hiked_title,
                                descriptionResId = ua.nure.kryvko.hikeway.R.string.achievement_total_50k_hiked_description,
                                progressValue = 12.5,
                                targetValue = 50.0,
                                kind = AchievementProgressKind.DISTANCE_KM,
                                completedAtEpochMillis = null,
                            ),
                        )
                    ),
                    onBack = {},
                )
            }
        }

        composeRule.onNodeWithText("First hike").assertIsDisplayed()
        composeRule.onNodeWithText("Completed").assertIsDisplayed()
        composeRule.onNodeWithText("50 km hiked").assertIsDisplayed()
        composeRule.onNodeWithText("12.5 / 50.0 km").assertIsDisplayed()
    }

    @Test
    fun emergencyContactScreenEditsAndSavesContact() {
        var name = ""
        var phoneNumber = ""
        var saved = false
        composeRule.setContent {
            HikeWayTheme {
                EmergencyContactScreen(
                    state = EmergencyContactsUiState(
                        name = name,
                        phoneNumber = phoneNumber,
                        isLoading = false,
                    ),
                    onBack = {},
                    onNameChange = { name = it },
                    onPhoneNumberChange = { phoneNumber = it },
                    onSave = { saved = true },
                    onDelete = {},
                )
            }
        }

        composeRule.onNodeWithText("Name (optional)").performTextInput("Alex")
        composeRule.onNodeWithText("Phone number").performTextInput("5556")
        composeRule.onNodeWithText("Save").performClick()

        assertEquals("Alex", name)
        assertEquals("5556", phoneNumber)
        assertEquals(true, saved)
    }

    @Test
    fun emergencyContactScreenShowsValidationAndDeleteForSavedContact() {
        composeRule.setContent {
            HikeWayTheme {
                EmergencyContactScreen(
                    state = EmergencyContactsUiState(
                        contact = EmergencyContact(id = 1, name = null, phoneNumber = "5556"),
                        phoneNumber = "5556",
                        isLoading = false,
                        validationError = "Phone number is required.",
                    ),
                    onBack = {},
                    onNameChange = {},
                    onPhoneNumberChange = {},
                    onSave = {},
                    onDelete = {},
                )
            }
        }

        composeRule.onNodeWithText("Phone number is required.").assertIsDisplayed()
        composeRule.onNodeWithText("Delete").assertIsDisplayed()
    }
}
