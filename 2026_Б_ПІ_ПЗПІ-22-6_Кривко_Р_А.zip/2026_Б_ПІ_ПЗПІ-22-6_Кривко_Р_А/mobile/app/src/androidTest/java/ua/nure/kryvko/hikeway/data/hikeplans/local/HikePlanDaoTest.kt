package ua.nure.kryvko.hikeway.data.hikeplans.local

import androidx.room.Room
import androidx.test.platform.app.InstrumentationRegistry
import com.google.gson.Gson
import java.time.LocalDate
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Before
import org.junit.Test
import ua.nure.kryvko.hikeway.core.model.Difficulty
import ua.nure.kryvko.hikeway.core.model.GeoPoint
import ua.nure.kryvko.hikeway.core.model.Route
import ua.nure.kryvko.hikeway.core.model.RouteGeometry
import ua.nure.kryvko.hikeway.core.model.Terrain
import ua.nure.kryvko.hikeway.data.hikelogging.local.HikeWayDatabase
import ua.nure.kryvko.hikeway.domain.auth.MutableCurrentUserProvider
import ua.nure.kryvko.hikeway.domain.hikeplans.HikePlan
import ua.nure.kryvko.hikeway.domain.hikeplans.HikePlanChecklistItem

class HikePlanDaoTest {
    private lateinit var database: HikeWayDatabase
    private lateinit var repository: RoomHikePlanRepository
    private lateinit var currentUserProvider: MutableCurrentUserProvider

    @Before
    fun setUp() {
        database = Room.inMemoryDatabaseBuilder(
            InstrumentationRegistry.getInstrumentation().targetContext,
            HikeWayDatabase::class.java,
        ).allowMainThreadQueries().build()
        currentUserProvider = MutableCurrentUserProvider()
        currentUserProvider.setCurrentUserId("user-1")
        repository = RoomHikePlanRepository(database.hikePlanDao(), currentUserProvider, Gson())
    }

    @After
    fun tearDown() {
        database.close()
    }

    @Test
    fun savesObservesUpdatesAndDeletesPlanForCurrentUser() = runBlocking {
        val id = repository.save(plan(routeName = "High Castle Loop"))

        val savedPlan = repository.observeAll().first().single()
        assertEquals(id, savedPlan.id)
        assertEquals("High Castle Loop", savedPlan.routeName)
        assertEquals("Water", savedPlan.checklist.first().text)
        assertEquals(true, savedPlan.checklist.first().checked)
        assertEquals("High Castle Loop", savedPlan.routeSnapshot?.name)

        repository.save(savedPlan.copy(routeName = "Forest Ridge"))

        assertEquals("Forest Ridge", repository.observeById(id).first()?.routeName)

        repository.delete(id)

        assertEquals(emptyList<HikePlan>(), repository.observeAll().first())
    }

    @Test
    fun plansAreScopedToCurrentUser() = runBlocking {
        repository.save(plan())

        currentUserProvider.setCurrentUserId("user-2")

        assertEquals(emptyList<HikePlan>(), repository.observeAll().first())
    }

    private fun plan(routeName: String = "High Castle Loop") = HikePlan(
        routeId = 1,
        routeName = routeName,
        plannedDateEpochDay = LocalDate.of(2026, 7, 5).toEpochDay(),
        checklist = listOf(
            HikePlanChecklistItem(
                id = "water",
                text = "Water",
                checked = true,
            ),
            HikePlanChecklistItem(
                id = "map",
                text = "Offline map",
                checked = false,
            ),
        ),
        routeSnapshot = route(name = routeName),
    )

    private fun route(name: String = "High Castle Loop") = Route(
        id = 1,
        name = name,
        description = "A short city-edge climb with a panoramic viewpoint.",
        distanceKm = 4.8,
        estimatedTimeMinutes = 95,
        difficulty = Difficulty.EASY,
        elevationGainMeters = 140,
        terrain = Terrain.FOREST,
        geometry = RouteGeometry(
            listOf(
                GeoPoint(longitude = 24.0316, latitude = 49.8429),
                GeoPoint(longitude = 24.0394, latitude = 49.8461),
            )
        ),
    )
}
