package ua.nure.kryvko.hikeway.feature.navigation

import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onNodeWithContentDescription
import androidx.compose.ui.test.onNodeWithText
import androidx.compose.ui.test.performClick
import org.junit.Assert.assertEquals
import org.junit.Rule
import org.junit.Test
import ua.nure.kryvko.hikeway.core.model.Difficulty
import ua.nure.kryvko.hikeway.core.model.GeoPoint
import ua.nure.kryvko.hikeway.core.model.Route
import ua.nure.kryvko.hikeway.core.model.RouteGeometry
import ua.nure.kryvko.hikeway.core.model.Terrain
import ua.nure.kryvko.hikeway.domain.routepicking.RoutePickingSession
import ua.nure.kryvko.hikeway.domain.routepicking.RoutePickingStatus
import ua.nure.kryvko.hikeway.ui.theme.HikeWayTheme

class TrackingStatusOverlayTest {
    @get:Rule
    val composeRule = createComposeRule()

    @Test
    fun activeOverlayShowsTimerDistanceAndPauseAction() {
        var paused = false
        composeRule.setContent {
            HikeWayTheme {
                TrackingStatusOverlay(
                    session = session(RoutePickingStatus.ACTIVE),
                    saveErrorMessage = null,
                    onPause = { paused = true },
                    onUnpause = {},
                    onFinish = {},
                )
            }
        }

        composeRule.onNodeWithText("00:02:03").assertIsDisplayed()
        composeRule.onNodeWithText("Walked 1.25 km").assertIsDisplayed()
        composeRule.onNodeWithContentDescription("Pause tracking").performClick()

        assertEquals(true, paused)
    }

    @Test
    fun pausedOverlayShowsResumeAndStopActions() {
        var resumed = false
        var stopped = false
        composeRule.setContent {
            HikeWayTheme {
                TrackingStatusOverlay(
                    session = session(RoutePickingStatus.PAUSED),
                    saveErrorMessage = "Could not save completed hike.",
                    onPause = {},
                    onUnpause = { resumed = true },
                    onFinish = { stopped = true },
                )
            }
        }

        composeRule.onNodeWithText("Could not save completed hike.").assertIsDisplayed()
        composeRule.onNodeWithContentDescription("Resume tracking").performClick()
        composeRule.onNodeWithContentDescription("Stop tracking").performClick()

        assertEquals(true, resumed)
        assertEquals(true, stopped)
    }
}

private fun session(status: RoutePickingStatus) = RoutePickingSession(
    route = Route(
        id = 1,
        name = "Route",
        description = "Description",
        distanceKm = 1.0,
        estimatedTimeMinutes = 30,
        difficulty = Difficulty.EASY,
        elevationGainMeters = 10,
        terrain = Terrain.FOREST,
        geometry = RouteGeometry(listOf(GeoPoint(longitude = 24.0, latitude = 49.0))),
    ),
    userPosition = GeoPoint(longitude = 24.0, latitude = 49.0),
    bearingDegrees = 0.0,
    pointIndex = 0,
    status = status,
    walkedPath = listOf(GeoPoint(longitude = 24.0, latitude = 49.0)),
    walkedDistanceKm = 1.25,
    activeElapsedMillis = 123_000L,
    startedAtEpochMillis = 1_000L,
)
