package ua.nure.kryvko.hikeway.feature.hikeplans

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onNodeWithContentDescription
import androidx.compose.ui.test.onNodeWithText
import androidx.compose.ui.test.performClick
import androidx.compose.ui.test.performTextInput
import java.time.LocalDate
import java.time.Instant
import java.time.LocalDateTime
import java.time.LocalTime
import org.junit.Assert.assertEquals
import org.junit.Rule
import org.junit.Test
import ua.nure.kryvko.hikeway.core.model.Difficulty
import ua.nure.kryvko.hikeway.core.model.GeoPoint
import ua.nure.kryvko.hikeway.core.model.Route
import ua.nure.kryvko.hikeway.core.model.RouteGeometry
import ua.nure.kryvko.hikeway.core.model.Terrain
import ua.nure.kryvko.hikeway.domain.hikeplans.HikePlanChecklistItem
import ua.nure.kryvko.hikeway.domain.weather.DailyPlanWeather
import ua.nure.kryvko.hikeway.domain.weather.HikePlanWeather
import ua.nure.kryvko.hikeway.domain.weather.StartTimeRecommendation
import ua.nure.kryvko.hikeway.ui.theme.HikeWayTheme

class HikePlanScreenTest {
    @get:Rule
    val composeRule = createComposeRule()

    @Test
    fun editsDateChecklistAndRunsActions() {
        var saveCount = 0
        var startCount = 0
        var deleteCount = 0

        composeRule.setContent {
            HikeWayTheme {
                var state by remember { mutableStateOf(screenState()) }
                HikePlanScreen(
                    state = state,
                    onBack = {},
                    onSelectDate = { state = state.copy(plannedDateEpochDay = it) },
                    onAddChecklistItem = {
                        state = state.copy(
                            checklist = state.checklist + HikePlanChecklistItem(
                                id = "new",
                                text = it,
                                checked = false,
                            )
                        )
                    },
                    onUpdateChecklistItem = { id, text ->
                        state = state.copy(
                            checklist = state.checklist.map { item ->
                                if (item.id == id) item.copy(text = text) else item
                            }
                        )
                    },
                    onToggleChecklistItem = { id, checked ->
                        state = state.copy(
                            checklist = state.checklist.map { item ->
                                if (item.id == id) item.copy(checked = checked) else item
                            }
                        )
                    },
                    onDeleteChecklistItem = { id ->
                        state = state.copy(checklist = state.checklist.filterNot { it.id == id })
                    },
                    onSave = { saveCount++ },
                    onDelete = { deleteCount++ },
                    onStartRoute = { startCount++ },
                    onRetryWeather = {},
                )
            }
        }

        composeRule.onNodeWithText("High Castle Loop").assertIsDisplayed()
        composeRule.onNodeWithText("Clear | 10-20 C | 10% precipitation risk")
            .assertIsDisplayed()
        composeRule.onNodeWithText("Sunrise: 06:00").assertIsDisplayed()
        composeRule.onNodeWithText("Sunset: 20:00").assertIsDisplayed()
        composeRule.onNodeWithText("Start 08:30 | return 10:00").assertIsDisplayed()

        composeRule.onNodeWithText("Planned date: 2026-07-05").performClick()
        composeRule.onNodeWithText("Apply").performClick()
        composeRule.onNodeWithText("Planned date: 2026-07-05").assertIsDisplayed()

        composeRule.onNodeWithText("Checklist item").performTextInput("Water")
        composeRule.onNodeWithContentDescription("Add checklist item").performClick()
        composeRule.onNodeWithText("Water").assertIsDisplayed()
        composeRule.onNodeWithText("Water").performClick()
        composeRule.onNodeWithContentDescription("Delete checklist item").performClick()
        composeRule.onNodeWithText("No checklist items yet.").assertIsDisplayed()

        composeRule.onNodeWithText("Save plan").performClick()
        composeRule.onNodeWithText("Start route").performClick()
        composeRule.onNodeWithContentDescription("Delete hike plan").performClick()

        composeRule.runOnIdle {
            assertEquals(1, saveCount)
            assertEquals(1, startCount)
            assertEquals(1, deleteCount)
        }
    }

    private fun screenState() = HikePlanDraftUiState(
        isOpen = true,
        planId = 10,
        route = route(),
        routeName = "High Castle Loop",
        plannedDateEpochDay = LocalDate.of(2026, 7, 5).toEpochDay(),
        weatherState = HikePlanWeatherState.Loaded(weather()),
    )

    private fun weather() = HikePlanWeather(
        routeId = 1,
        date = LocalDate.of(2026, 7, 5),
        timezone = "Europe/Kyiv",
        summary = DailyPlanWeather(
            weatherCode = 0,
            condition = "CLEAR",
            temperatureMaxC = 20.0,
            temperatureMinC = 10.0,
            sunrise = LocalTime.of(6, 0),
            sunset = LocalTime.of(20, 0),
            daylightDurationSeconds = 50_400,
            uvIndexMax = 4.0,
            precipitationSumMm = 0.0,
            precipitationProbabilityMaxPercent = 10,
            windSpeedMaxKmh = 12.0,
            windGustsMaxKmh = 20.0,
        ),
        hourlyForecast = emptyList(),
        risks = emptyList(),
        recommendation = StartTimeRecommendation(
            recommendedStartTime = LocalDateTime.of(2026, 7, 5, 8, 30),
            expectedReturnTime = LocalDateTime.of(2026, 7, 5, 10, 0),
            explanation = "RECOMMENDED_WINDOW_AVOIDS_NIGHTTIME_AND_HIGH_RISK_FORECAST_HOURS",
        ),
        dataSource = "open-meteo",
        lastUpdated = Instant.parse("2026-07-05T06:00:00Z"),
    )

    private fun route() = Route(
        id = 1,
        name = "High Castle Loop",
        description = "A short city-edge climb with a panoramic viewpoint.",
        distanceKm = 4.8,
        estimatedTimeMinutes = 95,
        difficulty = Difficulty.EASY,
        elevationGainMeters = 140,
        terrain = Terrain.FOREST,
        geometry = RouteGeometry(
            listOf(
                GeoPoint(longitude = 24.0316, latitude = 49.8429),
                GeoPoint(longitude = 24.0394, latitude = 49.8461),
            )
        ),
    )
}
