package ua.nure.kryvko.hikeway.data.routes.local

import androidx.room.Room
import androidx.test.platform.app.InstrumentationRegistry
import kotlinx.coroutines.runBlocking
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Before
import org.junit.Test
import ua.nure.kryvko.hikeway.core.model.Difficulty
import ua.nure.kryvko.hikeway.core.model.GeoPoint
import ua.nure.kryvko.hikeway.core.model.Route
import ua.nure.kryvko.hikeway.core.model.RouteGeometry
import ua.nure.kryvko.hikeway.core.model.RouteVisibility
import ua.nure.kryvko.hikeway.core.model.Terrain
import ua.nure.kryvko.hikeway.data.hikelogging.local.HikeWayDatabase
import ua.nure.kryvko.hikeway.data.services.backend.SyncService
import ua.nure.kryvko.hikeway.data.sync.RouteChangeDto
import ua.nure.kryvko.hikeway.data.sync.SyncCoordinator
import ua.nure.kryvko.hikeway.data.sync.SyncLocalDataSource
import ua.nure.kryvko.hikeway.data.sync.SyncMetadataStore
import ua.nure.kryvko.hikeway.data.sync.SyncRequestDto
import ua.nure.kryvko.hikeway.data.sync.SyncResponseDto
import ua.nure.kryvko.hikeway.data.sync.SyncTransport
import ua.nure.kryvko.hikeway.data.sync.SyncTrigger
import ua.nure.kryvko.hikeway.domain.auth.MutableCurrentUserProvider
import ua.nure.kryvko.hikeway.domain.routes.RouteSearchCriteria

class RouteDaoTest {
    private lateinit var database: HikeWayDatabase
    private lateinit var repository: RoomRouteRepository
    private lateinit var currentUserProvider: MutableCurrentUserProvider
    private lateinit var syncService: FakeSyncService

    @Before
    fun setUp() {
        database = Room.inMemoryDatabaseBuilder(
            InstrumentationRegistry.getInstrumentation().targetContext,
            HikeWayDatabase::class.java,
        ).allowMainThreadQueries().build()
        currentUserProvider = MutableCurrentUserProvider()
        currentUserProvider.setCurrentUserId("user-1")
        syncService = FakeSyncService()
        repository = RoomRouteRepository(
            dao = database.routeDao(),
            currentUserProvider = currentUserProvider,
            syncService = syncService,
            syncTrigger = SyncTrigger(FakeSyncCoordinator(), currentUserProvider),
        )
    }

    @After
    fun tearDown() {
        database.close()
    }

    @Test
    fun insertsAndReadsCustomRoute() = runBlocking {
        val id = repository.save(route())

        val routes = repository.search(
            criteria = RouteSearchCriteria(),
            origin = GeoPoint(longitude = 24.0316, latitude = 49.8429),
        )

        assertEquals(id, routes.single().id)
        assertEquals("Local route", routes.single().name)
        assertEquals(2, routes.single().geometry.points.size)
    }

    @Test
    fun searchesOnlyCurrentUsersCustomRoutes() = runBlocking {
        repository.save(route(name = "User one route"))
        currentUserProvider.setCurrentUserId("user-2")
        repository.save(route(name = "User two route"))

        val userTwoRoutes = repository.search(
            criteria = RouteSearchCriteria(),
            origin = GeoPoint(longitude = 24.0316, latitude = 49.8429),
        )
        currentUserProvider.setCurrentUserId("user-1")
        val userOneRoutes = repository.search(
            criteria = RouteSearchCriteria(),
            origin = GeoPoint(longitude = 24.0316, latitude = 49.8429),
        )

        assertEquals("User two route", userTwoRoutes.single().name)
        assertEquals("User one route", userOneRoutes.single().name)
    }

    @Test
    fun publishRemovesRouteFromLocalStorage() = runBlocking {
        val id = repository.save(route(name = "Publish me"))
        val stored = database.routeDao().findById("user-1", id)!!
        database.routeDao().update(
            stored.copy(
                serverId = 42,
                syncVersion = 1,
                syncState = "SYNCED",
            )
        )

        val published = repository.publish(stored.toDomain())

        assertEquals(RouteVisibility.PUBLIC, published.visibility)
        assertEquals(42, published.serverId)
        assertEquals(
            emptyList<Route>(),
            repository.search(
                criteria = RouteSearchCriteria(),
                origin = GeoPoint(longitude = 24.0316, latitude = 49.8429),
            ),
        )
    }

    private fun route(name: String = "Local route") = Route(
        id = 0,
        name = name,
        description = "Created locally",
        distanceKm = 0.5,
        estimatedTimeMinutes = 8,
        difficulty = Difficulty.EASY,
        elevationGainMeters = 0,
        terrain = Terrain.FOREST,
        geometry = RouteGeometry(
            listOf(
                GeoPoint(longitude = 24.0316, latitude = 49.8429),
                GeoPoint(longitude = 24.0394, latitude = 49.8461),
            )
        ),
    )
}

private fun FakeSyncCoordinator() = SyncCoordinator(
    transport = object : SyncTransport {
        override suspend fun exchange(request: SyncRequestDto): SyncResponseDto {
            error("Sync is not used by this test.")
        }
    },
    localDataSource = object : SyncLocalDataSource {
        override suspend fun createRequest(cursor: String?, deviceId: String): SyncRequestDto {
            error("Sync is not used by this test.")
        }

        override suspend fun apply(response: SyncResponseDto) = Unit
    },
    metadataStore = object : SyncMetadataStore {
        override fun cursor(userId: String): String? = null

        override fun saveCursor(userId: String, cursor: String) = Unit

        override fun deviceId(): String = "test-device"
    },
)

private class FakeSyncService : SyncService {
    override suspend fun sync(request: SyncRequestDto): SyncResponseDto {
        error("Sync is not used by this test.")
    }

    override suspend fun publishRoute(clientId: String): RouteChangeDto {
        return RouteChangeDto(
            clientId = clientId,
            serverId = 42,
            version = 2,
            name = "Publish me",
            description = "Created locally",
            distanceKm = 0.5,
            estimatedTimeMinutes = 8,
            difficulty = Difficulty.EASY.name,
            elevationGainMeters = 0,
            terrain = Terrain.FOREST.name,
            geometry = ua.nure.kryvko.hikeway.data.sync.GeoJsonLineStringDto(
                coordinates = listOf(
                    listOf(24.0316, 49.8429),
                    listOf(24.0394, 49.8461),
                )
            ),
            visibility = RouteVisibility.PUBLIC.name,
            updatedAt = "2026-07-08T10:00:00Z",
            deleted = false,
        )
    }

    override suspend fun unpublishRoute(clientId: String): RouteChangeDto {
        error("Unpublish is not used by this test.")
    }

    override suspend fun deleteRoute(clientId: String): RouteChangeDto {
        error("Delete is not used by this test.")
    }

    override suspend fun deleteRouteByServerId(serverId: Long): RouteChangeDto {
        error("Delete is not used by this test.")
    }
}
