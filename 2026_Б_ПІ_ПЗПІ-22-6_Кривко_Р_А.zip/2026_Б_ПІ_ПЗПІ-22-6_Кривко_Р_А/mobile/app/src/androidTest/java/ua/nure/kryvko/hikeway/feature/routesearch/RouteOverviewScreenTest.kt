package ua.nure.kryvko.hikeway.feature.routesearch

import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.assert
import androidx.compose.ui.test.assertCountEquals
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onAllNodesWithContentDescription
import androidx.compose.ui.test.onNodeWithContentDescription
import androidx.compose.ui.test.onNodeWithText
import androidx.compose.ui.test.performClick
import androidx.compose.ui.test.performTouchInput
import androidx.compose.ui.test.swipeUp
import androidx.compose.ui.semantics.SemanticsProperties
import androidx.compose.ui.test.SemanticsMatcher
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import org.junit.Assert.assertEquals
import org.junit.Rule
import org.junit.Test
import ua.nure.kryvko.hikeway.core.model.Difficulty
import ua.nure.kryvko.hikeway.core.model.GeoPoint
import ua.nure.kryvko.hikeway.core.model.Route
import ua.nure.kryvko.hikeway.core.model.RouteGeometry
import ua.nure.kryvko.hikeway.core.model.RouteVisibility
import ua.nure.kryvko.hikeway.core.model.Terrain
import ua.nure.kryvko.hikeway.domain.offlinemaps.RouteMapBounds
import ua.nure.kryvko.hikeway.domain.offlinemaps.RouteMapDownloadEstimate
import ua.nure.kryvko.hikeway.ui.theme.HikeWayTheme

class RouteOverviewScreenTest {
    @get:Rule
    val composeRule = createComposeRule()

    @Test
    fun showsRouteSummaryAndActions() {
        var backCount = 0
        var startCount = 0
        var saveCount = 0
        var planCount = 0
        var saveMapCount = 0

        composeRule.setContent {
            HikeWayTheme {
                var isSaved by remember { mutableStateOf(false) }
                RouteOverviewScreen(
                    route = route(),
                    isSaved = isSaved,
                    mapDownload = null,
                    pendingMapEstimate = null,
                    isStartingMapDownload = false,
                    currentUserId = "",
                    onBack = { backCount++ },
                    onToggleSaved = {
                        isSaved = !isSaved
                        saveCount++
                    },
                    onStartRoute = { startCount++ },
                    onPlanTrip = { planCount++ },
                    onSaveMap = { saveMapCount++ },
                    onConfirmSaveMap = {},
                    onDismissSaveMapEstimate = {},
                )
            }
        }

        composeRule.onNodeWithText("Route overview").assertIsDisplayed()
        composeRule.onNodeWithText("High Castle Loop").assertIsDisplayed()
        composeRule.onNodeWithText("A short city-edge climb with a panoramic viewpoint.").assertIsDisplayed()
        composeRule.onNodeWithText("Distance").assertIsDisplayed()
        composeRule.onNodeWithText("4.8 km").assertIsDisplayed()
        composeRule.onNodeWithText("Estimated time").assertIsDisplayed()
        composeRule.onNodeWithText("95 min").assertIsDisplayed()
        composeRule.onNodeWithText("Elevation gain").assertIsDisplayed()
        composeRule.onNodeWithText("140 m").assertIsDisplayed()
        composeRule.onNodeWithText("Difficulty").assertIsDisplayed()
        composeRule.onNodeWithText("Easy").assertIsDisplayed()
        composeRule.onNodeWithText("Terrain").assertIsDisplayed()
        composeRule.onNodeWithText("Forest").assertIsDisplayed()
        composeRule.onNodeWithContentDescription("Route info drag handle")
            .assertIsDisplayed()
            .assert(SemanticsMatcher.expectValue(SemanticsProperties.StateDescription, "Collapsed"))

        composeRule.onNodeWithContentDescription("Route info drag handle").performTouchInput {
            swipeUp()
        }
        composeRule.waitForIdle()
        composeRule.onNodeWithContentDescription("Route info drag handle")
            .assert(SemanticsMatcher.expectValue(SemanticsProperties.StateDescription, "Expanded"))

        composeRule.onNodeWithContentDescription("Save route for later").performClick()
        composeRule.onNodeWithContentDescription("Remove saved route").assertIsDisplayed()
        composeRule.onNodeWithContentDescription("Back").performClick()
        composeRule.onNodeWithText("Start route").performClick()
        composeRule.onNodeWithText("Plan trip").performClick()
        composeRule.onNodeWithText("Save map").performClick()

        composeRule.runOnIdle {
            assertEquals(1, saveCount)
            assertEquals(1, backCount)
            assertEquals(1, startCount)
            assertEquals(1, planCount)
            assertEquals(1, saveMapCount)
        }
    }

    @Test
    fun confirmsMapDownloadFromEstimateDialog() {
        var confirmCount = 0
        var dismissCount = 0

        composeRule.setContent {
            HikeWayTheme {
                RouteOverviewScreen(
                    route = route(),
                    isSaved = false,
                    mapDownload = null,
                    pendingMapEstimate = RouteMapDownloadEstimate(
                        minBytes = 12L * 1024L * 1024L,
                        maxBytes = 30L * 1024L * 1024L,
                        tileCount = 120L,
                        minZoom = 10.0,
                        maxZoom = 15.0,
                        bounds = RouteMapBounds(north = 49.9, east = 24.1, south = 49.8, west = 24.0),
                    ),
                    isStartingMapDownload = false,
                    currentUserId = "",
                    onBack = {},
                    onToggleSaved = {},
                    onStartRoute = {},
                    onPlanTrip = {},
                    onSaveMap = {},
                    onConfirmSaveMap = { confirmCount++ },
                    onDismissSaveMapEstimate = { dismissCount++ },
                )
            }
        }

        composeRule.onNodeWithText("Estimated size: ~12-30 MB").assertIsDisplayed()
        composeRule.onNodeWithText("Download").performClick()
        composeRule.onNodeWithText("Cancel").performClick()

        composeRule.runOnIdle {
            assertEquals(1, confirmCount)
            assertEquals(1, dismissCount)
        }
    }

    @Test
    fun creatorCanPublishAndDeletePrivateRoute() {
        var publishCount = 0
        var deleteCount = 0

        composeRule.setContent {
            HikeWayTheme {
                RouteOverviewScreen(
                    route = route(createdBy = "user-1", visibility = RouteVisibility.PRIVATE),
                    isSaved = false,
                    mapDownload = null,
                    pendingMapEstimate = null,
                    isStartingMapDownload = false,
                    currentUserId = "user-1",
                    onBack = {},
                    onToggleSaved = {},
                    onStartRoute = {},
                    onPlanTrip = {},
                    onSaveMap = {},
                    onConfirmSaveMap = {},
                    onDismissSaveMapEstimate = {},
                    onPublishRoute = { publishCount++ },
                    onDeleteRoute = { deleteCount++ },
                )
            }
        }

        composeRule.onNodeWithContentDescription("Publish route").assertIsDisplayed().performClick()
        composeRule.onNodeWithContentDescription("Delete route").assertIsDisplayed().performClick()
        composeRule.onNodeWithText("Delete route?").assertIsDisplayed()
        composeRule.onNodeWithText("Delete").performClick()

        composeRule.runOnIdle {
            assertEquals(1, publishCount)
            assertEquals(1, deleteCount)
        }
    }

    @Test
    fun nonCreatorDoesNotSeePublishOrDeleteActions() {
        composeRule.setContent {
            HikeWayTheme {
                RouteOverviewScreen(
                    route = route(createdBy = "user-1", visibility = RouteVisibility.PRIVATE),
                    isSaved = false,
                    mapDownload = null,
                    pendingMapEstimate = null,
                    isStartingMapDownload = false,
                    currentUserId = "user-2",
                    onBack = {},
                    onToggleSaved = {},
                    onStartRoute = {},
                    onPlanTrip = {},
                    onSaveMap = {},
                    onConfirmSaveMap = {},
                    onDismissSaveMapEstimate = {},
                )
            }
        }

        composeRule.onAllNodesWithContentDescription("Publish route").assertCountEquals(0)
        composeRule.onAllNodesWithContentDescription("Delete route").assertCountEquals(0)
    }
}

private fun route(
    createdBy: String? = null,
    visibility: RouteVisibility = RouteVisibility.PRIVATE,
) = Route(
    id = 1,
    name = "High Castle Loop",
    description = "A short city-edge climb with a panoramic viewpoint.",
    distanceKm = 4.8,
    estimatedTimeMinutes = 95,
    difficulty = Difficulty.EASY,
    elevationGainMeters = 140,
    terrain = Terrain.FOREST,
    geometry = RouteGeometry(
        listOf(
            GeoPoint(longitude = 24.0316, latitude = 49.8429),
            GeoPoint(longitude = 24.0394, latitude = 49.8461),
            GeoPoint(longitude = 24.0438, latitude = 49.8488),
        )
    ),
    createdBy = createdBy,
    visibility = visibility,
)
