package ua.nure.kryvko.hikeway.data.routepicking.local

import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.test.runTest
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Before
import org.junit.Test
import ua.nure.kryvko.hikeway.data.hikelogging.local.HikeWayDatabase

class ActiveRouteTrackingSessionDaoTest {
    private lateinit var database: HikeWayDatabase
    private lateinit var dao: ActiveRouteTrackingSessionDao

    @Before
    fun setUp() {
        database = Room.inMemoryDatabaseBuilder(
            ApplicationProvider.getApplicationContext(),
            HikeWayDatabase::class.java,
        ).build()
        dao = database.activeRouteTrackingSessionDao()
    }

    @After
    fun tearDown() {
        database.close()
    }

    @Test
    fun upsertReplacesSessionForOwnerAndDeleteClearsIt() = runTest {
        dao.upsert(entity(ownerUserId = "user-1", routeName = "First route"))
        assertEquals("First route", dao.observe("user-1").first()?.routeName)

        dao.upsert(entity(ownerUserId = "user-1", routeName = "Updated route"))
        assertEquals("Updated route", dao.observe("user-1").first()?.routeName)

        dao.delete("user-1")

        assertNull(dao.observe("user-1").first())
    }
}

private fun entity(
    ownerUserId: String,
    routeName: String,
) = ActiveRouteTrackingSessionEntity(
    ownerUserId = ownerUserId,
    routeId = 1,
    routeName = routeName,
    routeDescription = "Description",
    routeDistanceKm = 4.2,
    routeEstimatedTimeMinutes = 60,
    routeDifficulty = "EASY",
    routeElevationGainMeters = 120,
    routeTerrain = "FOREST",
    routeGeometryGeoJson = """{"type":"LineString","coordinates":[[24.0,49.0],[24.1,49.1]]}""",
    userLongitude = 24.0,
    userLatitude = 49.0,
    bearingDegrees = 90.0,
    pointIndex = 0,
    status = "PAUSED",
    walkedPathGeoJson = """{"type":"LineString","coordinates":[[24.0,49.0]]}""",
    walkedDistanceKm = 0.0,
    activeElapsedMillis = 1_000,
    startedAtEpochMillis = 100,
    updatedAtEpochMillis = 200,
)
