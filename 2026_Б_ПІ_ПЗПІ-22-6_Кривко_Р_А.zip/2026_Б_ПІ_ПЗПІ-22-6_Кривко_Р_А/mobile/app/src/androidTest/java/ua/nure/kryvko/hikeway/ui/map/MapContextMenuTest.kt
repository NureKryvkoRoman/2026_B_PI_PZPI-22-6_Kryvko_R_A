package ua.nure.kryvko.hikeway.ui.map

import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onNodeWithText
import androidx.compose.ui.test.performClick
import org.junit.Assert.assertEquals
import org.junit.Rule
import org.junit.Test
import ua.nure.kryvko.hikeway.core.model.GeoPoint
import ua.nure.kryvko.hikeway.ui.theme.HikeWayTheme

class MapContextMenuTest {
    @get:Rule
    val composeRule = createComposeRule()

    @Test
    fun showsFindRoutesNearbyAndAddPoiActions() {
        var findCount = 0
        var addPoiCount = 0
        var createRouteCount = 0

        composeRule.setContent {
            HikeWayTheme {
                MapContextMenu(
                    point = GeoPoint(longitude = 24.0316, latitude = 49.8429),
                    actions = listOf(
                        MapContextAction(
                            label = "Find routes nearby",
                            onClick = { findCount++ },
                        ),
                        MapContextAction(
                            label = "Add PoI",
                            onClick = { addPoiCount++ },
                        ),
                        MapContextAction(
                            label = "Create route from here",
                            onClick = { createRouteCount++ },
                        ),
                    ),
                )
            }
        }

        composeRule.onNodeWithText("Find routes nearby").assertIsDisplayed()
        composeRule.onNodeWithText("Add PoI").assertIsDisplayed()
        composeRule.onNodeWithText("Create route from here").assertIsDisplayed()

        composeRule.onNodeWithText("Find routes nearby").performClick()
        composeRule.onNodeWithText("Add PoI").performClick()
        composeRule.onNodeWithText("Create route from here").performClick()

        composeRule.runOnIdle {
            assertEquals(1, findCount)
            assertEquals(1, addPoiCount)
            assertEquals(1, createRouteCount)
        }
    }
}
