package ua.nure.kryvko.hikeway.feature.routesearch

import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.assertCountEquals
import androidx.compose.ui.test.assertIsEnabled
import androidx.compose.ui.test.assertIsNotEnabled
import androidx.compose.ui.test.hasText
import androidx.compose.ui.test.hasTestTag
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onAllNodesWithContentDescription
import androidx.compose.ui.test.onAllNodesWithTag
import androidx.compose.ui.test.onAllNodesWithText
import androidx.compose.ui.test.onNodeWithContentDescription
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.test.onNodeWithText
import androidx.compose.ui.test.onFirst
import androidx.compose.ui.test.performClick
import androidx.compose.ui.test.performScrollTo
import androidx.compose.ui.test.performTextInput
import androidx.compose.ui.test.performTouchInput
import androidx.compose.ui.test.SemanticsMatcher
import androidx.compose.ui.test.swipeUp
import androidx.compose.ui.semantics.SemanticsProperties
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.test.assert
import org.junit.Before
import org.junit.Rule
import org.junit.Test
import ua.nure.kryvko.hikeway.core.model.GeoPoint
import ua.nure.kryvko.hikeway.core.model.PointOfInterest
import ua.nure.kryvko.hikeway.core.model.Difficulty
import ua.nure.kryvko.hikeway.core.model.PoiRating
import ua.nure.kryvko.hikeway.core.model.Route
import ua.nure.kryvko.hikeway.core.model.RouteComment
import ua.nure.kryvko.hikeway.core.model.RouteGeometry
import ua.nure.kryvko.hikeway.core.model.RouteRating
import ua.nure.kryvko.hikeway.core.model.RouteVisibility
import ua.nure.kryvko.hikeway.core.model.Terrain
import ua.nure.kryvko.hikeway.core.location.StubLocationProvider
import ua.nure.kryvko.hikeway.data.routepicking.stub.StubRouteTrackingProvider
import ua.nure.kryvko.hikeway.domain.hikelogging.ActiveTimer
import ua.nure.kryvko.hikeway.domain.hikelogging.HikeLog
import ua.nure.kryvko.hikeway.domain.hikelogging.HikeLogRepository
import ua.nure.kryvko.hikeway.domain.hikelogging.SaveCompletedHikeUseCase
import ua.nure.kryvko.hikeway.domain.hikelogging.SystemTimeProvider
import ua.nure.kryvko.hikeway.domain.routepicking.ActiveRouteTrackingSessionRepository
import ua.nure.kryvko.hikeway.domain.routepicking.DeleteActiveRouteTrackingSessionUseCase
import ua.nure.kryvko.hikeway.domain.routepicking.ObserveActiveRouteTrackingSessionUseCase
import ua.nure.kryvko.hikeway.domain.routepicking.RoutePickingSession
import ua.nure.kryvko.hikeway.domain.routepicking.SaveActiveRouteTrackingSessionUseCase
import ua.nure.kryvko.hikeway.domain.pois.GetPointsOfInterestUseCase
import ua.nure.kryvko.hikeway.domain.pois.AddPoiCommentUseCase
import ua.nure.kryvko.hikeway.domain.pois.CreatePointOfInterestUseCase
import ua.nure.kryvko.hikeway.domain.pois.DeletePoiCommentUseCase
import ua.nure.kryvko.hikeway.domain.pois.DeletePoiPhotoUseCase
import ua.nure.kryvko.hikeway.domain.pois.DeletePointOfInterestUseCase
import ua.nure.kryvko.hikeway.domain.pois.GetNearbyPointsOfInterestUseCase
import ua.nure.kryvko.hikeway.domain.pois.GetPointOfInterestDetailUseCase
import ua.nure.kryvko.hikeway.domain.pois.PointOfInterestRepository
import ua.nure.kryvko.hikeway.domain.pois.RatePointOfInterestUseCase
import ua.nure.kryvko.hikeway.domain.pois.RemovePointOfInterestRatingUseCase
import ua.nure.kryvko.hikeway.domain.pois.UpdatePoiCommentUseCase
import ua.nure.kryvko.hikeway.domain.pois.UpdatePoiPhotoUseCase
import ua.nure.kryvko.hikeway.domain.pois.UpdatePointOfInterestUseCase
import ua.nure.kryvko.hikeway.domain.pois.UploadPoiPhotoUseCase
import ua.nure.kryvko.hikeway.domain.routes.GetCurrentLocationUseCase
import ua.nure.kryvko.hikeway.domain.routes.AddRouteCommentUseCase
import ua.nure.kryvko.hikeway.domain.routes.CustomRouteRepository
import ua.nure.kryvko.hikeway.domain.routes.DeleteCustomRouteUseCase
import ua.nure.kryvko.hikeway.domain.routes.DeleteRouteCommentUseCase
import ua.nure.kryvko.hikeway.domain.routes.GetRecommendedRoutesUseCase
import ua.nure.kryvko.hikeway.domain.routes.GetRouteCommentsUseCase
import ua.nure.kryvko.hikeway.domain.routes.PublishCustomRouteUseCase
import ua.nure.kryvko.hikeway.domain.routes.RateRouteUseCase
import ua.nure.kryvko.hikeway.domain.routes.RecommendedRouteRepository
import ua.nure.kryvko.hikeway.domain.routes.RemoveRouteRatingUseCase
import ua.nure.kryvko.hikeway.domain.routes.RouteContentRepository
import ua.nure.kryvko.hikeway.domain.routes.RouteRepository
import ua.nure.kryvko.hikeway.domain.routes.RouteSearchCriteria
import ua.nure.kryvko.hikeway.domain.routes.SearchRoutesUseCase
import ua.nure.kryvko.hikeway.domain.routes.UpdateRouteCommentUseCase
import ua.nure.kryvko.hikeway.domain.routes.matches
import ua.nure.kryvko.hikeway.ui.theme.HikeWayTheme
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.emptyFlow
import kotlinx.coroutines.flow.flowOf
import org.junit.Assert.assertEquals

class RouteSearchScreenTest {
    @get:Rule
    val composeRule = createComposeRule()
    private lateinit var viewModel: RouteSearchViewModel
    private var createRouteClicks = 0
    private val toggledSavedRoutes = mutableListOf<Route>()
    private val submittedSearches = mutableListOf<String>()

    @Before
    fun setUp() {
        createRouteClicks = 0
        toggledSavedRoutes.clear()
        submittedSearches.clear()
        val locationProvider = StubLocationProvider()
        val poiRepository = FakePointOfInterestRepository()
        val routeContentRepository = FakeRouteContentRepository()
        viewModel = RouteSearchViewModel(
            searchRoutes = SearchRoutesUseCase(
                repository = FakeRouteRepository(),
                locationProvider = locationProvider,
            ),
            getRecommendedRoutes = GetRecommendedRoutesUseCase(
                repository = FakeRecommendedRouteRepository(),
                locationProvider = locationProvider,
            ),
            getCurrentLocation = GetCurrentLocationUseCase(locationProvider),
            routeTrackingProvider = StubRouteTrackingProvider(),
            saveCompletedHike = SaveCompletedHikeUseCase(FakeHikeLogRepository()),
            observeActiveSession = ObserveActiveRouteTrackingSessionUseCase(FakeActiveRouteTrackingSessionRepository()),
            saveActiveSession = SaveActiveRouteTrackingSessionUseCase(FakeActiveRouteTrackingSessionRepository()),
            deleteActiveSession = DeleteActiveRouteTrackingSessionUseCase(FakeActiveRouteTrackingSessionRepository()),
            timeProvider = SystemTimeProvider(),
            activeTimer = NoOpActiveTimer(),
            getPointsOfInterest = GetPointsOfInterestUseCase(poiRepository),
            getNearbyPointsOfInterest = GetNearbyPointsOfInterestUseCase(poiRepository),
            getPointOfInterestDetail = GetPointOfInterestDetailUseCase(poiRepository),
            createPointOfInterest = CreatePointOfInterestUseCase(poiRepository),
            updatePointOfInterest = UpdatePointOfInterestUseCase(poiRepository),
            deletePointOfInterest = DeletePointOfInterestUseCase(poiRepository),
            ratePointOfInterest = RatePointOfInterestUseCase(poiRepository),
            removePointOfInterestRating = RemovePointOfInterestRatingUseCase(poiRepository),
            addPoiCommentUseCase = AddPoiCommentUseCase(poiRepository),
            updatePoiCommentUseCase = UpdatePoiCommentUseCase(poiRepository),
            deletePoiCommentUseCase = DeletePoiCommentUseCase(poiRepository),
            uploadPoiPhotoUseCase = UploadPoiPhotoUseCase(poiRepository),
            updatePoiPhotoUseCase = UpdatePoiPhotoUseCase(poiRepository),
            deletePoiPhotoUseCase = DeletePoiPhotoUseCase(poiRepository),
            publishCustomRoute = PublishCustomRouteUseCase(FakeCustomRouteRepository()),
            deleteCustomRoute = DeleteCustomRouteUseCase(FakeCustomRouteRepository()),
            rateRoute = RateRouteUseCase(routeContentRepository),
            removeRouteRating = RemoveRouteRatingUseCase(routeContentRepository),
            getRouteComments = GetRouteCommentsUseCase(routeContentRepository),
            addRouteCommentUseCase = AddRouteCommentUseCase(routeContentRepository),
            updateRouteCommentUseCase = UpdateRouteCommentUseCase(routeContentRepository),
            deleteRouteCommentUseCase = DeleteRouteCommentUseCase(routeContentRepository),
        )
        composeRule.setContent {
            HikeWayTheme {
                RouteSearchScreen(
                    viewModel = viewModel,
                    username = "Roman",
                    onToggleSavedRoute = toggledSavedRoutes::add,
                    onCreateRoute = { createRouteClicks++ },
                    onSearchSubmit = submittedSearches::add,
                )
            }
        }
        composeRule.waitUntil { composeRule.onAllNodes(hasText("5 routes found")).fetchSemanticsNodes().isNotEmpty() }
    }

    @Test
    fun showsHomeSections() {
        composeRule.onNodeWithText("Welcome, Roman").assertIsDisplayed()
        composeRule.onNodeWithText("Where are we heading today?").assertIsDisplayed()
        composeRule.onNodeWithText("Search routes or places").assertIsDisplayed()
        composeRule.onNodeWithText("Recommended routes").assertIsDisplayed()
        composeRule.onNodeWithContentDescription("Refresh recommendations").assertIsDisplayed()
        composeRule.onNodeWithText("Popular nearby").assertIsDisplayed()
        composeRule.onNodeWithText("Route search").assertIsDisplayed()
        composeRule.onNodeWithText("Waterfall Viewpoint").assertIsDisplayed()
    }

    @Test
    fun showsImprovedRouteCardDetailsAndCreateButton() {
        composeRule.onNodeWithContentDescription("Create route").assertIsDisplayed()
        composeRule.onAllNodesWithText("Easy").onFirst().assertIsDisplayed()
        composeRule.onAllNodesWithText("Forest").onFirst().assertIsDisplayed()
        composeRule.onAllNodesWithText("4.8 km | 1h 35m | 140 m").onFirst().assertIsDisplayed()
    }

    @Test
    fun createRouteButtonInvokesCallback() {
        composeRule.onNodeWithContentDescription("Create route").performClick()

        composeRule.runOnIdle {
            assertEquals(1, createRouteClicks)
        }
    }

    @Test
    fun searchBarSubmitsTrimmedQuery() {
        composeRule.onNodeWithText("Search routes or places").performTextInput("  forest  ")
        composeRule.onNodeWithContentDescription("Search").performClick()

        composeRule.runOnIdle {
            assertEquals(listOf("forest"), submittedSearches)
        }
    }

    @Test
    fun saveRouteButtonInvokesCallbackWithoutOpeningRoute() {
        composeRule.onAllNodesWithContentDescription("Save route for later").onFirst().performClick()

        composeRule.runOnIdle {
            assertEquals(1, toggledSavedRoutes.size)
            assertEquals(null, viewModel.uiState.value.previewRoute)
        }
    }

    @Test
    fun routeListSupportsDuplicateRouteIds() {
        val firstRoute = route(
            2,
            "Remote Route",
            "A route loaded from the backend.",
            7.2,
            120,
            Difficulty.MEDIUM,
            220,
            Terrain.FOREST,
            24.0 to 49.0,
            24.1 to 49.1,
        )
        val secondRoute = route(
            2,
            "Local Route",
            "A route created on this device.",
            5.4,
            85,
            Difficulty.EASY,
            120,
            Terrain.MIXED,
            24.2 to 49.2,
            24.3 to 49.3,
        )
        composeRule.setContent {
            HikeWayTheme {
                RouteHomePanel(
                    state = RouteSearchUiState(routes = listOf(firstRoute, secondRoute)),
                    username = "Roman",
                    recommendedExpanded = false,
                    popularNearbyExpanded = false,
                    onRecommendedExpandedChange = {},
                    onPopularNearbyExpandedChange = {},
                    onRouteClick = {},
                    onPoiClick = {},
                    onFilterClick = {},
                )
            }
        }

        composeRule.onNodeWithText("Local Route").performScrollTo().assertIsDisplayed()
    }

    @Test
    fun collapsibleSectionsToggleContent() {
        composeRule.onNodeWithContentDescription("Collapse Recommended routes").performClick()
        composeRule.onNodeWithContentDescription("Expand Recommended routes").assertIsDisplayed()
        composeRule.onNodeWithContentDescription("Expand Recommended routes").performClick()
        composeRule.onNodeWithContentDescription("Collapse Recommended routes").assertIsDisplayed()

        composeRule.onNodeWithContentDescription("Collapse Popular nearby").performClick()
        composeRule.onNodeWithContentDescription("Expand Popular nearby").assertIsDisplayed()
        composeRule.onNodeWithContentDescription("Expand Popular nearby").performClick()
        composeRule.onNodeWithText("Waterfall Viewpoint").assertIsDisplayed()
    }

    @Test
    fun appliesDifficultyFilterAndUpdatesCards() {
        composeRule.onNodeWithTag("filters-inactive-icon").assertIsDisplayed()
        composeRule.onNodeWithContentDescription("Filters").performClick()
        composeRule.onNodeWithText("Route filters").assertIsDisplayed()
        composeRule.onNodeWithText("Hard").performClick()
        composeRule.onNodeWithText("Apply").performClick()

        composeRule.onNodeWithText("1 routes found").assertIsDisplayed()
        composeRule.onNodeWithText("Rocky Ridge Traverse").assertIsDisplayed()
        composeRule.onNodeWithTag("filters-active-icon").assertIsDisplayed()
        composeRule.onNode(hasTestTag("applied-filter-chip") and hasText("Hard")).assertIsDisplayed()
    }

    @Test
    fun showsEmptyStateForUnmatchedFilters() {
        composeRule.onNodeWithContentDescription("Filters").performClick()
        composeRule.onNodeWithText("Hard").performClick()
        composeRule.onNodeWithText("Maximum distance from you, km").performTextInput("0.1")
        composeRule.onNodeWithText("Apply").performClick()

        composeRule.onNodeWithText("No routes match the applied filters.").assertIsDisplayed()
        composeRule.onNode(hasTestTag("applied-filter-chip") and hasText("Within 0.1 km")).assertIsDisplayed()
    }

    @Test
    fun noAppliedFilterChipsShownByDefault() {
        composeRule.onAllNodesWithTag("applied-filter-chip").assertCountEquals(0)
    }

    @Test
    fun rangeFiltersShowAppliedFilterChips() {
        composeRule.onNodeWithContentDescription("Filters").performClick()
        composeRule.onNodeWithTag("route-filter-distance-min").performTextInput("4")
        composeRule.onNodeWithTag("route-filter-distance-max").performTextInput("10")
        composeRule.onNodeWithTag("route-filter-time-min").performTextInput("60")
        composeRule.onNodeWithTag("route-filter-time-max").performTextInput("120")
        composeRule.onNodeWithText("Apply").performClick()

        composeRule.onNode(hasTestTag("applied-filter-chip") and hasText("Distance 4-10 km")).assertIsDisplayed()
        composeRule.onNode(hasTestTag("applied-filter-chip") and hasText("Time 60-120 min")).assertIsDisplayed()
    }

    @Test
    fun clearFiltersRemovesAppliedFilterChips() {
        composeRule.onNodeWithContentDescription("Filters").performClick()
        composeRule.onNodeWithText("Hard").performClick()
        composeRule.onNodeWithText("Apply").performClick()
        composeRule.onNode(hasTestTag("applied-filter-chip") and hasText("Hard")).assertIsDisplayed()

        composeRule.onNodeWithContentDescription("Filters").performClick()
        composeRule.onNodeWithText("Clear").performClick()

        composeRule.onAllNodesWithTag("applied-filter-chip").assertCountEquals(0)
        composeRule.onNodeWithTag("filters-inactive-icon").assertIsDisplayed()
    }

    @Test
    fun filterNumericFieldsRejectInvalidCharactersButAllowZero() {
        composeRule.onNodeWithContentDescription("Filters").performClick()

        composeRule.onNodeWithTag("route-filter-distance-min").performTextInput("-1a.2.3")
        composeRule.onNodeWithTag("route-filter-time-min").performTextInput("1.5h")
        composeRule.onNodeWithTag("route-filter-proximity").performTextInput("-0.1x")

        composeRule.onNodeWithTag("route-filter-distance-min").assertEditableText("1.23")
        composeRule.onNodeWithTag("route-filter-time-min").assertEditableText("15")
        composeRule.onNodeWithTag("route-filter-proximity").assertEditableText("0.1")
    }

    @Test
    fun distanceRangeErrorDisablesApplyUntilRangeIsCorrected() {
        composeRule.onNodeWithContentDescription("Filters").performClick()

        composeRule.onNodeWithTag("route-filter-distance-min").performTextInput("10")
        composeRule.onNodeWithTag("route-filter-distance-max").performTextInput("5")

        composeRule.onNodeWithText("Minimum distance cannot be greater than maximum distance.").assertIsDisplayed()
        composeRule.onNodeWithText("Apply").assertIsNotEnabled()

        composeRule.onNodeWithTag("route-filter-distance-max").performTextInput("0")

        composeRule.onAllNodesWithText("Minimum distance cannot be greater than maximum distance.").assertCountEquals(0)
        composeRule.onNodeWithText("Apply").assertIsEnabled()
    }

    @Test
    fun durationRangeErrorDisablesApplyUntilRangeIsCorrected() {
        composeRule.onNodeWithContentDescription("Filters").performClick()

        composeRule.onNodeWithTag("route-filter-time-min").performTextInput("120")
        composeRule.onNodeWithTag("route-filter-time-max").performTextInput("60")

        composeRule.onNodeWithText("Minimum duration cannot be greater than maximum duration.").assertIsDisplayed()
        composeRule.onNodeWithText("Apply").assertIsNotEnabled()

        composeRule.onNodeWithTag("route-filter-time-max").performTextInput("0")

        composeRule.onAllNodesWithText("Minimum duration cannot be greater than maximum duration.").assertCountEquals(0)
        composeRule.onNodeWithText("Apply").assertIsEnabled()
    }

    @Test
    fun routeCardSelectsRouteForOverview() {
        composeRule.onAllNodesWithText("High Castle Loop").onFirst().performClick()

        composeRule.runOnIdle {
            assertEquals("High Castle Loop", viewModel.uiState.value.previewRoute?.name)
        }
    }

    @Test
    fun selectedRouteCanBeDismissed() {
        composeRule.onNodeWithText("High Castle Loop").performClick()

        composeRule.runOnIdle {
            viewModel.dismissRoutePreview()
            assertEquals(null, viewModel.uiState.value.previewRoute)
        }
    }

    @Test
    fun poiPopupDismissesByDragHandleWithoutCloseButton() {
        composeRule.onNodeWithText("Waterfall Viewpoint").performClick()
        composeRule.onNodeWithText("Point of interest").assertIsDisplayed()
        composeRule.onAllNodesWithText("Close").assertCountEquals(0)

        composeRule.onNodeWithContentDescription("PoI popup drag handle").performTouchInput {
            swipeUp()
        }

        composeRule.runOnIdle {
            assertEquals(null, viewModel.uiState.value.selectedPoi)
        }
    }
}

private fun androidx.compose.ui.test.SemanticsNodeInteraction.assertEditableText(
    expected: String,
): androidx.compose.ui.test.SemanticsNodeInteraction {
    return this.assert(
        SemanticsMatcher.expectValue(
            SemanticsProperties.EditableText,
            AnnotatedString(expected),
        )
    )
}

private class NoOpActiveTimer : ActiveTimer {
    override fun ticks(periodMillis: Long): Flow<Long> = flowOf()
}

private class FakeHikeLogRepository : HikeLogRepository {
    override suspend fun save(log: HikeLog): Long = 1L

    override fun observeAll(): Flow<List<HikeLog>> = emptyFlow()
}

private class FakeActiveRouteTrackingSessionRepository : ActiveRouteTrackingSessionRepository {
    private val session = MutableStateFlow<RoutePickingSession?>(null)

    override fun observe(): Flow<RoutePickingSession?> = session

    override suspend fun save(session: RoutePickingSession) {
        this.session.value = session
    }

    override suspend fun delete() {
        session.value = null
    }
}

private class FakeRouteRepository : RouteRepository {
    private val routes = listOf(
        route(
            1,
            "High Castle Loop",
            "A short city-edge climb with a panoramic viewpoint.",
            4.8,
            95,
            Difficulty.EASY,
            140,
            Terrain.FOREST,
            24.0316 to 49.8429,
            24.0394 to 49.8461,
            24.0438 to 49.8488,
        ),
        route(
            2,
            "Vynnyky Forest Trail",
            "A rolling forest route with quiet paths and several lakes.",
            11.2,
            210,
            Difficulty.MEDIUM,
            310,
            Terrain.FOREST,
            24.1290 to 49.8170,
            24.1440 to 49.8105,
            24.1570 to 49.8030,
        ),
        route(
            3,
            "Rocky Ridge Traverse",
            "A longer exposed ridge route for experienced hikers.",
            18.6,
            390,
            Difficulty.HARD,
            920,
            Terrain.ROCKY,
            23.8910 to 49.6510,
            23.9140 to 49.6600,
            23.9400 to 49.6560,
        ),
        route(
            4,
            "Mountain Meadow Path",
            "A steady climb through meadows and mixed woodland.",
            8.4,
            175,
            Difficulty.MEDIUM,
            460,
            Terrain.MOUNTAIN,
            23.9870 to 49.7310,
            24.0020 to 49.7260,
            24.0150 to 49.7190,
        ),
        route(
            5,
            "Lakeside Mixed Walk",
            "An accessible mixed-terrain route for a relaxed afternoon.",
            6.1,
            120,
            Difficulty.EASY,
            90,
            Terrain.MIXED,
            24.0710 to 49.8680,
            24.0800 to 49.8710,
            24.0920 to 49.8660,
        ),
    )

    override suspend fun search(criteria: RouteSearchCriteria, origin: GeoPoint): List<Route> {
        return routes.filter { it.matches(criteria, origin) }
    }
}

private class FakeRecommendedRouteRepository : RecommendedRouteRepository {
    private val routes = listOf(
        route(
            1,
            "High Castle Loop",
            "A short city-edge climb with a panoramic viewpoint.",
            4.8,
            95,
            Difficulty.EASY,
            140,
            Terrain.FOREST,
            24.0316 to 49.8429,
            24.0394 to 49.8461,
        ),
        route(
            2,
            "Vynnyky Forest Trail",
            "A rolling forest route with quiet paths and several lakes.",
            11.2,
            210,
            Difficulty.MEDIUM,
            310,
            Terrain.FOREST,
            24.1290 to 49.8170,
            24.1440 to 49.8105,
        ),
    )

    override suspend fun recommended(origin: GeoPoint?): List<Route> = routes
}

private class FakeCustomRouteRepository : CustomRouteRepository {
    override fun observeAll(): Flow<List<Route>> = emptyFlow()

    override suspend fun save(route: Route): Long = route.id

    override suspend fun publish(route: Route): Route = route.copy(visibility = RouteVisibility.PUBLIC)

    override suspend fun delete(route: Route) = Unit
}

private fun route(
    id: Long,
    name: String,
    description: String,
    distanceKm: Double,
    estimatedTimeMinutes: Int,
    difficulty: Difficulty,
    elevationGainMeters: Int,
    terrain: Terrain,
    vararg points: Pair<Double, Double>,
) = Route(
    id = id,
    name = name,
    description = description,
    distanceKm = distanceKm,
    estimatedTimeMinutes = estimatedTimeMinutes,
    difficulty = difficulty,
    elevationGainMeters = elevationGainMeters,
    terrain = terrain,
    geometry = RouteGeometry(points.map { (longitude, latitude) -> GeoPoint(longitude, latitude) }),
    serverId = id,
)

private class FakeRouteContentRepository : RouteContentRepository {
    override suspend fun submitRating(routeId: Long, rating: Int): RouteRating {
        return RouteRating(rating.toDouble(), 1, rating)
    }

    override suspend fun removeRating(routeId: Long): RouteRating {
        return RouteRating(0.0, 0, null)
    }

    override suspend fun getComments(routeId: Long): List<RouteComment> = emptyList()

    override suspend fun addComment(routeId: Long, text: String): RouteComment {
        return RouteComment(1, "user-1", "Hiker", true, text)
    }

    override suspend fun updateComment(routeId: Long, commentId: Long, text: String): RouteComment {
        return RouteComment(commentId, "user-1", "Hiker", true, text)
    }

    override suspend fun deleteComment(routeId: Long, commentId: Long) = Unit
}

private class FakePointOfInterestRepository : PointOfInterestRepository {
    override suspend fun getPointsOfInterest(): List<PointOfInterest> {
        return listOf(
            PointOfInterest(
                id = 1,
                name = "Test PoI",
                description = "A test point.",
                location = GeoPoint(longitude = 24.0, latitude = 49.0),
                photoResIds = emptyList(),
                averageRating = 4.0,
            )
        )
    }

    override suspend fun submitRating(poiId: Long, rating: Int): PoiRating {
        return PoiRating(rating.toDouble(), 1, rating)
    }
}
