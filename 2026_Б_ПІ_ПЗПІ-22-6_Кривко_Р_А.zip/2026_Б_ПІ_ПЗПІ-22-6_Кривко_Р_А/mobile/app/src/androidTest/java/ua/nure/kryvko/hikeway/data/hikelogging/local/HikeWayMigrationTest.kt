package ua.nure.kryvko.hikeway.data.hikelogging.local

import androidx.room.testing.MigrationTestHelper
import androidx.sqlite.db.framework.FrameworkSQLiteOpenHelperFactory
import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.platform.app.InstrumentationRegistry
import org.junit.Assert.assertEquals
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class HikeWayMigrationTest {
    @get:Rule
    val helper = MigrationTestHelper(
        InstrumentationRegistry.getInstrumentation(),
        HikeWayDatabase::class.java,
        listOf(),
        FrameworkSQLiteOpenHelperFactory(),
    )

    @Test
    fun migratesFromOneToTwoAndCreatesRoutesTable() {
        helper.createDatabase(TEST_DB, 1).apply {
            close()
        }

        helper.runMigrationsAndValidate(TEST_DB, 2, true, MIGRATION_1_2).close()
    }

    @Test
    fun migratesFromTwoToThreeAndDeletesGlobalRows() {
        helper.createDatabase(TEST_DB, 2).apply {
            execSQL(
                """
                INSERT INTO hike_logs (
                    routeId,
                    routeName,
                    startedAtEpochMillis,
                    finishedAtEpochMillis,
                    activeDurationMillis,
                    wallClockDurationMillis,
                    totalDistanceKm,
                    pathGeoJson
                ) VALUES (
                    1,
                    'Old hike',
                    1000,
                    2000,
                    1000,
                    1000,
                    1.0,
                    '{"type":"LineString","coordinates":[[24.0,49.0],[24.1,49.1]]}'
                )
                """.trimIndent()
            )
            execSQL(
                """
                INSERT INTO routes (
                    name,
                    description,
                    distanceKm,
                    estimatedTimeMinutes,
                    difficulty,
                    elevationGainMeters,
                    terrain,
                    geometryGeoJson
                ) VALUES (
                    'Old route',
                    'Global route',
                    1.0,
                    15,
                    'EASY',
                    0,
                    'FOREST',
                    '{"type":"LineString","coordinates":[[24.0,49.0],[24.1,49.1]]}'
                )
                """.trimIndent()
            )
            close()
        }

        helper.runMigrationsAndValidate(TEST_DB, 3, true, MIGRATION_2_3).apply {
            query("SELECT COUNT(*) FROM hike_logs").use { cursor ->
                cursor.moveToFirst()
                assertEquals(0, cursor.getInt(0))
            }
            query("SELECT COUNT(*) FROM routes").use { cursor ->
                cursor.moveToFirst()
                assertEquals(0, cursor.getInt(0))
            }
            close()
        }
    }

    @Test
    fun migratesFromThreeToFourAndMarksExistingRowsForSync() {
        helper.createDatabase(TEST_DB, 3).apply {
            execSQL(
                """
                INSERT INTO routes (
                    ownerUserId, name, description, distanceKm, estimatedTimeMinutes,
                    difficulty, elevationGainMeters, terrain, geometryGeoJson
                ) VALUES (
                    'user-1', 'Local route', 'Description', 1.0, 15,
                    'EASY', 0, 'FOREST',
                    '{"type":"LineString","coordinates":[[24.0,49.0],[24.1,49.1]]}'
                )
                """.trimIndent()
            )
            close()
        }

        helper.runMigrationsAndValidate(TEST_DB, 4, true, MIGRATION_3_4).apply {
            query("SELECT clientId, syncVersion, syncState, deleted FROM routes").use { cursor ->
                cursor.moveToFirst()
                assertEquals(false, cursor.getString(0).isBlank())
                assertEquals(0, cursor.getLong(1))
                assertEquals("PENDING", cursor.getString(2))
                assertEquals(0, cursor.getInt(3))
            }
            close()
        }
    }

    @Test
    fun migratesFromFourToFiveAndCreatesSavedRoutesTable() {
        helper.createDatabase(TEST_DB, 4).apply {
            close()
        }

        helper.runMigrationsAndValidate(TEST_DB, 5, true, MIGRATION_4_5).apply {
            query("SELECT COUNT(*) FROM saved_routes").use { cursor ->
                cursor.moveToFirst()
                assertEquals(0, cursor.getInt(0))
            }
            close()
        }
    }

    @Test
    fun migratesFromFiveToSixAndCreatesHikePlansTable() {
        helper.createDatabase(TEST_DB, 5).apply {
            close()
        }

        helper.runMigrationsAndValidate(TEST_DB, 6, true, MIGRATION_5_6).apply {
            query("SELECT COUNT(*) FROM hike_plans").use { cursor ->
                cursor.moveToFirst()
                assertEquals(0, cursor.getInt(0))
            }
            close()
        }
    }

    @Test
    fun migratesFromSixToSevenAndAddsRouteSnapshotToHikePlans() {
        helper.createDatabase(TEST_DB, 6).apply {
            execSQL(
                """
                INSERT INTO hike_plans (
                    ownerUserId,
                    routeId,
                    routeName,
                    plannedDateEpochDay,
                    checklistJson,
                    createdAtEpochMillis,
                    updatedAtEpochMillis
                ) VALUES (
                    'user-1',
                    1,
                    'Legacy plan',
                    20640,
                    '[]',
                    1000,
                    1000
                )
                """.trimIndent()
            )
            close()
        }

        helper.runMigrationsAndValidate(TEST_DB, 7, true, MIGRATION_6_7).apply {
            query("SELECT routeSnapshotJson FROM hike_plans WHERE routeName = 'Legacy plan'").use { cursor ->
                cursor.moveToFirst()
                assertEquals(true, cursor.isNull(0))
            }
            close()
        }
    }

    @Test
    fun migratesFromSevenToEightAndCreatesRouteMapDownloadsTable() {
        helper.createDatabase(TEST_DB, 7).apply {
            close()
        }

        helper.runMigrationsAndValidate(TEST_DB, 8, true, MIGRATION_7_8).apply {
            query("SELECT COUNT(*) FROM route_map_downloads").use { cursor ->
                cursor.moveToFirst()
                assertEquals(0, cursor.getInt(0))
            }
            close()
        }
    }

    @Test
    fun migratesFromEightToNineAndCreatesEmergencyContactsTable() {
        helper.createDatabase(TEST_DB, 8).apply {
            close()
        }

        helper.runMigrationsAndValidate(TEST_DB, 9, true, MIGRATION_8_9).apply {
            query("SELECT COUNT(*) FROM emergency_contacts").use { cursor ->
                cursor.moveToFirst()
                assertEquals(0, cursor.getInt(0))
            }
            close()
        }
    }

    @Test
    fun migratesFromNineToTenAndCreatesActiveRouteTrackingSessionsTable() {
        helper.createDatabase(TEST_DB, 9).apply {
            close()
        }

        helper.runMigrationsAndValidate(TEST_DB, 10, true, MIGRATION_9_10).apply {
            query("SELECT COUNT(*) FROM active_route_tracking_sessions").use { cursor ->
                cursor.moveToFirst()
                assertEquals(0, cursor.getInt(0))
            }
            close()
        }
    }

    @Test
    fun migratesFromTenToElevenAndCreatesAchievementsTable() {
        helper.createDatabase(TEST_DB, 10).apply {
            close()
        }

        helper.runMigrationsAndValidate(TEST_DB, 11, true, MIGRATION_10_11).apply {
            query("SELECT COUNT(*) FROM achievements").use { cursor ->
                cursor.moveToFirst()
                assertEquals(0, cursor.getInt(0))
            }
            close()
        }
    }

    @Test
    fun migratesFromElevenToTwelveAndAddsCompletedHikeElevationGain() {
        helper.createDatabase(TEST_DB, 11).apply {
            execSQL(
                """
                INSERT INTO hike_logs (
                    ownerUserId,
                    routeId,
                    routeName,
                    startedAtEpochMillis,
                    finishedAtEpochMillis,
                    activeDurationMillis,
                    wallClockDurationMillis,
                    totalDistanceKm,
                    pathGeoJson,
                    clientId,
                    syncVersion,
                    updatedAtEpochMillis,
                    syncState,
                    deleted
                ) VALUES (
                    'user-1',
                    1,
                    'Legacy hike',
                    1000,
                    2000,
                    1000,
                    1000,
                    1.0,
                    '{"type":"LineString","coordinates":[[24.0,49.0],[24.1,49.1]]}',
                    'client-1',
                    0,
                    2000,
                    'SYNCED',
                    0
                )
                """.trimIndent()
            )
            close()
        }

        helper.runMigrationsAndValidate(TEST_DB, 12, true, MIGRATION_11_12).apply {
            query("SELECT elevationGainMeters FROM hike_logs WHERE routeName = 'Legacy hike'").use { cursor ->
                cursor.moveToFirst()
                assertEquals(0, cursor.getInt(0))
            }
            close()
        }
    }

    @Test
    fun migratesFromTwelveToThirteenAndResyncsZeroElevationCompletedHikes() {
        helper.createDatabase(TEST_DB, 12).apply {
            execSQL(
                """
                INSERT INTO hike_logs (
                    ownerUserId,
                    routeId,
                    routeName,
                    startedAtEpochMillis,
                    finishedAtEpochMillis,
                    activeDurationMillis,
                    wallClockDurationMillis,
                    totalDistanceKm,
                    elevationGainMeters,
                    pathGeoJson,
                    clientId,
                    serverId,
                    syncVersion,
                    updatedAtEpochMillis,
                    syncState,
                    deleted
                ) VALUES (
                    'user-1',
                    1,
                    'Synced zero elevation hike',
                    1000,
                    2000,
                    1000,
                    1000,
                    1.0,
                    0,
                    '{"type":"LineString","coordinates":[[24.0,49.0],[24.1,49.1]]}',
                    'client-1',
                    100,
                    1,
                    2000,
                    'SYNCED',
                    0
                )
                """.trimIndent()
            )
            close()
        }

        helper.runMigrationsAndValidate(TEST_DB, 13, true, MIGRATION_12_13).apply {
            query("SELECT syncState FROM hike_logs WHERE routeName = 'Synced zero elevation hike'").use { cursor ->
                cursor.moveToFirst()
                assertEquals("PENDING", cursor.getString(0))
            }
            close()
        }
    }

    private companion object {
        const val TEST_DB = "hikeway-migration-test"
    }
}
