package ua.nure.kryvko.hikeway.app.di

import android.content.Context
import androidx.room.Room
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton
import ua.nure.kryvko.hikeway.data.hikelogging.local.HikeLogDao
import ua.nure.kryvko.hikeway.data.hikelogging.local.HikeWayDatabase
import ua.nure.kryvko.hikeway.data.achievements.local.AchievementDao
import ua.nure.kryvko.hikeway.data.hikelogging.local.MIGRATION_1_2
import ua.nure.kryvko.hikeway.data.hikelogging.local.MIGRATION_2_3
import ua.nure.kryvko.hikeway.data.hikelogging.local.MIGRATION_3_4
import ua.nure.kryvko.hikeway.data.hikelogging.local.MIGRATION_4_5
import ua.nure.kryvko.hikeway.data.hikelogging.local.MIGRATION_5_6
import ua.nure.kryvko.hikeway.data.hikelogging.local.MIGRATION_6_7
import ua.nure.kryvko.hikeway.data.hikelogging.local.MIGRATION_7_8
import ua.nure.kryvko.hikeway.data.hikelogging.local.MIGRATION_8_9
import ua.nure.kryvko.hikeway.data.hikelogging.local.MIGRATION_9_10
import ua.nure.kryvko.hikeway.data.hikelogging.local.MIGRATION_10_11
import ua.nure.kryvko.hikeway.data.hikelogging.local.MIGRATION_11_12
import ua.nure.kryvko.hikeway.data.hikelogging.local.MIGRATION_12_13
import ua.nure.kryvko.hikeway.data.hikelogging.local.MIGRATION_13_14
import ua.nure.kryvko.hikeway.data.hikeplans.local.HikePlanDao
import ua.nure.kryvko.hikeway.data.offlinemaps.local.RouteMapDownloadDao
import ua.nure.kryvko.hikeway.data.routepicking.local.ActiveRouteTrackingSessionDao
import ua.nure.kryvko.hikeway.data.safety.local.EmergencyContactDao
import ua.nure.kryvko.hikeway.data.savedroutes.local.SavedRouteDao
import ua.nure.kryvko.hikeway.data.routes.local.RouteDao
import ua.nure.kryvko.hikeway.data.sync.SyncConflictDao

@Module
@InstallIn(SingletonComponent::class)
object DatabaseModule {
    @Provides
    @Singleton
    fun provideDatabase(@ApplicationContext context: Context): HikeWayDatabase {
        return Room.databaseBuilder(
            context,
            HikeWayDatabase::class.java,
            "hikeway.db",
        ).addMigrations(
            MIGRATION_1_2,
            MIGRATION_2_3,
            MIGRATION_3_4,
            MIGRATION_4_5,
            MIGRATION_5_6,
            MIGRATION_6_7,
            MIGRATION_7_8,
            MIGRATION_8_9,
            MIGRATION_9_10,
            MIGRATION_10_11,
            MIGRATION_11_12,
            MIGRATION_12_13,
            MIGRATION_13_14,
        ).build()
    }

    @Provides
    fun provideRouteDao(database: HikeWayDatabase): RouteDao = database.routeDao()

    @Provides
    fun provideHikeLogDao(database: HikeWayDatabase): HikeLogDao = database.hikeLogDao()

    @Provides
    fun provideSyncConflictDao(database: HikeWayDatabase): SyncConflictDao = database.syncConflictDao()

    @Provides
    fun provideSavedRouteDao(database: HikeWayDatabase): SavedRouteDao = database.savedRouteDao()

    @Provides
    fun provideHikePlanDao(database: HikeWayDatabase): HikePlanDao = database.hikePlanDao()

    @Provides
    fun provideRouteMapDownloadDao(database: HikeWayDatabase): RouteMapDownloadDao =
        database.routeMapDownloadDao()

    @Provides
    fun provideEmergencyContactDao(database: HikeWayDatabase): EmergencyContactDao =
        database.emergencyContactDao()

    @Provides
    fun provideActiveRouteTrackingSessionDao(
        database: HikeWayDatabase,
    ): ActiveRouteTrackingSessionDao = database.activeRouteTrackingSessionDao()

    @Provides
    fun provideAchievementDao(database: HikeWayDatabase): AchievementDao = database.achievementDao()
}
