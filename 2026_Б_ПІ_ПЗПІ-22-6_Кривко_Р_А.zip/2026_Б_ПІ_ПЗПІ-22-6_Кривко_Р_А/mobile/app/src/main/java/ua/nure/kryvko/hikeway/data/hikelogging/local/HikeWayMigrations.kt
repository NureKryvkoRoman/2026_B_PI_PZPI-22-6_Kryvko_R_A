package ua.nure.kryvko.hikeway.data.hikelogging.local

import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase
import java.util.UUID

val MIGRATION_1_2 = object : Migration(1, 2) {
    override fun migrate(db: SupportSQLiteDatabase) {
        db.execSQL(
            """
            CREATE TABLE IF NOT EXISTS `routes` (
                `id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
                `name` TEXT NOT NULL,
                `description` TEXT NOT NULL,
                `distanceKm` REAL NOT NULL,
                `estimatedTimeMinutes` INTEGER NOT NULL,
                `difficulty` TEXT NOT NULL,
                `elevationGainMeters` INTEGER NOT NULL,
                `terrain` TEXT NOT NULL,
                `geometryGeoJson` TEXT NOT NULL
            )
            """.trimIndent()
        )
    }
}

val MIGRATION_2_3 = object : Migration(2, 3) {
    override fun migrate(db: SupportSQLiteDatabase) {
        db.execSQL("DROP TABLE IF EXISTS `hike_logs`")
        db.execSQL("DROP TABLE IF EXISTS `routes`")
        db.execSQL(
            """
            CREATE TABLE IF NOT EXISTS `hike_logs` (
                `id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
                `ownerUserId` TEXT NOT NULL,
                `routeId` INTEGER NOT NULL,
                `routeName` TEXT NOT NULL,
                `startedAtEpochMillis` INTEGER NOT NULL,
                `finishedAtEpochMillis` INTEGER NOT NULL,
                `activeDurationMillis` INTEGER NOT NULL,
                `wallClockDurationMillis` INTEGER NOT NULL,
                `totalDistanceKm` REAL NOT NULL,
                `pathGeoJson` TEXT NOT NULL
            )
            """.trimIndent()
        )
        db.execSQL(
            """
            CREATE TABLE IF NOT EXISTS `routes` (
                `id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
                `ownerUserId` TEXT NOT NULL,
                `name` TEXT NOT NULL,
                `description` TEXT NOT NULL,
                `distanceKm` REAL NOT NULL,
                `estimatedTimeMinutes` INTEGER NOT NULL,
                `difficulty` TEXT NOT NULL,
                `elevationGainMeters` INTEGER NOT NULL,
                `terrain` TEXT NOT NULL,
                `geometryGeoJson` TEXT NOT NULL
            )
            """.trimIndent()
        )
    }
}

val MIGRATION_3_4 = object : Migration(3, 4) {
    override fun migrate(db: SupportSQLiteDatabase) {
        addSyncColumns(db, "routes", includeRouteReference = false)
        addSyncColumns(db, "hike_logs", includeRouteReference = true)
        assignClientIds(db, "routes")
        assignClientIds(db, "hike_logs")
        db.execSQL(
            """
            UPDATE `hike_logs`
            SET `routeClientId` = (
                SELECT `routes`.`clientId`
                FROM `routes`
                WHERE `routes`.`id` = `hike_logs`.`routeId`
                  AND `routes`.`ownerUserId` = `hike_logs`.`ownerUserId`
            ),
            `routeServerId` = (
                SELECT `routes`.`serverId`
                FROM `routes`
                WHERE `routes`.`id` = `hike_logs`.`routeId`
                  AND `routes`.`ownerUserId` = `hike_logs`.`ownerUserId`
            )
            WHERE EXISTS (
                SELECT 1 FROM `routes`
                WHERE `routes`.`id` = `hike_logs`.`routeId`
                  AND `routes`.`ownerUserId` = `hike_logs`.`ownerUserId`
            )
            """.trimIndent()
        )
        db.execSQL(
            "CREATE UNIQUE INDEX IF NOT EXISTS `index_routes_ownerUserId_clientId` " +
                "ON `routes` (`ownerUserId`, `clientId`)"
        )
        db.execSQL(
            "CREATE UNIQUE INDEX IF NOT EXISTS `index_hike_logs_ownerUserId_clientId` " +
                "ON `hike_logs` (`ownerUserId`, `clientId`)"
        )
        db.execSQL(
            """
            CREATE TABLE IF NOT EXISTS `sync_conflicts` (
                `id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
                `ownerUserId` TEXT NOT NULL,
                `resourceType` TEXT NOT NULL,
                `clientId` TEXT NOT NULL,
                `submittedBaseVersion` INTEGER NOT NULL,
                `serverVersion` INTEGER NOT NULL,
                `serverRecordJson` TEXT NOT NULL,
                `createdAtEpochMillis` INTEGER NOT NULL
            )
            """.trimIndent()
        )
        db.execSQL(
            "CREATE UNIQUE INDEX IF NOT EXISTS " +
                "`index_sync_conflicts_ownerUserId_resourceType_clientId` " +
                "ON `sync_conflicts` (`ownerUserId`, `resourceType`, `clientId`)"
        )
    }
}

val MIGRATION_4_5 = object : Migration(4, 5) {
    override fun migrate(db: SupportSQLiteDatabase) {
        db.execSQL(
            """
            CREATE TABLE IF NOT EXISTS `saved_routes` (
                `id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
                `ownerUserId` TEXT NOT NULL,
                `routeKey` TEXT NOT NULL,
                `routeId` INTEGER NOT NULL,
                `name` TEXT NOT NULL,
                `description` TEXT NOT NULL,
                `distanceKm` REAL NOT NULL,
                `estimatedTimeMinutes` INTEGER NOT NULL,
                `difficulty` TEXT NOT NULL,
                `elevationGainMeters` INTEGER NOT NULL,
                `terrain` TEXT NOT NULL,
                `geometryGeoJson` TEXT NOT NULL,
                `savedAtEpochMillis` INTEGER NOT NULL
            )
            """.trimIndent()
        )
        db.execSQL(
            "CREATE UNIQUE INDEX IF NOT EXISTS `index_saved_routes_ownerUserId_routeKey` " +
                "ON `saved_routes` (`ownerUserId`, `routeKey`)"
        )
    }
}

val MIGRATION_5_6 = object : Migration(5, 6) {
    override fun migrate(db: SupportSQLiteDatabase) {
        db.execSQL(
            """
            CREATE TABLE IF NOT EXISTS `hike_plans` (
                `id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
                `ownerUserId` TEXT NOT NULL,
                `routeId` INTEGER NOT NULL,
                `routeName` TEXT NOT NULL,
                `plannedDateEpochDay` INTEGER NOT NULL,
                `checklistJson` TEXT NOT NULL,
                `createdAtEpochMillis` INTEGER NOT NULL,
                `updatedAtEpochMillis` INTEGER NOT NULL
            )
            """.trimIndent()
        )
        db.execSQL(
            "CREATE INDEX IF NOT EXISTS `index_hike_plans_ownerUserId_plannedDateEpochDay` " +
                "ON `hike_plans` (`ownerUserId`, `plannedDateEpochDay`)"
        )
    }
}

val MIGRATION_6_7 = object : Migration(6, 7) {
    override fun migrate(db: SupportSQLiteDatabase) {
        db.execSQL("ALTER TABLE `hike_plans` ADD COLUMN `routeSnapshotJson` TEXT")
    }
}

val MIGRATION_7_8 = object : Migration(7, 8) {
    override fun migrate(db: SupportSQLiteDatabase) {
        db.execSQL(
            """
            CREATE TABLE IF NOT EXISTS `route_map_downloads` (
                `id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
                `ownerUserId` TEXT NOT NULL,
                `routeKey` TEXT NOT NULL,
                `routeId` INTEGER NOT NULL,
                `routeName` TEXT NOT NULL,
                `routeGeometryGeoJson` TEXT NOT NULL,
                `north` REAL NOT NULL,
                `east` REAL NOT NULL,
                `south` REAL NOT NULL,
                `west` REAL NOT NULL,
                `minZoom` REAL NOT NULL,
                `maxZoom` REAL NOT NULL,
                `mapLibreRegionId` INTEGER,
                `status` TEXT NOT NULL,
                `completedResourceCount` INTEGER NOT NULL,
                `requiredResourceCount` INTEGER,
                `completedResourceSizeBytes` INTEGER NOT NULL,
                `completedTileCount` INTEGER NOT NULL,
                `completedTileSizeBytes` INTEGER NOT NULL,
                `estimatedMinBytes` INTEGER NOT NULL,
                `estimatedMaxBytes` INTEGER NOT NULL,
                `errorMessage` TEXT,
                `createdAtEpochMillis` INTEGER NOT NULL,
                `updatedAtEpochMillis` INTEGER NOT NULL
            )
            """.trimIndent()
        )
        db.execSQL(
            "CREATE UNIQUE INDEX IF NOT EXISTS " +
                "`index_route_map_downloads_ownerUserId_routeKey` " +
                "ON `route_map_downloads` (`ownerUserId`, `routeKey`)"
        )
    }
}

val MIGRATION_8_9 = object : Migration(8, 9) {
    override fun migrate(db: SupportSQLiteDatabase) {
        db.execSQL(
            """
            CREATE TABLE IF NOT EXISTS `emergency_contacts` (
                `id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
                `ownerUserId` TEXT NOT NULL,
                `name` TEXT,
                `phoneNumber` TEXT NOT NULL,
                `updatedAtEpochMillis` INTEGER NOT NULL
            )
            """.trimIndent()
        )
        db.execSQL(
            "CREATE UNIQUE INDEX IF NOT EXISTS `index_emergency_contacts_ownerUserId` " +
                "ON `emergency_contacts` (`ownerUserId`)"
        )
    }
}

val MIGRATION_9_10 = object : Migration(9, 10) {
    override fun migrate(db: SupportSQLiteDatabase) {
        db.execSQL(
            """
            CREATE TABLE IF NOT EXISTS `active_route_tracking_sessions` (
                `id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
                `ownerUserId` TEXT NOT NULL,
                `routeId` INTEGER NOT NULL,
                `routeName` TEXT NOT NULL,
                `routeDescription` TEXT NOT NULL,
                `routeDistanceKm` REAL NOT NULL,
                `routeEstimatedTimeMinutes` INTEGER NOT NULL,
                `routeDifficulty` TEXT NOT NULL,
                `routeElevationGainMeters` INTEGER NOT NULL,
                `routeTerrain` TEXT NOT NULL,
                `routeGeometryGeoJson` TEXT NOT NULL,
                `userLongitude` REAL NOT NULL,
                `userLatitude` REAL NOT NULL,
                `bearingDegrees` REAL NOT NULL,
                `pointIndex` INTEGER NOT NULL,
                `status` TEXT NOT NULL,
                `walkedPathGeoJson` TEXT NOT NULL,
                `walkedDistanceKm` REAL NOT NULL,
                `activeElapsedMillis` INTEGER NOT NULL,
                `startedAtEpochMillis` INTEGER NOT NULL,
                `updatedAtEpochMillis` INTEGER NOT NULL
            )
            """.trimIndent()
        )
        db.execSQL(
            "CREATE UNIQUE INDEX IF NOT EXISTS `index_active_route_tracking_sessions_ownerUserId` " +
                "ON `active_route_tracking_sessions` (`ownerUserId`)"
        )
    }
}

val MIGRATION_10_11 = object : Migration(10, 11) {
    override fun migrate(db: SupportSQLiteDatabase) {
        db.execSQL(
            """
            CREATE TABLE IF NOT EXISTS `achievements` (
                `id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
                `ownerUserId` TEXT NOT NULL,
                `serverId` INTEGER,
                `code` TEXT NOT NULL,
                `progressValue` REAL NOT NULL,
                `targetValue` REAL NOT NULL,
                `completedAtEpochMillis` INTEGER,
                `updatedAtEpochMillis` INTEGER NOT NULL
            )
            """.trimIndent()
        )
        db.execSQL(
            "CREATE UNIQUE INDEX IF NOT EXISTS `index_achievements_ownerUserId_code` " +
                "ON `achievements` (`ownerUserId`, `code`)"
        )
    }
}

val MIGRATION_11_12 = object : Migration(11, 12) {
    override fun migrate(db: SupportSQLiteDatabase) {
        db.execSQL("ALTER TABLE `hike_logs` ADD COLUMN `elevationGainMeters` INTEGER NOT NULL DEFAULT 0")
    }
}

val MIGRATION_12_13 = object : Migration(12, 13) {
    override fun migrate(db: SupportSQLiteDatabase) {
        db.execSQL(
            """
            UPDATE `hike_logs`
            SET `syncState` = 'PENDING'
            WHERE `deleted` = 0
              AND `serverId` IS NOT NULL
              AND `syncState` = 'SYNCED'
              AND `elevationGainMeters` = 0
            """.trimIndent()
        )
    }
}

val MIGRATION_13_14 = object : Migration(13, 14) {
    override fun migrate(db: SupportSQLiteDatabase) {
        db.execSQL("ALTER TABLE `routes` ADD COLUMN `visibility` TEXT NOT NULL DEFAULT 'PRIVATE'")
    }
}

private fun addSyncColumns(
    db: SupportSQLiteDatabase,
    table: String,
    includeRouteReference: Boolean,
) {
    db.execSQL("ALTER TABLE `$table` ADD COLUMN `clientId` TEXT NOT NULL DEFAULT ''")
    db.execSQL("ALTER TABLE `$table` ADD COLUMN `serverId` INTEGER")
    db.execSQL("ALTER TABLE `$table` ADD COLUMN `syncVersion` INTEGER NOT NULL DEFAULT 0")
    db.execSQL("ALTER TABLE `$table` ADD COLUMN `updatedAtEpochMillis` INTEGER NOT NULL DEFAULT 0")
    db.execSQL("ALTER TABLE `$table` ADD COLUMN `syncState` TEXT NOT NULL DEFAULT 'PENDING'")
    db.execSQL("ALTER TABLE `$table` ADD COLUMN `deleted` INTEGER NOT NULL DEFAULT 0")
    if (includeRouteReference) {
        db.execSQL("ALTER TABLE `$table` ADD COLUMN `routeClientId` TEXT")
        db.execSQL("ALTER TABLE `$table` ADD COLUMN `routeServerId` INTEGER")
    }
}

private fun assignClientIds(db: SupportSQLiteDatabase, table: String) {
    db.query("SELECT id FROM `$table` WHERE clientId = ''").use { cursor ->
        val idIndex = cursor.getColumnIndexOrThrow("id")
        while (cursor.moveToNext()) {
            db.execSQL(
                "UPDATE `$table` SET clientId = ? WHERE id = ?",
                arrayOf<Any>(UUID.randomUUID().toString(), cursor.getLong(idIndex)),
            )
        }
    }
}
