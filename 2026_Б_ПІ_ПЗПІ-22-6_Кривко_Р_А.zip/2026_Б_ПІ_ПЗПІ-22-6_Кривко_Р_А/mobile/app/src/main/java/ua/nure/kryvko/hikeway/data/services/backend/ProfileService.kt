package ua.nure.kryvko.hikeway.data.services.backend

import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.PATCH
import ua.nure.kryvko.hikeway.domain.profile.UpdateUserProfileRequest
import ua.nure.kryvko.hikeway.domain.profile.UserProfile

data class UserProfileDto(
    val id: Long,
    val keycloakId: String,
    val email: String,
    val username: String,
    val firstName: String,
    val lastName: String,
)

data class UpdateUserProfileDto(
    val email: String?,
    val username: String?,
    val firstName: String?,
    val lastName: String?,
)

interface ProfileService {
    @GET("profile/me")
    suspend fun currentProfile(): UserProfileDto

    @PATCH("profile/me")
    suspend fun updateProfile(@Body request: UpdateUserProfileDto): UserProfileDto
}

fun UserProfileDto.toDomain() = UserProfile(
    id = id,
    keycloakId = keycloakId,
    email = email,
    username = username,
    firstName = firstName,
    lastName = lastName,
)

fun UpdateUserProfileRequest.toDto() = UpdateUserProfileDto(
    email = email,
    username = username,
    firstName = firstName,
    lastName = lastName,
)
