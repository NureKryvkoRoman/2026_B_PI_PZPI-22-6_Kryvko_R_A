package ua.nure.kryvko.hikeway.domain.profile

import javax.inject.Inject

data class UserProfile(
    val id: Long,
    val keycloakId: String,
    val email: String,
    val username: String,
    val firstName: String,
    val lastName: String,
) {
    val fullName: String
        get() = listOf(firstName, lastName)
            .map(String::trim)
            .filter(String::isNotBlank)
            .joinToString(" ")
}

data class UpdateUserProfileRequest(
    val email: String,
    val username: String,
    val firstName: String,
    val lastName: String,
)

interface ProfileRepository {
    suspend fun currentProfile(): UserProfile
    suspend fun updateProfile(request: UpdateUserProfileRequest): UserProfile
}

class GetCurrentProfileUseCase @Inject constructor(
    private val repository: ProfileRepository,
) {
    suspend operator fun invoke(): UserProfile = repository.currentProfile()
}

class UpdateCurrentProfileUseCase @Inject constructor(
    private val repository: ProfileRepository,
) {
    suspend operator fun invoke(request: UpdateUserProfileRequest): UserProfile {
        return repository.updateProfile(request)
    }
}
