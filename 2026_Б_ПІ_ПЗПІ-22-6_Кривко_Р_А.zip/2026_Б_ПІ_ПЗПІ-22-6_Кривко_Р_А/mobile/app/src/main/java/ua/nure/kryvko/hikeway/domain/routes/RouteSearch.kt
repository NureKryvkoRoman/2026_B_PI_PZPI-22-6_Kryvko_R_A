package ua.nure.kryvko.hikeway.domain.routes

import kotlin.math.asin
import kotlin.math.cos
import kotlin.math.pow
import kotlin.math.sin
import kotlin.math.sqrt
import kotlinx.coroutines.flow.Flow
import ua.nure.kryvko.hikeway.core.location.LocationProvider
import ua.nure.kryvko.hikeway.core.model.Difficulty
import ua.nure.kryvko.hikeway.core.model.GeoPoint
import ua.nure.kryvko.hikeway.core.model.Route
import ua.nure.kryvko.hikeway.core.model.RouteComment
import ua.nure.kryvko.hikeway.core.model.RouteRating
import ua.nure.kryvko.hikeway.core.model.Terrain
import javax.inject.Inject

data class RouteSearchCriteria(
    val distanceKm: ClosedFloatingPointRange<Double>? = null,
    val estimatedTimeMinutes: IntRange? = null,
    val difficulties: Set<Difficulty> = emptySet(),
    val terrains: Set<Terrain> = emptySet(),
    val maxProximityKm: Double? = null,
)

interface RouteRepository {
    suspend fun search(criteria: RouteSearchCriteria, origin: GeoPoint): List<Route>
}

interface RecommendedRouteRepository {
    suspend fun recommended(origin: GeoPoint?): List<Route>
}

interface RouteDetailRepository {
    suspend fun findById(id: Long): Route?
    suspend fun findByClientId(clientId: String): Route?
    suspend fun findByServerId(serverId: Long): Route?
}

interface RouteContentRepository {
    suspend fun submitRating(routeId: Long, rating: Int): RouteRating
    suspend fun removeRating(routeId: Long): RouteRating
    suspend fun getComments(routeId: Long): List<RouteComment>
    suspend fun addComment(routeId: Long, text: String): RouteComment
    suspend fun updateComment(routeId: Long, commentId: Long, text: String): RouteComment
    suspend fun deleteComment(routeId: Long, commentId: Long)
}

interface CustomRouteRepository {
    fun observeAll(): Flow<List<Route>>
    suspend fun save(route: Route): Long
    suspend fun publish(route: Route): Route
    suspend fun delete(route: Route)
}

class SearchRoutesUseCase @Inject constructor(
    private val repository: RouteRepository,
    private val locationProvider: LocationProvider,
) {
    suspend operator fun invoke(
        criteria: RouteSearchCriteria,
        originOverride: GeoPoint? = null,
    ): List<Route> {
        return repository.search(criteria, originOverride ?: locationProvider.getCurrentLocation())
    }
}

class GetRecommendedRoutesUseCase @Inject constructor(
    private val repository: RecommendedRouteRepository,
    private val locationProvider: LocationProvider,
) {
    suspend operator fun invoke(): List<Route> {
        val origin = runCatching { locationProvider.getCurrentLocation() }.getOrNull()
        return repository.recommended(origin)
    }
}

class GetRouteUseCase @Inject constructor(
    private val repository: RouteDetailRepository,
) {
    suspend operator fun invoke(
        routeId: Long,
        routeClientId: String?,
        routeServerId: Long?,
    ): Route? {
        return routeClientId?.let { repository.findByClientId(it) }
            ?: routeServerId?.let { repository.findByServerId(it) }
            ?: repository.findById(routeId)
    }
}

class GetCurrentLocationUseCase @Inject constructor(
    private val locationProvider: LocationProvider,
) {
    suspend operator fun invoke(): GeoPoint {
        return locationProvider.getCurrentLocation()
    }
}

class SaveCustomRouteUseCase @Inject constructor(
    private val repository: CustomRouteRepository,
) {
    suspend operator fun invoke(route: Route): Long = repository.save(route)
}

class ObserveUserCreatedRoutesUseCase @Inject constructor(
    private val repository: CustomRouteRepository,
) {
    operator fun invoke(): Flow<List<Route>> = repository.observeAll()
}

class PublishCustomRouteUseCase @Inject constructor(
    private val repository: CustomRouteRepository,
) {
    suspend operator fun invoke(route: Route): Route = repository.publish(route)
}

class DeleteCustomRouteUseCase @Inject constructor(
    private val repository: CustomRouteRepository,
) {
    suspend operator fun invoke(route: Route) = repository.delete(route)
}

class RateRouteUseCase @Inject constructor(
    private val repository: RouteContentRepository,
) {
    suspend operator fun invoke(routeId: Long, rating: Int): RouteRating {
        require(rating in 1..5) { "Rating must be from 1 to 5." }
        return repository.submitRating(routeId, rating)
    }
}

class RemoveRouteRatingUseCase @Inject constructor(
    private val repository: RouteContentRepository,
) {
    suspend operator fun invoke(routeId: Long): RouteRating {
        return repository.removeRating(routeId)
    }
}

class GetRouteCommentsUseCase @Inject constructor(
    private val repository: RouteContentRepository,
) {
    suspend operator fun invoke(routeId: Long): List<RouteComment> {
        return repository.getComments(routeId)
    }
}

class AddRouteCommentUseCase @Inject constructor(
    private val repository: RouteContentRepository,
) {
    suspend operator fun invoke(routeId: Long, text: String): RouteComment {
        return repository.addComment(routeId, requireCommentText(text))
    }
}

class UpdateRouteCommentUseCase @Inject constructor(
    private val repository: RouteContentRepository,
) {
    suspend operator fun invoke(routeId: Long, commentId: Long, text: String): RouteComment {
        return repository.updateComment(routeId, commentId, requireCommentText(text))
    }
}

class DeleteRouteCommentUseCase @Inject constructor(
    private val repository: RouteContentRepository,
) {
    suspend operator fun invoke(routeId: Long, commentId: Long) {
        repository.deleteComment(routeId, commentId)
    }
}

fun Route.matches(criteria: RouteSearchCriteria, origin: GeoPoint): Boolean {
    return criteria.distanceKm?.contains(distanceKm) != false &&
        criteria.estimatedTimeMinutes?.contains(estimatedTimeMinutes) != false &&
        (criteria.difficulties.isEmpty() || difficulty in criteria.difficulties) &&
        (criteria.terrains.isEmpty() || terrain in criteria.terrains) &&
        criteria.maxProximityKm?.let { maximum ->
            geometry.points.firstOrNull()?.let { distanceKm(origin, it) <= maximum } ?: false
        } != false
}

fun distanceKm(from: GeoPoint, to: GeoPoint): Double {
    val earthRadiusKm = 6371.0
    val latitudeDelta = Math.toRadians(to.latitude - from.latitude)
    val longitudeDelta = Math.toRadians(to.longitude - from.longitude)
    val fromLatitude = Math.toRadians(from.latitude)
    val toLatitude = Math.toRadians(to.latitude)
    val haversine = sin(latitudeDelta / 2).pow(2) +
        cos(fromLatitude) * cos(toLatitude) * sin(longitudeDelta / 2).pow(2)
    return earthRadiusKm * 2 * asin(sqrt(haversine))
}

private fun requireCommentText(text: String): String {
    val trimmed = text.trim()
    require(trimmed.isNotEmpty()) { "Comment is required." }
    require(trimmed.length <= 2000) { "Comment must be at most 2000 characters." }
    return trimmed
}
