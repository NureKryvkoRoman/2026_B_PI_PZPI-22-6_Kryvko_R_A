package ua.nure.kryvko.hikeway.feature.profile

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import ua.nure.kryvko.hikeway.data.services.network.ApiException
import ua.nure.kryvko.hikeway.domain.profile.GetCurrentProfileUseCase
import ua.nure.kryvko.hikeway.domain.profile.UpdateCurrentProfileUseCase
import ua.nure.kryvko.hikeway.domain.profile.UpdateUserProfileRequest
import ua.nure.kryvko.hikeway.domain.profile.UserProfile

data class ProfileFieldErrors(
    val username: String? = null,
    val email: String? = null,
    val firstName: String? = null,
    val lastName: String? = null,
) {
    val hasErrors: Boolean
        get() = listOf(username, email, firstName, lastName).any { it != null }
}

data class ProfileUiState(
    val profile: UserProfile? = null,
    val activeUserId: String? = null,
    val username: String = "",
    val email: String = "",
    val firstName: String = "",
    val lastName: String = "",
    val isLoading: Boolean = false,
    val isSaving: Boolean = false,
    val errorMessage: String? = null,
    val successMessage: String? = null,
    val fieldErrors: ProfileFieldErrors = ProfileFieldErrors(),
) {
    val displayUsername: String
        get() = profile?.username ?: username

    val displayEmail: String
        get() = profile?.email.orEmpty()

    val displayFullName: String
        get() = profile?.fullName.orEmpty()
}

@HiltViewModel
class ProfileViewModel @Inject constructor(
    private val getCurrentProfile: GetCurrentProfileUseCase,
    private val updateCurrentProfile: UpdateCurrentProfileUseCase,
) : ViewModel() {
    private val _uiState = MutableStateFlow(ProfileUiState())
    val uiState: StateFlow<ProfileUiState> = _uiState.asStateFlow()

    fun loadForUser(userId: String) {
        if (userId.isBlank()) {
            _uiState.value = ProfileUiState()
            return
        }
        if (_uiState.value.activeUserId == userId && _uiState.value.profile != null) {
            return
        }
        _uiState.value = ProfileUiState(activeUserId = userId, isLoading = true)
        refresh()
    }

    fun refresh() {
        val activeUserId = _uiState.value.activeUserId
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true, errorMessage = null) }
            runCatching { getCurrentProfile() }
                .onSuccess { profile ->
                    _uiState.update {
                        it.copy(
                            profile = profile,
                            activeUserId = activeUserId ?: profile.keycloakId,
                            username = profile.username,
                            email = profile.email,
                            firstName = profile.firstName,
                            lastName = profile.lastName,
                            isLoading = false,
                            errorMessage = null,
                            fieldErrors = ProfileFieldErrors(),
                        )
                    }
                }
                .onFailure { error ->
                    _uiState.update {
                        it.copy(
                            isLoading = false,
                            errorMessage = error.userMessage("Profile is unavailable."),
                        )
                    }
                }
        }
    }

    fun beginEditing() {
        val profile = _uiState.value.profile ?: return
        _uiState.update {
            it.copy(
                username = profile.username,
                email = profile.email,
                firstName = profile.firstName,
                lastName = profile.lastName,
                errorMessage = null,
                successMessage = null,
                fieldErrors = ProfileFieldErrors(),
            )
        }
    }

    fun updateUsername(username: String) {
        _uiState.update {
            it.copy(username = username, fieldErrors = it.fieldErrors.copy(username = null), errorMessage = null)
        }
    }

    fun updateEmail(email: String) {
        _uiState.update {
            it.copy(email = email, fieldErrors = it.fieldErrors.copy(email = null), errorMessage = null)
        }
    }

    fun updateFirstName(firstName: String) {
        _uiState.update {
            it.copy(firstName = firstName, fieldErrors = it.fieldErrors.copy(firstName = null), errorMessage = null)
        }
    }

    fun updateLastName(lastName: String) {
        _uiState.update {
            it.copy(lastName = lastName, fieldErrors = it.fieldErrors.copy(lastName = null), errorMessage = null)
        }
    }

    fun save(onSaved: () -> Unit = {}) {
        val state = _uiState.value
        val errors = validateProfile(state)
        if (errors.hasErrors) {
            _uiState.update { it.copy(fieldErrors = errors, successMessage = null) }
            return
        }

        val request = UpdateUserProfileRequest(
            email = state.email.trim(),
            username = state.username.trim(),
            firstName = state.firstName.trim(),
            lastName = state.lastName.trim(),
        )
        viewModelScope.launch {
            _uiState.update {
                it.copy(
                    isSaving = true,
                    errorMessage = null,
                    successMessage = null,
                    fieldErrors = ProfileFieldErrors(),
                )
            }
            runCatching { updateCurrentProfile(request) }
                .onSuccess { profile ->
                    _uiState.update {
                        it.copy(
                            profile = profile,
                            username = profile.username,
                            email = profile.email,
                            firstName = profile.firstName,
                            lastName = profile.lastName,
                            isSaving = false,
                            successMessage = "Profile saved.",
                            errorMessage = null,
                        )
                    }
                    onSaved()
                }
                .onFailure { error ->
                    _uiState.update {
                        it.copy(
                            isSaving = false,
                            errorMessage = error.userMessage("Could not save profile."),
                        )
                    }
                }
        }
    }

    private fun validateProfile(state: ProfileUiState): ProfileFieldErrors {
        return ProfileFieldErrors(
            username = when {
                state.username.isBlank() -> "Username is required."
                else -> null
            },
            email = when {
                state.email.isBlank() -> "Email is required."
                !state.email.trim().isValidEmail() -> "Email is invalid."
                else -> null
            },
            firstName = when {
                state.firstName.isBlank() -> "First name is required."
                else -> null
            },
            lastName = when {
                state.lastName.isBlank() -> "Last name is required."
                else -> null
            },
        )
    }
}

private fun Throwable.userMessage(fallback: String): String {
    return when {
        this is ApiException && code == "USER_ALREADY_EXISTS" -> "Email or username is already in use."
        else -> message ?: fallback
    }
}

private fun String.isValidEmail(): Boolean {
    return Regex("^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+$").matches(this)
}
