package ua.nure.kryvko.hikeway.domain.safety

import kotlinx.coroutines.flow.Flow
import ua.nure.kryvko.hikeway.core.model.GeoPoint
import ua.nure.kryvko.hikeway.core.model.Route
import javax.inject.Inject

data class EmergencyContact(
    val id: Long = 0,
    val name: String?,
    val phoneNumber: String,
)

data class SosSmsMessage(
    val phoneNumber: String,
    val body: String,
)

interface EmergencyContactRepository {
    fun observePrimaryContact(): Flow<EmergencyContact?>
    suspend fun savePrimaryContact(name: String?, phoneNumber: String): EmergencyContact
    suspend fun deletePrimaryContact()
}

class ObservePrimaryEmergencyContactUseCase @Inject constructor(
    private val repository: EmergencyContactRepository,
) {
    operator fun invoke(): Flow<EmergencyContact?> = repository.observePrimaryContact()
}

class SavePrimaryEmergencyContactUseCase @Inject constructor(
    private val repository: EmergencyContactRepository,
) {
    suspend operator fun invoke(name: String?, phoneNumber: String): EmergencyContact {
        require(phoneNumber.isNotBlank()) { "Phone number is required." }
        return repository.savePrimaryContact(
            name = name?.trim()?.takeIf { it.isNotBlank() },
            phoneNumber = phoneNumber.trim(),
        )
    }
}

class DeletePrimaryEmergencyContactUseCase @Inject constructor(
    private val repository: EmergencyContactRepository,
) {
    suspend operator fun invoke() = repository.deletePrimaryContact()
}

class BuildSosSmsMessageUseCase @Inject constructor() {
    operator fun invoke(
        contact: EmergencyContact,
        username: String,
        route: Route,
        location: GeoPoint?,
    ): SosSmsMessage {
        val locationText = if (location == null) {
            "Location is unavailable."
        } else {
            val latitude = location.latitude
            val longitude = location.longitude
            "Location: $latitude, $longitude\nhttps://maps.google.com/?q=$latitude,$longitude"
        }
        val senderText = username.trim().takeIf { it.isNotBlank() } ?: "Unknown user"
        return SosSmsMessage(
            phoneNumber = contact.phoneNumber,
            body = "SOS signal from HikeWay.\nUser: $senderText\nRoute: ${route.name}\n$locationText",
        )
    }
}
