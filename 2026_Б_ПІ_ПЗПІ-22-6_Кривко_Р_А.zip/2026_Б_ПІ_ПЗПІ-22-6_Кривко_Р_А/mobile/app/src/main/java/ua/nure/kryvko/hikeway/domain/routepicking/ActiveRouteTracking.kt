package ua.nure.kryvko.hikeway.domain.routepicking

import kotlinx.coroutines.flow.Flow
import javax.inject.Inject

interface ActiveRouteTrackingSessionRepository {
    fun observe(): Flow<RoutePickingSession?>
    suspend fun save(session: RoutePickingSession)
    suspend fun delete()
}

class ObserveActiveRouteTrackingSessionUseCase @Inject constructor(
    private val repository: ActiveRouteTrackingSessionRepository,
) {
    operator fun invoke(): Flow<RoutePickingSession?> = repository.observe()
}

class SaveActiveRouteTrackingSessionUseCase @Inject constructor(
    private val repository: ActiveRouteTrackingSessionRepository,
) {
    suspend operator fun invoke(session: RoutePickingSession) = repository.save(session)
}

class DeleteActiveRouteTrackingSessionUseCase @Inject constructor(
    private val repository: ActiveRouteTrackingSessionRepository,
) {
    suspend operator fun invoke() = repository.delete()
}

fun RoutePickingSession.restoredPaused(): RoutePickingSession {
    return copy(status = RoutePickingStatus.PAUSED)
}

