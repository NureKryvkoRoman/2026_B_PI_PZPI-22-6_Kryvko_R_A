package ua.nure.kryvko.hikeway.domain.weather

import java.time.Instant
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.LocalTime
import javax.inject.Inject

data class HikePlanWeather(
    val routeId: Long,
    val date: LocalDate,
    val timezone: String?,
    val summary: DailyPlanWeather,
    val hourlyForecast: List<HourlyPlanWeather>,
    val risks: List<WeatherRiskUiModel>,
    val recommendation: StartTimeRecommendation,
    val dataSource: String,
    val lastUpdated: Instant,
)

data class DailyPlanWeather(
    val weatherCode: Int?,
    val condition: String?,
    val temperatureMaxC: Double?,
    val temperatureMinC: Double?,
    val sunrise: LocalTime?,
    val sunset: LocalTime?,
    val daylightDurationSeconds: Long?,
    val uvIndexMax: Double?,
    val precipitationSumMm: Double?,
    val precipitationProbabilityMaxPercent: Int?,
    val windSpeedMaxKmh: Double?,
    val windGustsMaxKmh: Double?,
)

data class HourlyPlanWeather(
    val time: LocalDateTime,
    val temperatureC: Double?,
    val apparentTemperatureC: Double?,
    val precipitationProbabilityPercent: Int?,
    val precipitationMm: Double?,
    val weatherCode: Int?,
    val condition: String?,
    val windGustsKmh: Double?,
)

data class WeatherRiskUiModel(
    val type: String,
    val severity: String,
    val message: String,
)

data class StartTimeRecommendation(
    val recommendedStartTime: LocalDateTime?,
    val expectedReturnTime: LocalDateTime?,
    val explanation: String?,
)

interface WeatherRepository {
    suspend fun getHikePlanWeather(routeId: Long, date: LocalDate): HikePlanWeather
}

class GetHikePlanWeatherUseCase @Inject constructor(
    private val repository: WeatherRepository,
) {
    suspend operator fun invoke(routeId: Long, date: LocalDate): HikePlanWeather {
        return repository.getHikePlanWeather(routeId, date)
    }
}

class RefreshHikePlanWeatherUseCase @Inject constructor(
    private val repository: WeatherRepository,
) {
    suspend operator fun invoke(routeId: Long, date: LocalDate): HikePlanWeather {
        return repository.getHikePlanWeather(routeId, date)
    }
}
