package ua.nure.kryvko.hikeway.ui.map

import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.DpSize
import androidx.compose.ui.unit.dp
import org.maplibre.compose.expressions.dsl.image
import org.maplibre.compose.expressions.dsl.const
import org.maplibre.compose.layers.LineLayer
import org.maplibre.compose.layers.SymbolLayer
import org.maplibre.compose.sources.GeoJsonData
import org.maplibre.compose.sources.rememberGeoJsonSource
import ua.nure.kryvko.hikeway.R
import ua.nure.kryvko.hikeway.core.model.GeoPoint

@Composable
@Suppress("COMPOSE_APPLIER_CALL_MISMATCH")
fun PathMap(
    path: List<GeoPoint>,
    modifier: Modifier = Modifier,
    pathColor: Color = Color.Unspecified,
) {
    val effectivePathColor = if (pathColor == Color.Unspecified) {
        MaterialTheme.colorScheme.primary
    } else {
        pathColor
    }
    val geoJson = remember(path) { path.toLineStringFeatureGeoJson() }
    val startGeoJson = remember(path) { path.take(1).toPointFeatureCollectionGeoJson() }
    val endGeoJson = remember(path) {
        if (path.size >= 2) listOf(path.last()).toPointFeatureCollectionGeoJson() else emptyFeatureCollectionGeoJson()
    }
    val routeStartPainter = painterResource(R.drawable.ic_route_start)
    val routeEndPainter = painterResource(R.drawable.ic_route_end)

    HikeWayMap(
        centerMode = MapCenterMode.RouteStart(path),
        initialZoom = 12.0,
        modifier = modifier,
    ) {
        val source = rememberGeoJsonSource(GeoJsonData.JsonString(geoJson))
        LineLayer(
            id = "path",
            source = source,
            color = const(effectivePathColor),
            width = const(5.dp),
        )
        if (path.isNotEmpty()) {
            val startSource = rememberGeoJsonSource(GeoJsonData.JsonString(startGeoJson))
            SymbolLayer(
                id = "path-start",
                source = startSource,
                iconImage = image(
                    value = routeStartPainter,
                    size = DpSize(30.dp, 30.dp),
                    drawAsSdf = false,
                ),
                iconAllowOverlap = const(true),
                iconIgnorePlacement = const(true),
            )
        }
        if (path.size >= 2) {
            val endSource = rememberGeoJsonSource(GeoJsonData.JsonString(endGeoJson))
            SymbolLayer(
                id = "path-end",
                source = endSource,
                iconImage = image(
                    value = routeEndPainter,
                    size = DpSize(30.dp, 30.dp),
                    drawAsSdf = false,
                ),
                iconAllowOverlap = const(true),
                iconIgnorePlacement = const(true),
            )
        }
    }
}
