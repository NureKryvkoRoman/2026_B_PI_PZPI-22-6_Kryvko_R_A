package ua.nure.kryvko.hikeway.feature.routesearch

import androidx.annotation.StringRes
import androidx.compose.runtime.Composable
import androidx.compose.ui.res.stringResource
import java.util.Locale
import ua.nure.kryvko.hikeway.R
import ua.nure.kryvko.hikeway.core.model.Difficulty
import ua.nure.kryvko.hikeway.core.model.Terrain
import ua.nure.kryvko.hikeway.domain.routepicking.RoutePickingStatus

@Composable
fun Difficulty.label(): String = stringResource(difficultyLabelRes())

@Composable
fun Terrain.label(): String = stringResource(terrainLabelRes())

@StringRes
fun Difficulty.difficultyLabelRes(): Int {
    return when (this) {
        Difficulty.EASY -> R.string.difficulty_easy
        Difficulty.MEDIUM -> R.string.difficulty_medium
        Difficulty.HARD -> R.string.difficulty_hard
    }
}

@StringRes
fun Terrain.terrainLabelRes(): Int {
    return when (this) {
        Terrain.FOREST -> R.string.terrain_forest
        Terrain.MOUNTAIN -> R.string.terrain_mountain
        Terrain.ROCKY -> R.string.terrain_rocky
        Terrain.MIXED -> R.string.terrain_mixed
    }
}

fun RoutePickingStatus.label() = name.lowercase().replaceFirstChar(Char::uppercase)

fun Long.formatDuration(): String {
    val totalSeconds = this / 1_000
    val hours = totalSeconds / 3_600
    val minutes = (totalSeconds % 3_600) / 60
    val seconds = totalSeconds % 60
    return "%02d:%02d:%02d".format(Locale.US, hours, minutes, seconds)
}

fun Double.formatDistance(): String {
    return "%.2f km".format(Locale.US, this)
}
