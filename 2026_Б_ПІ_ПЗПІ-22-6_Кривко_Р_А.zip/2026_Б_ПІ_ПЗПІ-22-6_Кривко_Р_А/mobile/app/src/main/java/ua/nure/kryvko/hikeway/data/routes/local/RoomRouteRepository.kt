package ua.nure.kryvko.hikeway.data.routes.local

import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.map
import retrofit2.HttpException
import ua.nure.kryvko.hikeway.data.services.backend.SyncService
import ua.nure.kryvko.hikeway.data.sync.RouteChangeDto
import ua.nure.kryvko.hikeway.data.sync.SyncTrigger
import ua.nure.kryvko.hikeway.core.model.Difficulty
import ua.nure.kryvko.hikeway.core.model.GeoPoint
import ua.nure.kryvko.hikeway.core.model.Route
import ua.nure.kryvko.hikeway.core.model.RouteGeometry
import ua.nure.kryvko.hikeway.core.model.RouteVisibility
import ua.nure.kryvko.hikeway.core.model.Terrain
import ua.nure.kryvko.hikeway.data.geojson.GeoJsonLineStringCodec
import ua.nure.kryvko.hikeway.domain.auth.CurrentUserProvider
import ua.nure.kryvko.hikeway.domain.routes.CustomRouteRepository
import ua.nure.kryvko.hikeway.domain.routes.RouteDetailRepository
import ua.nure.kryvko.hikeway.domain.routes.RouteRepository
import ua.nure.kryvko.hikeway.domain.routes.RouteSearchCriteria
import ua.nure.kryvko.hikeway.domain.routes.matches
import java.util.UUID

class RoomRouteRepository(
    private val dao: RouteDao,
    private val currentUserProvider: CurrentUserProvider,
    private val syncService: SyncService,
    private val syncTrigger: SyncTrigger,
    private val onLocalMutation: suspend () -> Unit = {},
) : RouteRepository, CustomRouteRepository, RouteDetailRepository {
    @OptIn(ExperimentalCoroutinesApi::class)
    override fun observeAll(): Flow<List<Route>> {
        return currentUserProvider.currentUserId.flatMapLatest { ownerUserId ->
            if (ownerUserId == null) {
                flowOf(emptyList())
            } else {
                dao.observeAll(ownerUserId).map { routes -> routes.map { it.toDomain() } }
            }
        }
    }

    override suspend fun search(criteria: RouteSearchCriteria, origin: GeoPoint): List<Route> {
        val ownerUserId = currentUserProvider.currentUserId.value ?: return emptyList()
        return dao.getAll(ownerUserId)
            .map { it.toDomain() }
            .filter { it.matches(criteria, origin) }
    }

    override suspend fun findById(id: Long): Route? {
        val ownerUserId = currentUserProvider.currentUserId.value ?: return null
        return dao.findById(ownerUserId, id)?.toDomain()
    }

    override suspend fun findByClientId(clientId: String): Route? {
        val ownerUserId = currentUserProvider.currentUserId.value ?: return null
        return dao.findByClientId(ownerUserId, clientId)?.toDomain()
    }

    override suspend fun findByServerId(serverId: Long): Route? {
        val ownerUserId = currentUserProvider.currentUserId.value ?: return null
        return dao.findByServerId(ownerUserId, serverId)?.toDomain()
    }

    override suspend fun save(route: Route): Long {
        return dao.insert(route.toEntity(currentUserProvider.requireCurrentUserId()))
            .also { runCatching { onLocalMutation() } }
    }

    override suspend fun publish(route: Route): Route {
        val ownerUserId = currentUserProvider.requireCurrentUserId()
        var entity = requireLocalRoute(ownerUserId, route)
        if (entity.serverId == null || entity.syncState != "SYNCED") {
            syncTrigger()
            entity = requireLocalRoute(ownerUserId, route)
        }
        val change = syncService.publishRoute(entity.clientId)
        val publishedRoute = change.toRouteEntity(ownerUserId, entity).toDomain()
        dao.hardDeleteById(ownerUserId, entity.id)
        return publishedRoute
    }

    override suspend fun delete(route: Route) {
        val ownerUserId = currentUserProvider.requireCurrentUserId()
        val entity = dao.findById(ownerUserId, route.id)
        if (entity == null) {
            when {
                route.clientId != null && route.serverId != null -> deleteRemoteRoute(route.clientId, route.serverId)
                route.serverId != null -> syncService.deleteRouteByServerId(route.serverId)
            }
            return
        }
        if (entity.serverId == null) {
            dao.hardDeleteById(ownerUserId, entity.id)
            return
        }
        deleteRemoteRoute(entity.clientId, entity.serverId)
        dao.hardDeleteById(ownerUserId, entity.id)
    }

    private suspend fun deleteRemoteRoute(clientId: String, serverId: Long) {
        runCatching { syncService.deleteRoute(clientId) }
            .recoverCatching { error ->
                if (error is HttpException && error.code() == 404) {
                    syncService.deleteRouteByServerId(serverId)
                } else {
                    throw error
                }
            }
            .getOrThrow()
    }

    private suspend fun requireLocalRoute(ownerUserId: String, route: Route): RouteEntity {
        return dao.findById(ownerUserId, route.id) ?: error("Route is not available locally.")
    }

    private suspend fun applyRouteChange(
        ownerUserId: String,
        existing: RouteEntity,
        change: RouteChangeDto,
    ): Route {
        if (change.deleted) {
            dao.hardDeleteById(ownerUserId, existing.id)
            return existing.toDomain().copy(visibility = RouteVisibility.PRIVATE)
        }
        val entity = change.toRouteEntity(ownerUserId, existing)
        dao.upsert(entity)
        return entity.toDomain()
    }
}

private fun RouteChangeDto.toRouteEntity(
    ownerUserId: String,
    existing: RouteEntity,
) = RouteEntity(
    id = existing.id,
    ownerUserId = ownerUserId,
    name = requireNotNull(name),
    description = requireNotNull(description),
    distanceKm = requireNotNull(distanceKm),
    estimatedTimeMinutes = requireNotNull(estimatedTimeMinutes),
    difficulty = requireNotNull(difficulty),
    elevationGainMeters = requireNotNull(elevationGainMeters),
    terrain = requireNotNull(terrain),
    geometryGeoJson = requireNotNull(geometry).toGeoJson(),
    clientId = clientId,
    serverId = serverId,
    visibility = visibility ?: existing.visibility,
    syncVersion = version,
    updatedAtEpochMillis = updatedAt.toEpochMillis(),
    syncState = "SYNCED",
    deleted = false,
)

fun Route.toEntity(
    ownerUserId: String,
    clientId: String = UUID.randomUUID().toString(),
    updatedAtEpochMillis: Long = System.currentTimeMillis(),
) = RouteEntity(
    id = if (id < 0) 0 else id,
    ownerUserId = ownerUserId,
    name = name,
    description = description,
    distanceKm = distanceKm,
    estimatedTimeMinutes = estimatedTimeMinutes,
    difficulty = difficulty.name,
    elevationGainMeters = elevationGainMeters,
    terrain = terrain.name,
    geometryGeoJson = GeoJsonLineStringCodec.encode(geometry.points),
    clientId = clientId,
    visibility = visibility.name,
    updatedAtEpochMillis = updatedAtEpochMillis,
)

fun RouteEntity.toDomain() = Route(
    id = id,
    name = name,
    description = description,
    distanceKm = distanceKm,
    estimatedTimeMinutes = estimatedTimeMinutes,
    difficulty = Difficulty.valueOf(difficulty),
    elevationGainMeters = elevationGainMeters,
    terrain = Terrain.valueOf(terrain),
    geometry = RouteGeometry(GeoJsonLineStringCodec.decode(geometryGeoJson)),
    clientId = clientId,
    serverId = serverId,
    createdBy = ownerUserId,
    visibility = RouteVisibility.valueOf(visibility),
)

private fun ua.nure.kryvko.hikeway.data.sync.GeoJsonLineStringDto.toGeoJson(): String {
    return GeoJsonLineStringCodec.encode(
        coordinates.map { coordinate ->
            GeoPoint(
                longitude = coordinate[0],
                latitude = coordinate[1],
            )
        }
    )
}

private fun String.toEpochMillis(): Long = java.time.Instant.parse(this).toEpochMilli()
