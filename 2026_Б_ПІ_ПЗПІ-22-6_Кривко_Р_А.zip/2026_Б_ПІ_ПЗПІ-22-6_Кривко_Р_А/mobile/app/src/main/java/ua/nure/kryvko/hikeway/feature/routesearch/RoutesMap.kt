package ua.nure.kryvko.hikeway.feature.routesearch

import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.DpSize
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.serialization.json.jsonPrimitive
import kotlinx.serialization.json.longOrNull
import org.maplibre.compose.expressions.dsl.const
import org.maplibre.compose.expressions.dsl.image
import org.maplibre.compose.expressions.value.IconRotationAlignment
import org.maplibre.compose.layers.CircleLayer
import org.maplibre.compose.layers.LineLayer
import org.maplibre.compose.map.MapOptions
import org.maplibre.compose.map.OrnamentOptions
import org.maplibre.compose.layers.SymbolLayer
import org.maplibre.compose.sources.GeoJsonData
import org.maplibre.compose.sources.GeoJsonOptions
import org.maplibre.compose.sources.rememberGeoJsonSource
import org.maplibre.compose.util.ClickResult
import ua.nure.kryvko.hikeway.R
import ua.nure.kryvko.hikeway.core.model.GeoPoint
import ua.nure.kryvko.hikeway.core.model.PointOfInterest
import ua.nure.kryvko.hikeway.core.model.Route
import ua.nure.kryvko.hikeway.domain.routes.distanceKm
import ua.nure.kryvko.hikeway.ui.map.HikeWayMap
import ua.nure.kryvko.hikeway.ui.map.MapCenterMode
import ua.nure.kryvko.hikeway.ui.map.MapCenterRequest
import ua.nure.kryvko.hikeway.ui.map.emptyFeatureCollectionGeoJson
import ua.nure.kryvko.hikeway.ui.map.toGeoPoint
import ua.nure.kryvko.hikeway.ui.map.toLineStringFeatureGeoJson
import ua.nure.kryvko.hikeway.ui.map.toPoiFeatureCollectionGeoJson
import ua.nure.kryvko.hikeway.ui.map.toPointFeatureGeoJson
import ua.nure.kryvko.hikeway.ui.map.toPointFeatureCollectionGeoJson
import ua.nure.kryvko.hikeway.ui.map.toRouteFeatureCollectionGeoJson

@Composable
@Suppress("COMPOSE_APPLIER_CALL_MISMATCH")
fun RoutesMap(
    routes: List<Route>,
    walkedPath: List<GeoPoint>,
    userPosition: GeoPoint?,
    userBearingDegrees: Double,
    pointsOfInterest: List<PointOfInterest>,
    contextPoint: GeoPoint?,
    mapCenter: GeoPoint?,
    mapCenterRequestId: Long,
    onCenterLocation: () -> Unit,
    onPoiClick: (Long) -> Unit,
    onMapClick: (() -> Unit)?,
    onMapLongClick: ((GeoPoint) -> Unit)?,
    onMapViewportChanged: (GeoPoint, Double) -> Unit,
    centerMode: MapCenterMode,
    highlightedMode: Boolean,
) {
    val geoJson = remember(routes) { routes.toRouteFeatureCollectionGeoJson() }
    val routeStartGeoJson = remember(routes) {
        routes.mapNotNull { it.geometry.points.firstOrNull() }.toPointFeatureCollectionGeoJson()
    }
    val routeEndGeoJson = remember(routes) {
        routes.mapNotNull { it.geometry.points.takeIf { points -> points.size >= 2 }?.lastOrNull() }
            .toPointFeatureCollectionGeoJson()
    }
    val walkedPathGeoJson = remember(walkedPath) { walkedPath.toLineStringFeatureGeoJson() }
    val userGeoJson = remember(userPosition) { userPosition.toPointFeatureGeoJson() }
    val poiGeoJson = remember(pointsOfInterest) { pointsOfInterest.toPoiFeatureCollectionGeoJson() }
    val contextGeoJson = remember(contextPoint) {
        contextPoint?.toPointFeatureGeoJson() ?: emptyFeatureCollectionGeoJson()
    }
    val effectiveCurrentLocation = userPosition ?: mapCenter
    val arrowPainter = painterResource(R.drawable.ic_navigation_arrow_24)
    val poiPainter = painterResource(R.drawable.poi_marker_24)
    val routeStartPainter = painterResource(R.drawable.ic_route_start)
    val routeEndPainter = painterResource(R.drawable.ic_route_end)
    val routeColor = MaterialTheme.colorScheme.primary
    val highlightedRouteColor = MaterialTheme.colorScheme.secondary
    val trackingColor = MaterialTheme.colorScheme.error
    val poiColor = MaterialTheme.colorScheme.error
    val contextColor = MaterialTheme.colorScheme.primary
    val markerHaloColor = MaterialTheme.colorScheme.surface
    var isCurrentLocationCentered by remember(effectiveCurrentLocation, centerMode) {
        mutableStateOf(effectiveCurrentLocation != null && centerMode == MapCenterMode.CurrentLocation)
    }
    val liveGeoJsonOptions = remember {
        GeoJsonOptions(synchronousUpdate = true)
    }
    val mapOptions = remember {
        MapOptions(
            ornamentOptions = OrnamentOptions(
                isLogoEnabled = true,
                isAttributionEnabled = true,
                isCompassEnabled = true,
                compassAlignment = Alignment.TopStart,
                isScaleBarEnabled = false,
                padding = PaddingValues(16.dp),
            )
        )
    }
    val currentLocationCenterRequest = effectiveCurrentLocation?.let {
        MapCenterRequest(
            target = it,
            zoom = 14.0,
            requestId = mapCenterRequestId,
        )
    }
    val routeStartCenterRequest = (centerMode as? MapCenterMode.RouteStart)
        ?.points
        ?.firstOrNull()
        ?.let {
            MapCenterRequest(
                target = it,
                zoom = 12.0,
                requestId = it.hashCode().toLong(),
            )
        }

    HikeWayMap(
        centerMode = centerMode,
        currentLocation = effectiveCurrentLocation,
        centerRequest = routeStartCenterRequest ?: currentLocationCenterRequest,
        mapOptions = mapOptions,
        onMapClick = onMapClick,
        onMapLongClick = onMapLongClick,
        cameraEffect = { cameraState ->
            LaunchedEffect(cameraState, effectiveCurrentLocation) {
                snapshotFlow {
                    cameraState.position.target.toGeoPoint() to cameraState.position.zoom
                }
                    .distinctUntilChanged()
                    .collect { (center, zoom) ->
                        isCurrentLocationCentered = center.isNear(effectiveCurrentLocation)
                        onMapViewportChanged(center, zoom)
                    }
            }
        },
        overlays = {
            IconButton(
                onClick = onCenterLocation,
                modifier = Modifier
                    .align(Alignment.CenterEnd)
                    .size(70.dp)
                    .padding(16.dp),
            ) {
                Icon(
                    modifier = Modifier.size(70.dp),
                    painter = painterResource(
                        if (isCurrentLocationCentered) {
                            R.drawable.ic_center_centered
                        } else {
                            R.drawable.ic_center_uncentered
                        }
                    ),
                    contentDescription = stringResource(R.string.cd_center_location_button),
                )
            }
        },
    ) {
        val routesSource = rememberGeoJsonSource(GeoJsonData.JsonString(geoJson))
        LineLayer(
            id = "matching-routes",
            source = routesSource,
            color = const(if (highlightedMode) highlightedRouteColor else routeColor),
            width = const(if (highlightedMode) 6.dp else 4.dp),
        )
        if (routes.any { it.geometry.points.isNotEmpty() }) {
            val routeStartSource = rememberGeoJsonSource(GeoJsonData.JsonString(routeStartGeoJson))
            SymbolLayer(
                id = "route-start-points",
                source = routeStartSource,
                iconImage = image(
                    value = routeStartPainter,
                    size = DpSize(30.dp, 30.dp),
                    drawAsSdf = false,
                ),
                iconAllowOverlap = const(true),
                iconIgnorePlacement = const(true),
            )
        }
        if (routes.any { it.geometry.points.size >= 2 }) {
            val routeEndSource = rememberGeoJsonSource(GeoJsonData.JsonString(routeEndGeoJson))
            SymbolLayer(
                id = "route-end-points",
                source = routeEndSource,
                iconImage = image(
                    value = routeEndPainter,
                    size = DpSize(30.dp, 30.dp),
                    drawAsSdf = false,
                ),
                iconAllowOverlap = const(true),
                iconIgnorePlacement = const(true),
            )
        }
        if (walkedPath.size >= 2) {
            val walkedPathSource =
                rememberGeoJsonSource(
                    data = GeoJsonData.JsonString(walkedPathGeoJson),
                    options = liveGeoJsonOptions,
                )
            LineLayer(
                id = "walked-path",
                source = walkedPathSource,
                color = const(trackingColor),
                width = const(4.dp),
            )
        }
        if (userPosition != null) {
            val userSource = rememberGeoJsonSource(
                data = GeoJsonData.JsonString(userGeoJson),
                options = liveGeoJsonOptions,
            )
            CircleLayer(
                id = "user-position-dot",
                source = userSource,
                color = const(trackingColor),
                radius = const(8.dp),
                strokeColor = const(markerHaloColor),
                strokeWidth = const(3.dp),
            )
            SymbolLayer(
                id = "user-position",
                source = userSource,
                iconImage = image(
                    value = arrowPainter,
                    size = DpSize(32.dp, 32.dp),
                    drawAsSdf = true,
                ),
                iconColor = const(trackingColor),
                iconHaloColor = const(markerHaloColor),
                iconHaloWidth = const(2.dp),
                iconAllowOverlap = const(true),
                iconIgnorePlacement = const(true),
                iconRotationAlignment = const(IconRotationAlignment.Map),
                iconRotate = const(userBearingDegrees.toFloat()),
            )
        }
        if (pointsOfInterest.isNotEmpty()) {
            val poiSource = rememberGeoJsonSource(GeoJsonData.JsonString(poiGeoJson))
            SymbolLayer(
                id = "points-of-interest",
                source = poiSource,
                iconImage = image(
                    value = poiPainter,
                    size = DpSize(34.dp, 34.dp),
                    drawAsSdf = true,
                ),
                iconColor = const(poiColor),
                iconHaloColor = const(markerHaloColor),
                iconHaloWidth = const(2.dp),
                iconAllowOverlap = const(true),
                iconIgnorePlacement = const(true),
                onClick = { features ->
                    val poiId = features.firstOrNull()
                        ?.properties
                        ?.get("poiId")
                        ?.jsonPrimitive
                        ?.longOrNull
                    if (poiId != null) {
                        onPoiClick(poiId)
                        ClickResult.Consume
                    } else {
                        ClickResult.Pass
                    }
                },
            )
        }
        if (contextPoint != null) {
            val contextSource = rememberGeoJsonSource(GeoJsonData.JsonString(contextGeoJson))
            SymbolLayer(
                id = "map-context-point",
                source = contextSource,
                iconImage = image(
                    value = painterResource(R.drawable.center_24),
                    size = DpSize(34.dp, 34.dp),
                    drawAsSdf = true,
                ),
                iconColor = const(contextColor),
                iconHaloColor = const(markerHaloColor),
                iconHaloWidth = const(2.dp),
                iconAllowOverlap = const(true),
                iconIgnorePlacement = const(true),
            )
        }
    }
}

private fun GeoPoint.isNear(target: GeoPoint?): Boolean {
    return target != null && distanceKm(this, target) <= CENTERED_THRESHOLD_KM
}

private const val CENTERED_THRESHOLD_KM = 0.03
