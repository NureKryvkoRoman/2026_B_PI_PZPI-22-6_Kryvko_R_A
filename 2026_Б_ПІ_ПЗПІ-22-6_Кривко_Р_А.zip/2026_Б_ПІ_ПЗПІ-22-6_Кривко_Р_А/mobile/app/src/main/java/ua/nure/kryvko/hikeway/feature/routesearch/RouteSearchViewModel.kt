package ua.nure.kryvko.hikeway.feature.routesearch

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import ua.nure.kryvko.hikeway.core.model.Difficulty
import ua.nure.kryvko.hikeway.core.model.GeoPoint
import ua.nure.kryvko.hikeway.core.model.PoiPhotoUpload
import ua.nure.kryvko.hikeway.core.model.PointOfInterest
import ua.nure.kryvko.hikeway.core.model.Route
import ua.nure.kryvko.hikeway.core.model.Terrain
import ua.nure.kryvko.hikeway.domain.hikelogging.ActiveTimer
import ua.nure.kryvko.hikeway.domain.hikelogging.SaveCompletedHikeUseCase
import ua.nure.kryvko.hikeway.domain.hikelogging.TimeProvider
import ua.nure.kryvko.hikeway.domain.pois.AddPoiCommentUseCase
import ua.nure.kryvko.hikeway.domain.pois.CreatePointOfInterestUseCase
import ua.nure.kryvko.hikeway.domain.pois.DeletePoiCommentUseCase
import ua.nure.kryvko.hikeway.domain.pois.DeletePoiPhotoUseCase
import ua.nure.kryvko.hikeway.domain.pois.DeletePointOfInterestUseCase
import ua.nure.kryvko.hikeway.domain.pois.GetNearbyPointsOfInterestUseCase
import ua.nure.kryvko.hikeway.domain.pois.GetPointOfInterestDetailUseCase
import ua.nure.kryvko.hikeway.domain.pois.GetPointsOfInterestUseCase
import ua.nure.kryvko.hikeway.domain.pois.RatePointOfInterestUseCase
import ua.nure.kryvko.hikeway.domain.pois.RemovePointOfInterestRatingUseCase
import ua.nure.kryvko.hikeway.domain.pois.UpdatePoiCommentUseCase
import ua.nure.kryvko.hikeway.domain.pois.UpdatePoiPhotoUseCase
import ua.nure.kryvko.hikeway.domain.pois.UpdatePointOfInterestUseCase
import ua.nure.kryvko.hikeway.domain.pois.UploadPoiPhotoUseCase
import ua.nure.kryvko.hikeway.domain.routepicking.DeleteActiveRouteTrackingSessionUseCase
import ua.nure.kryvko.hikeway.domain.routepicking.ObserveActiveRouteTrackingSessionUseCase
import ua.nure.kryvko.hikeway.domain.routepicking.RoutePickingSession
import ua.nure.kryvko.hikeway.domain.routepicking.RouteTrackingProvider
import ua.nure.kryvko.hikeway.domain.routepicking.SaveActiveRouteTrackingSessionUseCase
import ua.nure.kryvko.hikeway.domain.routepicking.restoredPaused
import ua.nure.kryvko.hikeway.domain.routes.GetCurrentLocationUseCase
import ua.nure.kryvko.hikeway.domain.routes.AddRouteCommentUseCase
import ua.nure.kryvko.hikeway.domain.routes.DeleteCustomRouteUseCase
import ua.nure.kryvko.hikeway.domain.routes.DeleteRouteCommentUseCase
import ua.nure.kryvko.hikeway.domain.routes.GetRecommendedRoutesUseCase
import ua.nure.kryvko.hikeway.domain.routes.GetRouteCommentsUseCase
import ua.nure.kryvko.hikeway.domain.routes.PublishCustomRouteUseCase
import ua.nure.kryvko.hikeway.domain.routes.RateRouteUseCase
import ua.nure.kryvko.hikeway.domain.routes.RemoveRouteRatingUseCase
import ua.nure.kryvko.hikeway.domain.routes.RouteSearchCriteria
import ua.nure.kryvko.hikeway.domain.routes.SearchRoutesUseCase
import ua.nure.kryvko.hikeway.domain.routes.UpdateRouteCommentUseCase
import ua.nure.kryvko.hikeway.feature.navigation.HikeTrackingController
import javax.inject.Inject

data class RouteSearchUiState(
    val routes: List<Route> = emptyList(),
    val recommendedRoutes: List<Route> = emptyList(),
    val mapCenter: GeoPoint? = null,
    val mapCenterRequestId: Long = 0L,
    val draftCriteria: RouteSearchCriteria = RouteSearchCriteria(),
    val appliedCriteria: RouteSearchCriteria = RouteSearchCriteria(),
    val appliedOrigin: GeoPoint? = null,
    val isLoading: Boolean = false,
    val isRecommendedLoading: Boolean = false,
    val errorMessage: String? = null,
    val recommendedErrorMessage: String? = null,
    val saveErrorMessage: String? = null,
    val previewRoute: Route? = null,
    val pickingSession: RoutePickingSession? = null,
    val pointsOfInterest: List<PointOfInterest> = emptyList(),
    val selectedPoi: PointOfInterest? = null,
    val isPoiLoading: Boolean = false,
    val isPoiActionInProgress: Boolean = false,
    val poiErrorMessage: String? = null,
    val mapContextPoint: GeoPoint? = null,
    val poiCreationPoint: GeoPoint? = null,
    val poiCreationName: String = "",
    val poiCreationDescription: String = "",
    val isPoiCreationSaving: Boolean = false,
    val poiCreationErrorMessage: String? = null,
    val isRouteActionInProgress: Boolean = false,
    val routeActionErrorMessage: String? = null,
    val isRouteContentLoading: Boolean = false,
    val isRouteContentActionInProgress: Boolean = false,
    val routeContentErrorMessage: String? = null,
)

@HiltViewModel
class RouteSearchViewModel @Inject constructor(
    private val searchRoutes: SearchRoutesUseCase,
    private val getRecommendedRoutes: GetRecommendedRoutesUseCase,
    private val getCurrentLocation: GetCurrentLocationUseCase,
    private val routeTrackingProvider: RouteTrackingProvider,
    private val saveCompletedHike: SaveCompletedHikeUseCase,
    private val observeActiveSession: ObserveActiveRouteTrackingSessionUseCase,
    private val saveActiveSession: SaveActiveRouteTrackingSessionUseCase,
    private val deleteActiveSession: DeleteActiveRouteTrackingSessionUseCase,
    private val timeProvider: TimeProvider,
    private val activeTimer: ActiveTimer,
    private val getPointsOfInterest: GetPointsOfInterestUseCase,
    private val getNearbyPointsOfInterest: GetNearbyPointsOfInterestUseCase,
    private val getPointOfInterestDetail: GetPointOfInterestDetailUseCase,
    private val createPointOfInterest: CreatePointOfInterestUseCase,
    private val updatePointOfInterest: UpdatePointOfInterestUseCase,
    private val deletePointOfInterest: DeletePointOfInterestUseCase,
    private val ratePointOfInterest: RatePointOfInterestUseCase,
    private val removePointOfInterestRating: RemovePointOfInterestRatingUseCase,
    private val addPoiCommentUseCase: AddPoiCommentUseCase,
    private val updatePoiCommentUseCase: UpdatePoiCommentUseCase,
    private val deletePoiCommentUseCase: DeletePoiCommentUseCase,
    private val uploadPoiPhotoUseCase: UploadPoiPhotoUseCase,
    private val updatePoiPhotoUseCase: UpdatePoiPhotoUseCase,
    private val deletePoiPhotoUseCase: DeletePoiPhotoUseCase,
    private val publishCustomRoute: PublishCustomRouteUseCase,
    private val deleteCustomRoute: DeleteCustomRouteUseCase,
    private val rateRoute: RateRouteUseCase,
    private val removeRouteRating: RemoveRouteRatingUseCase,
    private val getRouteComments: GetRouteCommentsUseCase,
    private val addRouteCommentUseCase: AddRouteCommentUseCase,
    private val updateRouteCommentUseCase: UpdateRouteCommentUseCase,
    private val deleteRouteCommentUseCase: DeleteRouteCommentUseCase,
) : ViewModel() {
    private val _uiState = MutableStateFlow(RouteSearchUiState())
    val uiState: StateFlow<RouteSearchUiState> = _uiState.asStateFlow()
    private val routeSearchController = RouteSearchController(
        scope = viewModelScope,
        uiState = _uiState,
        searchRoutes = searchRoutes,
    )
    private val hikeTrackingController = HikeTrackingController(
        scope = viewModelScope,
        uiState = _uiState,
        routeTrackingProvider = routeTrackingProvider,
        saveCompletedHike = saveCompletedHike,
        saveActiveSession = saveActiveSession,
        deleteActiveSession = deleteActiveSession,
        timeProvider = timeProvider,
        activeTimer = activeTimer,
    )
    private val poiController = PoiController(
        scope = viewModelScope,
        uiState = _uiState,
        getPointsOfInterest = getPointsOfInterest,
        getNearbyPointsOfInterest = getNearbyPointsOfInterest,
        getPointOfInterestDetail = getPointOfInterestDetail,
        createPointOfInterest = createPointOfInterest,
        updatePointOfInterest = updatePointOfInterest,
        deletePointOfInterest = deletePointOfInterest,
        ratePointOfInterest = ratePointOfInterest,
        removePointOfInterestRating = removePointOfInterestRating,
        addPoiCommentUseCase = addPoiCommentUseCase,
        updatePoiCommentUseCase = updatePoiCommentUseCase,
        deletePoiCommentUseCase = deletePoiCommentUseCase,
        uploadPoiPhotoUseCase = uploadPoiPhotoUseCase,
        updatePoiPhotoUseCase = updatePoiPhotoUseCase,
        deletePoiPhotoUseCase = deletePoiPhotoUseCase,
    )

    init {
        centerOnCurrentLocation()
        routeSearchController.refresh(RouteSearchCriteria())
        loadRecommendedRoutes()
        poiController.loadPointsOfInterest()
        restoreActiveSession()
    }

    fun updateDraft(criteria: RouteSearchCriteria) {
        routeSearchController.updateDraft(criteria)
    }

    fun toggleDifficulty(difficulty: Difficulty) {
        routeSearchController.toggleDifficulty(difficulty)
    }

    fun toggleTerrain(terrain: Terrain) {
        routeSearchController.toggleTerrain(terrain)
    }

    fun applyFilters() {
        routeSearchController.applyFilters()
    }

    fun clearFilters() {
        routeSearchController.clearFilters()
    }

    fun refreshCurrentSearch() {
        routeSearchController.refreshCurrentSearch()
    }

    fun loadRecommendedRoutes() {
        viewModelScope.launch {
            _uiState.update {
                it.copy(
                    isRecommendedLoading = true,
                    recommendedErrorMessage = null,
                )
            }
            runCatching { getRecommendedRoutes() }
                .onSuccess { routes ->
                    _uiState.update {
                        it.copy(
                            recommendedRoutes = routes,
                            isRecommendedLoading = false,
                            recommendedErrorMessage = null,
                        )
                    }
                }
                .onFailure { error ->
                    _uiState.update {
                        it.copy(
                            isRecommendedLoading = false,
                            recommendedErrorMessage = error.message ?: "Recommended routes are unavailable.",
                        )
                    }
                }
        }
    }

    fun refreshPointsOfInterest() {
        poiController.refreshPointsOfInterest()
    }

    fun centerOnCurrentLocation() {
        viewModelScope.launch {
            runCatching { getCurrentLocation() }
                .onSuccess { location ->
                    _uiState.update {
                        it.copy(
                            mapCenter = location,
                            mapCenterRequestId = it.mapCenterRequestId + 1,
                            errorMessage = null,
                        )
                    }
                    poiController.loadPointsOfInterest(location)
                }
                .onFailure { error ->
                    _uiState.update {
                        it.copy(errorMessage = error.message ?: "Current location is unavailable.")
                    }
                }
        }
    }

    fun previewRoute(route: Route) {
        routeSearchController.previewRoute(route)
    }

    fun dismissRoutePreview() {
        routeSearchController.dismissRoutePreview()
    }

    fun publishPreviewedRoute() {
        val route = _uiState.value.previewRoute ?: return
        viewModelScope.launch {
            _uiState.update { it.copy(isRouteActionInProgress = true, routeActionErrorMessage = null) }
            runCatching { publishCustomRoute(route) }
                .onSuccess { publishedRoute ->
                    _uiState.update {
                        it.copy(
                            previewRoute = publishedRoute,
                            isRouteActionInProgress = false,
                            routeActionErrorMessage = null,
                        )
                    }
                    refreshCurrentSearch()
                    loadRecommendedRoutes()
                }
                .onFailure { error ->
                    _uiState.update {
                        it.copy(
                            isRouteActionInProgress = false,
                            routeActionErrorMessage = error.message ?: "Could not publish route.",
                        )
                    }
                }
        }
    }

    fun deletePreviewedRoute() {
        val route = _uiState.value.previewRoute ?: return
        viewModelScope.launch {
            _uiState.update { it.copy(isRouteActionInProgress = true, routeActionErrorMessage = null) }
            runCatching { deleteCustomRoute(route) }
                .onSuccess {
                    _uiState.update {
                        it.copy(
                            previewRoute = null,
                            isRouteActionInProgress = false,
                            routeActionErrorMessage = null,
                        )
                    }
                    refreshCurrentSearch()
                    loadRecommendedRoutes()
                }
                .onFailure { error ->
                    _uiState.update {
                        it.copy(
                            isRouteActionInProgress = false,
                            routeActionErrorMessage = error.message ?: "Could not delete route.",
                        )
                    }
                }
        }
    }

    fun selectPoi(poiId: Long) {
        poiController.selectPoi(poiId)
    }

    fun refreshSelectedPoiDetail() {
        poiController.refreshSelectedPoiDetail()
    }

    fun dismissPoi() {
        poiController.dismissPoi()
    }

    fun openMapContext(point: GeoPoint) {
        poiController.openMapContext(point)
    }

    fun dismissMapContext() {
        poiController.dismissMapContext()
    }

    fun findRoutesNearContextPoint() {
        val point = _uiState.value.mapContextPoint ?: return
        routeSearchController.findRoutesNear(point)
    }

    fun startPoiCreationFromContext() {
        poiController.startPoiCreationFromContext()
    }

    fun updatePoiCreationName(name: String) {
        poiController.updatePoiCreationName(name)
    }

    fun updatePoiCreationDescription(description: String) {
        poiController.updatePoiCreationDescription(description)
    }

    fun cancelPoiCreation() {
        poiController.cancelPoiCreation()
    }

    fun createPoi() {
        poiController.createPoi()
    }

    fun onMapViewportChanged(center: GeoPoint, zoom: Double) {
        poiController.onMapViewportChanged(center, zoom)
    }

    fun ratePoi(rating: Int) {
        poiController.ratePoi(rating)
    }

    fun removePoiRating() {
        poiController.removePoiRating()
    }

    fun addPoiComment(text: String) {
        poiController.addPoiComment(text)
    }

    fun updatePoiComment(commentId: Long, text: String) {
        poiController.updatePoiComment(commentId, text)
    }

    fun deletePoiComment(commentId: Long) {
        poiController.deletePoiComment(commentId)
    }

    fun uploadPoiPhoto(upload: PoiPhotoUpload) {
        poiController.uploadPoiPhoto(upload)
    }

    fun updatePoiPhoto(photoId: Long, caption: String?) {
        poiController.updatePoiPhoto(photoId, caption)
    }

    fun deletePoiPhoto(photoId: Long) {
        poiController.deletePoiPhoto(photoId)
    }

    fun updateSelectedPoi(
        name: String,
        description: String,
        location: GeoPoint,
        onUpdated: (Boolean) -> Unit = {},
    ) {
        poiController.updateSelectedPoi(name, description, location, onUpdated)
    }

    fun deleteSelectedPoi(onDeleted: (Boolean) -> Unit = {}) {
        poiController.deleteSelectedPoi(onDeleted)
    }

    fun ratePreviewedRoute(rating: Int) {
        val route = _uiState.value.previewRoute ?: return
        val routeId = backendRouteId(route) ?: return setRouteContentError("Publish this route to enable ratings and comments.")
        viewModelScope.launch {
            _uiState.update { it.copy(isRouteContentActionInProgress = true, routeContentErrorMessage = null) }
            runCatching { rateRoute(routeId, rating) }
                .onSuccess { updatedRating ->
                    _uiState.update {
                        it.withRouteRating(route, updatedRating.averageRating, updatedRating.ratingCount, updatedRating.userRating)
                            .copy(isRouteContentActionInProgress = false, routeContentErrorMessage = null)
                    }
                }
                .onFailure { error ->
                    _uiState.update {
                        it.copy(
                            isRouteContentActionInProgress = false,
                            routeContentErrorMessage = error.message ?: "Could not submit route rating.",
                        )
                    }
                }
        }
    }

    fun removePreviewedRouteRating() {
        val route = _uiState.value.previewRoute ?: return
        val routeId = backendRouteId(route) ?: return setRouteContentError("Publish this route to enable ratings and comments.")
        viewModelScope.launch {
            _uiState.update { it.copy(isRouteContentActionInProgress = true, routeContentErrorMessage = null) }
            runCatching { removeRouteRating(routeId) }
                .onSuccess { updatedRating ->
                    _uiState.update {
                        it.withRouteRating(route, updatedRating.averageRating, updatedRating.ratingCount, updatedRating.userRating)
                            .copy(isRouteContentActionInProgress = false, routeContentErrorMessage = null)
                    }
                }
                .onFailure { error ->
                    _uiState.update {
                        it.copy(
                            isRouteContentActionInProgress = false,
                            routeContentErrorMessage = error.message ?: "Could not remove route rating.",
                        )
                    }
                }
        }
    }

    fun loadPreviewedRouteComments() {
        val route = _uiState.value.previewRoute ?: return
        val routeId = backendRouteId(route) ?: return setRouteContentError("Publish this route to enable ratings and comments.")
        viewModelScope.launch {
            _uiState.update { it.copy(isRouteContentLoading = true, routeContentErrorMessage = null) }
            runCatching { getRouteComments(routeId) }
                .onSuccess { comments ->
                    _uiState.update {
                        it.withRouteComments(route, comments)
                            .copy(isRouteContentLoading = false, routeContentErrorMessage = null)
                    }
                }
                .onFailure { error ->
                    _uiState.update {
                        it.copy(
                            isRouteContentLoading = false,
                            routeContentErrorMessage = error.message ?: "Route comments are unavailable.",
                        )
                    }
                }
        }
    }

    fun addRouteComment(text: String) {
        val route = _uiState.value.previewRoute ?: return
        val routeId = backendRouteId(route) ?: return setRouteContentError("Publish this route to enable ratings and comments.")
        viewModelScope.launch {
            _uiState.update { it.copy(isRouteContentActionInProgress = true, routeContentErrorMessage = null) }
            runCatching { addRouteCommentUseCase(routeId, text) }
                .onSuccess { comment ->
                    _uiState.update {
                        it.withAddedRouteComment(route, comment)
                            .copy(isRouteContentActionInProgress = false, routeContentErrorMessage = null)
                    }
                }
                .onFailure { error ->
                    _uiState.update {
                        it.copy(
                            isRouteContentActionInProgress = false,
                            routeContentErrorMessage = error.message ?: "Could not add route comment.",
                        )
                    }
                }
        }
    }

    fun updateRouteComment(commentId: Long, text: String) {
        val route = _uiState.value.previewRoute ?: return
        val routeId = backendRouteId(route) ?: return setRouteContentError("Publish this route to enable ratings and comments.")
        viewModelScope.launch {
            _uiState.update { it.copy(isRouteContentActionInProgress = true, routeContentErrorMessage = null) }
            runCatching { updateRouteCommentUseCase(routeId, commentId, text) }
                .onSuccess { comment ->
                    _uiState.update {
                        it.withUpdatedRouteComment(route, comment)
                            .copy(isRouteContentActionInProgress = false, routeContentErrorMessage = null)
                    }
                }
                .onFailure { error ->
                    _uiState.update {
                        it.copy(
                            isRouteContentActionInProgress = false,
                            routeContentErrorMessage = error.message ?: "Could not update route comment.",
                        )
                    }
                }
        }
    }

    fun deleteRouteComment(commentId: Long) {
        val route = _uiState.value.previewRoute ?: return
        val routeId = backendRouteId(route) ?: return setRouteContentError("Publish this route to enable ratings and comments.")
        viewModelScope.launch {
            _uiState.update { it.copy(isRouteContentActionInProgress = true, routeContentErrorMessage = null) }
            runCatching { deleteRouteCommentUseCase(routeId, commentId) }
                .onSuccess {
                    _uiState.update {
                        it.withDeletedRouteComment(route, commentId)
                            .copy(isRouteContentActionInProgress = false, routeContentErrorMessage = null)
                    }
                }
                .onFailure { error ->
                    _uiState.update {
                        it.copy(
                            isRouteContentActionInProgress = false,
                            routeContentErrorMessage = error.message ?: "Could not delete route comment.",
                        )
                    }
                }
        }
    }

    fun startPreviewedRoute() {
        val route = _uiState.value.previewRoute ?: return
        startRoute(route)
    }

    fun startRoute(route: Route) {
        hikeTrackingController.startRoute(route)
    }

    fun pauseRoute() {
        hikeTrackingController.pauseRoute()
    }

    fun unpauseRoute() {
        hikeTrackingController.unpauseRoute()
    }

    fun finishRoute() {
        hikeTrackingController.finishRoute()
    }

    private fun restoreActiveSession() {
        viewModelScope.launch {
            observeActiveSession().collect { session ->
                session?.let { hikeTrackingController.restoreSession(it.restoredPaused()) }
            }
        }
    }

    private fun setRouteContentError(message: String) {
        _uiState.update { it.copy(routeContentErrorMessage = message) }
    }
}

private fun backendRouteId(route: Route): Long? = route.serverId

private fun RouteSearchUiState.withRouteRating(
    route: Route,
    averageRating: Double,
    ratingCount: Long,
    userRating: Int?,
): RouteSearchUiState {
    fun Route.updated(): Route = copy(
        averageRating = averageRating,
        ratingCount = ratingCount,
        userRating = userRating,
    )
    return copy(
        routes = routes.map { if (it.sameRouteAs(route)) it.updated() else it },
        recommendedRoutes = recommendedRoutes.map { if (it.sameRouteAs(route)) it.updated() else it },
        previewRoute = previewRoute?.let { if (it.sameRouteAs(route)) it.updated() else it },
    )
}

private fun RouteSearchUiState.withRouteComments(
    route: Route,
    comments: List<ua.nure.kryvko.hikeway.core.model.RouteComment>,
): RouteSearchUiState {
    return copy(previewRoute = previewRoute?.let { if (it.sameRouteAs(route)) it.copy(comments = comments) else it })
}

private fun RouteSearchUiState.withAddedRouteComment(
    route: Route,
    comment: ua.nure.kryvko.hikeway.core.model.RouteComment,
): RouteSearchUiState {
    val current = previewRoute?.comments.orEmpty()
    return withRouteComments(route, listOf(comment) + current.filterNot { it.id == comment.id })
}

private fun RouteSearchUiState.withUpdatedRouteComment(
    route: Route,
    comment: ua.nure.kryvko.hikeway.core.model.RouteComment,
): RouteSearchUiState {
    return withRouteComments(route, previewRoute?.comments.orEmpty().map { if (it.id == comment.id) comment else it })
}

private fun RouteSearchUiState.withDeletedRouteComment(route: Route, commentId: Long): RouteSearchUiState {
    return withRouteComments(route, previewRoute?.comments.orEmpty().filterNot { it.id == commentId })
}

private fun Route.sameRouteAs(other: Route): Boolean {
    return serverId != null && serverId == other.serverId ||
        clientId != null && clientId == other.clientId ||
        id == other.id
}
