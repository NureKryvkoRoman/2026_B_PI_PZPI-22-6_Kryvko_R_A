package ua.nure.kryvko.hikeway.data.savedroutes.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface SavedRouteDao {
    @Query("SELECT * FROM saved_routes WHERE ownerUserId = :ownerUserId ORDER BY savedAtEpochMillis DESC")
    fun observeAll(ownerUserId: String): Flow<List<SavedRouteEntity>>

    @Query(
        "SELECT EXISTS(SELECT 1 FROM saved_routes " +
            "WHERE ownerUserId = :ownerUserId AND routeKey = :routeKey)"
    )
    suspend fun exists(ownerUserId: String, routeKey: String): Boolean

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(route: SavedRouteEntity)

    @Query("DELETE FROM saved_routes WHERE ownerUserId = :ownerUserId AND routeKey = :routeKey")
    suspend fun delete(ownerUserId: String, routeKey: String)
}
