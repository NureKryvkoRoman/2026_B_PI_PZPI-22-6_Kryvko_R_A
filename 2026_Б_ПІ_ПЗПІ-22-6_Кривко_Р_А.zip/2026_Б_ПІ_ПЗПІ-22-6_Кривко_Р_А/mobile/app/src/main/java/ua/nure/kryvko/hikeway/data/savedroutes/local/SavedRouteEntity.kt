package ua.nure.kryvko.hikeway.data.savedroutes.local

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "saved_routes",
    indices = [Index(value = ["ownerUserId", "routeKey"], unique = true)],
)
data class SavedRouteEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val ownerUserId: String,
    val routeKey: String,
    val routeId: Long,
    val name: String,
    val description: String,
    val distanceKm: Double,
    val estimatedTimeMinutes: Int,
    val difficulty: String,
    val elevationGainMeters: Int,
    val terrain: String,
    val geometryGeoJson: String,
    val savedAtEpochMillis: Long,
)
