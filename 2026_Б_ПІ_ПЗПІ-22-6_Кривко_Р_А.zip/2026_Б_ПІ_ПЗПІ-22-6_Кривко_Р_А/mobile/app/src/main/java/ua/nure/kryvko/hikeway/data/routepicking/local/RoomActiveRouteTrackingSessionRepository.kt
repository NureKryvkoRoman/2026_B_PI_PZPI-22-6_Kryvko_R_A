package ua.nure.kryvko.hikeway.data.routepicking.local

import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.map
import ua.nure.kryvko.hikeway.core.model.Difficulty
import ua.nure.kryvko.hikeway.core.model.GeoPoint
import ua.nure.kryvko.hikeway.core.model.Route
import ua.nure.kryvko.hikeway.core.model.RouteGeometry
import ua.nure.kryvko.hikeway.core.model.Terrain
import ua.nure.kryvko.hikeway.data.geojson.GeoJsonLineStringCodec
import ua.nure.kryvko.hikeway.domain.auth.CurrentUserProvider
import ua.nure.kryvko.hikeway.domain.routepicking.ActiveRouteTrackingSessionRepository
import ua.nure.kryvko.hikeway.domain.routepicking.RoutePickingSession
import ua.nure.kryvko.hikeway.domain.routepicking.RoutePickingStatus

class RoomActiveRouteTrackingSessionRepository(
    private val dao: ActiveRouteTrackingSessionDao,
    private val currentUserProvider: CurrentUserProvider,
) : ActiveRouteTrackingSessionRepository {
    @OptIn(ExperimentalCoroutinesApi::class)
    override fun observe(): Flow<RoutePickingSession?> {
        return currentUserProvider.currentUserId.flatMapLatest { ownerUserId ->
            if (ownerUserId == null) {
                flowOf(null)
            } else {
                dao.observe(ownerUserId).map { it?.toDomain() }
            }
        }
    }

    override suspend fun save(session: RoutePickingSession) {
        dao.upsert(session.toEntity(currentUserProvider.requireCurrentUserId()))
    }

    override suspend fun delete() {
        dao.delete(currentUserProvider.requireCurrentUserId())
    }
}

fun RoutePickingSession.toEntity(
    ownerUserId: String,
    updatedAtEpochMillis: Long = System.currentTimeMillis(),
) = ActiveRouteTrackingSessionEntity(
    ownerUserId = ownerUserId,
    routeId = route.id,
    routeName = route.name,
    routeDescription = route.description,
    routeDistanceKm = route.distanceKm,
    routeEstimatedTimeMinutes = route.estimatedTimeMinutes,
    routeDifficulty = route.difficulty.name,
    routeElevationGainMeters = route.elevationGainMeters,
    routeTerrain = route.terrain.name,
    routeGeometryGeoJson = GeoJsonLineStringCodec.encode(route.geometry.points),
    userLongitude = userPosition.longitude,
    userLatitude = userPosition.latitude,
    bearingDegrees = bearingDegrees,
    pointIndex = pointIndex,
    status = status.name,
    walkedPathGeoJson = GeoJsonLineStringCodec.encode(walkedPath),
    walkedDistanceKm = walkedDistanceKm,
    activeElapsedMillis = activeElapsedMillis,
    startedAtEpochMillis = startedAtEpochMillis,
    updatedAtEpochMillis = updatedAtEpochMillis,
)

fun ActiveRouteTrackingSessionEntity.toDomain() = RoutePickingSession(
    route = Route(
        id = routeId,
        name = routeName,
        description = routeDescription,
        distanceKm = routeDistanceKm,
        estimatedTimeMinutes = routeEstimatedTimeMinutes,
        difficulty = Difficulty.valueOf(routeDifficulty),
        elevationGainMeters = routeElevationGainMeters,
        terrain = Terrain.valueOf(routeTerrain),
        geometry = RouteGeometry(GeoJsonLineStringCodec.decode(routeGeometryGeoJson)),
    ),
    userPosition = GeoPoint(longitude = userLongitude, latitude = userLatitude),
    bearingDegrees = bearingDegrees,
    pointIndex = pointIndex,
    status = RoutePickingStatus.valueOf(status),
    walkedPath = GeoJsonLineStringCodec.decode(walkedPathGeoJson),
    walkedDistanceKm = walkedDistanceKm,
    activeElapsedMillis = activeElapsedMillis,
    startedAtEpochMillis = startedAtEpochMillis,
)
