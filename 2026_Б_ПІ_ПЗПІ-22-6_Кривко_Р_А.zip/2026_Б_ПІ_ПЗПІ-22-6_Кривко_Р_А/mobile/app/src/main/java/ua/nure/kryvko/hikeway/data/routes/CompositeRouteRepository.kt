package ua.nure.kryvko.hikeway.data.routes

import ua.nure.kryvko.hikeway.core.model.GeoPoint
import ua.nure.kryvko.hikeway.core.model.Route
import ua.nure.kryvko.hikeway.domain.routes.RouteDetailRepository
import ua.nure.kryvko.hikeway.domain.routes.RouteRepository
import ua.nure.kryvko.hikeway.domain.routes.RouteSearchCriteria

class CompositeRouteRepository(
    private val repositories: List<RouteRepository>,
) : RouteRepository {
    override suspend fun search(criteria: RouteSearchCriteria, origin: GeoPoint): List<Route> {
        return repositories.flatMap { it.search(criteria, origin) }
    }
}

class CompositeRouteDetailRepository(
    private val repositories: List<RouteDetailRepository>,
) : RouteDetailRepository {
    override suspend fun findById(id: Long): Route? {
        return repositories.firstNotNullOfOrNull { it.findById(id) }
    }

    override suspend fun findByClientId(clientId: String): Route? {
        return repositories.firstNotNullOfOrNull { it.findByClientId(clientId) }
    }

    override suspend fun findByServerId(serverId: Long): Route? {
        return repositories.firstNotNullOfOrNull { it.findByServerId(serverId) }
    }
}
