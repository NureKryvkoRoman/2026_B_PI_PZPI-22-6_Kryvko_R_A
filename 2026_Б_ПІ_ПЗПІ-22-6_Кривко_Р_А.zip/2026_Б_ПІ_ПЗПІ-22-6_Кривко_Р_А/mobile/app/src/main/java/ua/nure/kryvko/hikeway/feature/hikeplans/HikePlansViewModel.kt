package ua.nure.kryvko.hikeway.feature.hikeplans

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.lifecycle.HiltViewModel
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.util.UUID
import javax.inject.Inject
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import ua.nure.kryvko.hikeway.core.model.Route
import ua.nure.kryvko.hikeway.domain.hikeplans.DeleteHikePlanUseCase
import ua.nure.kryvko.hikeway.domain.hikeplans.HikePlan
import ua.nure.kryvko.hikeway.domain.hikeplans.HikePlanChecklistItem
import ua.nure.kryvko.hikeway.domain.hikeplans.HikePlanReminderScheduler
import ua.nure.kryvko.hikeway.domain.hikeplans.ObserveHikePlansUseCase
import ua.nure.kryvko.hikeway.domain.hikeplans.SaveHikePlanUseCase
import ua.nure.kryvko.hikeway.domain.hikelogging.TimeProvider
import ua.nure.kryvko.hikeway.domain.weather.GetHikePlanWeatherUseCase
import ua.nure.kryvko.hikeway.domain.weather.HikePlanWeather

data class HikePlansUiState(
    val plans: List<HikePlan> = emptyList(),
    val isLoading: Boolean = true,
    val errorMessage: String? = null,
)

data class HikePlanDraftUiState(
    val isOpen: Boolean = false,
    val planId: Long = 0,
    val route: Route? = null,
    val routeName: String = "",
    val plannedDateEpochDay: Long = 0,
    val checklist: List<HikePlanChecklistItem> = emptyList(),
    val weatherState: HikePlanWeatherState = HikePlanWeatherState.Idle,
    val isSaving: Boolean = false,
    val errorMessage: String? = null,
) {
    val canStart: Boolean get() = route != null
}

sealed interface HikePlanWeatherState {
    data object Idle : HikePlanWeatherState
    data object Loading : HikePlanWeatherState
    data class Loaded(val weather: HikePlanWeather) : HikePlanWeatherState
    data class Stale(val weather: HikePlanWeather, val message: String) : HikePlanWeatherState
    data class Error(val message: String) : HikePlanWeatherState
}

@HiltViewModel
class HikePlansViewModel @Inject constructor(
    private val observeHikePlans: ObserveHikePlansUseCase,
    private val saveHikePlan: SaveHikePlanUseCase,
    private val deleteHikePlan: DeleteHikePlanUseCase,
    private val getHikePlanWeather: GetHikePlanWeatherUseCase,
    private val timeProvider: TimeProvider,
    private val reminderScheduler: HikePlanReminderScheduler,
) : ViewModel() {
    private val _uiState = MutableStateFlow(HikePlansUiState())
    val uiState: StateFlow<HikePlansUiState> = _uiState.asStateFlow()
    private val _draftState = MutableStateFlow(HikePlanDraftUiState())
    val draftState: StateFlow<HikePlanDraftUiState> = _draftState.asStateFlow()
    private var weatherJob: Job? = null

    init {
        viewModelScope.launch {
            observeHikePlans()
                .catch {
                    _uiState.update {
                        it.copy(
                            isLoading = false,
                            errorMessage = "Could not load hike plans.",
                        )
                    }
                }
                .collect { plans ->
                    _uiState.update {
                        it.copy(
                            plans = plans,
                            isLoading = false,
                            errorMessage = null,
                        )
                    }
                }
        }
    }

    fun delete(id: Long) {
        viewModelScope.launch {
            runCatching { deleteHikePlan(id) }
                .onSuccess { reminderScheduler.cancel(id) }
                .onFailure {
                    _uiState.update { state ->
                        state.copy(errorMessage = "Could not delete hike plan.")
                    }
                }
        }
    }

    fun openNewPlan(route: Route) {
        val today = todayEpochDay()
        _draftState.value = HikePlanDraftUiState(
            isOpen = true,
            route = route,
            routeName = route.name,
            plannedDateEpochDay = today,
        )
        loadWeather()
    }

    fun openExistingPlan(plan: HikePlan) {
        _draftState.value = HikePlanDraftUiState(
            isOpen = true,
            planId = plan.id,
            route = plan.routeSnapshot,
            routeName = plan.routeName,
            plannedDateEpochDay = plan.plannedDateEpochDay,
            checklist = plan.checklist,
        )
        loadWeather()
    }

    fun closeDraft() {
        weatherJob?.cancel()
        _draftState.value = HikePlanDraftUiState()
    }

    fun selectDate(epochDay: Long) {
        val today = todayEpochDay()
        _draftState.update { state ->
            state.copy(plannedDateEpochDay = epochDay.coerceAtLeast(today))
        }
        loadWeather()
    }

    fun retryWeather() {
        loadWeather(forceLoading = true)
    }

    fun addChecklistItem(text: String) {
        val trimmed = text.trim()
        if (trimmed.isEmpty()) return
        _draftState.update { state ->
            state.copy(
                checklist = state.checklist + HikePlanChecklistItem(
                    id = UUID.randomUUID().toString(),
                    text = trimmed,
                    checked = false,
                ),
                errorMessage = null,
            )
        }
    }

    fun updateChecklistItem(id: String, text: String) {
        _draftState.update { state ->
            state.copy(
                checklist = state.checklist.map { item ->
                    if (item.id == id) item.copy(text = text) else item
                },
                errorMessage = null,
            )
        }
    }

    fun toggleChecklistItem(id: String, checked: Boolean) {
        _draftState.update { state ->
            state.copy(
                checklist = state.checklist.map { item ->
                    if (item.id == id) item.copy(checked = checked) else item
                },
                errorMessage = null,
            )
        }
    }

    fun deleteChecklistItem(id: String) {
        _draftState.update { state ->
            state.copy(
                checklist = state.checklist.filterNot { it.id == id },
                errorMessage = null,
            )
        }
    }

    fun saveDraft(onSaved: (() -> Unit)? = null) {
        val plan = _draftState.value.toPlanOrNull() ?: return
        viewModelScope.launch {
            _draftState.update { it.copy(isSaving = true, errorMessage = null) }
            runCatching { saveHikePlan(plan) }
                .onSuccess { id ->
                    reminderScheduler.schedule(plan.copy(id = id))
                    _draftState.update { it.copy(planId = id, isSaving = false, errorMessage = null) }
                    onSaved?.invoke()
                }
                .onFailure {
                    _draftState.update {
                        it.copy(isSaving = false, errorMessage = "Could not save hike plan.")
                    }
                }
        }
    }

    fun saveAndStart(onRouteReady: (Route) -> Unit) {
        val route = _draftState.value.route ?: run {
            _draftState.update { it.copy(errorMessage = "Route data is unavailable for this plan.") }
            return
        }
        saveDraft(onSaved = { onRouteReady(route) })
    }

    fun deleteCurrentPlan(onDeleted: () -> Unit) {
        val id = _draftState.value.planId
        if (id == 0L) {
            closeDraft()
            onDeleted()
            return
        }
        viewModelScope.launch {
            runCatching { deleteHikePlan(id) }
                .onSuccess {
                    reminderScheduler.cancel(id)
                    closeDraft()
                    onDeleted()
                }
                .onFailure {
                    _draftState.update {
                        it.copy(errorMessage = "Could not delete hike plan.")
                    }
                }
        }
    }

    private fun loadWeather(forceLoading: Boolean = false) {
        val state = _draftState.value
        val routeId = state.route?.id ?: run {
            _draftState.update { it.copy(weatherState = HikePlanWeatherState.Idle) }
            return
        }
        val date = LocalDate.ofEpochDay(state.plannedDateEpochDay)
        val previousWeather = (state.weatherState as? HikePlanWeatherState.Loaded)?.weather
            ?: (state.weatherState as? HikePlanWeatherState.Stale)?.weather
        weatherJob?.cancel()
        _draftState.update {
            it.copy(
                weatherState = if (previousWeather != null && !forceLoading) {
                    HikePlanWeatherState.Stale(previousWeather, "Refreshing weather...")
                } else {
                    HikePlanWeatherState.Loading
                }
            )
        }
        weatherJob = viewModelScope.launch {
            runCatching { getHikePlanWeather(routeId, date) }
                .onSuccess { weather ->
                    _draftState.update { current ->
                        if (current.route?.id == routeId && current.plannedDateEpochDay == date.toEpochDay()) {
                            current.copy(weatherState = HikePlanWeatherState.Loaded(weather))
                        } else {
                            current
                        }
                    }
                }
                .onFailure {
                    _draftState.update { current ->
                        if (current.route?.id != routeId || current.plannedDateEpochDay != date.toEpochDay()) {
                            current
                        } else if (previousWeather != null) {
                            current.copy(
                                weatherState = HikePlanWeatherState.Stale(
                                    previousWeather,
                                    "Could not refresh weather. Showing last loaded forecast.",
                                )
                            )
                        } else {
                            current.copy(weatherState = HikePlanWeatherState.Error("Weather is unavailable."))
                        }
                    }
                }
        }
    }

    private fun HikePlanDraftUiState.toPlanOrNull(): HikePlan? {
        val route = route
        val routeId = route?.id ?: return null
        return HikePlan(
            id = planId,
            routeId = routeId,
            routeName = routeName.ifBlank { route.name },
            plannedDateEpochDay = plannedDateEpochDay,
            checklist = checklist.map { it.copy(text = it.text.trim()) }.filter { it.text.isNotEmpty() },
            routeSnapshot = route,
        )
    }

    private fun todayEpochDay(): Long {
        return Instant.ofEpochMilli(timeProvider.currentTimeMillis())
            .atZone(ZoneId.systemDefault())
            .toLocalDate()
            .toEpochDay()
    }
}
