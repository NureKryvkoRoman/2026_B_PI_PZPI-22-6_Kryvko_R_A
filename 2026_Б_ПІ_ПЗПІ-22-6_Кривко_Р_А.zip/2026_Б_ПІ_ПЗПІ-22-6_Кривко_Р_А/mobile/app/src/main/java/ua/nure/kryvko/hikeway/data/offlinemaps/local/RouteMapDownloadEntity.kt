package ua.nure.kryvko.hikeway.data.offlinemaps.local

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "route_map_downloads",
    indices = [Index(value = ["ownerUserId", "routeKey"], unique = true)],
)
data class RouteMapDownloadEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val ownerUserId: String,
    val routeKey: String,
    val routeId: Long,
    val routeName: String,
    val routeGeometryGeoJson: String,
    val north: Double,
    val east: Double,
    val south: Double,
    val west: Double,
    val minZoom: Double,
    val maxZoom: Double,
    val mapLibreRegionId: Long?,
    val status: String,
    val completedResourceCount: Long,
    val requiredResourceCount: Long?,
    val completedResourceSizeBytes: Long,
    val completedTileCount: Long,
    val completedTileSizeBytes: Long,
    val estimatedMinBytes: Long,
    val estimatedMaxBytes: Long,
    val errorMessage: String?,
    val createdAtEpochMillis: Long,
    val updatedAtEpochMillis: Long,
)
