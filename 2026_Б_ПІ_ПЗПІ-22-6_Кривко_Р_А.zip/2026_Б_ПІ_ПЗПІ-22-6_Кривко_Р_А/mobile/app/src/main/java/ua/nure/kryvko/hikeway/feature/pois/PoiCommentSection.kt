package ua.nure.kryvko.hikeway.feature.pois

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountCircle
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import ua.nure.kryvko.hikeway.R
import ua.nure.kryvko.hikeway.core.model.PoiComment

data class CommentUiModel(
    val id: Long,
    val authorId: String,
    val authorDisplayName: String,
    val text: String,
)

@Composable
fun CommentSection(
    comments: List<PoiComment>,
    enabled: Boolean,
    onAddComment: ((String) -> Unit)?,
    onUpdateComment: ((Long, String) -> Unit)?,
    onDeleteComment: ((Long) -> Unit)?,
    isAdmin: Boolean,
    currentUserId: String,
) {
    GenericCommentSection(
        comments = comments.map { it.toUiModel() },
        enabled = enabled,
        onAddComment = onAddComment,
        onUpdateComment = onUpdateComment,
        onDeleteComment = onDeleteComment,
        isAdmin = isAdmin,
        currentUserId = currentUserId,
        title = stringResource(R.string.poi_comments),
        addLabel = stringResource(R.string.poi_add_comment_label),
        emptyMessage = stringResource(R.string.poi_no_comments),
        editTitle = stringResource(R.string.poi_edit_comment_title),
    )
}

@Composable
fun GenericCommentSection(
    comments: List<CommentUiModel>,
    enabled: Boolean,
    onAddComment: ((String) -> Unit)?,
    onUpdateComment: ((Long, String) -> Unit)?,
    onDeleteComment: ((Long) -> Unit)?,
    isAdmin: Boolean,
    currentUserId: String,
    title: String,
    addLabel: String,
    emptyMessage: String,
    editTitle: String,
) {
    var commentText by remember { mutableStateOf("") }
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text(title, style = MaterialTheme.typography.titleSmall)
        onAddComment?.let {
            OutlinedTextField(
                value = commentText,
                onValueChange = { commentText = it },
                label = { Text(addLabel) },
                modifier = Modifier.fillMaxWidth(),
                enabled = enabled,
            )
            Button(
                onClick = {
                    it(commentText)
                    commentText = ""
                },
                enabled = enabled && commentText.isNotBlank(),
            ) {
                Text(stringResource(R.string.action_submit_comment))
            }
        }
        if (comments.isEmpty()) {
            Text(emptyMessage, style = MaterialTheme.typography.bodySmall)
        }
        comments.forEach { comment ->
            CommentRow(
                comment = comment,
                enabled = enabled,
                onUpdateComment = onUpdateComment,
                onDeleteComment = onDeleteComment,
                isAdmin = isAdmin,
                currentUserId = currentUserId,
                editTitle = editTitle,
            )
        }
    }
}

@Composable
private fun CommentRow(
    comment: CommentUiModel,
    enabled: Boolean,
    onUpdateComment: ((Long, String) -> Unit)?,
    onDeleteComment: ((Long) -> Unit)?,
    isAdmin: Boolean,
    currentUserId: String,
    editTitle: String,
) {
    var isEditing by remember(comment.id) { mutableStateOf(false) }
    val canEdit = comment.authorId == currentUserId && onUpdateComment != null
    val canDelete = (comment.authorId == currentUserId || isAdmin) && onDeleteComment != null

    Card(modifier = Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            Icon(
                imageVector = Icons.Default.AccountCircle,
                contentDescription = stringResource(R.string.cd_profile_picture_placeholder),
                modifier = Modifier.size(40.dp),
                tint = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Column(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(4.dp),
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(4.dp),
                ) {
                    Text(
                        comment.authorDisplayName,
                        modifier = Modifier.weight(1f),
                        style = MaterialTheme.typography.labelLarge,
                    )
                    if (canEdit) {
                        IconButton(
                            onClick = { isEditing = true },
                            enabled = enabled,
                            modifier = Modifier.size(36.dp),
                        ) {
                            Icon(
                                imageVector = Icons.Default.Edit,
                                contentDescription = stringResource(R.string.cd_edit_comment),
                            )
                        }
                    }
                    if (canDelete) {
                        IconButton(
                            onClick = { onDeleteComment(comment.id) },
                            enabled = enabled,
                            modifier = Modifier.size(36.dp),
                        ) {
                            Icon(
                                imageVector = Icons.Default.Delete,
                                contentDescription = stringResource(R.string.cd_delete_comment),
                            )
                        }
                    }
                }
                Text(comment.text, style = MaterialTheme.typography.bodyMedium)
            }
        }
    }

    if (isEditing && onUpdateComment != null) {
        var text by remember(comment.id, comment.text) { mutableStateOf(comment.text) }
        AlertDialog(
            onDismissRequest = { if (enabled) isEditing = false },
            title = { Text(editTitle) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = text,
                        onValueChange = { text = it },
                        modifier = Modifier.fillMaxWidth(),
                        enabled = enabled,
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        onUpdateComment(comment.id, text)
                        isEditing = false
                    },
                    enabled = enabled && text.isNotBlank(),
                ) {
                    Text(stringResource(R.string.action_save))
                }
            },
            dismissButton = {
                TextButton(
                    onClick = { isEditing = false },
                    enabled = enabled,
                ) {
                    Text(stringResource(R.string.action_cancel))
                }
            },
        )
    }
}

private fun PoiComment.toUiModel(): CommentUiModel = CommentUiModel(
    id = id,
    authorId = authorId,
    authorDisplayName = authorDisplayName,
    text = text,
)
