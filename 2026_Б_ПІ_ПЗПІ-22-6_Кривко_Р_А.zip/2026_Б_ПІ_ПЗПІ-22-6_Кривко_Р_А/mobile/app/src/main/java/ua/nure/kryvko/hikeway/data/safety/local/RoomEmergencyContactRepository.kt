package ua.nure.kryvko.hikeway.data.safety.local

import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.map
import ua.nure.kryvko.hikeway.domain.auth.CurrentUserProvider
import ua.nure.kryvko.hikeway.domain.safety.EmergencyContact
import ua.nure.kryvko.hikeway.domain.safety.EmergencyContactRepository

class RoomEmergencyContactRepository(
    private val dao: EmergencyContactDao,
    private val currentUserProvider: CurrentUserProvider,
) : EmergencyContactRepository {
    @OptIn(ExperimentalCoroutinesApi::class)
    override fun observePrimaryContact(): Flow<EmergencyContact?> {
        return currentUserProvider.currentUserId.flatMapLatest { ownerUserId ->
            if (ownerUserId == null) {
                flowOf(null)
            } else {
                dao.observePrimary(ownerUserId).map { it?.toDomain() }
            }
        }
    }

    override suspend fun savePrimaryContact(name: String?, phoneNumber: String): EmergencyContact {
        val ownerUserId = currentUserProvider.requireCurrentUserId()
        dao.deletePrimary(ownerUserId)
        val entity = EmergencyContactEntity(
            ownerUserId = ownerUserId,
            name = name,
            phoneNumber = phoneNumber,
            updatedAtEpochMillis = System.currentTimeMillis(),
        )
        val id = dao.upsert(entity)
        return entity.copy(id = id).toDomain()
    }

    override suspend fun deletePrimaryContact() {
        dao.deletePrimary(currentUserProvider.requireCurrentUserId())
    }
}

fun EmergencyContactEntity.toDomain() = EmergencyContact(
    id = id,
    name = name,
    phoneNumber = phoneNumber,
)
