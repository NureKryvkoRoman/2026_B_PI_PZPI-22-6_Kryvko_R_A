package ua.nure.kryvko.hikeway.data.services.backend

import retrofit2.http.GET
import retrofit2.http.Query
import ua.nure.kryvko.hikeway.data.search.remote.SearchResponseDto

interface SearchService {
    @GET("search")
    suspend fun search(
        @Query("name") name: String,
        @Query("page") page: Int = 0,
        @Query("size") size: Int = 20,
    ): SearchResponseDto
}
