package ua.nure.kryvko.hikeway.data.routepicking.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface ActiveRouteTrackingSessionDao {
    @Query("SELECT * FROM active_route_tracking_sessions WHERE ownerUserId = :ownerUserId LIMIT 1")
    fun observe(ownerUserId: String): Flow<ActiveRouteTrackingSessionEntity?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(session: ActiveRouteTrackingSessionEntity)

    @Query("DELETE FROM active_route_tracking_sessions WHERE ownerUserId = :ownerUserId")
    suspend fun delete(ownerUserId: String)
}
