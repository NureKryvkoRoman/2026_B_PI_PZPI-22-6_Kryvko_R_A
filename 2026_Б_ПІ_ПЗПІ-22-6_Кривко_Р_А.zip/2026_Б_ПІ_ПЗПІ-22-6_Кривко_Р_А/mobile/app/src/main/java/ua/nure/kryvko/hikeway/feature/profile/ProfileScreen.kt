package ua.nure.kryvko.hikeway.feature.profile

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ExitToApp
import androidx.compose.material.icons.filled.AccountCircle
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import java.time.Instant
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.util.Locale
import ua.nure.kryvko.hikeway.R
import ua.nure.kryvko.hikeway.domain.achievements.Achievement
import ua.nure.kryvko.hikeway.domain.achievements.AchievementProgressKind
import ua.nure.kryvko.hikeway.feature.safety.EmergencyContactsUiState

@Composable
fun ProfileScreen(
    username: String,
    email: String,
    fullName: String,
    isProfileLoading: Boolean = false,
    profileErrorMessage: String? = null,
    onRetryProfile: () -> Unit = {},
    selectedLanguageTag: String = "en",
    onLanguageSelected: (String) -> Unit = {},
    onEditProfileClick: () -> Unit,
    onEmergencyContactClick: () -> Unit,
    onAchievementsClick: () -> Unit,
    onLogOut: () -> Unit,
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
    ) {
        ProfileHeader(
            username = username,
            email = email,
            fullName = fullName,
            isProfileLoading = isProfileLoading,
            profileErrorMessage = profileErrorMessage,
            onRetryProfile = onRetryProfile,
            onEditProfileClick = onEditProfileClick,
            onLogOut = onLogOut,
        )
        LanguageMenuCard(
            selectedLanguageTag = selectedLanguageTag,
            onLanguageSelected = onLanguageSelected,
        )
        ProfileMenuCard(
            title = stringResource(R.string.profile_emergency_contact),
            description = stringResource(R.string.profile_emergency_contact_description),
            onClick = onEmergencyContactClick,
        )
        ProfileMenuCard(
            title = stringResource(R.string.profile_my_achievements),
            description = stringResource(R.string.profile_my_achievements_description),
            onClick = onAchievementsClick,
        )
    }
}

@Composable
private fun LanguageMenuCard(
    selectedLanguageTag: String,
    onLanguageSelected: (String) -> Unit,
) {
    var expanded by rememberSaveable { mutableStateOf(false) }
    val selectedLanguage = LanguageOption.entries.firstOrNull {
        it.languageTag == selectedLanguageTag
    } ?: LanguageOption.ENGLISH
    val selectedLabel = selectedLanguage.label()
    Card(modifier = Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clickable { expanded = true }
                .padding(16.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Column(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(4.dp),
            ) {
                Text(stringResource(R.string.profile_language), style = MaterialTheme.typography.titleMedium)
                Text(
                    stringResource(R.string.profile_language_current, selectedLabel),
                    style = MaterialTheme.typography.bodyMedium,
                )
            }
            Box {
                IconButton(onClick = { expanded = true }) {
                    Icon(
                        painter = painterResource(R.drawable.ic_language_24),
                        contentDescription = stringResource(R.string.profile_language_menu),
                    )
                }
                DropdownMenu(
                    expanded = expanded,
                    onDismissRequest = { expanded = false },
                ) {
                    LanguageOption.entries.forEach { language ->
                        DropdownMenuItem(
                            text = { Text(language.label()) },
                            onClick = {
                                expanded = false
                                onLanguageSelected(language.languageTag)
                            },
                        )
                    }
                }
            }
        }
    }
}

private enum class LanguageOption {
    ENGLISH,
    UKRAINIAN,
    ;

    val languageTag: String
        get() = when (this) {
            ENGLISH -> "en"
            UKRAINIAN -> "uk"
        }
}

@Composable
private fun LanguageOption.label(): String {
    return when (this) {
        LanguageOption.ENGLISH -> stringResource(R.string.profile_language_english)
        LanguageOption.UKRAINIAN -> stringResource(R.string.profile_language_ukrainian)
    }
}

@Composable
private fun ProfileHeader(
    username: String,
    email: String,
    fullName: String,
    isProfileLoading: Boolean,
    profileErrorMessage: String?,
    onRetryProfile: () -> Unit,
    onEditProfileClick: () -> Unit,
    onLogOut: () -> Unit,
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(
            modifier = Modifier
                .size(72.dp)
                .background(MaterialTheme.colorScheme.surfaceVariant, CircleShape),
            contentAlignment = Alignment.Center,
        ) {
            Icon(
                imageVector = Icons.Default.AccountCircle,
                contentDescription = stringResource(R.string.cd_profile_picture_placeholder),
                modifier = Modifier.size(56.dp),
                tint = MaterialTheme.colorScheme.primary,
            )
        }
        Column(
            modifier = Modifier.weight(1f),
            verticalArrangement = Arrangement.spacedBy(2.dp),
        ) {
            if (isProfileLoading && username.isBlank()) {
                CircularProgressIndicator(modifier = Modifier.size(24.dp))
            }
            Text(
                username.ifBlank { stringResource(R.string.profile_unknown_user) },
                style = MaterialTheme.typography.titleLarge,
            )
            if (email.isNotBlank()) {
                Text(email, style = MaterialTheme.typography.bodyMedium)
            }
            if (fullName.isNotBlank()) {
                Text(fullName, style = MaterialTheme.typography.bodyMedium)
            }
            profileErrorMessage?.let { message ->
                Text(message, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodyMedium)
                TextButton(onClick = onRetryProfile) {
                    Text(stringResource(R.string.action_retry))
                }
            }
        }
        Column {
            IconButton(onClick = onEditProfileClick) {
                Icon(
                    imageVector = Icons.Default.Edit,
                    contentDescription = stringResource(R.string.profile_edit_profile),
                )
            }
            IconButton(onClick = onLogOut) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.ExitToApp,
                    contentDescription = stringResource(R.string.profile_log_out),
                )
            }
        }
    }
}

@Composable
private fun ProfileMenuCard(
    title: String,
    description: String,
    onClick: () -> Unit,
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick),
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp),
        ) {
            Text(title, style = MaterialTheme.typography.titleMedium)
            Text(description, style = MaterialTheme.typography.bodyMedium)
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EditProfileScreen(
    state: ProfileUiState,
    onUsernameChange: (String) -> Unit,
    onEmailChange: (String) -> Unit,
    onFirstNameChange: (String) -> Unit,
    onLastNameChange: (String) -> Unit,
    onSave: () -> Unit,
    onBack: () -> Unit,
) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(stringResource(R.string.profile_edit_title)) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = stringResource(R.string.action_back),
                        )
                    }
                },
            )
        },
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .verticalScroll(rememberScrollState())
                .padding(24.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            OutlinedTextField(
                value = state.username,
                onValueChange = onUsernameChange,
                modifier = Modifier.fillMaxWidth(),
                label = { Text(stringResource(R.string.profile_username)) },
                isError = state.fieldErrors.username != null,
                supportingText = state.fieldErrors.username?.let { message -> { Text(message) } },
                singleLine = true,
            )
            OutlinedTextField(
                value = state.email,
                onValueChange = onEmailChange,
                modifier = Modifier.fillMaxWidth(),
                label = { Text(stringResource(R.string.profile_email)) },
                isError = state.fieldErrors.email != null,
                supportingText = state.fieldErrors.email?.let { message -> { Text(message) } },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email),
                singleLine = true,
            )
            OutlinedTextField(
                value = state.firstName,
                onValueChange = onFirstNameChange,
                modifier = Modifier.fillMaxWidth(),
                label = { Text(stringResource(R.string.auth_first_name)) },
                isError = state.fieldErrors.firstName != null,
                supportingText = state.fieldErrors.firstName?.let { message -> { Text(message) } },
                singleLine = true,
            )
            OutlinedTextField(
                value = state.lastName,
                onValueChange = onLastNameChange,
                modifier = Modifier.fillMaxWidth(),
                label = { Text(stringResource(R.string.auth_last_name)) },
                isError = state.fieldErrors.lastName != null,
                supportingText = state.fieldErrors.lastName?.let { message -> { Text(message) } },
                singleLine = true,
            )
            state.errorMessage?.let { message ->
                Text(message, color = MaterialTheme.colorScheme.error)
            }
            state.successMessage?.let { message ->
                Text(message, color = MaterialTheme.colorScheme.primary)
            }
            Button(
                onClick = onSave,
                enabled = !state.isSaving,
            ) {
                Text(
                    if (state.isSaving) {
                        stringResource(R.string.profile_saving)
                    } else {
                        stringResource(R.string.action_save)
                    }
                )
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AchievementsScreen(
    state: AchievementsUiState,
    onBack: () -> Unit,
) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(stringResource(R.string.profile_my_achievements)) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = stringResource(R.string.action_back),
                        )
                    }
                },
            )
        },
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            when {
                state.isLoading -> Box(
                    modifier = Modifier.fillMaxWidth().padding(24.dp),
                    contentAlignment = Alignment.Center,
                ) {
                    CircularProgressIndicator()
                }
                state.errorMessage != null -> {
                    Text(
                        text = state.errorMessage,
                        color = MaterialTheme.colorScheme.error,
                        style = MaterialTheme.typography.bodyMedium,
                    )
                }
                else -> state.achievements.forEach { achievement ->
                    AchievementCard(achievement)
                }
            }
        }
    }
}

@Composable
private fun AchievementCard(achievement: Achievement) {
    Card(modifier = Modifier.fillMaxWidth()) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text(
                    text = stringResource(achievement.titleResId),
                    style = MaterialTheme.typography.titleMedium,
                    modifier = Modifier.weight(1f),
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = if (achievement.isCompleted) {
                        stringResource(R.string.achievement_completed)
                    } else {
                        stringResource(R.string.achievement_in_progress)
                    },
                    style = MaterialTheme.typography.labelMedium,
                    color = if (achievement.isCompleted) {
                        MaterialTheme.colorScheme.primary
                    } else {
                        MaterialTheme.colorScheme.onSurfaceVariant
                    },
                )
            }
            Text(
                text = stringResource(achievement.descriptionResId),
                style = MaterialTheme.typography.bodyMedium,
            )
            LinearProgressIndicator(
                progress = {
                    (achievement.progressValue / achievement.targetValue)
                        .coerceIn(0.0, 1.0)
                        .toFloat()
                },
                modifier = Modifier.fillMaxWidth(),
            )
            Text(
                text = achievement.progressText(),
                style = MaterialTheme.typography.bodySmall,
            )
            achievement.completedAtEpochMillis?.let { completedAt ->
                Text(
                    text = stringResource(
                        R.string.achievement_completed_at,
                        completedAt.formatAchievementDate(),
                    ),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }
    }
}

@Composable
private fun Achievement.progressText(): String {
    return when (kind) {
        AchievementProgressKind.COUNT -> stringResource(
            R.string.achievement_progress_count,
            progressValue.toInt(),
            targetValue.toInt(),
        )
        AchievementProgressKind.DISTANCE_KM -> stringResource(
            R.string.achievement_progress_distance,
            "%.1f".format(Locale.US, progressValue),
            "%.1f".format(Locale.US, targetValue),
        )
    }
}

private fun Long.formatAchievementDate(): String {
    return Instant.ofEpochMilli(this)
        .atZone(ZoneId.systemDefault())
        .format(achievementDateFormatter)
}

private val achievementDateFormatter: DateTimeFormatter =
    DateTimeFormatter.ofPattern("dd MMM yyyy, HH:mm", Locale.US)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EmergencyContactScreen(
    state: EmergencyContactsUiState,
    onBack: () -> Unit,
    onNameChange: (String) -> Unit,
    onPhoneNumberChange: (String) -> Unit,
    onSave: () -> Unit,
    onDelete: () -> Unit,
) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(stringResource(R.string.profile_emergency_contact)) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = stringResource(R.string.action_back),
                        )
                    }
                },
            )
        },
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .padding(24.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            if (state.isLoading) {
                CircularProgressIndicator()
                return@Column
            }

            OutlinedTextField(
                value = state.name,
                onValueChange = onNameChange,
                modifier = Modifier.fillMaxWidth(),
                label = { Text(stringResource(R.string.profile_name_optional)) },
                singleLine = true,
            )
            OutlinedTextField(
                value = state.phoneNumber,
                onValueChange = onPhoneNumberChange,
                modifier = Modifier.fillMaxWidth(),
                label = { Text(stringResource(R.string.profile_phone_number)) },
                isError = state.validationError != null,
                supportingText = state.validationError?.let { message -> { Text(message) } },
                singleLine = true,
            )
            state.message?.let { message ->
                Text(
                    text = message,
                    color = if (message.startsWith("Could not")) {
                        MaterialTheme.colorScheme.error
                    } else {
                        MaterialTheme.colorScheme.primary
                    },
                )
            }
            Row(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Button(
                    onClick = onSave,
                    enabled = !state.isSaving,
                ) {
                    Text(
                        if (state.isSaving) {
                            stringResource(R.string.profile_saving)
                        } else {
                            stringResource(R.string.action_save)
                        }
                    )
                }
                if (state.contact != null) {
                    TextButton(onClick = onDelete) {
                        Text(stringResource(R.string.action_delete))
                    }
                }
            }
        }
    }
}
