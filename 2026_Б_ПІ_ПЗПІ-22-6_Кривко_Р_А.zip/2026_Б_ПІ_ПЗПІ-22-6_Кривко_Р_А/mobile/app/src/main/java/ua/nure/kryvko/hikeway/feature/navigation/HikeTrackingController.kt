package ua.nure.kryvko.hikeway.feature.navigation

import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import ua.nure.kryvko.hikeway.core.model.GeoPoint
import ua.nure.kryvko.hikeway.core.model.Route
import ua.nure.kryvko.hikeway.domain.hikelogging.ActiveTimer
import ua.nure.kryvko.hikeway.domain.hikelogging.HikeLog
import ua.nure.kryvko.hikeway.domain.hikelogging.SaveCompletedHikeUseCase
import ua.nure.kryvko.hikeway.domain.hikelogging.TimeProvider
import ua.nure.kryvko.hikeway.domain.routepicking.DeleteActiveRouteTrackingSessionUseCase
import ua.nure.kryvko.hikeway.domain.routepicking.RoutePickingSession
import ua.nure.kryvko.hikeway.domain.routepicking.RoutePickingStatus
import ua.nure.kryvko.hikeway.domain.routepicking.RouteTrackingProvider
import ua.nure.kryvko.hikeway.domain.routepicking.SaveActiveRouteTrackingSessionUseCase
import ua.nure.kryvko.hikeway.domain.routepicking.initialProgress
import ua.nure.kryvko.hikeway.domain.routes.distanceKm
import ua.nure.kryvko.hikeway.feature.routesearch.RouteSearchUiState

class HikeTrackingController(
    private val scope: CoroutineScope,
    private val uiState: MutableStateFlow<RouteSearchUiState>,
    private val routeTrackingProvider: RouteTrackingProvider,
    private val saveCompletedHike: SaveCompletedHikeUseCase,
    private val saveActiveSession: SaveActiveRouteTrackingSessionUseCase,
    private val deleteActiveSession: DeleteActiveRouteTrackingSessionUseCase,
    private val timeProvider: TimeProvider,
    private val activeTimer: ActiveTimer,
) {
    private var trackingJob: Job? = null
    private var activeTimerJob: Job? = null
    private var persistJob: Job? = null

    fun startRoute(route: Route) {
        val progress = initialProgress(route) ?: return
        trackingJob?.cancel()
        activeTimerJob?.cancel()
        val session = RoutePickingSession(
            route = route,
            userPosition = progress.position,
            bearingDegrees = progress.bearingDegrees,
            pointIndex = progress.pointIndex,
            status = RoutePickingStatus.ACTIVE,
            walkedPath = listOf(progress.position),
            walkedDistanceKm = 0.0,
            activeElapsedMillis = 0L,
            startedAtEpochMillis = timeProvider.currentTimeMillis(),
        )
        uiState.update {
            it.copy(
                saveErrorMessage = null,
                previewRoute = null,
                pickingSession = session,
            )
        }
        persist(session)
        startTracking(route = route, startIndex = progress.pointIndex)
        startActiveTimer(routeId = route.id)
    }

    fun pauseRoute() {
        trackingJob?.cancel()
        trackingJob = null
        activeTimerJob?.cancel()
        activeTimerJob = null
        uiState.updateAndPersistSession { session ->
            session.copy(status = RoutePickingStatus.PAUSED)
        }
    }

    fun unpauseRoute() {
        val session = uiState.value.pickingSession ?: return
        if (session.status == RoutePickingStatus.ACTIVE) return
        uiState.update {
            it.copy(pickingSession = session.copy(status = RoutePickingStatus.ACTIVE))
        }
        persist(session.copy(status = RoutePickingStatus.ACTIVE))
        startTracking(route = session.route, startIndex = session.pointIndex)
        startActiveTimer(routeId = session.route.id)
    }

    fun restoreSession(session: RoutePickingSession) {
        uiState.update { state ->
            if (state.pickingSession == null) {
                trackingJob?.cancel()
                trackingJob = null
                activeTimerJob?.cancel()
                activeTimerJob = null
                state.copy(
                    pickingSession = session.copy(status = RoutePickingStatus.PAUSED),
                    saveErrorMessage = null,
                )
            } else {
                state
            }
        }
    }

    fun finishRoute() {
        val session = uiState.value.pickingSession ?: return
        trackingJob?.cancel()
        trackingJob = null
        activeTimerJob?.cancel()
        activeTimerJob = null
        uiState.update { state ->
            state.copy(pickingSession = state.pickingSession?.copy(status = RoutePickingStatus.PAUSED))
        }

        scope.launch {
            val finishedAt = timeProvider.currentTimeMillis()
            val log = HikeLog(
                routeId = session.route.id,
                routeName = session.route.name,
                routeClientId = session.route.clientId,
                routeServerId = session.route.serverId,
                startedAtEpochMillis = session.startedAtEpochMillis,
                finishedAtEpochMillis = finishedAt,
                activeDurationMillis = session.activeElapsedMillis,
                wallClockDurationMillis = finishedAt - session.startedAtEpochMillis,
                totalDistanceKm = session.walkedDistanceKm,
                path = session.walkedPath,
            )
            runCatching { saveCompletedHike(log) }
                .onSuccess {
                    persistJob?.cancel()
                    persistJob = null
                    runCatching { deleteActiveSession() }
                    uiState.update { it.copy(pickingSession = null, saveErrorMessage = null) }
                }
                .onFailure {
                    uiState.updateAndPersistSession { current ->
                        current.copy(status = RoutePickingStatus.PAUSED)
                    }
                    uiState.update {
                        it.copy(saveErrorMessage = "Could not save completed hike.")
                    }
                }
        }
    }

    private fun startTracking(route: Route, startIndex: Int) {
        trackingJob?.cancel()
        trackingJob = scope.launch {
            routeTrackingProvider.positions(route, startIndex)
                .catch {
                    uiState.updateAndPersistSession { session ->
                        session.copy(status = RoutePickingStatus.PAUSED)
                    }
                    uiState.update { state ->
                        state.copy(saveErrorMessage = it.message ?: "Could not track current location.")
                    }
                }
                .collect { progress ->
                    var sessionToPersist: RoutePickingSession? = null
                    uiState.update { state ->
                        val session = state.pickingSession
                        if (session?.route?.id != route.id || session.status != RoutePickingStatus.ACTIVE) {
                            state
                        } else {
                            val updatedSession = session.copy(
                                userPosition = progress.position,
                                bearingDegrees = progress.bearingDegrees,
                                pointIndex = progress.pointIndex,
                                walkedPath = session.walkedPath.appendDistinct(progress.position),
                                walkedDistanceKm = session.walkedDistanceKm +
                                    session.walkedPath.lastOrNull()
                                        ?.takeIf { it != progress.position }
                                        ?.let { distanceKm(it, progress.position) }
                                        .orZero(),
                            )
                            sessionToPersist = updatedSession
                            state.copy(
                                pickingSession = updatedSession,
                                saveErrorMessage = null,
                            )
                        }
                    }
                    sessionToPersist?.let(::persist)
                }
        }
    }

    private fun startActiveTimer(routeId: Long) {
        activeTimerJob?.cancel()
        activeTimerJob = scope.launch {
            activeTimer.ticks().collect { deltaMillis ->
                uiState.update { state ->
                    val session = state.pickingSession
                    if (session?.route?.id != routeId || session.status != RoutePickingStatus.ACTIVE) {
                        state
                    } else {
                        val updatedSession = session.copy(
                            activeElapsedMillis = session.activeElapsedMillis + deltaMillis
                        )
                        persist(updatedSession)
                        state.copy(
                            pickingSession = updatedSession
                        )
                    }
                }
            }
        }
    }

    private fun persist(session: RoutePickingSession) {
        persistJob?.cancel()
        persistJob = scope.launch {
            runCatching { saveActiveSession(session) }
        }
    }

    private fun MutableStateFlow<RouteSearchUiState>.updateAndPersistSession(
        transform: (RoutePickingSession) -> RoutePickingSession,
    ) {
        var sessionToPersist: RoutePickingSession? = null
        update { state ->
            val updatedSession = state.pickingSession?.let(transform)
            sessionToPersist = updatedSession
            state.copy(pickingSession = updatedSession)
        }
        sessionToPersist?.let(::persist)
    }
}

private fun List<GeoPoint>.appendDistinct(value: GeoPoint): List<GeoPoint> {
    return if (lastOrNull() == value) this else this + value
}

private fun Double?.orZero(): Double = this ?: 0.0
