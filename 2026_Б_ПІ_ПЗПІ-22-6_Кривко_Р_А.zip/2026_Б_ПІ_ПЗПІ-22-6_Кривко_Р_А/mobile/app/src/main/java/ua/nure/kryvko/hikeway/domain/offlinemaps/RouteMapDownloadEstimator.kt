package ua.nure.kryvko.hikeway.domain.offlinemaps

import kotlin.math.PI
import kotlin.math.asinh
import kotlin.math.floor
import kotlin.math.tan
import ua.nure.kryvko.hikeway.core.model.GeoPoint
import ua.nure.kryvko.hikeway.core.model.Route

const val ROUTE_MAP_MIN_ZOOM = 10.0
const val ROUTE_MAP_MAX_ZOOM = 15.0

private const val ROUTE_BOUNDS_PADDING_FRACTION = 0.20
private const val MIN_PADDING_DEGREES = 0.01
private const val AVG_VECTOR_TILE_BYTES = 35L * 1024L
private const val STYLE_OVERHEAD_BYTES = 3L * 1024L * 1024L

fun estimateRouteMapDownload(route: Route): RouteMapDownloadEstimate {
    val bounds = route.geometry.points.paddedBounds()
    val tileCount = countTiles(bounds, ROUTE_MAP_MIN_ZOOM.toInt(), ROUTE_MAP_MAX_ZOOM.toInt())
    val middle = STYLE_OVERHEAD_BYTES + tileCount * AVG_VECTOR_TILE_BYTES
    return RouteMapDownloadEstimate(
        minBytes = (middle * 0.6).toLong(),
        maxBytes = (middle * 1.6).toLong(),
        tileCount = tileCount,
        minZoom = ROUTE_MAP_MIN_ZOOM,
        maxZoom = ROUTE_MAP_MAX_ZOOM,
        bounds = bounds,
    )
}

fun List<GeoPoint>.paddedBounds(): RouteMapBounds {
    val points = ifEmpty { listOf(GeoPoint(longitude = 0.0, latitude = 0.0)) }
    val north = points.maxOf { it.latitude }
    val south = points.minOf { it.latitude }
    val east = points.maxOf { it.longitude }
    val west = points.minOf { it.longitude }
    val latPadding = ((north - south) * ROUTE_BOUNDS_PADDING_FRACTION)
        .coerceAtLeast(MIN_PADDING_DEGREES)
    val lonPadding = ((east - west) * ROUTE_BOUNDS_PADDING_FRACTION)
        .coerceAtLeast(MIN_PADDING_DEGREES)
    return RouteMapBounds(
        north = (north + latPadding).coerceIn(-85.0, 85.0),
        east = (east + lonPadding).coerceIn(-180.0, 180.0),
        south = (south - latPadding).coerceIn(-85.0, 85.0),
        west = (west - lonPadding).coerceIn(-180.0, 180.0),
    )
}

private fun countTiles(bounds: RouteMapBounds, minZoom: Int, maxZoom: Int): Long {
    return (minZoom..maxZoom).sumOf { zoom ->
        val westTile = lonToTileX(bounds.west, zoom)
        val eastTile = lonToTileX(bounds.east, zoom)
        val northTile = latToTileY(bounds.north, zoom)
        val southTile = latToTileY(bounds.south, zoom)
        ((eastTile - westTile + 1).coerceAtLeast(1) *
            (southTile - northTile + 1).coerceAtLeast(1)).toLong()
    }
}

private fun lonToTileX(lon: Double, zoom: Int): Int {
    val scale = 1 shl zoom
    return floor((lon + 180.0) / 360.0 * scale).toInt().coerceIn(0, scale - 1)
}

private fun latToTileY(lat: Double, zoom: Int): Int {
    val scale = 1 shl zoom
    val radians = Math.toRadians(lat.coerceIn(-85.0, 85.0))
    return floor((1.0 - asinh(tan(radians)) / PI) / 2.0 * scale)
        .toInt()
        .coerceIn(0, scale - 1)
}

fun Long.formatBytesRange(maxBytes: Long): String {
    return "~${toMegabytes()}-${maxBytes.toMegabytes()} MB"
}

private fun Long.toMegabytes(): Long = (this.toDouble() / (1024.0 * 1024.0)).toLong().coerceAtLeast(1L)
