package ua.nure.kryvko.hikeway.domain.savedroutes

import java.security.MessageDigest
import kotlinx.coroutines.flow.Flow
import ua.nure.kryvko.hikeway.core.model.Route
import javax.inject.Inject

interface SavedRouteRepository {
    fun observeAll(): Flow<List<Route>>
    suspend fun save(route: Route)
    suspend fun remove(route: Route)
    suspend fun isSaved(route: Route): Boolean
}

class ObserveSavedRoutesUseCase @Inject constructor(
    private val repository: SavedRouteRepository,
) {
    operator fun invoke(): Flow<List<Route>> = repository.observeAll()
}

class SaveRouteForLaterUseCase @Inject constructor(
    private val repository: SavedRouteRepository,
) {
    suspend operator fun invoke(route: Route) = repository.save(route)
}

class RemoveSavedRouteUseCase @Inject constructor(
    private val repository: SavedRouteRepository,
) {
    suspend operator fun invoke(route: Route) = repository.remove(route)
}

class IsRouteSavedUseCase @Inject constructor(
    private val repository: SavedRouteRepository,
) {
    suspend operator fun invoke(route: Route): Boolean = repository.isSaved(route)
}

class ToggleSavedRouteUseCase @Inject constructor(
    private val repository: SavedRouteRepository,
) {
    suspend operator fun invoke(route: Route): Boolean {
        return if (repository.isSaved(route)) {
            repository.remove(route)
            false
        } else {
            repository.save(route)
            true
        }
    }
}

fun Route.savedRouteKey(): String {
    val points = geometry.points.joinToString(separator = ";") { point ->
        "${point.longitude},${point.latitude}"
    }
    return "$id:${"$name|$points".sha256()}"
}

private fun String.sha256(): String {
    val digest = MessageDigest.getInstance("SHA-256").digest(toByteArray(Charsets.UTF_8))
    return digest.joinToString(separator = "") { "%02x".format(it) }
}
