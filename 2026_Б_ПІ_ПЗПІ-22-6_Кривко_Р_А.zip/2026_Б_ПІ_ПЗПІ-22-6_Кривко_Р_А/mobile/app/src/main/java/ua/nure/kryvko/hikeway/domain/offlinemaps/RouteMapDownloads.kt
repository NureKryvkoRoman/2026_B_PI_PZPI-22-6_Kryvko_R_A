package ua.nure.kryvko.hikeway.domain.offlinemaps

import kotlinx.coroutines.flow.Flow
import ua.nure.kryvko.hikeway.core.model.GeoPoint
import ua.nure.kryvko.hikeway.core.model.Route
import javax.inject.Inject

enum class RouteMapDownloadStatus {
    PENDING,
    DOWNLOADING,
    READY,
    FAILED,
}

data class RouteMapBounds(
    val north: Double,
    val east: Double,
    val south: Double,
    val west: Double,
)

data class RouteMapDownloadEstimate(
    val minBytes: Long,
    val maxBytes: Long,
    val tileCount: Long,
    val minZoom: Double,
    val maxZoom: Double,
    val bounds: RouteMapBounds,
)

data class RouteMapDownload(
    val id: Long,
    val routeKey: String,
    val routeId: Long,
    val routeName: String,
    val routeGeometry: List<GeoPoint>,
    val bounds: RouteMapBounds,
    val minZoom: Double,
    val maxZoom: Double,
    val mapLibreRegionId: Long?,
    val status: RouteMapDownloadStatus,
    val completedResourceCount: Long,
    val requiredResourceCount: Long?,
    val completedResourceSizeBytes: Long,
    val completedTileCount: Long,
    val completedTileSizeBytes: Long,
    val estimatedMinBytes: Long,
    val estimatedMaxBytes: Long,
    val errorMessage: String?,
    val createdAtEpochMillis: Long,
    val updatedAtEpochMillis: Long,
) {
    val progressFraction: Float?
        get() = requiredResourceCount
            ?.takeIf { it > 0L }
            ?.let { (completedResourceCount.toFloat() / it).coerceIn(0f, 1f) }
}

interface RouteMapDownloadRepository {
    fun observeAll(): Flow<List<RouteMapDownload>>
    fun observeByRoute(route: Route): Flow<RouteMapDownload?>
    fun estimate(route: Route): RouteMapDownloadEstimate
    suspend fun start(route: Route)
    suspend fun delete(download: RouteMapDownload)
    suspend fun refreshStatuses()
}

class ObserveRouteMapDownloadsUseCase @Inject constructor(
    private val repository: RouteMapDownloadRepository,
) {
    operator fun invoke(): Flow<List<RouteMapDownload>> = repository.observeAll()
}

class ObserveRouteMapDownloadUseCase @Inject constructor(
    private val repository: RouteMapDownloadRepository,
) {
    operator fun invoke(route: Route): Flow<RouteMapDownload?> = repository.observeByRoute(route)
}

class EstimateRouteMapDownloadUseCase @Inject constructor(
    private val repository: RouteMapDownloadRepository,
) {
    operator fun invoke(route: Route): RouteMapDownloadEstimate = repository.estimate(route)
}

class StartRouteMapDownloadUseCase @Inject constructor(
    private val repository: RouteMapDownloadRepository,
) {
    suspend operator fun invoke(route: Route) = repository.start(route)
}

class DeleteRouteMapDownloadUseCase @Inject constructor(
    private val repository: RouteMapDownloadRepository,
) {
    suspend operator fun invoke(download: RouteMapDownload) = repository.delete(download)
}

class RefreshRouteMapDownloadsUseCase @Inject constructor(
    private val repository: RouteMapDownloadRepository,
) {
    suspend operator fun invoke() = repository.refreshStatuses()
}
