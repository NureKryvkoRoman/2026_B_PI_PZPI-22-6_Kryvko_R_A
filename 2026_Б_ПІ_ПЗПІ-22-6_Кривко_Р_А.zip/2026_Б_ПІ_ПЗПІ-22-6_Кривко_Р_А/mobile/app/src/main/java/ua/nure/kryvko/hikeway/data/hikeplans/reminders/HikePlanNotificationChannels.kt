package ua.nure.kryvko.hikeway.data.hikeplans.reminders

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.os.Build
import androidx.core.content.getSystemService

object HikePlanNotificationChannels {
    const val REMINDERS_CHANNEL_ID = "hike_plan_reminders"

    fun ensureReminderChannel(context: Context) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
        val notificationManager = context.getSystemService<NotificationManager>() ?: return
        val channel = NotificationChannel(
            REMINDERS_CHANNEL_ID,
            "Hike plan reminders",
            NotificationManager.IMPORTANCE_DEFAULT,
        ).apply {
            description = "Reminders for saved hike plans"
        }
        notificationManager.createNotificationChannel(channel)
    }
}
