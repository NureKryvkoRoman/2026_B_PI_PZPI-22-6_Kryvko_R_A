package ua.nure.kryvko.hikeway.data.offlinemaps.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface RouteMapDownloadDao {
    @Query(
        "SELECT * FROM route_map_downloads " +
            "WHERE ownerUserId = :ownerUserId ORDER BY updatedAtEpochMillis DESC"
    )
    fun observeAll(ownerUserId: String): Flow<List<RouteMapDownloadEntity>>

    @Query(
        "SELECT * FROM route_map_downloads " +
            "WHERE ownerUserId = :ownerUserId AND routeKey = :routeKey LIMIT 1"
    )
    fun observeByRouteKey(ownerUserId: String, routeKey: String): Flow<RouteMapDownloadEntity?>

    @Query(
        "SELECT * FROM route_map_downloads " +
            "WHERE ownerUserId = :ownerUserId AND routeKey = :routeKey LIMIT 1"
    )
    suspend fun findByRouteKey(ownerUserId: String, routeKey: String): RouteMapDownloadEntity?

    @Query(
        "SELECT * FROM route_map_downloads " +
            "WHERE ownerUserId = :ownerUserId AND mapLibreRegionId = :regionId LIMIT 1"
    )
    suspend fun findByRegionId(ownerUserId: String, regionId: Long): RouteMapDownloadEntity?

    @Query("SELECT * FROM route_map_downloads WHERE ownerUserId = :ownerUserId")
    suspend fun getAll(ownerUserId: String): List<RouteMapDownloadEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(download: RouteMapDownloadEntity): Long

    @Update
    suspend fun update(download: RouteMapDownloadEntity)

    @Query("DELETE FROM route_map_downloads WHERE ownerUserId = :ownerUserId AND id = :id")
    suspend fun delete(ownerUserId: String, id: Long)
}
