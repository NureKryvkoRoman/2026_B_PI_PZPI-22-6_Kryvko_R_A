package ua.nure.kryvko.hikeway.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.platform.LocalContext

private val DarkColorScheme = darkColorScheme(
    primary = HikeWayPrimary,
    onPrimary = HikeWayOnDark,
    primaryContainer = HikeWayDarkPrimaryContainer,
    onPrimaryContainer = HikeWayOnDark,
    secondary = HikeWaySecondary,
    onSecondary = HikeWayOnDark,
    secondaryContainer = HikeWayDarkSecondaryContainer,
    onSecondaryContainer = HikeWayOnDark,
    tertiary = HikeWayTertiary,
    onTertiary = HikeWayOnLight,
    tertiaryContainer = HikeWayDarkTertiaryContainer,
    onTertiaryContainer = HikeWayOnDark,
    background = HikeWayDarkBackground,
    onBackground = HikeWayDarkOnSurface,
    surface = HikeWayDarkSurface,
    onSurface = HikeWayDarkOnSurface,
    surfaceVariant = HikeWayDarkSurfaceVariant,
    onSurfaceVariant = HikeWayDarkOnSurfaceVariant,
    surfaceDim = HikeWayDarkSurfaceDim,
    surfaceBright = HikeWayDarkSurfaceBright,
    surfaceContainerLowest = HikeWayDarkSurfaceContainerLowest,
    surfaceContainerLow = HikeWayDarkSurfaceContainerLow,
    surfaceContainer = HikeWayDarkSurfaceContainer,
    surfaceContainerHigh = HikeWayDarkSurfaceContainerHigh,
    surfaceContainerHighest = HikeWayDarkSurfaceContainerHighest,
    outline = HikeWayDarkOutline,
    inverseSurface = HikeWayInverseOnSurface,
    inverseOnSurface = HikeWayInverseSurface,
)

private val LightColorScheme = lightColorScheme(
    primary = HikeWayPrimary,
    onPrimary = HikeWayOnDark,
    primaryContainer = HikeWayPrimaryContainer,
    onPrimaryContainer = HikeWayOnLight,
    secondary = HikeWaySecondary,
    onSecondary = HikeWayOnDark,
    secondaryContainer = HikeWaySecondaryContainer,
    onSecondaryContainer = HikeWayOnLight,
    tertiary = HikeWayTertiary,
    onTertiary = HikeWayOnLight,
    tertiaryContainer = HikeWayTertiaryContainer,
    onTertiaryContainer = HikeWayOnLight,
    background = HikeWayBackground,
    onBackground = HikeWayOnLight,
    surface = HikeWaySurface,
    onSurface = HikeWayOnLight,
    surfaceVariant = HikeWaySurfaceVariant,
    onSurfaceVariant = HikeWayOnSurfaceVariant,
    surfaceDim = HikeWaySurfaceDim,
    surfaceBright = HikeWaySurfaceBright,
    surfaceContainerLowest = HikeWaySurfaceContainerLowest,
    surfaceContainerLow = HikeWaySurfaceContainerLow,
    surfaceContainer = HikeWaySurfaceContainer,
    surfaceContainerHigh = HikeWaySurfaceContainerHigh,
    surfaceContainerHighest = HikeWaySurfaceContainerHighest,
    outline = HikeWayOutline,
    inverseSurface = HikeWayInverseSurface,
    inverseOnSurface = HikeWayInverseOnSurface,
)

@Composable
fun HikeWayTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    // Dynamic color is available on Android 12+
    dynamicColor: Boolean = false,
    content: @Composable () -> Unit
) {
    val colorScheme = when {
        dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
            val context = LocalContext.current
            if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
        }

        darkTheme -> DarkColorScheme
        else -> LightColorScheme
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
