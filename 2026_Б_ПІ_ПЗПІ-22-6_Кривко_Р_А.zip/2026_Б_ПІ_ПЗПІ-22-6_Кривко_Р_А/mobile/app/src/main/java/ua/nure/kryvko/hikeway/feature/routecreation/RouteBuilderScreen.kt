package ua.nure.kryvko.hikeway.feature.routecreation

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import ua.nure.kryvko.hikeway.R
import ua.nure.kryvko.hikeway.core.model.GeoPoint
import ua.nure.kryvko.hikeway.feature.pois.PoiOverviewPopup

@Composable
@OptIn(ExperimentalLayoutApi::class)
fun RouteBuilderScreen(
    state: RouteCreationUiState,
    onCrosshairChange: (GeoPoint) -> Unit,
    onCancel: () -> Unit,
    onPlacePoint: () -> Unit,
    onFinish: () -> Unit,
    onPoiClick: (Long) -> Unit,
    onDismissPoi: () -> Unit,
    onRatePoi: (Int) -> Unit,
    onAddPoiToRoute: () -> Unit,
) {
    Box(modifier = Modifier.fillMaxSize()) {
        RouteBuilderMap(
            points = state.points,
            crosshairPoint = state.crosshairPoint,
            pointsOfInterest = state.pointsOfInterest,
            onCrosshairChange = onCrosshairChange,
            onPoiClick = onPoiClick,
        )
        Crosshair(modifier = Modifier.align(Alignment.Center))
        Surface(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth(),
            tonalElevation = 8.dp,
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                Text(stringResource(R.string.create_route_title), style = MaterialTheme.typography.titleMedium)
                Text(
                    stringResource(
                        R.string.format_placed_points_distance,
                        state.points.size,
                        state.distanceKm.formatDistance(),
                    ),
                    style = MaterialTheme.typography.bodyMedium,
                )
                state.validationMessage?.let {
                    Text(it, color = MaterialTheme.colorScheme.error)
                }
                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    TextButton(onClick = onCancel) {
                        Text(stringResource(R.string.action_cancel))
                    }
                    Button(onClick = onPlacePoint) {
                        Text(stringResource(R.string.route_creation_place_point))
                    }
                    Button(onClick = onFinish) {
                        Text(stringResource(R.string.action_finish))
                    }
                }
            }
        }
        state.selectedPoi?.let { poi ->
            PoiOverviewPopup(
                poi = poi,
                onDismiss = onDismissPoi,
                onRate = onRatePoi,
                onAddToRoute = onAddPoiToRoute,
                modifier = Modifier.align(Alignment.TopCenter),
            )
        }
    }
}

@Composable
private fun Crosshair(modifier: Modifier = Modifier) {
    Icon(
        painter = painterResource(R.drawable.ic_crosshair),
        contentDescription = stringResource(R.string.cd_route_creation_crosshair),
        tint = MaterialTheme.colorScheme.primary,
        modifier = modifier.size(40.dp),
    )
}
