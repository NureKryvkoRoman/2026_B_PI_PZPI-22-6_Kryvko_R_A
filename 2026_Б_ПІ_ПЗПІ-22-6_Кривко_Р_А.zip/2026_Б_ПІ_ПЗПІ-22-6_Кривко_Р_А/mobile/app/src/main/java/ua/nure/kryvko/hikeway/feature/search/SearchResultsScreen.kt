package ua.nure.kryvko.hikeway.feature.search

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import ua.nure.kryvko.hikeway.R
import ua.nure.kryvko.hikeway.core.model.PointOfInterest
import ua.nure.kryvko.hikeway.core.model.Route
import ua.nure.kryvko.hikeway.domain.savedroutes.savedRouteKey
import ua.nure.kryvko.hikeway.feature.routesearch.PoiCard
import ua.nure.kryvko.hikeway.feature.routesearch.RouteCard

@Composable
fun SearchResultsScreen(
    state: SearchResultsUiState,
    savedRouteKeys: Set<String>,
    onQueryChange: (String) -> Unit,
    onSubmit: () -> Unit,
    onBack: () -> Unit,
    onRouteClick: (Route) -> Unit,
    onPoiClick: (PointOfInterest) -> Unit,
    onToggleSavedRoute: (Route) -> Unit,
    modifier: Modifier = Modifier,
) {
    BackHandler(onBack = onBack)

    Column(
        modifier = modifier
            .fillMaxSize()
            .windowInsetsPadding(WindowInsets.safeDrawing)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            IconButton(onClick = onBack) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                    contentDescription = stringResource(R.string.action_back),
                )
            }
            OutlinedTextField(
                value = state.query,
                onValueChange = onQueryChange,
                singleLine = true,
                leadingIcon = {
                    Icon(
                        imageVector = Icons.Default.Search,
                        contentDescription = null,
                    )
                },
                trailingIcon = {
                    IconButton(onClick = onSubmit) {
                        Icon(
                            imageVector = Icons.Default.Search,
                            contentDescription = stringResource(R.string.action_search),
                        )
                    }
                },
                placeholder = { Text(stringResource(R.string.home_search_placeholder)) },
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                keyboardActions = KeyboardActions(onSearch = { onSubmit() }),
                modifier = Modifier.weight(1f),
            )
        }

        SearchResultsContent(
            state = state,
            savedRouteKeys = savedRouteKeys,
            onRetry = onSubmit,
            onRouteClick = onRouteClick,
            onPoiClick = onPoiClick,
            onToggleSavedRoute = onToggleSavedRoute,
        )
    }
}

@Composable
private fun SearchResultsContent(
    state: SearchResultsUiState,
    savedRouteKeys: Set<String>,
    onRetry: () -> Unit,
    onRouteClick: (Route) -> Unit,
    onPoiClick: (PointOfInterest) -> Unit,
    onToggleSavedRoute: (Route) -> Unit,
) {
    when {
        state.isLoading -> {
            CircularProgressIndicator(modifier = Modifier.padding(16.dp))
        }

        state.errorMessage != null -> {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text(
                    text = state.errorMessage,
                    color = MaterialTheme.colorScheme.error,
                )
                Button(onClick = onRetry) {
                    Text(stringResource(R.string.action_retry))
                }
            }
        }

        state.routes.isEmpty() && state.pointsOfInterest.isEmpty() -> {
            Text(
                stringResource(R.string.search_no_results),
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }

        else -> {
            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier.fillMaxSize(),
            ) {
                if (state.routes.isNotEmpty()) {
                    item {
                        Text(
                            stringResource(R.string.search_routes_section),
                            style = MaterialTheme.typography.titleMedium,
                        )
                    }
                    items(state.routes, key = { it.savedRouteKey() }) { route ->
                        RouteCard(
                            route = route,
                            isSaved = route.savedRouteKey() in savedRouteKeys,
                            onClick = { onRouteClick(route) },
                            onToggleSaved = { onToggleSavedRoute(route) },
                        )
                    }
                }
                if (state.pointsOfInterest.isNotEmpty()) {
                    item {
                        Text(
                            stringResource(R.string.search_pois_section),
                            style = MaterialTheme.typography.titleMedium,
                        )
                    }
                    items(state.pointsOfInterest, key = { it.id }) { poi ->
                        PoiCard(
                            poi = poi,
                            onClick = { onPoiClick(poi) },
                        )
                    }
                }
            }
        }
    }
}
