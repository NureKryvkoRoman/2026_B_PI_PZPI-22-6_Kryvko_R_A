package ua.nure.kryvko.hikeway.data.hikeplans.local

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "hike_plans",
    indices = [
        Index(value = ["ownerUserId", "plannedDateEpochDay"]),
    ],
)
data class HikePlanEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val ownerUserId: String,
    val routeId: Long,
    val routeName: String,
    val plannedDateEpochDay: Long,
    val checklistJson: String,
    val routeSnapshotJson: String?,
    val createdAtEpochMillis: Long,
    val updatedAtEpochMillis: Long,
)
