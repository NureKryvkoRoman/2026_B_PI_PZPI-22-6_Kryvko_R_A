package ua.nure.kryvko.hikeway.feature.pois

import androidx.activity.compose.BackHandler
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.Orientation
import androidx.compose.foundation.gestures.draggable
import androidx.compose.foundation.gestures.rememberDraggableState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.launch
import ua.nure.kryvko.hikeway.R
import ua.nure.kryvko.hikeway.core.model.PoiPhotoUpload
import ua.nure.kryvko.hikeway.core.model.PointOfInterest
import kotlin.math.roundToInt

@Composable
fun PoiOverviewPopup(
    poi: PointOfInterest,
    onDismiss: () -> Unit,
    onRate: (Int) -> Unit,
    modifier: Modifier = Modifier,
    onAddToRoute: (() -> Unit)? = null,
    isLoading: Boolean = false,
    isActionInProgress: Boolean = false,
    errorMessage: String? = null,
    onRemoveRating: (() -> Unit)? = null,
    onUploadPhoto: ((PoiPhotoUpload) -> Unit)? = null,
    onUpdatePhoto: ((Long, String?) -> Unit)? = null,
    onDeletePhoto: ((Long) -> Unit)? = null,
    onEditPoi: (() -> Unit)? = null,
    onViewComments: (() -> Unit)? = null,
    isAdmin: Boolean = false,
) {
    BackHandler(onBack = onDismiss)

    val density = LocalDensity.current
    val scope = rememberCoroutineScope()
    val dismissThresholdPx = with(density) { 72.dp.toPx() }
    var dragOffsetPx by remember(poi.id) { mutableFloatStateOf(0f) }

    LaunchedEffect(poi.id) {
        dragOffsetPx = 0f
    }

    fun settlePopup(velocity: Float = 0f) {
        if (dragOffsetPx <= -dismissThresholdPx || velocity < -600f) {
            onDismiss()
            return
        }
        scope.launch {
            val animation = Animatable(dragOffsetPx)
            animation.animateTo(
                targetValue = 0f,
                animationSpec = tween(durationMillis = 180),
            ) {
                dragOffsetPx = value
            }
        }
    }

    Surface(
        modifier = modifier
            .fillMaxWidth()
            .offset { IntOffset(x = 0, y = dragOffsetPx.roundToInt()) },
        tonalElevation = 8.dp,
        shape = RoundedCornerShape(0, 0, 5, 5)
    ) {
        Column(
            modifier = Modifier
                .heightIn(max = 620.dp)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text(stringResource(R.string.poi_point_of_interest), style = MaterialTheme.typography.labelLarge)
                if (isLoading || isActionInProgress) {
                    CircularProgressIndicator(modifier = Modifier.size(22.dp))
                }
            }
            Text(poi.name, style = MaterialTheme.typography.titleMedium)
            poi.ownerDisplayName?.let {
                Text(stringResource(R.string.format_added_by, it), style = MaterialTheme.typography.bodySmall)
            }
            errorMessage?.let {
                Text(it, color = MaterialTheme.colorScheme.error)
            }
            PoiPhotoStrip(
                poi = poi,
                onUploadPhoto = onUploadPhoto,
                onUpdatePhoto = onUpdatePhoto,
                onDeletePhoto = onDeletePhoto,
                enabled = !isActionInProgress,
                isAdmin = isAdmin,
            )
            Text(poi.description, style = MaterialTheme.typography.bodyMedium)
            RatingRow(
                poi = poi,
                onRate = onRate,
                onRemoveRating = onRemoveRating,
            )
            if ((poi.ownedByCurrentUser || isAdmin) && onEditPoi != null) {
                Button(
                    onClick = onEditPoi,
                    enabled = !isActionInProgress,
                ) {
                    Text(stringResource(R.string.poi_edit_poi))
                }
            }
            HorizontalDivider()
            onViewComments?.let {
                Button(
                    onClick = it,
                    enabled = !isActionInProgress,
                ) {
                    Text(
                        stringResource(
                            R.string.poi_view_comments_count,
                            poi.comments.size,
                        )
                    )
                }
            }
            onAddToRoute?.let { addToRoute ->
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = addToRoute) {
                        Text(stringResource(R.string.action_add_to_route))
                    }
                }
            }
            val dragHandleDescription = stringResource(R.string.cd_poi_popup_drag_handle)
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(28.dp)
                    .draggable(
                        orientation = Orientation.Vertical,
                        state = rememberDraggableState { delta ->
                            dragOffsetPx = (dragOffsetPx + delta).coerceAtMost(0f)
                        },
                        onDragStopped = { velocity -> settlePopup(velocity) },
                    )
                    .semantics {
                        contentDescription = dragHandleDescription
                    },
                contentAlignment = Alignment.Center,
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth(0.18f)
                        .height(4.dp)
                        .background(
                            color = MaterialTheme.colorScheme.outline,
                            shape = RoundedCornerShape(percent = 50),
                        )
                )
            }
        }
    }
}
