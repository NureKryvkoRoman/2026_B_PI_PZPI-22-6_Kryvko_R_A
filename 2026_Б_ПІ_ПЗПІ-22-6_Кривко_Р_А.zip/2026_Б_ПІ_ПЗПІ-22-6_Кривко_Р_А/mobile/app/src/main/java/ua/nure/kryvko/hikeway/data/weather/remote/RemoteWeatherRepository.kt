package ua.nure.kryvko.hikeway.data.weather.remote

import com.google.gson.Gson
import java.time.LocalDate
import ua.nure.kryvko.hikeway.data.services.backend.WeatherService
import ua.nure.kryvko.hikeway.data.services.network.toApiException
import ua.nure.kryvko.hikeway.domain.weather.HikePlanWeather
import ua.nure.kryvko.hikeway.domain.weather.WeatherRepository

class RemoteWeatherRepository(
    private val service: WeatherService,
    private val gson: Gson,
) : WeatherRepository {
    override suspend fun getHikePlanWeather(routeId: Long, date: LocalDate): HikePlanWeather {
        return runCatching {
            service.weather(routeId = routeId, date = date.toString()).toDomain()
        }.getOrElse {
            throw it.toApiException(gson, "Weather is unavailable.")
        }
    }
}
