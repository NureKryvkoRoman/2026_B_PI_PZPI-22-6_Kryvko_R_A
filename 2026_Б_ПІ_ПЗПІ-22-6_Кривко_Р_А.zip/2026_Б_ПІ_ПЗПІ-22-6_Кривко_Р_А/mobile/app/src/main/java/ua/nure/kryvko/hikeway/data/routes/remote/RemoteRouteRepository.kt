package ua.nure.kryvko.hikeway.data.routes.remote

import com.google.gson.Gson
import ua.nure.kryvko.hikeway.core.model.GeoPoint
import ua.nure.kryvko.hikeway.core.model.Route
import ua.nure.kryvko.hikeway.core.model.RouteComment
import ua.nure.kryvko.hikeway.core.model.RouteRating
import ua.nure.kryvko.hikeway.data.services.backend.RouteService
import ua.nure.kryvko.hikeway.data.services.network.toApiException
import ua.nure.kryvko.hikeway.domain.routes.RecommendedRouteRepository
import ua.nure.kryvko.hikeway.domain.routes.RouteContentRepository
import ua.nure.kryvko.hikeway.domain.routes.RouteDetailRepository
import ua.nure.kryvko.hikeway.domain.routes.RouteRepository
import ua.nure.kryvko.hikeway.domain.routes.RouteSearchCriteria

private const val DEFAULT_PAGE_SIZE = 50
private const val USER_CREATED_PAGE_SIZE = 100
private const val RECOMMENDED_PAGE_SIZE = 10

class RemoteRouteRepository(
    private val service: RouteService,
    private val gson: Gson,
) : RouteRepository, RecommendedRouteRepository, RouteDetailRepository, RouteContentRepository {
    override suspend fun search(criteria: RouteSearchCriteria, origin: GeoPoint): List<Route> {
        return runCatching {
            service.search(
                minDistanceKm = criteria.distanceKm?.start,
                maxDistanceKm = criteria.distanceKm?.endInclusive,
                minEstimatedTimeMinutes = criteria.estimatedTimeMinutes?.first,
                maxEstimatedTimeMinutes = criteria.estimatedTimeMinutes?.last,
                difficulties = criteria.difficulties.map { it.name }.sorted().takeIf { it.isNotEmpty() },
                terrains = criteria.terrains.map { it.name }.sorted().takeIf { it.isNotEmpty() },
                longitude = origin.longitude,
                latitude = origin.latitude,
                maxProximityKm = criteria.maxProximityKm,
                size = DEFAULT_PAGE_SIZE,
            ).items.map { it.toDomain() }
        }.getOrElse {
            throw it.toApiException(gson, "Routes are unavailable.")
        }
    }

    override suspend fun findById(id: Long): Route? {
        return findByServerId(id)
    }

    override suspend fun findByClientId(clientId: String): Route? = null

    override suspend fun findByServerId(serverId: Long): Route? {
        return runCatching {
            val route = service.getRoute(serverId)
            val geometry = service.getRouteGeometry(serverId)
            route.toDomain(geometry)
        }.getOrElse { error ->
            if (error is retrofit2.HttpException && error.code() == 404) {
                null
            } else {
                throw error.toApiException(gson, "Route is unavailable.")
            }
        }
    }

    suspend fun currentUserRoutes(): List<Route> {
        return runCatching {
            val routes = mutableListOf<Route>()
            var page = 0
            do {
                val response = service.currentUserRoutes(page = page, size = USER_CREATED_PAGE_SIZE)
                routes += response.items.map { it.toDomain() }
                page += 1
            } while (page < response.totalPages)
            routes
        }.getOrElse {
            throw it.toApiException(gson, "Could not load user-created routes.")
        }
    }

    override suspend fun recommended(origin: GeoPoint?): List<Route> {
        return runCatching {
            service.recommendedRoutes(
                longitude = origin?.longitude,
                latitude = origin?.latitude,
                size = RECOMMENDED_PAGE_SIZE,
            ).items.map { it.toDomain() }
        }.getOrElse {
            throw it.toApiException(gson, "Recommended routes are unavailable.")
        }
    }

    override suspend fun submitRating(routeId: Long, rating: Int): RouteRating {
        return runCatching {
            service.rate(routeId, RouteRatingRequestDto(rating)).toDomain()
        }.getOrElse {
            throw it.toApiException(gson, "Could not submit route rating.")
        }
    }

    override suspend fun removeRating(routeId: Long): RouteRating {
        return runCatching {
            service.removeRating(routeId).toDomain()
        }.getOrElse {
            throw it.toApiException(gson, "Could not remove route rating.")
        }
    }

    override suspend fun getComments(routeId: Long): List<RouteComment> {
        return runCatching {
            service.comments(routeId, size = DEFAULT_PAGE_SIZE).items.map { it.toDomain() }
        }.getOrElse {
            throw it.toApiException(gson, "Route comments are unavailable.")
        }
    }

    override suspend fun addComment(routeId: Long, text: String): RouteComment {
        return runCatching {
            service.addComment(routeId, RouteCommentRequestDto(text)).toDomain()
        }.getOrElse {
            throw it.toApiException(gson, "Could not add route comment.")
        }
    }

    override suspend fun updateComment(routeId: Long, commentId: Long, text: String): RouteComment {
        return runCatching {
            service.updateComment(routeId, commentId, RouteCommentRequestDto(text)).toDomain()
        }.getOrElse {
            throw it.toApiException(gson, "Could not update route comment.")
        }
    }

    override suspend fun deleteComment(routeId: Long, commentId: Long) {
        return runCatching {
            service.deleteComment(routeId, commentId)
        }.getOrElse {
            throw it.toApiException(gson, "Could not delete route comment.")
        }
    }
}
