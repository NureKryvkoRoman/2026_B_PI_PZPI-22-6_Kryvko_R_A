package ua.nure.kryvko.hikeway.feature.routecreation

import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.DpSize
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.serialization.json.jsonPrimitive
import kotlinx.serialization.json.longOrNull
import org.maplibre.compose.expressions.dsl.const
import org.maplibre.compose.expressions.dsl.image
import org.maplibre.compose.layers.LineLayer
import org.maplibre.compose.layers.SymbolLayer
import org.maplibre.compose.sources.GeoJsonData
import org.maplibre.compose.sources.rememberGeoJsonSource
import org.maplibre.compose.util.ClickResult
import ua.nure.kryvko.hikeway.R
import ua.nure.kryvko.hikeway.core.model.GeoPoint
import ua.nure.kryvko.hikeway.core.model.PointOfInterest
import ua.nure.kryvko.hikeway.ui.map.HikeWayMap
import ua.nure.kryvko.hikeway.ui.map.MapCenterMode
import ua.nure.kryvko.hikeway.ui.map.emptyFeatureCollectionGeoJson
import ua.nure.kryvko.hikeway.ui.map.toGeoPoint
import ua.nure.kryvko.hikeway.ui.map.toLineStringFeatureGeoJson
import ua.nure.kryvko.hikeway.ui.map.toPoiFeatureCollectionGeoJson
import ua.nure.kryvko.hikeway.ui.map.toPointFeatureCollectionGeoJson

@Composable
@Suppress("COMPOSE_APPLIER_CALL_MISMATCH")
fun RouteBuilderMap(
    points: List<GeoPoint>,
    crosshairPoint: GeoPoint,
    pointsOfInterest: List<PointOfInterest>,
    onCrosshairChange: (GeoPoint) -> Unit,
    onPoiClick: (Long) -> Unit,
) {
    val solidGeoJson = remember(points) { points.toLineStringFeatureGeoJson() }
    val previewGeoJson = remember(points, crosshairPoint) {
        points.lastOrNull()
            ?.let { listOf(it, crosshairPoint).toLineStringFeatureGeoJson() }
            ?: emptyFeatureCollectionGeoJson()
    }
    val startPointGeoJson = remember(points) {
        points.take(1).toPointFeatureCollectionGeoJson()
    }
    val middlePointsGeoJson = remember(points) {
        points.drop(1).dropLast(1).toPointFeatureCollectionGeoJson()
    }
    val endPointGeoJson = remember(points) {
        if (points.size >= 2) {
            listOf(points.last()).toPointFeatureCollectionGeoJson()
        } else {
            emptyFeatureCollectionGeoJson()
        }
    }
    val poiGeoJson = remember(pointsOfInterest) { pointsOfInterest.toPoiFeatureCollectionGeoJson() }
    val poiPainter = painterResource(R.drawable.poi_marker_24)
    val routeStartPainter = painterResource(R.drawable.ic_route_start)
    val routePointPainter = painterResource(R.drawable.ic_route_point)
    val routeEndPainter = painterResource(R.drawable.ic_route_end)
    val routeColor = MaterialTheme.colorScheme.primary
    val previewSegmentColor = MaterialTheme.colorScheme.error
    val poiColor = MaterialTheme.colorScheme.error

    HikeWayMap(
        centerMode = MapCenterMode.Fixed(crosshairPoint),
        initialZoom = 12.0,
        cameraEffect = { cameraState ->
            LaunchedEffect(cameraState) {
                snapshotFlow { cameraState.position.target }
                    .distinctUntilChanged()
                    .collect { target ->
                        onCrosshairChange(target.toGeoPoint())
                    }
            }
        },
    ) {
        if (points.size >= 2) {
            val solidSource = rememberGeoJsonSource(GeoJsonData.JsonString(solidGeoJson))
            LineLayer(
                id = "created-route",
                source = solidSource,
                color = const(routeColor),
                width = const(5.dp),
            )
        }
        if (points.isNotEmpty()) {
            val previewSource = rememberGeoJsonSource(GeoJsonData.JsonString(previewGeoJson))
            LineLayer(
                id = "route-preview-segment",
                source = previewSource,
                color = const(previewSegmentColor),
                dasharray = const(listOf(1.5, 1.5)),
                width = const(4.dp),
            )
        }
        if (points.isNotEmpty()) {
            val startPointSource = rememberGeoJsonSource(GeoJsonData.JsonString(startPointGeoJson))
            SymbolLayer(
                id = "route-creation-start-point",
                source = startPointSource,
                iconImage = image(
                    value = routeStartPainter,
                    size = DpSize(30.dp, 30.dp),
                    drawAsSdf = false,
                ),
                iconAllowOverlap = const(true),
                iconIgnorePlacement = const(true),
            )
        }
        if (points.size > 2) {
            val middlePointsSource = rememberGeoJsonSource(GeoJsonData.JsonString(middlePointsGeoJson))
            SymbolLayer(
                id = "route-creation-middle-points",
                source = middlePointsSource,
                iconImage = image(
                    value = routePointPainter,
                    size = DpSize(24.dp, 24.dp),
                    drawAsSdf = false,
                ),
                iconAllowOverlap = const(true),
                iconIgnorePlacement = const(true),
            )
        }
        if (points.size >= 2) {
            val endPointSource = rememberGeoJsonSource(GeoJsonData.JsonString(endPointGeoJson))
            SymbolLayer(
                id = "route-creation-end-point",
                source = endPointSource,
                iconImage = image(
                    value = routeEndPainter,
                    size = DpSize(30.dp, 30.dp),
                    drawAsSdf = false,
                ),
                iconAllowOverlap = const(true),
                iconIgnorePlacement = const(true),
            )
        }
        if (pointsOfInterest.isNotEmpty()) {
            val poiSource = rememberGeoJsonSource(GeoJsonData.JsonString(poiGeoJson))
            SymbolLayer(
                id = "route-creation-points-of-interest",
                source = poiSource,
                iconImage = image(
                    value = poiPainter,
                    size = DpSize(34.dp, 34.dp),
                    drawAsSdf = true,
                ),
                iconColor = const(poiColor),
                iconHaloWidth = const(2.dp),
                iconAllowOverlap = const(true),
                iconIgnorePlacement = const(true),
                onClick = { features ->
                    val poiId = features.firstOrNull()
                        ?.properties
                        ?.get("poiId")
                        ?.jsonPrimitive
                        ?.longOrNull
                    if (poiId != null) {
                        onPoiClick(poiId)
                        ClickResult.Consume
                    } else {
                        ClickResult.Pass
                    }
                },
            )
        }
    }
}
