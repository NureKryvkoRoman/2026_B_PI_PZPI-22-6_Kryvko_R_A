package ua.nure.kryvko.hikeway.feature.routesearch

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.WindowInsetsSides
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.only
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import ua.nure.kryvko.hikeway.R
import ua.nure.kryvko.hikeway.core.model.Route
import ua.nure.kryvko.hikeway.core.model.RouteComment
import ua.nure.kryvko.hikeway.feature.pois.CommentUiModel
import ua.nure.kryvko.hikeway.feature.pois.GenericCommentSection

@Composable
fun RouteCommentsScreen(
    route: Route,
    isActionInProgress: Boolean,
    errorMessage: String?,
    isAdmin: Boolean,
    currentUserId: String,
    onBack: () -> Unit,
    onAddComment: (String) -> Unit,
    onUpdateComment: (Long, String) -> Unit,
    onDeleteComment: (Long) -> Unit,
) {
    BackHandler(onBack = onBack)

    Column(
        modifier = Modifier
            .fillMaxSize()
            .windowInsetsPadding(
                WindowInsets.safeDrawing.only(
                    WindowInsetsSides.Top + WindowInsetsSides.Horizontal
                )
            )
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            IconButton(onClick = onBack) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                    contentDescription = stringResource(R.string.action_back),
                )
            }
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    stringResource(R.string.route_comments_title),
                    style = MaterialTheme.typography.headlineSmall,
                )
                Text(
                    route.name,
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            if (isActionInProgress) {
                CircularProgressIndicator(modifier = Modifier.size(22.dp))
            }
        }

        errorMessage?.let {
            Text(it, color = MaterialTheme.colorScheme.error)
        }

        GenericCommentSection(
            comments = route.comments.map { it.toUiModel() },
            enabled = !isActionInProgress,
            onAddComment = onAddComment,
            onUpdateComment = onUpdateComment,
            onDeleteComment = onDeleteComment,
            isAdmin = isAdmin,
            currentUserId = currentUserId,
            title = stringResource(R.string.route_comments),
            addLabel = stringResource(R.string.route_add_comment_label),
            emptyMessage = stringResource(R.string.route_no_comments),
            editTitle = stringResource(R.string.route_edit_comment_title),
        )
    }
}

private fun RouteComment.toUiModel(): CommentUiModel = CommentUiModel(
    id = id,
    authorId = authorId,
    authorDisplayName = authorDisplayName,
    text = text,
)
