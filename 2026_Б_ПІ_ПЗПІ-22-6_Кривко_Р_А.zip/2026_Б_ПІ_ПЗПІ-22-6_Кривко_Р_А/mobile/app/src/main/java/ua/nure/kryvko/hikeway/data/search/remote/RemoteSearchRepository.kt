package ua.nure.kryvko.hikeway.data.search.remote

import com.google.gson.Gson
import ua.nure.kryvko.hikeway.data.services.backend.SearchService
import ua.nure.kryvko.hikeway.data.services.network.toApiException
import ua.nure.kryvko.hikeway.domain.search.SearchRepository
import ua.nure.kryvko.hikeway.domain.search.SearchResults

private const val DEFAULT_SEARCH_PAGE_SIZE = 20

class RemoteSearchRepository(
    private val service: SearchService,
    private val gson: Gson,
) : SearchRepository {
    override suspend fun search(name: String): SearchResults {
        return runCatching {
            service.search(
                name = name,
                size = DEFAULT_SEARCH_PAGE_SIZE,
            ).toDomain()
        }.getOrElse {
            throw it.toApiException(gson, "Search is unavailable.")
        }
    }
}
