package ua.nure.kryvko.hikeway.data.safety.local

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "emergency_contacts",
    indices = [Index(value = ["ownerUserId"], unique = true)],
)
data class EmergencyContactEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val ownerUserId: String,
    val name: String?,
    val phoneNumber: String,
    val updatedAtEpochMillis: Long,
)
