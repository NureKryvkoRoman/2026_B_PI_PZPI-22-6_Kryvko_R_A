package ua.nure.kryvko.hikeway.data.routepicking.local

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "active_route_tracking_sessions",
    indices = [Index(value = ["ownerUserId"], unique = true)],
)
data class ActiveRouteTrackingSessionEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val ownerUserId: String,
    val routeId: Long,
    val routeName: String,
    val routeDescription: String,
    val routeDistanceKm: Double,
    val routeEstimatedTimeMinutes: Int,
    val routeDifficulty: String,
    val routeElevationGainMeters: Int,
    val routeTerrain: String,
    val routeGeometryGeoJson: String,
    val userLongitude: Double,
    val userLatitude: Double,
    val bearingDegrees: Double,
    val pointIndex: Int,
    val status: String,
    val walkedPathGeoJson: String,
    val walkedDistanceKm: Double,
    val activeElapsedMillis: Long,
    val startedAtEpochMillis: Long,
    val updatedAtEpochMillis: Long,
)
