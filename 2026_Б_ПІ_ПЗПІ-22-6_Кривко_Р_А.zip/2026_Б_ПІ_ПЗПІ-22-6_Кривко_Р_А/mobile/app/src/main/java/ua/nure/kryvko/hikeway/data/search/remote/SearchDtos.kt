package ua.nure.kryvko.hikeway.data.search.remote

import ua.nure.kryvko.hikeway.data.pois.remote.PoiSummaryDto
import ua.nure.kryvko.hikeway.data.pois.remote.toDomain
import ua.nure.kryvko.hikeway.data.routes.remote.PageResponseDto
import ua.nure.kryvko.hikeway.data.routes.remote.RouteSummaryDto
import ua.nure.kryvko.hikeway.data.routes.remote.toDomain
import ua.nure.kryvko.hikeway.domain.search.SearchResults

data class SearchResponseDto(
    val routes: PageResponseDto<RouteSummaryDto>,
    val pois: PageResponseDto<PoiSummaryDto>,
)

fun SearchResponseDto.toDomain(): SearchResults = SearchResults(
    routes = routes.items.map(RouteSummaryDto::toDomain),
    pointsOfInterest = pois.items.map(PoiSummaryDto::toDomain),
)
