package ua.nure.kryvko.hikeway.data.weather.remote

import java.time.Instant
import java.time.LocalDate
import java.time.LocalDateTime
import ua.nure.kryvko.hikeway.domain.weather.DailyPlanWeather
import ua.nure.kryvko.hikeway.domain.weather.HikePlanWeather
import ua.nure.kryvko.hikeway.domain.weather.HourlyPlanWeather
import ua.nure.kryvko.hikeway.domain.weather.StartTimeRecommendation
import ua.nure.kryvko.hikeway.domain.weather.WeatherRiskUiModel

data class WeatherResponseDto(
    val routeId: Long,
    val date: String,
    val timezone: String?,
    val summary: DailyWeatherDto,
    val hourlyForecast: List<HourlyWeatherDto> = emptyList(),
    val risks: List<WeatherRiskDto> = emptyList(),
    val recommendation: StartTimeRecommendationDto?,
    val dataSource: String?,
    val lastUpdated: String?,
)

data class DailyWeatherDto(
    val weatherCode: Int?,
    val condition: String?,
    val temperatureMaxC: Double?,
    val temperatureMinC: Double?,
    val sunrise: String?,
    val sunset: String?,
    val daylightDurationSeconds: Long?,
    val uvIndexMax: Double?,
    val precipitationSumMm: Double?,
    val precipitationProbabilityMaxPercent: Int?,
    val windSpeedMaxKmh: Double?,
    val windGustsMaxKmh: Double?,
)

data class HourlyWeatherDto(
    val time: String,
    val temperatureC: Double?,
    val apparentTemperatureC: Double?,
    val precipitationProbabilityPercent: Int?,
    val precipitationMm: Double?,
    val weatherCode: Int?,
    val condition: String?,
    val windGustsKmh: Double?,
)

data class WeatherRiskDto(
    val type: String?,
    val severity: String?,
    val message: String?,
)

data class StartTimeRecommendationDto(
    val recommendedStartTime: String?,
    val expectedReturnTime: String?,
    val explanation: String?,
)

fun WeatherResponseDto.toDomain(): HikePlanWeather {
    return HikePlanWeather(
        routeId = routeId,
        date = LocalDate.parse(date),
        timezone = timezone,
        summary = summary.toDomain(),
        hourlyForecast = hourlyForecast.mapNotNull { it.toDomainOrNull() },
        risks = risks.mapNotNull { it.toDomainOrNull() },
        recommendation = recommendation.toDomain(),
        dataSource = dataSource ?: "weather",
        lastUpdated = lastUpdated?.let(Instant::parse) ?: Instant.EPOCH,
    )
}

private fun DailyWeatherDto.toDomain(): DailyPlanWeather {
    return DailyPlanWeather(
        weatherCode = weatherCode,
        condition = condition ?: weatherCode.conditionToken(),
        temperatureMaxC = temperatureMaxC,
        temperatureMinC = temperatureMinC,
        sunrise = sunrise?.let { LocalDateTime.parse(it).toLocalTime() },
        sunset = sunset?.let { LocalDateTime.parse(it).toLocalTime() },
        daylightDurationSeconds = daylightDurationSeconds,
        uvIndexMax = uvIndexMax,
        precipitationSumMm = precipitationSumMm,
        precipitationProbabilityMaxPercent = precipitationProbabilityMaxPercent,
        windSpeedMaxKmh = windSpeedMaxKmh,
        windGustsMaxKmh = windGustsMaxKmh,
    )
}

private fun HourlyWeatherDto.toDomainOrNull(): HourlyPlanWeather? {
    return runCatching {
        HourlyPlanWeather(
            time = LocalDateTime.parse(time),
            temperatureC = temperatureC,
            apparentTemperatureC = apparentTemperatureC,
            precipitationProbabilityPercent = precipitationProbabilityPercent,
            precipitationMm = precipitationMm,
            weatherCode = weatherCode,
            condition = condition ?: weatherCode.conditionToken(),
            windGustsKmh = windGustsKmh,
        )
    }.getOrNull()
}

private fun WeatherRiskDto.toDomainOrNull(): WeatherRiskUiModel? {
    val type = type ?: return null
    return WeatherRiskUiModel(
        type = type,
        severity = severity.orEmpty(),
        message = message.orEmpty(),
    )
}

private fun StartTimeRecommendationDto?.toDomain(): StartTimeRecommendation {
    return StartTimeRecommendation(
        recommendedStartTime = this?.recommendedStartTime?.let(LocalDateTime::parse),
        expectedReturnTime = this?.expectedReturnTime?.let(LocalDateTime::parse),
        explanation = this?.explanation,
    )
}

private fun Int?.conditionToken(): String {
    return when (this) {
        0 -> "CLEAR"
        1, 2, 3 -> "PARTLY_CLOUDY"
        45, 48 -> "FOG"
        51, 53, 55, 56, 57 -> "DRIZZLE"
        61, 63, 65, 66, 67, 80, 81, 82 -> "RAIN"
        71, 73, 75, 77, 85, 86 -> "SNOW"
        95, 96, 99 -> "THUNDERSTORM"
        else -> "FORECAST"
    }
}
