package ua.nure.kryvko.hikeway.feature.saved

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import ua.nure.kryvko.hikeway.core.model.Route
import ua.nure.kryvko.hikeway.domain.savedroutes.ObserveSavedRoutesUseCase
import ua.nure.kryvko.hikeway.domain.savedroutes.RemoveSavedRouteUseCase
import ua.nure.kryvko.hikeway.domain.savedroutes.ToggleSavedRouteUseCase
import ua.nure.kryvko.hikeway.domain.savedroutes.savedRouteKey

data class SavedRoutesUiState(
    val routes: List<Route> = emptyList(),
    val savedRouteKeys: Set<String> = emptySet(),
    val isLoading: Boolean = true,
    val errorMessage: String? = null,
)

@HiltViewModel
class SavedRoutesViewModel @Inject constructor(
    private val observeSavedRoutes: ObserveSavedRoutesUseCase,
    private val toggleSavedRoute: ToggleSavedRouteUseCase,
    private val removeSavedRoute: RemoveSavedRouteUseCase,
) : ViewModel() {
    private val _uiState = MutableStateFlow(SavedRoutesUiState())
    val uiState: StateFlow<SavedRoutesUiState> = _uiState.asStateFlow()

    init {
        viewModelScope.launch {
            observeSavedRoutes()
                .catch {
                    _uiState.update {
                        it.copy(
                            isLoading = false,
                            errorMessage = "Could not load saved routes.",
                        )
                    }
                }
                .collect { routes ->
                    _uiState.update {
                        it.copy(
                            routes = routes,
                            savedRouteKeys = routes.map { route -> route.savedRouteKey() }.toSet(),
                            isLoading = false,
                            errorMessage = null,
                        )
                    }
                }
        }
    }

    fun toggleSaved(route: Route) {
        val routeKey = route.savedRouteKey()
        val wasSaved = routeKey in _uiState.value.savedRouteKeys
        _uiState.update { state ->
            if (wasSaved) {
                state.copy(
                    routes = state.routes.filterNot { it.savedRouteKey() == routeKey },
                    savedRouteKeys = state.savedRouteKeys - routeKey,
                    errorMessage = null,
                )
            } else {
                state.copy(
                    routes = state.routes + route,
                    savedRouteKeys = state.savedRouteKeys + routeKey,
                    errorMessage = null,
                )
            }
        }
        viewModelScope.launch {
            runCatching { toggleSavedRoute(route) }
                .onFailure {
                    _uiState.update { state ->
                        if (wasSaved) {
                            state.copy(
                                routes = state.routes + route,
                                savedRouteKeys = state.savedRouteKeys + routeKey,
                                errorMessage = "Could not update saved route.",
                            )
                        } else {
                            state.copy(
                                routes = state.routes.filterNot { it.savedRouteKey() == routeKey },
                                savedRouteKeys = state.savedRouteKeys - routeKey,
                                errorMessage = "Could not update saved route.",
                            )
                        }
                    }
                }
        }
    }

    fun remove(route: Route) {
        viewModelScope.launch {
            runCatching { removeSavedRoute(route) }
                .onFailure {
                    _uiState.update { state ->
                        state.copy(errorMessage = "Could not remove saved route.")
                    }
                }
        }
    }
}
