package ua.nure.kryvko.hikeway.feature.routecreation

import androidx.annotation.StringRes
import androidx.compose.runtime.Composable
import androidx.compose.ui.res.stringResource
import java.util.Locale
import ua.nure.kryvko.hikeway.R
import ua.nure.kryvko.hikeway.core.model.Difficulty
import ua.nure.kryvko.hikeway.core.model.Terrain

@Composable
fun Difficulty.label(): String = stringResource(difficultyLabelRes())

@Composable
fun Terrain.label(): String = stringResource(terrainLabelRes())

@StringRes
fun Difficulty.difficultyLabelRes(): Int {
    return when (this) {
        Difficulty.EASY -> R.string.difficulty_easy
        Difficulty.MEDIUM -> R.string.difficulty_medium
        Difficulty.HARD -> R.string.difficulty_hard
    }
}

@StringRes
fun Terrain.terrainLabelRes(): Int {
    return when (this) {
        Terrain.FOREST -> R.string.terrain_forest
        Terrain.MOUNTAIN -> R.string.terrain_mountain
        Terrain.ROCKY -> R.string.terrain_rocky
        Terrain.MIXED -> R.string.terrain_mixed
    }
}

fun Double.formatDistance(): String {
    return "%.2f km".format(Locale.US, this)
}
