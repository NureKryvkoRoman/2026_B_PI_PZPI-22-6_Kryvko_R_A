package ua.nure.kryvko.hikeway.feature.pois

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.FilledTonalIconButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import ua.nure.kryvko.hikeway.R
import ua.nure.kryvko.hikeway.core.model.PoiPhoto
import ua.nure.kryvko.hikeway.core.model.PoiPhotoUpload
import ua.nure.kryvko.hikeway.core.model.PointOfInterest

@Composable
fun PoiPhotoStrip(
    poi: PointOfInterest,
    onUploadPhoto: ((PoiPhotoUpload) -> Unit)?,
    onUpdatePhoto: ((Long, String?) -> Unit)?,
    onDeletePhoto: ((Long) -> Unit)?,
    enabled: Boolean,
    isAdmin: Boolean,
) {
    var isUploadDialogOpen by remember { mutableStateOf(false) }

    if (poi.photos.isEmpty() && poi.photoResIds.isEmpty()) {
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Image(
                painter = painterResource(R.drawable.poi_photo_placeholder),
                contentDescription = stringResource(R.string.poi_photo_placeholder_content_description, poi.name),
                contentScale = ContentScale.Crop,
                modifier = Modifier.size(width = 160.dp, height = 90.dp),
            )
            onUploadPhoto?.let {
                AddPhotoTile(
                    enabled = enabled,
                    onClick = { isUploadDialogOpen = true },
                )
            }
        }
    } else {
        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            items(poi.photos) { photo ->
                RemotePhotoCard(
                    photo = photo,
                    onUpdatePhoto = onUpdatePhoto,
                    onDeletePhoto = onDeletePhoto,
                    isAdmin = isAdmin,
                )
            }
            items(poi.photoResIds) { photoResId ->
                Image(
                    painter = painterResource(photoResId),
                    contentDescription = stringResource(R.string.poi_photo_content_description, poi.name),
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.size(width = 160.dp, height = 90.dp),
                )
            }
            onUploadPhoto?.let {
                item {
                    AddPhotoTile(
                        enabled = enabled,
                        onClick = { isUploadDialogOpen = true },
                    )
                }
            }
        }
    }

    if (isUploadDialogOpen && onUploadPhoto != null) {
        AddPhotoDialog(
            enabled = enabled,
            onDismiss = { isUploadDialogOpen = false },
            onUploadPhoto = {
                onUploadPhoto(it)
                isUploadDialogOpen = false
            },
        )
    }
}

@Composable
private fun AddPhotoTile(
    enabled: Boolean,
    onClick: () -> Unit,
) {
    Box(
        modifier = Modifier.size(width = 90.dp, height = 90.dp),
        contentAlignment = Alignment.Center,
    ) {
        FilledTonalIconButton(onClick = onClick, enabled = enabled) {
            Icon(
                imageVector = Icons.Default.Add,
                contentDescription = stringResource(R.string.cd_add_poi_photo),
            )
        }
    }
}

@Composable
private fun AddPhotoDialog(
    enabled: Boolean,
    onDismiss: () -> Unit,
    onUploadPhoto: (PoiPhotoUpload) -> Unit,
) {
    val context = LocalContext.current
    var caption by remember { mutableStateOf("") }
    val photoPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia(),
    ) { uri: Uri? ->
        val upload = uri?.let {
            context.contentResolver.poiPhotoUploadFromUri(
                uri = it,
                caption = caption,
            )
        }
        if (upload != null) {
            onUploadPhoto(upload)
        }
    }

    AlertDialog(
        onDismissRequest = { if (enabled) onDismiss() },
        title = { Text(stringResource(R.string.poi_add_photo)) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = caption,
                    onValueChange = { caption = it },
                    label = { Text(stringResource(R.string.poi_photo_caption)) },
                    singleLine = true,
                    enabled = enabled,
                )
                Button(
                    onClick = {
                        photoPicker.launch(
                            PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                        )
                    },
                    enabled = enabled,
                ) {
                    Text(stringResource(R.string.poi_choose_image))
                }
            }
        },
        confirmButton = {},
        dismissButton = {
            TextButton(onClick = onDismiss, enabled = enabled) {
                Text(stringResource(R.string.action_cancel))
            }
        },
    )
}

@Composable
private fun RemotePhotoCard(
    photo: PoiPhoto,
    onUpdatePhoto: ((Long, String?) -> Unit)?,
    onDeletePhoto: ((Long) -> Unit)?,
    isAdmin: Boolean,
) {
    var caption by remember(photo.id, photo.caption) { mutableStateOf(photo.caption.orEmpty()) }
    Column(
        modifier = Modifier.size(width = 190.dp, height = 180.dp),
        verticalArrangement = Arrangement.spacedBy(4.dp),
    ) {
        AsyncImage(
            model = photo.url,
            contentDescription = photo.caption ?: stringResource(R.string.poi_photo_content_description_fallback),
            contentScale = ContentScale.Crop,
            modifier = Modifier
                .size(width = 190.dp, height = 106.dp),
        )
        Text(
            photo.caption ?: stringResource(R.string.poi_photo_no_caption),
            style = MaterialTheme.typography.bodySmall,
            maxLines = 1,
        )
        if (photo.ownedByCurrentUser || isAdmin) {
            Row(
                modifier = Modifier.horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(4.dp),
            ) {
                OutlinedTextField(
                    value = caption,
                    onValueChange = { caption = it },
                    label = { Text(stringResource(R.string.poi_caption)) },
                    modifier = Modifier.size(width = 110.dp, height = 56.dp),
                    singleLine = true,
                )
                TextButton(onClick = { onUpdatePhoto?.invoke(photo.id, caption) }) {
                    Text(stringResource(R.string.action_save))
                }
                TextButton(onClick = { onDeletePhoto?.invoke(photo.id) }) {
                    Text(stringResource(R.string.action_delete))
                }
            }
        }
    }
}

private fun android.content.ContentResolver.poiPhotoUploadFromUri(
    uri: Uri,
    caption: String,
): PoiPhotoUpload? {
    val type = getType(uri) ?: return null
    val bytes = openInputStream(uri)?.use { it.readBytes() } ?: return null
    return PoiPhotoUpload(
        bytes = bytes,
        contentType = type,
        caption = caption.trim().takeIf { it.isNotEmpty() },
    )
}
