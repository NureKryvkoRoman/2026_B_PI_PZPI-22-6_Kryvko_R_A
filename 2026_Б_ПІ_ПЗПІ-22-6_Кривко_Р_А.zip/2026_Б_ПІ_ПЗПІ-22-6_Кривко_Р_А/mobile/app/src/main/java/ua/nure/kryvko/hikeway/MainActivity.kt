package ua.nure.kryvko.hikeway

import android.Manifest
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import dagger.hilt.android.AndroidEntryPoint
import ua.nure.kryvko.hikeway.app.HikeWayApp
import ua.nure.kryvko.hikeway.app.locale.LocalizedContextWrapper
import ua.nure.kryvko.hikeway.app.locale.savedLanguageTag
import ua.nure.kryvko.hikeway.app.locale.updateApplicationLocale
import ua.nure.kryvko.hikeway.data.sync.SyncWorkScheduler
import ua.nure.kryvko.hikeway.feature.auth.AuthViewModel
import ua.nure.kryvko.hikeway.feature.completedhikes.CompletedHikesViewModel
import ua.nure.kryvko.hikeway.feature.hikeplans.HikePlansViewModel
import ua.nure.kryvko.hikeway.feature.profile.AchievementsViewModel
import ua.nure.kryvko.hikeway.feature.profile.ProfileViewModel
import ua.nure.kryvko.hikeway.feature.routecreation.RouteCreationViewModel
import ua.nure.kryvko.hikeway.feature.routesearch.RouteSearchViewModel
import ua.nure.kryvko.hikeway.feature.search.SearchResultsViewModel
import ua.nure.kryvko.hikeway.feature.safety.EmergencyContactsViewModel
import ua.nure.kryvko.hikeway.feature.saved.SavedMapsViewModel
import ua.nure.kryvko.hikeway.feature.saved.SavedRoutesViewModel
import ua.nure.kryvko.hikeway.feature.saved.UserCreatedRoutesViewModel
import ua.nure.kryvko.hikeway.ui.theme.HikeWayTheme

@AndroidEntryPoint
class MainActivity : ComponentActivity() {
    private val authViewModel: AuthViewModel by viewModels()
    private val routeSearchViewModel: RouteSearchViewModel by viewModels()
    private val searchResultsViewModel: SearchResultsViewModel by viewModels()
    private val completedHikesViewModel: CompletedHikesViewModel by viewModels()
    private val routeCreationViewModel: RouteCreationViewModel by viewModels()
    private val savedRoutesViewModel: SavedRoutesViewModel by viewModels()
    private val userCreatedRoutesViewModel: UserCreatedRoutesViewModel by viewModels()
    private val savedMapsViewModel: SavedMapsViewModel by viewModels()
    private val hikePlansViewModel: HikePlansViewModel by viewModels()
    private val emergencyContactsViewModel: EmergencyContactsViewModel by viewModels()
    private val profileViewModel: ProfileViewModel by viewModels()
    private val achievementsViewModel: AchievementsViewModel by viewModels()
    private val notificationPermissionRequest = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) {}

    override fun attachBaseContext(newBase: Context) {
        super.attachBaseContext(LocalizedContextWrapper(newBase))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        SyncWorkScheduler.schedule(applicationContext)
        requestLocationPermissionForProduction()

        setContent {
            var selectedLanguageTag by androidx.compose.runtime.remember {
                androidx.compose.runtime.mutableStateOf(applicationContext.savedLanguageTag())
            }
            HikeWayTheme {
                HikeWayApp(
                    authViewModel = authViewModel,
                    routeSearchViewModel = routeSearchViewModel,
                    searchResultsViewModel = searchResultsViewModel,
                    completedHikesViewModel = completedHikesViewModel,
                    routeCreationViewModel = routeCreationViewModel,
                    savedRoutesViewModel = savedRoutesViewModel,
                    userCreatedRoutesViewModel = userCreatedRoutesViewModel,
                    savedMapsViewModel = savedMapsViewModel,
                    hikePlansViewModel = hikePlansViewModel,
                    emergencyContactsViewModel = emergencyContactsViewModel,
                    profileViewModel = profileViewModel,
                    achievementsViewModel = achievementsViewModel,
                    selectedLanguageTag = selectedLanguageTag,
                    onLanguageSelected = { languageTag ->
                        if (languageTag != selectedLanguageTag) {
                            selectedLanguageTag = languageTag
                            updateApplicationLocale(languageTag)
                            recreate()
                        }
                    },
                    requestNotificationPermission = ::requestNotificationPermissionIfNeeded,
                    launchSmsMessage = ::launchSmsMessage,
                    showToast = ::showToast,
                )
            }
        }
    }

    @Suppress("DEPRECATION", "OVERRIDE_DEPRECATION")
    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray,
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == LOCATION_PERMISSION_REQUEST_CODE &&
            grantResults.any { it == PackageManager.PERMISSION_GRANTED }
        ) {
            routeSearchViewModel.centerOnCurrentLocation()
            routeSearchViewModel.refreshCurrentSearch()
            routeSearchViewModel.refreshPointsOfInterest()
        }
    }

    private fun requestLocationPermissionForProduction() {
        if (BuildConfig.USE_SIMULATED_GPS) return
        val hasFineLocation = ContextCompat.checkSelfPermission(
            this,
            Manifest.permission.ACCESS_FINE_LOCATION,
        ) == PackageManager.PERMISSION_GRANTED
        val hasCoarseLocation = ContextCompat.checkSelfPermission(
            this,
            Manifest.permission.ACCESS_COARSE_LOCATION,
        ) == PackageManager.PERMISSION_GRANTED
        if (!hasFineLocation && !hasCoarseLocation) {
            ActivityCompat.requestPermissions(
                this,
                arrayOf(
                    Manifest.permission.ACCESS_FINE_LOCATION,
                    Manifest.permission.ACCESS_COARSE_LOCATION,
                ),
                LOCATION_PERMISSION_REQUEST_CODE,
            )
        }
    }

    private fun requestNotificationPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU) return
        val hasPermission = ContextCompat.checkSelfPermission(
            this,
            Manifest.permission.POST_NOTIFICATIONS,
        ) == PackageManager.PERMISSION_GRANTED
        if (!hasPermission) {
            notificationPermissionRequest.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }

    private fun launchSmsMessage(phoneNumber: String, body: String) {
        val intent = Intent(Intent.ACTION_SENDTO).apply {
            data = Uri.parse("smsto:${Uri.encode(phoneNumber)}")
            putExtra("sms_body", body)
        }
        try {
            startActivity(intent)
        } catch (_: ActivityNotFoundException) {
            Toast.makeText(this, "No SMS app is available.", Toast.LENGTH_SHORT).show()
        }
    }

    private fun showToast(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    }

    private companion object {
        const val LOCATION_PERMISSION_REQUEST_CODE = 1001
    }
}
