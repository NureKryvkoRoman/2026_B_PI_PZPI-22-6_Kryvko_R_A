package ua.nure.kryvko.hikeway.core.model

import java.time.Instant

data class GeoPoint(
    val longitude: Double,
    val latitude: Double,
)

data class RouteGeometry(
    val points: List<GeoPoint>,
)

enum class Difficulty {
    EASY,
    MEDIUM,
    HARD,
}

enum class Terrain {
    FOREST,
    MOUNTAIN,
    ROCKY,
    MIXED,
}

enum class RouteVisibility {
    PRIVATE,
    PUBLIC,
}

data class Route(
    val id: Long,
    val name: String,
    val description: String,
    val distanceKm: Double,
    val estimatedTimeMinutes: Int,
    val difficulty: Difficulty,
    val elevationGainMeters: Int,
    val terrain: Terrain,
    val geometry: RouteGeometry,
    val clientId: String? = null,
    val serverId: Long? = null,
    val createdBy: String? = null,
    val visibility: RouteVisibility = RouteVisibility.PRIVATE,
    val averageRating: Double = 0.0,
    val ratingCount: Long = 0,
    val userRating: Int? = null,
    val comments: List<RouteComment> = emptyList(),
)

data class RouteRating(
    val averageRating: Double,
    val ratingCount: Long,
    val userRating: Int?,
)

data class RouteComment(
    val id: Long,
    val authorId: String,
    val authorDisplayName: String,
    val ownedByCurrentUser: Boolean,
    val text: String,
    val createdAt: Instant? = null,
    val updatedAt: Instant? = null,
)
