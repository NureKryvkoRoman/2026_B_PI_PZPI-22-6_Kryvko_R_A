package ua.nure.kryvko.hikeway.data.services.backend

import retrofit2.http.GET
import retrofit2.http.Query
import ua.nure.kryvko.hikeway.data.weather.remote.WeatherResponseDto

interface WeatherService {
    @GET("weather")
    suspend fun weather(
        @Query("routeId") routeId: Long,
        @Query("date") date: String,
    ): WeatherResponseDto
}
