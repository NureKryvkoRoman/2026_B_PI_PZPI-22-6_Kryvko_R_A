package ua.nure.kryvko.hikeway.feature.routesearch

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.testTag
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import ua.nure.kryvko.hikeway.R
import ua.nure.kryvko.hikeway.core.model.Difficulty
import ua.nure.kryvko.hikeway.core.model.Terrain
import ua.nure.kryvko.hikeway.domain.routes.RouteSearchCriteria
import ua.nure.kryvko.hikeway.ui.common.ChoiceChip

@Composable
@OptIn(ExperimentalLayoutApi::class)
fun FilterDialog(
    criteria: RouteSearchCriteria,
    onCriteriaChange: (RouteSearchCriteria) -> Unit,
    onDifficultyToggle: (Difficulty) -> Unit,
    onTerrainToggle: (Terrain) -> Unit,
    onClear: () -> Unit,
    onApply: () -> Unit,
    onDismiss: () -> Unit,
) {
    var minimumDistance by remember {
        mutableStateOf(
            criteria.distanceKm?.start?.toString().orEmpty()
        )
    }
    var maximumDistance by remember {
        mutableStateOf(
            criteria.distanceKm?.endInclusive?.toString().orEmpty()
        )
    }
    var minimumTime by remember {
        mutableStateOf(
            criteria.estimatedTimeMinutes?.first?.toString().orEmpty()
        )
    }
    var maximumTime by remember {
        mutableStateOf(
            criteria.estimatedTimeMinutes?.last?.toString().orEmpty()
        )
    }
    var maximumProximity by remember {
        mutableStateOf(
            criteria.maxProximityKm?.toString().orEmpty()
        )
    }
    val isDistanceRangeReversed = decimalRangeReversed(minimumDistance, maximumDistance)
    val isTimeRangeReversed = integerRangeReversed(minimumTime, maximumTime)
    val hasValidationError = isDistanceRangeReversed || isTimeRangeReversed

    fun updateNumericCriteria(
        nextMinimumDistance: String = minimumDistance,
        nextMaximumDistance: String = maximumDistance,
        nextMinimumTime: String = minimumTime,
        nextMaximumTime: String = maximumTime,
        nextMaximumProximity: String = maximumProximity,
    ) {
        if (
            decimalRangeReversed(nextMinimumDistance, nextMaximumDistance) ||
            integerRangeReversed(nextMinimumTime, nextMaximumTime)
        ) {
            return
        }
        onCriteriaChange(
            criteria.copy(
                distanceKm = decimalRange(nextMinimumDistance, nextMaximumDistance),
                estimatedTimeMinutes = integerRange(nextMinimumTime, nextMaximumTime),
                maxProximityKm = decimalValue(nextMaximumProximity),
            )
        )
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(stringResource(R.string.route_filter_title)) },
        text = {
            Column(
                modifier = Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                Text(
                    stringResource(R.string.route_filter_distance_km),
                    style = MaterialTheme.typography.labelLarge
                )
                RangeFields(
                    minimum = minimumDistance,
                    maximum = maximumDistance,
                    minimumTag = ROUTE_FILTER_DISTANCE_MIN_TAG,
                    maximumTag = ROUTE_FILTER_DISTANCE_MAX_TAG,
                    keyboardType = KeyboardType.Decimal,
                    isError = isDistanceRangeReversed,
                    errorMessage = stringResource(R.string.route_filter_distance_range_error)
                        .takeIf { isDistanceRangeReversed },
                    onChange = { minimum, maximum ->
                        val sanitizedMinimum = sanitizeDecimalInput(minimum)
                        val sanitizedMaximum = sanitizeDecimalInput(maximum)
                        minimumDistance = sanitizedMinimum
                        maximumDistance = sanitizedMaximum
                        updateNumericCriteria(
                            nextMinimumDistance = sanitizedMinimum,
                            nextMaximumDistance = sanitizedMaximum,
                        )
                    },
                )
                Text(
                    stringResource(R.string.route_filter_estimated_time_minutes),
                    style = MaterialTheme.typography.labelLarge
                )
                RangeFields(
                    minimum = minimumTime,
                    maximum = maximumTime,
                    minimumTag = ROUTE_FILTER_TIME_MIN_TAG,
                    maximumTag = ROUTE_FILTER_TIME_MAX_TAG,
                    keyboardType = KeyboardType.Number,
                    isError = isTimeRangeReversed,
                    errorMessage = stringResource(R.string.route_filter_duration_range_error)
                        .takeIf { isTimeRangeReversed },
                    onChange = { minimum, maximum ->
                        val sanitizedMinimum = sanitizeIntegerInput(minimum)
                        val sanitizedMaximum = sanitizeIntegerInput(maximum)
                        minimumTime = sanitizedMinimum
                        maximumTime = sanitizedMaximum
                        updateNumericCriteria(
                            nextMinimumTime = sanitizedMinimum,
                            nextMaximumTime = sanitizedMaximum,
                        )
                    },
                )
                OutlinedTextField(
                    value = maximumProximity,
                    onValueChange = {
                        val sanitized = sanitizeDecimalInput(it)
                        maximumProximity = sanitized
                        updateNumericCriteria(nextMaximumProximity = sanitized)
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .semantics { testTag = ROUTE_FILTER_PROXIMITY_TAG },
                    label = { Text(stringResource(R.string.route_filter_max_distance_from_you_km)) },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    singleLine = true,
                )
                Text(
                    stringResource(R.string.common_difficulty),
                    style = MaterialTheme.typography.labelLarge
                )
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Difficulty.entries.forEach { difficulty ->
                        ChoiceChip(
                            label = difficulty.label(),
                            selected = difficulty in criteria.difficulties,
                            onClick = { onDifficultyToggle(difficulty) },
                        )
                    }
                }
                Text(
                    stringResource(R.string.common_terrain),
                    style = MaterialTheme.typography.labelLarge
                )
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Terrain.entries.forEach { terrain ->
                        ChoiceChip(
                            label = terrain.label(),
                            selected = terrain in criteria.terrains,
                            onClick = { onTerrainToggle(terrain) },
                        )
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = onApply,
                enabled = !hasValidationError,
            ) {
                Text(stringResource(R.string.action_apply))
            }
        },
        dismissButton = {
            Row {
                TextButton(onClick = onClear) { Text(stringResource(R.string.action_clear)) }
                TextButton(onClick = onDismiss) { Text(stringResource(R.string.action_cancel)) }
            }
        },
    )
}

@Composable
private fun RangeFields(
    minimum: String,
    maximum: String,
    minimumTag: String,
    maximumTag: String,
    keyboardType: KeyboardType,
    isError: Boolean,
    errorMessage: String?,
    onChange: (String, String) -> Unit,
) {
    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(
                value = minimum,
                onValueChange = { onChange(it, maximum) },
                modifier = Modifier
                    .weight(1f)
                    .semantics { testTag = minimumTag },
                label = { Text(stringResource(R.string.common_min)) },
                keyboardOptions = KeyboardOptions(keyboardType = keyboardType),
                singleLine = true,
                isError = isError,
            )
            OutlinedTextField(
                value = maximum,
                onValueChange = { onChange(minimum, it) },
                modifier = Modifier
                    .weight(1f)
                    .semantics { testTag = maximumTag },
                label = { Text(stringResource(R.string.common_max)) },
                keyboardOptions = KeyboardOptions(keyboardType = keyboardType),
                singleLine = true,
                isError = isError,
            )
        }
        errorMessage?.let {
            Text(
                text = it,
                color = MaterialTheme.colorScheme.error,
                style = MaterialTheme.typography.bodySmall,
            )
        }
    }
}

private fun decimalRange(minimum: String, maximum: String): ClosedFloatingPointRange<Double>? {
    val min = minimum.toDoubleOrNull() ?: return null
    val max = maximum.toDoubleOrNull() ?: return null
    return min..max
}

private fun integerRange(minimum: String, maximum: String): IntRange? {
    val min = minimum.toIntOrNull() ?: return null
    val max = maximum.toIntOrNull() ?: return null
    return min..max
}

private fun decimalValue(value: String): Double? {
    return value.toDoubleOrNull()
}

private fun decimalRangeReversed(minimum: String, maximum: String): Boolean {
    val min = minimum.toDoubleOrNull() ?: return false
    val max = maximum.toDoubleOrNull() ?: return false
    return min > max
}

private fun integerRangeReversed(minimum: String, maximum: String): Boolean {
    val min = minimum.toIntOrNull() ?: return false
    val max = maximum.toIntOrNull() ?: return false
    return min > max
}

private fun sanitizeDecimalInput(input: String): String {
    val sanitized = buildString {
        var hasDecimalSeparator = false
        input.forEach { character ->
            when {
                character.isDigit() -> append(character)
                character == '.' && !hasDecimalSeparator -> {
                    append(character)
                    hasDecimalSeparator = true
                }
            }
        }
    }
    return if (sanitized == ".") "0." else sanitized
}

private fun sanitizeIntegerInput(input: String): String {
    return input.filter { it.isDigit() }
}

private const val ROUTE_FILTER_DISTANCE_MIN_TAG = "route-filter-distance-min"
private const val ROUTE_FILTER_DISTANCE_MAX_TAG = "route-filter-distance-max"
private const val ROUTE_FILTER_TIME_MIN_TAG = "route-filter-time-min"
private const val ROUTE_FILTER_TIME_MAX_TAG = "route-filter-time-max"
private const val ROUTE_FILTER_PROXIMITY_TAG = "route-filter-proximity"
