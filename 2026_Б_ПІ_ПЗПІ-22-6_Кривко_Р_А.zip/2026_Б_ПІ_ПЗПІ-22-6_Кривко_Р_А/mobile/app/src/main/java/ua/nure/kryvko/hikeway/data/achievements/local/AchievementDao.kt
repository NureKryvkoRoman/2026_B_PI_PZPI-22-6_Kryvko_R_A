package ua.nure.kryvko.hikeway.data.achievements.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface AchievementDao {
    @Query("SELECT * FROM achievements WHERE ownerUserId = :ownerUserId")
    fun observeAll(ownerUserId: String): Flow<List<AchievementEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(achievement: AchievementEntity): Long

    @Query("SELECT * FROM achievements WHERE ownerUserId = :ownerUserId AND code = :code LIMIT 1")
    suspend fun findByCode(ownerUserId: String, code: String): AchievementEntity?
}
