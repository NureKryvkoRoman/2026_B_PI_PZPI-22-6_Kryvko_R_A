package ua.nure.kryvko.hikeway.feature.routesearch

import androidx.activity.compose.BackHandler
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.Orientation
import androidx.compose.foundation.gestures.draggable
import androidx.compose.foundation.gestures.rememberDraggableState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.WindowInsetsSides
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.only
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Done
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.semantics.stateDescription
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.IntOffset
import ua.nure.kryvko.hikeway.R
import kotlinx.coroutines.launch
import kotlin.math.roundToInt
import ua.nure.kryvko.hikeway.core.model.Route
import ua.nure.kryvko.hikeway.core.model.RouteVisibility
import ua.nure.kryvko.hikeway.domain.offlinemaps.RouteMapDownload
import ua.nure.kryvko.hikeway.domain.offlinemaps.RouteMapDownloadEstimate
import ua.nure.kryvko.hikeway.domain.offlinemaps.RouteMapDownloadStatus
import ua.nure.kryvko.hikeway.domain.offlinemaps.formatBytesRange
import ua.nure.kryvko.hikeway.feature.pois.GenericRatingRow
import ua.nure.kryvko.hikeway.ui.map.PathMap
import java.util.Locale

@Composable
fun RouteOverviewScreen(
    route: Route,
    isSaved: Boolean,
    currentUserId: String,
    mapDownload: RouteMapDownload?,
    pendingMapEstimate: RouteMapDownloadEstimate?,
    isStartingMapDownload: Boolean,
    isRouteActionInProgress: Boolean = false,
    routeActionErrorMessage: String? = null,
    routeContentErrorMessage: String? = null,
    isRouteContentActionInProgress: Boolean = false,
    onBack: () -> Unit,
    onToggleSaved: () -> Unit,
    onRateRoute: (Int) -> Unit = {},
    onRemoveRouteRating: () -> Unit = {},
    onViewComments: () -> Unit = {},
    onPublishRoute: () -> Unit = {},
    onDeleteRoute: () -> Unit = {},
    onStartRoute: () -> Unit,
    onPlanTrip: () -> Unit,
    onSaveMap: () -> Unit,
    onConfirmSaveMap: () -> Unit,
    onDismissSaveMapEstimate: () -> Unit,
) {
    BackHandler(onBack = onBack)
    var isDeleteConfirmationVisible by remember(route.id) { mutableStateOf(false) }
    val isCreator = route.createdBy == currentUserId && currentUserId.isNotBlank()
    val canPublish = isCreator && route.visibility == RouteVisibility.PRIVATE

    if (isDeleteConfirmationVisible) {
        AlertDialog(
            onDismissRequest = { isDeleteConfirmationVisible = false },
            title = { Text(stringResource(R.string.route_delete_confirmation_title)) },
            text = { Text(stringResource(R.string.route_delete_confirmation_message)) },
            confirmButton = {
                Button(
                    onClick = {
                        isDeleteConfirmationVisible = false
                        onDeleteRoute()
                    },
                    enabled = !isRouteActionInProgress,
                ) {
                    Text(stringResource(R.string.action_delete))
                }
            },
            dismissButton = {
                TextButton(onClick = { isDeleteConfirmationVisible = false }) {
                    Text(stringResource(R.string.action_cancel))
                }
            },
        )
    }
    if (pendingMapEstimate != null) {
        AlertDialog(
            onDismissRequest = onDismissSaveMapEstimate,
            title = { Text(stringResource(R.string.offline_save_map)) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(route.name)
                    Text(
                        stringResource(
                            R.string.format_estimated_size,
                            pendingMapEstimate.minBytes.formatBytesRange(pendingMapEstimate.maxBytes),
                        )
                    )
                    Text(
                        stringResource(
                            R.string.format_zoom_levels,
                            pendingMapEstimate.minZoom.toInt(),
                            pendingMapEstimate.maxZoom.toInt(),
                        )
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = onConfirmSaveMap,
                    enabled = !isStartingMapDownload,
                ) {
                    Text(
                        if (isStartingMapDownload) {
                            stringResource(R.string.action_starting)
                        } else {
                            stringResource(R.string.action_download)
                        }
                    )
                }
            },
            dismissButton = {
                TextButton(onClick = onDismissSaveMapEstimate) {
                    Text(stringResource(R.string.action_cancel))
                }
            },
        )
    }

    BoxWithConstraints(
        modifier = Modifier
            .fillMaxSize()
            .windowInsetsPadding(
                WindowInsets.safeDrawing.only(
                    WindowInsetsSides.Top + WindowInsetsSides.Horizontal
                )
            )
    ) {
        val density = LocalDensity.current
        val scope = rememberCoroutineScope()
        val collapsedHeightPx = with(density) { 300.dp.toPx() }
        val maxHeightPx = with(density) { maxHeight.toPx() }
        val collapsedOffsetPx = (maxHeightPx - collapsedHeightPx).coerceAtLeast(0f)
        var sheetOffsetPx by remember { mutableFloatStateOf(collapsedOffsetPx) }
        val isExpanded = sheetOffsetPx <= collapsedOffsetPx / 2f

        LaunchedEffect(collapsedOffsetPx) {
            sheetOffsetPx = sheetOffsetPx.coerceIn(0f, collapsedOffsetPx)
        }

        fun settleSheet(velocity: Float = 0f) {
            val target = when {
                velocity < -300f -> 0f
                velocity > 300f -> collapsedOffsetPx
                sheetOffsetPx < collapsedOffsetPx / 2f -> 0f
                else -> collapsedOffsetPx
            }
            scope.launch {
                val animation = Animatable(sheetOffsetPx)
                animation.animateTo(
                    targetValue = target,
                    animationSpec = tween(durationMillis = 220),
                ) {
                    sheetOffsetPx = value
                }
            }
        }

        PathMap(
            path = route.geometry.points,
            pathColor = MaterialTheme.colorScheme.primary,
            modifier = Modifier.fillMaxSize(),
        )

        Surface(
            modifier = Modifier
                .fillMaxSize()
                .offset { IntOffset(x = 0, y = sheetOffsetPx.roundToInt()) },
            shape = RoundedCornerShape(topStart = 8.dp, topEnd = 8.dp),
            tonalElevation = 4.dp,
            shadowElevation = 8.dp,
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    IconButton(onClick = onBack) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = stringResource(R.string.action_back),
                        )
                    }
                    val dragHandleDescription = stringResource(R.string.cd_route_info_drag_handle)
                    val expandedDescription = stringResource(R.string.state_expanded)
                    val collapsedDescription = stringResource(R.string.state_collapsed)
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .height(48.dp)
                            .draggable(
                                orientation = Orientation.Vertical,
                                state = rememberDraggableState { delta ->
                                    sheetOffsetPx = (sheetOffsetPx + delta)
                                        .coerceIn(0f, collapsedOffsetPx)
                                },
                                onDragStopped = { velocity -> settleSheet(velocity) },
                            )
                            .semantics {
                                contentDescription = dragHandleDescription
                                stateDescription = if (isExpanded) expandedDescription else collapsedDescription
                            },
                        contentAlignment = Alignment.Center,
                    ) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth(0.18f)
                                .height(4.dp)
                                .background(
                                    color = MaterialTheme.colorScheme.outline,
                                    shape = RoundedCornerShape(percent = 50),
                                )
                        )
                    }
                    IconButton(onClick = onToggleSaved) {
                        Icon(
                            painter = painterResource(
                                if (isSaved) {
                                    R.drawable.ic_nav_saved
                                } else {
                                    R.drawable.ic_nav_saved_inactive
                                }
                            ),
                            contentDescription = if (isSaved) {
                                stringResource(R.string.cd_remove_saved_route)
                            } else {
                                stringResource(R.string.cd_save_route_for_later)
                            },
                            tint = if (isSaved) {
                                MaterialTheme.colorScheme.primary
                            } else {
                                MaterialTheme.colorScheme.outline
                            },
                        )
                    }
                    if (canPublish) {
                        IconButton(
                            onClick = onPublishRoute,
                            enabled = !isRouteActionInProgress,
                        ) {
                            Icon(
                                imageVector = Icons.Default.Done,
                                contentDescription = stringResource(R.string.cd_publish_route),
                            )
                        }
                    }
                    if (isCreator) {
                        IconButton(
                            onClick = { isDeleteConfirmationVisible = true },
                            enabled = !isRouteActionInProgress,
                        ) {
                            Icon(
                                imageVector = Icons.Default.Delete,
                                contentDescription = stringResource(R.string.cd_delete_route),
                            )
                        }
                    }
                }
                Column(
                    modifier = Modifier.padding(start = 16.dp, end = 16.dp, bottom = 16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                ) {
                    Text(stringResource(R.string.route_overview_title), style = MaterialTheme.typography.labelLarge)
                    Text(route.name, style = MaterialTheme.typography.headlineSmall)
                    Text(route.description, style = MaterialTheme.typography.bodyMedium)
                    routeActionErrorMessage?.let {
                        Text(it, color = MaterialTheme.colorScheme.error)
                    }
                    routeContentErrorMessage?.let {
                        Text(it, color = MaterialTheme.colorScheme.error)
                    }
                    GenericRatingRow(
                        averageRating = route.averageRating,
                        ratingCount = route.ratingCount,
                        userRating = route.userRating,
                        onRate = onRateRoute,
                        onRemoveRating = route.userRating?.let { { onRemoveRouteRating() } },
                    )
                    RouteInfoRow(stringResource(R.string.common_distance), "${"%.2f".format(Locale.US, route.distanceKm)} km")
                    RouteInfoRow(stringResource(R.string.common_estimated_time), "${route.estimatedTimeMinutes} min")
                    RouteInfoRow(stringResource(R.string.common_elevation_gain), "${route.elevationGainMeters} m")
                    RouteInfoRow(stringResource(R.string.common_difficulty), route.difficulty.label())
                    RouteInfoRow(stringResource(R.string.common_terrain), route.terrain.label())
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                    ) {
                        Button(
                            onClick = onStartRoute,
                            modifier = Modifier.weight(1f),
                        ) {
                            Text(stringResource(R.string.hike_plan_start_route))
                        }
                        Button(
                            onClick = onPlanTrip,
                            modifier = Modifier.weight(1f),
                        ) {
                            Text(stringResource(R.string.route_overview_plan_trip))
                        }
                    }
                    OutlinedButton(
                        onClick = onSaveMap,
                        enabled = mapDownload?.status !in setOf(
                            RouteMapDownloadStatus.PENDING,
                            RouteMapDownloadStatus.DOWNLOADING,
                            RouteMapDownloadStatus.READY,
                        ),
                        modifier = Modifier.fillMaxWidth(),
                    ) {
                        Text(mapDownload.saveMapButtonText())
                    }
                    OutlinedButton(
                        onClick = onViewComments,
                        enabled = !isRouteContentActionInProgress,
                        modifier = Modifier.fillMaxWidth(),
                    ) {
                        Text(
                            if (route.comments.isEmpty()) {
                                stringResource(R.string.route_view_comments)
                            } else {
                                stringResource(R.string.route_view_comments_count, route.comments.size)
                            }
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun RouteMapDownload?.saveMapButtonText(): String {
    return when (this?.status) {
        RouteMapDownloadStatus.PENDING -> stringResource(R.string.offline_preparing_map)
        RouteMapDownloadStatus.DOWNLOADING -> progressFraction?.let { progress ->
            stringResource(R.string.format_downloading_map, (progress * 100).roundToInt())
        } ?: stringResource(R.string.offline_downloading_map)
        RouteMapDownloadStatus.READY -> stringResource(R.string.offline_map_saved)
        RouteMapDownloadStatus.FAILED -> stringResource(R.string.offline_retry_map_download)
        null -> stringResource(R.string.offline_save_map)
    }
}

@Composable
fun RouteInfoRow(label: String, value: String) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
    ) {
        Text(label, style = MaterialTheme.typography.bodySmall)
        Text(value, style = MaterialTheme.typography.bodyMedium)
    }
}
