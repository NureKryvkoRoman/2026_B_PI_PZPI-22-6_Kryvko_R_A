package ua.nure.kryvko.hikeway.feature.saved

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import ua.nure.kryvko.hikeway.core.model.Route
import ua.nure.kryvko.hikeway.domain.offlinemaps.DeleteRouteMapDownloadUseCase
import ua.nure.kryvko.hikeway.domain.offlinemaps.EstimateRouteMapDownloadUseCase
import ua.nure.kryvko.hikeway.domain.offlinemaps.ObserveRouteMapDownloadUseCase
import ua.nure.kryvko.hikeway.domain.offlinemaps.ObserveRouteMapDownloadsUseCase
import ua.nure.kryvko.hikeway.domain.offlinemaps.RefreshRouteMapDownloadsUseCase
import ua.nure.kryvko.hikeway.domain.offlinemaps.RouteMapDownload
import ua.nure.kryvko.hikeway.domain.offlinemaps.RouteMapDownloadEstimate
import ua.nure.kryvko.hikeway.domain.offlinemaps.RouteMapDownloadStatus
import ua.nure.kryvko.hikeway.domain.offlinemaps.StartRouteMapDownloadUseCase
import javax.inject.Inject

data class SavedMapsUiState(
    val downloads: List<RouteMapDownload> = emptyList(),
    val routeDownload: RouteMapDownload? = null,
    val pendingRoute: Route? = null,
    val pendingEstimate: RouteMapDownloadEstimate? = null,
    val isLoading: Boolean = true,
    val isStarting: Boolean = false,
    val deletingIds: Set<Long> = emptySet(),
    val errorMessage: String? = null,
)

@HiltViewModel
class SavedMapsViewModel @Inject constructor(
    private val observeDownloads: ObserveRouteMapDownloadsUseCase,
    private val observeDownload: ObserveRouteMapDownloadUseCase,
    private val estimateDownload: EstimateRouteMapDownloadUseCase,
    private val startDownload: StartRouteMapDownloadUseCase,
    private val deleteDownload: DeleteRouteMapDownloadUseCase,
    private val refreshDownloads: RefreshRouteMapDownloadsUseCase,
) : ViewModel() {
    private val _uiState = MutableStateFlow(SavedMapsUiState())
    val uiState: StateFlow<SavedMapsUiState> = _uiState.asStateFlow()
    private var routeDownloadJob: Job? = null

    init {
        viewModelScope.launch {
            observeDownloads().collect { downloads ->
                _uiState.update {
                    it.copy(downloads = downloads, isLoading = false)
                }
            }
        }
        refresh()
    }

    fun observeRoute(route: Route) {
        routeDownloadJob?.cancel()
        routeDownloadJob = viewModelScope.launch {
            observeDownload(route).collect { download ->
                _uiState.update { it.copy(routeDownload = download) }
            }
        }
    }

    fun refresh() {
        viewModelScope.launch {
            runCatching { refreshDownloads() }
                .onFailure { error ->
                    _uiState.update {
                        it.copy(errorMessage = error.message ?: "Could not refresh saved maps.")
                    }
                }
        }
    }

    fun prepareDownload(route: Route) {
        val existing = _uiState.value.routeDownload
        if (existing?.status == RouteMapDownloadStatus.DOWNLOADING ||
            existing?.status == RouteMapDownloadStatus.PENDING ||
            existing?.status == RouteMapDownloadStatus.READY
        ) {
            return
        }
        _uiState.update {
            it.copy(
                pendingRoute = route,
                pendingEstimate = estimateDownload(route),
                errorMessage = null,
            )
        }
    }

    fun dismissEstimate() {
        _uiState.update { it.copy(pendingRoute = null, pendingEstimate = null) }
    }

    fun confirmDownload() {
        val route = _uiState.value.pendingRoute ?: return
        viewModelScope.launch {
            _uiState.update {
                it.copy(isStarting = true, pendingRoute = null, pendingEstimate = null, errorMessage = null)
            }
            runCatching { startDownload(route) }
                .onFailure { error ->
                    _uiState.update {
                        it.copy(errorMessage = error.message ?: "Could not start map download.")
                    }
                }
            _uiState.update { it.copy(isStarting = false) }
        }
    }

    fun delete(download: RouteMapDownload) {
        viewModelScope.launch {
            _uiState.update { it.copy(deletingIds = it.deletingIds + download.id, errorMessage = null) }
            runCatching { deleteDownload(download) }
                .onFailure { error ->
                    _uiState.update {
                        it.copy(errorMessage = error.message ?: "Could not delete saved map.")
                    }
                }
            _uiState.update { it.copy(deletingIds = it.deletingIds - download.id) }
        }
    }
}
