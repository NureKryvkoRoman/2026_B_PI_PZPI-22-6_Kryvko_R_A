package ua.nure.kryvko.hikeway.data.safety.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface EmergencyContactDao {
    @Query("SELECT * FROM emergency_contacts WHERE ownerUserId = :ownerUserId LIMIT 1")
    fun observePrimary(ownerUserId: String): Flow<EmergencyContactEntity?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(contact: EmergencyContactEntity): Long

    @Query("DELETE FROM emergency_contacts WHERE ownerUserId = :ownerUserId")
    suspend fun deletePrimary(ownerUserId: String)
}
