package ua.nure.kryvko.hikeway.domain.search

import javax.inject.Inject
import ua.nure.kryvko.hikeway.core.model.PointOfInterest
import ua.nure.kryvko.hikeway.core.model.Route

data class SearchResults(
    val routes: List<Route>,
    val pointsOfInterest: List<PointOfInterest>,
)

interface SearchRepository {
    suspend fun search(name: String): SearchResults
}

class SearchHikeContentUseCase @Inject constructor(
    private val repository: SearchRepository,
) {
    suspend operator fun invoke(query: String): SearchResults {
        val trimmed = query.trim()
        require(trimmed.isNotEmpty()) { "Search query is required." }
        return repository.search(trimmed)
    }
}
