package ua.nure.kryvko.hikeway.feature.navigation

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import ua.nure.kryvko.hikeway.R
import ua.nure.kryvko.hikeway.domain.routepicking.RoutePickingSession
import ua.nure.kryvko.hikeway.domain.routepicking.RoutePickingStatus
import ua.nure.kryvko.hikeway.feature.routesearch.formatDistance
import ua.nure.kryvko.hikeway.feature.routesearch.formatDuration

@Composable
fun TrackingStatusOverlay(
    session: RoutePickingSession,
    saveErrorMessage: String?,
    onPause: () -> Unit,
    onUnpause: () -> Unit,
    onFinish: () -> Unit,
    modifier: Modifier = Modifier,
) {
    Surface(
        modifier = modifier.widthIn(min = 220.dp, max = 320.dp),
        shape = MaterialTheme.shapes.medium,
        tonalElevation = 8.dp,
        shadowElevation = 4.dp,
    ) {
        Column(
            modifier = Modifier.padding(12.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            Text(
                session.activeElapsedMillis.formatDuration(),
                style = MaterialTheme.typography.titleLarge,
            )
            Text(
                stringResource(R.string.format_walked_distance, session.walkedDistanceKm.formatDistance()),
                style = MaterialTheme.typography.bodyMedium,
            )
            if (saveErrorMessage != null) {
                Text(
                    saveErrorMessage,
                    color = MaterialTheme.colorScheme.error,
                    style = MaterialTheme.typography.bodySmall,
                )
            }
            Row(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                when (session.status) {
                    RoutePickingStatus.ACTIVE -> {
                        IconButton(
                            onClick = onPause,
                            modifier = Modifier,
                        ) {
                            Icon(
                                painter = painterResource(R.drawable.ic_pause_24),
                                contentDescription = stringResource(R.string.cd_pause_tracking),
                            )
                        }
                    }

                    RoutePickingStatus.PAUSED -> {
                        IconButton(
                            onClick = onUnpause,
                            modifier = Modifier,
                        ) {
                            Icon(
                                imageVector = Icons.Default.PlayArrow,
                                contentDescription = stringResource(R.string.cd_resume_tracking),
                            )
                        }
                        IconButton(
                            onClick = onFinish,
                            modifier = Modifier,
                        ) {
                            Icon(
                                painter = painterResource(R.drawable.ic_stop_24),
                                contentDescription = stringResource(R.string.cd_stop_tracking),
                                tint = MaterialTheme.colorScheme.error,
                            )
                        }
                    }
                }
            }
        }
    }
}
