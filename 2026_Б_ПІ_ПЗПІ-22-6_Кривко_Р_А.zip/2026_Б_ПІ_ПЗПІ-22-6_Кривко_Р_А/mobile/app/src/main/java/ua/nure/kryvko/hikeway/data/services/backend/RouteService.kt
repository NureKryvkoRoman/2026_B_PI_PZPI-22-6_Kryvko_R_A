package ua.nure.kryvko.hikeway.data.services.backend

import retrofit2.http.GET
import retrofit2.http.DELETE
import retrofit2.http.Body
import retrofit2.http.PATCH
import retrofit2.http.POST
import retrofit2.http.PUT
import retrofit2.http.Path
import retrofit2.http.Query
import ua.nure.kryvko.hikeway.data.routes.remote.GeoJsonLineStringDto
import ua.nure.kryvko.hikeway.data.routes.remote.RouteDetailDto
import ua.nure.kryvko.hikeway.data.routes.remote.RouteCommentDto
import ua.nure.kryvko.hikeway.data.routes.remote.RouteCommentRequestDto
import ua.nure.kryvko.hikeway.data.routes.remote.RouteRatingDto
import ua.nure.kryvko.hikeway.data.routes.remote.RouteRatingRequestDto
import ua.nure.kryvko.hikeway.data.routes.remote.RouteSummaryDto
import ua.nure.kryvko.hikeway.data.routes.remote.PageResponseDto

interface RouteService {
    @GET("route/{id}")
    suspend fun getRoute(
        @Path("id") id: Long,
    ): RouteDetailDto

    @GET("route/{id}/geometry")
    suspend fun getRouteGeometry(
        @Path("id") id: Long,
    ): GeoJsonLineStringDto

    @GET("routes")
    suspend fun search(
        @Query("minDistanceKm") minDistanceKm: Double? = null,
        @Query("maxDistanceKm") maxDistanceKm: Double? = null,
        @Query("minEstimatedTimeMinutes") minEstimatedTimeMinutes: Int? = null,
        @Query("maxEstimatedTimeMinutes") maxEstimatedTimeMinutes: Int? = null,
        @Query("difficulties") difficulties: List<String>? = null,
        @Query("terrains") terrains: List<String>? = null,
        @Query("longitude") longitude: Double? = null,
        @Query("latitude") latitude: Double? = null,
        @Query("maxProximityKm") maxProximityKm: Double? = null,
        @Query("page") page: Int = 0,
        @Query("size") size: Int = 50,
    ): PageResponseDto<RouteSummaryDto>

    @GET("routes/mine")
    suspend fun currentUserRoutes(
        @Query("page") page: Int = 0,
        @Query("size") size: Int = 100,
    ): PageResponseDto<RouteSummaryDto>

    @GET("routes/recommended")
    suspend fun recommendedRoutes(
        @Query("longitude") longitude: Double? = null,
        @Query("latitude") latitude: Double? = null,
        @Query("maxProximityKm") maxProximityKm: Double? = null,
        @Query("page") page: Int = 0,
        @Query("size") size: Int = 10,
    ): PageResponseDto<RouteSummaryDto>

    @PUT("routes/{id}/rating")
    suspend fun rate(
        @Path("id") id: Long,
        @Body request: RouteRatingRequestDto,
    ): RouteRatingDto

    @DELETE("routes/{id}/rating")
    suspend fun removeRating(@Path("id") id: Long): RouteRatingDto

    @GET("routes/{id}/comments")
    suspend fun comments(
        @Path("id") id: Long,
        @Query("page") page: Int = 0,
        @Query("size") size: Int = 50,
    ): PageResponseDto<RouteCommentDto>

    @POST("routes/{id}/comments")
    suspend fun addComment(
        @Path("id") id: Long,
        @Body request: RouteCommentRequestDto,
    ): RouteCommentDto

    @PATCH("routes/{id}/comments/{commentId}")
    suspend fun updateComment(
        @Path("id") id: Long,
        @Path("commentId") commentId: Long,
        @Body request: RouteCommentRequestDto,
    ): RouteCommentDto

    @DELETE("routes/{id}/comments/{commentId}")
    suspend fun deleteComment(
        @Path("id") id: Long,
        @Path("commentId") commentId: Long,
    )
}
