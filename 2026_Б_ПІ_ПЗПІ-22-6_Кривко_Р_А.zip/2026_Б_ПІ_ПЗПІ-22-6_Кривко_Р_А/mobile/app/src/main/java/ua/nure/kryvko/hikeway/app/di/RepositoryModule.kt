package ua.nure.kryvko.hikeway.app.di

import com.google.gson.Gson
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton
import ua.nure.kryvko.hikeway.BuildConfig
import ua.nure.kryvko.hikeway.data.achievements.local.AchievementDao
import ua.nure.kryvko.hikeway.data.achievements.local.RoomAchievementRepository
import ua.nure.kryvko.hikeway.data.auth.AuthSessionFactory
import ua.nure.kryvko.hikeway.data.auth.AuthSessionManager
import ua.nure.kryvko.hikeway.data.auth.DefaultAuthRepository
import ua.nure.kryvko.hikeway.data.hikelogging.local.HikeLogDao
import ua.nure.kryvko.hikeway.data.hikelogging.local.RoomHikeLogRepository
import ua.nure.kryvko.hikeway.data.hikeplans.local.HikePlanDao
import ua.nure.kryvko.hikeway.data.hikeplans.local.RoomHikePlanRepository
import ua.nure.kryvko.hikeway.data.hikeplans.reminders.WorkManagerHikePlanReminderScheduler
import ua.nure.kryvko.hikeway.data.offlinemaps.MapLibreRouteMapDownloadRepository
import ua.nure.kryvko.hikeway.data.pois.remote.RemotePointOfInterestRepository
import ua.nure.kryvko.hikeway.data.profile.remote.RemoteProfileRepository
import ua.nure.kryvko.hikeway.data.routepicking.local.ActiveRouteTrackingSessionDao
import ua.nure.kryvko.hikeway.data.routepicking.local.RoomActiveRouteTrackingSessionRepository
import ua.nure.kryvko.hikeway.data.safety.local.EmergencyContactDao
import ua.nure.kryvko.hikeway.data.safety.local.RoomEmergencyContactRepository
import ua.nure.kryvko.hikeway.data.savedroutes.local.RoomSavedRouteRepository
import ua.nure.kryvko.hikeway.data.savedroutes.local.SavedRouteDao
import ua.nure.kryvko.hikeway.data.routes.CompositeRouteDetailRepository
import ua.nure.kryvko.hikeway.data.routes.CompositeRouteRepository
import ua.nure.kryvko.hikeway.data.routes.UserCreatedRouteRepository
import ua.nure.kryvko.hikeway.data.routes.local.RoomRouteRepository
import ua.nure.kryvko.hikeway.data.routes.local.RouteDao
import ua.nure.kryvko.hikeway.data.routes.remote.RemoteRouteRepository
import ua.nure.kryvko.hikeway.data.search.remote.RemoteSearchRepository
import ua.nure.kryvko.hikeway.data.services.backend.BackendAuthService
import ua.nure.kryvko.hikeway.data.services.backend.PoiService
import ua.nure.kryvko.hikeway.data.services.backend.ProfileService
import ua.nure.kryvko.hikeway.data.services.backend.RouteService
import ua.nure.kryvko.hikeway.data.services.backend.SearchService
import ua.nure.kryvko.hikeway.data.services.backend.SyncService
import ua.nure.kryvko.hikeway.data.services.backend.WeatherService
import ua.nure.kryvko.hikeway.data.services.keycloak.KeycloakService
import ua.nure.kryvko.hikeway.data.services.network.TokenRefreshCoordinator
import ua.nure.kryvko.hikeway.data.sync.SyncTrigger
import ua.nure.kryvko.hikeway.data.weather.remote.RemoteWeatherRepository
import ua.nure.kryvko.hikeway.domain.auth.AuthRepository
import ua.nure.kryvko.hikeway.domain.auth.CurrentUserProvider
import ua.nure.kryvko.hikeway.domain.achievements.AchievementRepository
import ua.nure.kryvko.hikeway.domain.hikelogging.HikeLogRepository
import ua.nure.kryvko.hikeway.domain.hikeplans.HikePlanRepository
import ua.nure.kryvko.hikeway.domain.hikeplans.HikePlanReminderScheduler
import ua.nure.kryvko.hikeway.domain.offlinemaps.RouteMapDownloadRepository
import ua.nure.kryvko.hikeway.domain.pois.PointOfInterestRepository
import ua.nure.kryvko.hikeway.domain.profile.ProfileRepository
import ua.nure.kryvko.hikeway.domain.routepicking.ActiveRouteTrackingSessionRepository
import ua.nure.kryvko.hikeway.domain.routes.CustomRouteRepository
import ua.nure.kryvko.hikeway.domain.routes.RecommendedRouteRepository
import ua.nure.kryvko.hikeway.domain.routes.RouteContentRepository
import ua.nure.kryvko.hikeway.domain.routes.RouteDetailRepository
import ua.nure.kryvko.hikeway.domain.routes.RouteRepository
import ua.nure.kryvko.hikeway.domain.safety.EmergencyContactRepository
import ua.nure.kryvko.hikeway.domain.savedroutes.SavedRouteRepository
import ua.nure.kryvko.hikeway.domain.search.SearchRepository
import ua.nure.kryvko.hikeway.domain.weather.WeatherRepository

@Module
@InstallIn(SingletonComponent::class)
object RepositoryModule {
    @Provides
    @Singleton
    fun provideAuthRepository(
        keycloakService: KeycloakService,
        backendAuthService: BackendAuthService,
        sessionManager: AuthSessionManager,
        sessionFactory: AuthSessionFactory,
        refreshCoordinator: TokenRefreshCoordinator,
        gson: Gson,
        syncTrigger: SyncTrigger,
    ): AuthRepository {
        return DefaultAuthRepository(
            keycloakService = keycloakService,
            backendAuthService = backendAuthService,
            keycloakRealm = BuildConfig.KEYCLOAK_REALM,
            keycloakClientId = BuildConfig.KEYCLOAK_CLIENT_ID,
            sessionManager = sessionManager,
            sessionFactory = sessionFactory,
            refreshCoordinator = refreshCoordinator,
            gson = gson,
            onAuthenticated = syncTrigger::invoke,
        )
    }

    @Provides
    @Singleton
    fun provideLocalRouteRepository(
        routeDao: RouteDao,
        currentUserProvider: CurrentUserProvider,
        syncService: SyncService,
        syncTrigger: SyncTrigger,
    ): RoomRouteRepository {
        return RoomRouteRepository(
            dao = routeDao,
            currentUserProvider = currentUserProvider,
            syncService = syncService,
            syncTrigger = syncTrigger,
            onLocalMutation = syncTrigger::invoke,
        )
    }

    @Provides
    @Singleton
    fun provideCustomRouteRepository(
        localRepository: RoomRouteRepository,
        remoteRepository: RemoteRouteRepository,
    ): CustomRouteRepository {
        return UserCreatedRouteRepository(localRepository, remoteRepository)
    }

    @Provides
    @Singleton
    fun provideRemoteRouteRepository(
        routeService: RouteService,
        gson: Gson,
    ): RemoteRouteRepository = RemoteRouteRepository(routeService, gson)

    @Provides
    @Singleton
    fun provideRouteRepository(
        remoteRepository: RemoteRouteRepository,
        localRepository: RoomRouteRepository,
    ): RouteRepository {
        return CompositeRouteRepository(listOf(remoteRepository, localRepository))
    }

    @Provides
    @Singleton
    fun provideRouteDetailRepository(
        localRepository: RoomRouteRepository,
        remoteRepository: RemoteRouteRepository,
    ): RouteDetailRepository {
        return CompositeRouteDetailRepository(listOf(localRepository, remoteRepository))
    }

    @Provides
    @Singleton
    fun provideRecommendedRouteRepository(
        remoteRepository: RemoteRouteRepository,
    ): RecommendedRouteRepository = remoteRepository

    @Provides
    @Singleton
    fun provideRouteContentRepository(
        remoteRepository: RemoteRouteRepository,
    ): RouteContentRepository = remoteRepository

    @Provides
    @Singleton
    fun providePointOfInterestRepository(
        poiService: PoiService,
        gson: Gson,
    ): PointOfInterestRepository = RemotePointOfInterestRepository(poiService, gson)

    @Provides
    @Singleton
    fun provideSearchRepository(
        searchService: SearchService,
        gson: Gson,
    ): SearchRepository = RemoteSearchRepository(searchService, gson)

    @Provides
    @Singleton
    fun provideHikeLogRepository(
        hikeLogDao: HikeLogDao,
        routeDao: RouteDao,
        currentUserProvider: CurrentUserProvider,
        syncTrigger: SyncTrigger,
    ): HikeLogRepository {
        return RoomHikeLogRepository(
            dao = hikeLogDao,
            currentUserProvider = currentUserProvider,
            onLocalMutation = syncTrigger::invoke,
            routeDao = routeDao,
        )
    }

    @Provides
    @Singleton
    fun provideSavedRouteRepository(
        savedRouteDao: SavedRouteDao,
        currentUserProvider: CurrentUserProvider,
    ): SavedRouteRepository {
        return RoomSavedRouteRepository(
            dao = savedRouteDao,
            currentUserProvider = currentUserProvider,
        )
    }

    @Provides
    @Singleton
    fun provideEmergencyContactRepository(
        emergencyContactDao: EmergencyContactDao,
        currentUserProvider: CurrentUserProvider,
    ): EmergencyContactRepository {
        return RoomEmergencyContactRepository(
            dao = emergencyContactDao,
            currentUserProvider = currentUserProvider,
        )
    }

    @Provides
    @Singleton
    fun provideActiveRouteTrackingSessionRepository(
        dao: ActiveRouteTrackingSessionDao,
        currentUserProvider: CurrentUserProvider,
    ): ActiveRouteTrackingSessionRepository {
        return RoomActiveRouteTrackingSessionRepository(
            dao = dao,
            currentUserProvider = currentUserProvider,
        )
    }

    @Provides
    @Singleton
    fun provideHikePlanRepository(
        hikePlanDao: HikePlanDao,
        currentUserProvider: CurrentUserProvider,
        gson: Gson,
    ): HikePlanRepository {
        return RoomHikePlanRepository(
            dao = hikePlanDao,
            currentUserProvider = currentUserProvider,
            gson = gson,
        )
    }

    @Provides
    @Singleton
    fun provideRouteMapDownloadRepository(
        repository: MapLibreRouteMapDownloadRepository,
    ): RouteMapDownloadRepository = repository

    @Provides
    @Singleton
    fun provideHikePlanReminderScheduler(
        scheduler: WorkManagerHikePlanReminderScheduler,
    ): HikePlanReminderScheduler = scheduler

    @Provides
    @Singleton
    fun provideWeatherRepository(
        weatherService: WeatherService,
        gson: Gson,
    ): WeatherRepository = RemoteWeatherRepository(weatherService, gson)

    @Provides
    @Singleton
    fun provideProfileRepository(
        profileService: ProfileService,
        gson: Gson,
    ): ProfileRepository = RemoteProfileRepository(profileService, gson)

    @Provides
    @Singleton
    fun provideAchievementRepository(
        achievementDao: AchievementDao,
        hikeLogDao: HikeLogDao,
        routeDao: RouteDao,
        currentUserProvider: CurrentUserProvider,
    ): AchievementRepository {
        return RoomAchievementRepository(
            achievementDao = achievementDao,
            hikeLogDao = hikeLogDao,
            routeDao = routeDao,
            currentUserProvider = currentUserProvider,
        )
    }
}
