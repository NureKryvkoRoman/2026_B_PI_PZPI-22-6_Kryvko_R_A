package ua.nure.kryvko.hikeway.domain.hikeplans

import java.time.Instant
import java.time.LocalDate
import java.time.LocalTime
import java.time.ZoneId
import kotlin.math.acos
import kotlin.math.asin
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.sin
import kotlin.math.tan
import ua.nure.kryvko.hikeway.core.model.GeoPoint
import ua.nure.kryvko.hikeway.core.model.Route
import ua.nure.kryvko.hikeway.domain.hikelogging.TimeProvider

data class PlannerWeatherSummary(
    val condition: String,
    val temperatureCelsius: Int,
    val precipitationRiskPercent: Int,
    val warning: String? = null,
)

data class DaylightSummary(
    val sunrise: LocalTime,
    val sunset: LocalTime,
)

data class RecommendedStartTime(
    val time: LocalTime?,
    val warning: RecommendedStartWarning?,
)

sealed interface RecommendedStartWarning {
    data class Weather(val detail: String) : RecommendedStartWarning
    data object RouteDoesNotFitBeforeSunset : RecommendedStartWarning
}

class DaylightCalculator {
    fun daylightFor(route: Route, date: LocalDate): DaylightSummary {
        val point = route.geometry.points.firstOrNull() ?: GeoPoint(longitude = 0.0, latitude = 0.0)
        val sunriseHour = calculateUtcHour(date, point.latitude, point.longitude, sunrise = true)
            ?.let { normalizeLocalHour(it) }
            ?: 6.0
        val sunsetHour = calculateUtcHour(date, point.latitude, point.longitude, sunrise = false)
            ?.let { normalizeLocalHour(it) }
            ?: 18.0
        return DaylightSummary(
            sunrise = hourToLocalTime(sunriseHour),
            sunset = hourToLocalTime(sunsetHour),
        )
    }

    private fun calculateUtcHour(
        date: LocalDate,
        latitude: Double,
        longitude: Double,
        sunrise: Boolean,
    ): Double? {
        val day = date.dayOfYear.toDouble()
        val lngHour = longitude / 15.0
        val time = if (sunrise) day + ((6.0 - lngHour) / 24.0) else day + ((18.0 - lngHour) / 24.0)
        val meanAnomaly = (0.9856 * time) - 3.289
        val trueLongitude = normalizeDegrees(
            meanAnomaly +
                (1.916 * sin(Math.toRadians(meanAnomaly))) +
                (0.020 * sin(Math.toRadians(2.0 * meanAnomaly))) +
                282.634
        )
        var rightAscension = Math.toDegrees(atan(0.91764 * tan(Math.toRadians(trueLongitude))))
        rightAscension = normalizeDegrees(rightAscension)
        val longitudeQuadrant = floor(trueLongitude / 90.0) * 90.0
        val rightAscensionQuadrant = floor(rightAscension / 90.0) * 90.0
        rightAscension = (rightAscension + longitudeQuadrant - rightAscensionQuadrant) / 15.0

        val sinDeclination = 0.39782 * sin(Math.toRadians(trueLongitude))
        val cosDeclination = cos(asin(sinDeclination))
        val cosHourAngle = (
            cos(Math.toRadians(90.833)) -
                (sinDeclination * sin(Math.toRadians(latitude)))
            ) / (cosDeclination * cos(Math.toRadians(latitude)))
        if (cosHourAngle !in -1.0..1.0) return null

        val hourAngle = if (sunrise) {
            360.0 - Math.toDegrees(acos(cosHourAngle))
        } else {
            Math.toDegrees(acos(cosHourAngle))
        } / 15.0
        val localMeanTime = hourAngle + rightAscension - (0.06571 * time) - 6.622
        return normalizeHour(localMeanTime - lngHour)
    }

    private fun normalizeLocalHour(utcHour: Double): Double {
        val offsetHours = ZoneId.systemDefault().rules.getOffset(Instant.now()).totalSeconds / 3600.0
        return normalizeHour(utcHour + offsetHours)
    }

    private fun hourToLocalTime(hour: Double): LocalTime {
        val wholeHour = floor(hour).toInt()
        val minute = (((hour - wholeHour) * 60.0).toInt()).coerceIn(0, 59)
        return LocalTime.of(wholeHour.coerceIn(0, 23), minute)
    }

    private fun normalizeDegrees(value: Double): Double = ((value % 360.0) + 360.0) % 360.0

    private fun normalizeHour(value: Double): Double = ((value % 24.0) + 24.0) % 24.0
}

class StartTimeRecommendationCalculator(
    private val timeProvider: TimeProvider,
) {
    fun recommend(
        route: Route,
        date: LocalDate,
        daylight: DaylightSummary,
        weather: PlannerWeatherSummary,
    ): RecommendedStartTime {
        if (weather.warning != null && weather.precipitationRiskPercent >= 70) {
            return RecommendedStartTime(
                time = null,
                warning = RecommendedStartWarning.Weather(weather.warning),
            )
        }
        val currentDateTime = Instant.ofEpochMilli(timeProvider.currentTimeMillis())
            .atZone(ZoneId.systemDefault())
        val today = currentDateTime.toLocalDate()
        val now = currentDateTime
            .toLocalTime()
        val earliest = if (date == today && now.isAfter(daylight.sunrise)) {
            now.plusMinutes(15)
        } else {
            daylight.sunrise.plusMinutes(30)
        }
        val routeDuration = route.estimatedTimeMinutes.toLong().coerceAtLeast(1L)
        val latestStart = daylight.sunset.minusMinutes(routeDuration + 30)
        if (earliest.isAfter(latestStart)) {
            return RecommendedStartTime(
                time = null,
                warning = RecommendedStartWarning.RouteDoesNotFitBeforeSunset,
            )
        }
        return RecommendedStartTime(time = earliest, warning = null)
    }
}

private fun atan(value: Double): Double = kotlin.math.atan(value)
