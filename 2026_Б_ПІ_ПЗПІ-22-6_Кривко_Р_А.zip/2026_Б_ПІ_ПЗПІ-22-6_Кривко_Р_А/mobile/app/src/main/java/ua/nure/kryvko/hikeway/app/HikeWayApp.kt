package ua.nure.kryvko.hikeway.app

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.WindowInsetsSides
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.only
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.annotation.StringRes
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.adaptive.navigationsuite.NavigationSuiteScaffold
import androidx.annotation.DrawableRes
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import ua.nure.kryvko.hikeway.R
import ua.nure.kryvko.hikeway.feature.auth.AuthScreen
import ua.nure.kryvko.hikeway.feature.auth.AuthStatus
import ua.nure.kryvko.hikeway.feature.auth.AuthViewModel
import ua.nure.kryvko.hikeway.feature.completedhikes.CompletedHikesViewModel
import ua.nure.kryvko.hikeway.feature.hikeplans.HikePlanScreen
import ua.nure.kryvko.hikeway.feature.hikeplans.HikePlansViewModel
import ua.nure.kryvko.hikeway.feature.profile.AchievementsScreen
import ua.nure.kryvko.hikeway.feature.profile.AchievementsViewModel
import ua.nure.kryvko.hikeway.feature.profile.EditProfileScreen
import ua.nure.kryvko.hikeway.feature.profile.EmergencyContactScreen
import ua.nure.kryvko.hikeway.feature.profile.ProfileScreen
import ua.nure.kryvko.hikeway.feature.profile.ProfileViewModel
import ua.nure.kryvko.hikeway.feature.pois.PoiCommentsScreen
import ua.nure.kryvko.hikeway.feature.pois.PoiEditScreen
import ua.nure.kryvko.hikeway.feature.routecreation.RouteCreationScreen
import ua.nure.kryvko.hikeway.feature.routecreation.RouteCreationViewModel
import ua.nure.kryvko.hikeway.feature.safety.EmergencyContactsViewModel
import ua.nure.kryvko.hikeway.feature.saved.SavedMapsViewModel
import ua.nure.kryvko.hikeway.feature.saved.SavedRoutesViewModel
import ua.nure.kryvko.hikeway.feature.saved.SavedScreen
import ua.nure.kryvko.hikeway.feature.saved.SavedTab
import ua.nure.kryvko.hikeway.feature.saved.UserCreatedRoutesViewModel
import ua.nure.kryvko.hikeway.feature.routesearch.RouteCommentsScreen
import ua.nure.kryvko.hikeway.feature.routesearch.RouteOverviewScreen
import ua.nure.kryvko.hikeway.feature.routesearch.RouteSearchScreen
import ua.nure.kryvko.hikeway.feature.routesearch.RouteSearchViewModel
import ua.nure.kryvko.hikeway.feature.routesearch.RoutesMapScreen
import ua.nure.kryvko.hikeway.feature.search.SearchResultsScreen
import ua.nure.kryvko.hikeway.feature.search.SearchResultsViewModel
import ua.nure.kryvko.hikeway.domain.savedroutes.savedRouteKey

@Composable
fun HikeWayApp(
    authViewModel: AuthViewModel,
    routeSearchViewModel: RouteSearchViewModel,
    searchResultsViewModel: SearchResultsViewModel,
    completedHikesViewModel: CompletedHikesViewModel,
    routeCreationViewModel: RouteCreationViewModel,
    savedRoutesViewModel: SavedRoutesViewModel,
    userCreatedRoutesViewModel: UserCreatedRoutesViewModel,
    savedMapsViewModel: SavedMapsViewModel,
    hikePlansViewModel: HikePlansViewModel,
    emergencyContactsViewModel: EmergencyContactsViewModel,
    profileViewModel: ProfileViewModel,
    achievementsViewModel: AchievementsViewModel,
    selectedLanguageTag: String,
    onLanguageSelected: (String) -> Unit,
    requestNotificationPermission: () -> Unit,
    launchSmsMessage: (phoneNumber: String, body: String) -> Unit,
    showToast: (String) -> Unit,
) {
    val authState by authViewModel.uiState.collectAsState()
    val routeSearchState by routeSearchViewModel.uiState.collectAsState()
    val searchResultsState by searchResultsViewModel.uiState.collectAsState()
    val savedRoutesState by savedRoutesViewModel.uiState.collectAsState()
    val savedMapsState by savedMapsViewModel.uiState.collectAsState()
    val hikePlanDraftState by hikePlansViewModel.draftState.collectAsState()
    val emergencyContactsState by emergencyContactsViewModel.uiState.collectAsState()
    val profileState by profileViewModel.uiState.collectAsState()
    val achievementsState by achievementsViewModel.uiState.collectAsState()
    var currentDestination by rememberSaveable { mutableStateOf(AppDestination.ROUTES) }
    var currentSavedTab by rememberSaveable { mutableStateOf(SavedTab.FINISHED_HIKES) }
    var isCreatingRoute by rememberSaveable { mutableStateOf(false) }
    var isEditingPoi by rememberSaveable { mutableStateOf(false) }
    var isViewingPoiComments by rememberSaveable { mutableStateOf(false) }
    var isViewingRouteComments by rememberSaveable { mutableStateOf(false) }
    var activeSearchQuery by rememberSaveable { mutableStateOf<String?>(null) }
    var profileSubScreen by rememberSaveable { mutableStateOf(ProfileSubScreen.NONE) }

    when (authState.status) {
        AuthStatus.CHECKING -> {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                CircularProgressIndicator()
            }
            return
        }
        AuthStatus.UNAUTHENTICATED -> {
            AuthScreen(authViewModel)
            return
        }
        AuthStatus.AUTHENTICATED -> Unit
    }

    LaunchedEffect(authState.username) {
        routeSearchViewModel.refreshCurrentSearch()
        routeSearchViewModel.refreshPointsOfInterest()
    }

    LaunchedEffect(authState.userId, authState.status) {
        if (authState.status == AuthStatus.AUTHENTICATED) {
            profileViewModel.loadForUser(authState.userId)
            achievementsViewModel.loadForUser(authState.userId)
        }
    }

    val context = LocalContext.current
    val achievementToastPrefix = stringResource(R.string.achievement_toast_prefix)
    LaunchedEffect(Unit) {
        achievementsViewModel.toastEvents.collect { event ->
            showToast("$achievementToastPrefix ${context.getString(event.titleResId)}")
        }
    }

    if (isCreatingRoute) {
        RouteCreationScreen(
            viewModel = routeCreationViewModel,
            onCancel = {
                routeCreationViewModel.reset()
                isCreatingRoute = false
            },
            onSaved = {
                isCreatingRoute = false
                currentDestination = AppDestination.ROUTES
                routeSearchViewModel.refreshCurrentSearch()
                routeSearchViewModel.refreshPointsOfInterest()
            },
        )
        return
    }

    when (profileSubScreen) {
        ProfileSubScreen.EMERGENCY_CONTACT -> {
            EmergencyContactScreen(
                state = emergencyContactsState,
                onBack = { profileSubScreen = ProfileSubScreen.NONE },
                onNameChange = emergencyContactsViewModel::updateName,
                onPhoneNumberChange = emergencyContactsViewModel::updatePhoneNumber,
                onSave = emergencyContactsViewModel::save,
                onDelete = emergencyContactsViewModel::delete,
            )
            return
        }
        ProfileSubScreen.EDIT_PROFILE -> {
            EditProfileScreen(
                state = profileState,
                onUsernameChange = profileViewModel::updateUsername,
                onEmailChange = profileViewModel::updateEmail,
                onFirstNameChange = profileViewModel::updateFirstName,
                onLastNameChange = profileViewModel::updateLastName,
                onSave = {
                    profileViewModel.save {
                        profileSubScreen = ProfileSubScreen.NONE
                    }
                },
                onBack = { profileSubScreen = ProfileSubScreen.NONE },
            )
            return
        }
        ProfileSubScreen.ACHIEVEMENTS -> {
            AchievementsScreen(
                state = achievementsState,
                onBack = { profileSubScreen = ProfileSubScreen.NONE },
            )
            return
        }
        ProfileSubScreen.NONE -> Unit
    }

    if (hikePlanDraftState.isOpen) {
            HikePlanScreen(
                state = hikePlanDraftState,
                onBack = hikePlansViewModel::closeDraft,
                onSelectDate = hikePlansViewModel::selectDate,
                onAddChecklistItem = hikePlansViewModel::addChecklistItem,
                onUpdateChecklistItem = hikePlansViewModel::updateChecklistItem,
                onToggleChecklistItem = hikePlansViewModel::toggleChecklistItem,
                onDeleteChecklistItem = hikePlansViewModel::deleteChecklistItem,
                onSave = {
                    requestNotificationPermission()
                    hikePlansViewModel.saveDraft()
                },
                onDelete = { hikePlansViewModel.deleteCurrentPlan(onDeleted = {}) },
                onStartRoute = {
                    requestNotificationPermission()
                    hikePlansViewModel.saveAndStart { route ->
                        hikePlansViewModel.closeDraft()
                        routeSearchViewModel.dismissRoutePreview()
                        routeSearchViewModel.startRoute(route)
                        currentDestination = AppDestination.MAP
                    }
                },
                onRetryWeather = hikePlansViewModel::retryWeather,
            )
            return
    }

    emergencyContactsState.pendingSosMessage?.let { message ->
        LaunchedEffect(message) {
            launchSmsMessage(message.phoneNumber, message.body)
            emergencyContactsViewModel.consumePendingSosMessage()
        }
    }

    if (isEditingPoi) {
        val poi = routeSearchState.selectedPoi
        if (poi != null) {
            PoiEditScreen(
                poi = poi,
                isSaving = routeSearchState.isPoiActionInProgress,
                errorMessage = routeSearchState.poiErrorMessage,
                onBack = { isEditingPoi = false },
                onSave = { name, description, location ->
                    routeSearchViewModel.updateSelectedPoi(name, description, location) { updated ->
                        if (updated) {
                            isEditingPoi = false
                        }
                    }
                },
                onDelete = {
                    routeSearchViewModel.deleteSelectedPoi { deleted ->
                        if (deleted) {
                            isEditingPoi = false
                        }
                    }
                },
            )
        } else {
            LaunchedEffect(Unit) {
                isEditingPoi = false
            }
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                CircularProgressIndicator()
            }
        }
        return
    }

    if (isViewingPoiComments) {
        val poi = routeSearchState.selectedPoi
        if (poi != null) {
            PoiCommentsScreen(
                poi = poi,
                isActionInProgress = routeSearchState.isPoiLoading || routeSearchState.isPoiActionInProgress,
                errorMessage = routeSearchState.poiErrorMessage,
                isAdmin = authState.isAdmin,
                currentUserId = authState.userId,
                onBack = { isViewingPoiComments = false },
                onAddComment = routeSearchViewModel::addPoiComment,
                onUpdateComment = routeSearchViewModel::updatePoiComment,
                onDeleteComment = routeSearchViewModel::deletePoiComment,
            )
        } else {
            LaunchedEffect(Unit) {
                isViewingPoiComments = false
            }
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                CircularProgressIndicator()
            }
        }
        return
    }

    if (isViewingRouteComments) {
        val route = routeSearchState.previewRoute
        if (route != null) {
            RouteCommentsScreen(
                route = route,
                isActionInProgress = routeSearchState.isRouteContentLoading ||
                    routeSearchState.isRouteContentActionInProgress,
                errorMessage = routeSearchState.routeContentErrorMessage,
                isAdmin = authState.isAdmin,
                currentUserId = authState.userId,
                onBack = { isViewingRouteComments = false },
                onAddComment = routeSearchViewModel::addRouteComment,
                onUpdateComment = routeSearchViewModel::updateRouteComment,
                onDeleteComment = routeSearchViewModel::deleteRouteComment,
            )
        } else {
            LaunchedEffect(Unit) {
                isViewingRouteComments = false
            }
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                CircularProgressIndicator()
            }
        }
        return
    }

    routeSearchState.previewRoute
        ?.takeIf { routeSearchState.pickingSession == null }
        ?.let { route ->
            LaunchedEffect(route.savedRouteKey()) {
                savedMapsViewModel.observeRoute(route)
            }
            RouteOverviewScreen(
                route = route,
                isSaved = route.savedRouteKey() in savedRoutesState.savedRouteKeys,
                currentUserId = authState.userId,
                mapDownload = savedMapsState.routeDownload,
                pendingMapEstimate = savedMapsState.pendingEstimate,
                isStartingMapDownload = savedMapsState.isStarting,
                isRouteActionInProgress = routeSearchState.isRouteActionInProgress,
                routeActionErrorMessage = routeSearchState.routeActionErrorMessage,
                routeContentErrorMessage = routeSearchState.routeContentErrorMessage,
                isRouteContentActionInProgress = routeSearchState.isRouteContentActionInProgress,
                onBack = routeSearchViewModel::dismissRoutePreview,
                onToggleSaved = { savedRoutesViewModel.toggleSaved(route) },
                onRateRoute = routeSearchViewModel::ratePreviewedRoute,
                onRemoveRouteRating = routeSearchViewModel::removePreviewedRouteRating,
                onViewComments = {
                    routeSearchViewModel.loadPreviewedRouteComments()
                    isViewingRouteComments = true
                },
                onPublishRoute = routeSearchViewModel::publishPreviewedRoute,
                onDeleteRoute = routeSearchViewModel::deletePreviewedRoute,
                onStartRoute = {
                    routeSearchViewModel.startPreviewedRoute()
                    currentDestination = AppDestination.MAP
                },
                onPlanTrip = { hikePlansViewModel.openNewPlan(route) },
                onSaveMap = { savedMapsViewModel.prepareDownload(route) },
                onConfirmSaveMap = savedMapsViewModel::confirmDownload,
                onDismissSaveMapEstimate = savedMapsViewModel::dismissEstimate,
            )
            return
        }

    activeSearchQuery?.let {
        SearchResultsScreen(
            state = searchResultsState,
            savedRouteKeys = savedRoutesState.savedRouteKeys,
            onQueryChange = searchResultsViewModel::updateQuery,
            onSubmit = searchResultsViewModel::submitCurrentQuery,
            onBack = { activeSearchQuery = null },
            onRouteClick = routeSearchViewModel::previewRoute,
            onPoiClick = { poi ->
                routeSearchViewModel.selectPoi(poi.id)
                activeSearchQuery = null
                currentDestination = AppDestination.MAP
            },
            onToggleSavedRoute = savedRoutesViewModel::toggleSaved,
        )
        return
    }

    NavigationSuiteScaffold(
        navigationSuiteItems = {
            AppDestination.entries.forEach { destination ->
                val selected = destination == currentDestination
                item(
                    icon = {
                        Icon(
                            painter = painterResource(destination.iconRes(selected)),
                            contentDescription = stringResource(destination.labelRes),
                            modifier = Modifier.size(40.dp),
                            tint = if (selected) {
                                MaterialTheme.colorScheme.primary
                            } else {
                                MaterialTheme.colorScheme.onSurfaceVariant
                            },
                        )
                    },
                    label = { Text(stringResource(destination.labelRes)) },
                    selected = selected,
                    onClick = { currentDestination = destination },
                )
            }
        }
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .windowInsetsPadding(
                    WindowInsets.safeDrawing.only(
                        WindowInsetsSides.Top + WindowInsetsSides.Horizontal
                    )
                )
        ) {
            when (currentDestination) {
                AppDestination.ROUTES -> RouteSearchScreen(
                    viewModel = routeSearchViewModel,
                    username = authState.username,
                    savedRouteKeys = savedRoutesState.savedRouteKeys,
                    onToggleSavedRoute = savedRoutesViewModel::toggleSaved,
                    onCreateRoute = {
                        routeCreationViewModel.reset()
                        isCreatingRoute = true
                    },
                    onPoiClick = {
                        currentDestination = AppDestination.MAP
                    },
                    onSearchSubmit = { query ->
                        activeSearchQuery = query
                        searchResultsViewModel.search(query)
                    },
                )
                AppDestination.COMPLETED_HIKES -> SavedScreen(
                    completedHikesViewModel = completedHikesViewModel,
                    savedRoutesViewModel = savedRoutesViewModel,
                    userCreatedRoutesViewModel = userCreatedRoutesViewModel,
                    savedMapsViewModel = savedMapsViewModel,
                    hikePlansViewModel = hikePlansViewModel,
                    selectedTab = currentSavedTab,
                    onTabSelected = { currentSavedTab = it },
                    onRouteClick = routeSearchViewModel::previewRoute,
                    onOriginalRouteClick = routeSearchViewModel::previewRoute,
                    onHikePlanClick = hikePlansViewModel::openExistingPlan,
                )
                AppDestination.PROFILE -> ProfileScreen(
                    username = profileState.displayUsername.ifBlank { authState.username },
                    email = profileState.displayEmail,
                    fullName = profileState.displayFullName,
                    isProfileLoading = profileState.isLoading,
                    profileErrorMessage = profileState.errorMessage,
                    onRetryProfile = profileViewModel::refresh,
                    selectedLanguageTag = selectedLanguageTag,
                    onLanguageSelected = onLanguageSelected,
                    onEditProfileClick = {
                        if (profileState.profile != null) {
                            profileViewModel.beginEditing()
                            profileSubScreen = ProfileSubScreen.EDIT_PROFILE
                        } else {
                            profileViewModel.refresh()
                        }
                    },
                    onEmergencyContactClick = { profileSubScreen = ProfileSubScreen.EMERGENCY_CONTACT },
                    onAchievementsClick = { profileSubScreen = ProfileSubScreen.ACHIEVEMENTS },
                    onLogOut = authViewModel::logOut,
                )
                AppDestination.MAP -> RoutesMapScreen(
                    viewModel = routeSearchViewModel,
                    onCreateRoute = {
                        routeCreationViewModel.reset()
                        isCreatingRoute = true
                    },
                    onCreateRouteFromPoint = { point ->
                        routeCreationViewModel.startFromPoint(point)
                        isCreatingRoute = true
                    },
                    onEditPoi = { isEditingPoi = true },
                    onViewPoiComments = {
                        routeSearchViewModel.refreshSelectedPoiDetail()
                        isViewingPoiComments = true
                    },
                    isAdmin = authState.isAdmin,
                    sosMessage = emergencyContactsState.message
                        ?.takeIf { it.startsWith("Add an emergency contact") },
                    isSosConfirmationVisible = emergencyContactsState.isSosConfirmationVisible,
                    onSosClick = emergencyContactsViewModel::requestSosConfirmation,
                    onDismissSosMessage = emergencyContactsViewModel::clearMessage,
                    onDismissSosConfirmation = emergencyContactsViewModel::dismissSosConfirmation,
                    onConfirmSos = { route, position ->
                        emergencyContactsViewModel.confirmSos(authState.username, route, position)
                    },
                    onFindRoutesNearby = {
                        currentDestination = AppDestination.ROUTES
                    },
                )
            }
        }
    }
}

enum class AppDestination(
    @param:StringRes val labelRes: Int,
    @param:DrawableRes val activeIconRes: Int,
    @param:DrawableRes val inactiveIconRes: Int,
) {
    ROUTES(R.string.nav_routes, R.drawable.ic_nav_routes, R.drawable.ic_nav_routes_inactive),
    MAP(R.string.nav_map, R.drawable.ic_nav_map, R.drawable.ic_nav_map_inactive),
    COMPLETED_HIKES(R.string.nav_saved, R.drawable.ic_nav_saved, R.drawable.ic_nav_saved_inactive),
    PROFILE(R.string.nav_profile, R.drawable.ic_nav_profile, R.drawable.ic_nav_profile_inactive),
    ;

    @DrawableRes
    fun iconRes(selected: Boolean): Int = if (selected) activeIconRes else inactiveIconRes
}

private enum class ProfileSubScreen {
    NONE,
    EMERGENCY_CONTACT,
    EDIT_PROFILE,
    ACHIEVEMENTS,
}
