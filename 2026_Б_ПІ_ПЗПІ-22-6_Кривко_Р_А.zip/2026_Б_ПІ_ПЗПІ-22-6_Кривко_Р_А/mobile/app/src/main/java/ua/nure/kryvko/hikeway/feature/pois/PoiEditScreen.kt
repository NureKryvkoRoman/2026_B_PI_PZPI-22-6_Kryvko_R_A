package ua.nure.kryvko.hikeway.feature.pois

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.WindowInsetsSides
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.only
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import ua.nure.kryvko.hikeway.R
import ua.nure.kryvko.hikeway.core.model.GeoPoint
import ua.nure.kryvko.hikeway.core.model.PointOfInterest

@Composable
fun PoiEditScreen(
    poi: PointOfInterest,
    isSaving: Boolean,
    errorMessage: String?,
    onBack: () -> Unit,
    onSave: (String, String, GeoPoint) -> Unit,
    onDelete: () -> Unit,
) {
    BackHandler(onBack = onBack)
    var name by remember(poi.id, poi.name) { mutableStateOf(poi.name) }
    var description by remember(poi.id, poi.description) { mutableStateOf(poi.description) }
    var isDeleteConfirmationVisible by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .windowInsetsPadding(
                WindowInsets.safeDrawing.only(
                    WindowInsetsSides.Top + WindowInsetsSides.Horizontal
                )
            )
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            IconButton(onClick = onBack) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                    contentDescription = stringResource(R.string.action_back),
                )
            }
            Text(
                stringResource(R.string.poi_edit_title),
                modifier = Modifier.weight(1f),
                style = MaterialTheme.typography.headlineSmall,
            )
            IconButton(
                onClick = { isDeleteConfirmationVisible = true },
                enabled = !isSaving,
            ) {
                Icon(
                    imageVector = Icons.Default.Delete,
                    contentDescription = stringResource(R.string.poi_delete_poi),
                )
            }
        }

        OutlinedTextField(
            value = name,
            onValueChange = { name = it },
            label = { Text(stringResource(R.string.common_name)) },
            modifier = Modifier.fillMaxWidth(),
            enabled = !isSaving,
        )
        OutlinedTextField(
            value = description,
            onValueChange = { description = it },
            label = { Text(stringResource(R.string.common_description)) },
            modifier = Modifier.fillMaxWidth(),
            minLines = 4,
            enabled = !isSaving,
        )

        errorMessage?.let {
            Text(it, color = MaterialTheme.colorScheme.error)
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            TextButton(
                onClick = onBack,
                modifier = Modifier.weight(1f),
                enabled = !isSaving,
            ) {
                Text(stringResource(R.string.action_cancel))
            }
            Button(
                onClick = { onSave(name, description, poi.location) },
                modifier = Modifier.weight(1f),
                enabled = !isSaving,
            ) {
                if (isSaving) {
                    CircularProgressIndicator(modifier = Modifier.size(18.dp))
                } else {
                    Text(stringResource(R.string.poi_save_poi))
                }
            }
        }
    }

    if (isDeleteConfirmationVisible) {
        AlertDialog(
            onDismissRequest = {
                if (!isSaving) {
                    isDeleteConfirmationVisible = false
                }
            },
            title = { Text(stringResource(R.string.poi_delete_confirmation_title)) },
            text = { Text(stringResource(R.string.poi_delete_confirmation_message)) },
            confirmButton = {
                Button(
                    onClick = {
                        isDeleteConfirmationVisible = false
                        onDelete()
                    },
                    enabled = !isSaving,
                ) {
                    Text(stringResource(R.string.action_delete))
                }
            },
            dismissButton = {
                TextButton(
                    onClick = { isDeleteConfirmationVisible = false },
                    enabled = !isSaving,
                ) {
                    Text(stringResource(R.string.action_cancel))
                }
            },
        )
    }
}
