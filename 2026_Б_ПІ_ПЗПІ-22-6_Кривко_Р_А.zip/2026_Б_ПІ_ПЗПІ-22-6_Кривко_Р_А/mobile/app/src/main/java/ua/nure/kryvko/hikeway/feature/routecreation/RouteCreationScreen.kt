package ua.nure.kryvko.hikeway.feature.routecreation

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier

@Composable
fun RouteCreationScreen(
    viewModel: RouteCreationViewModel,
    onCancel: () -> Unit,
    onSaved: () -> Unit,
) {
    val state by viewModel.uiState.collectAsState()

    LaunchedEffect(state.didSave) {
        if (state.didSave) {
            viewModel.reset()
            onSaved()
        }
    }

    BackHandler {
        when (state.step) {
            RouteCreationStep.MAP -> onCancel()
            RouteCreationStep.DETAILS -> viewModel.backToMap()
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .windowInsetsPadding(WindowInsets.safeDrawing)
    ) {
        when (state.step) {
            RouteCreationStep.MAP -> RouteBuilderScreen(
                state = state,
                onCrosshairChange = viewModel::updateCrosshair,
                onCancel = onCancel,
                onPlacePoint = viewModel::placePoint,
                onFinish = viewModel::finishMapStep,
                onPoiClick = viewModel::selectPoi,
                onDismissPoi = viewModel::dismissPoi,
                onRatePoi = viewModel::ratePoi,
                onAddPoiToRoute = viewModel::addSelectedPoiToRoute,
            )
            RouteCreationStep.DETAILS -> RouteDetailsScreen(
                state = state,
                onBack = viewModel::backToMap,
                onCancel = onCancel,
                onNameChange = viewModel::updateName,
                onDescriptionChange = viewModel::updateDescription,
                onDifficultySelect = viewModel::selectDifficulty,
                onTerrainSelect = viewModel::selectTerrain,
                onSave = viewModel::saveRoute,
            )
        }
    }
}
