package ua.nure.kryvko.hikeway.data.hikeplans.reminders

import android.content.Context
import androidx.work.Data
import androidx.work.ExistingWorkPolicy
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import dagger.hilt.android.qualifiers.ApplicationContext
import ua.nure.kryvko.hikeway.domain.hikelogging.TimeProvider
import ua.nure.kryvko.hikeway.domain.hikeplans.HikePlan
import ua.nure.kryvko.hikeway.domain.hikeplans.HikePlanReminderScheduler
import java.time.LocalDate
import java.time.LocalTime
import java.time.ZoneId
import java.util.concurrent.TimeUnit
import javax.inject.Inject

class WorkManagerHikePlanReminderScheduler @Inject constructor(
    @param:ApplicationContext private val context: Context,
    private val timeProvider: TimeProvider,
) : HikePlanReminderScheduler {
    override fun schedule(plan: HikePlan) {
        if (plan.id == 0L) return
        HikePlanNotificationChannels.ensureReminderChannel(context)
        val request = OneTimeWorkRequestBuilder<HikePlanReminderWorker>()
            .setInputData(plan.toReminderWorkData())
            .setInitialDelay(reminderDelayMillis(plan.plannedDateEpochDay, timeProvider.currentTimeMillis()), TimeUnit.MILLISECONDS)
            .build()
        WorkManager.getInstance(context).enqueueUniqueWork(
            reminderWorkName(plan.id),
            ExistingWorkPolicy.REPLACE,
            request,
        )
    }

    override fun cancel(planId: Long) {
        if (planId == 0L) return
        WorkManager.getInstance(context).cancelUniqueWork(reminderWorkName(planId))
    }
}

fun reminderWorkName(planId: Long): String = "hike-plan-reminder-$planId"

fun reminderDelayMillis(
    plannedDateEpochDay: Long,
    nowEpochMillis: Long,
    zoneId: ZoneId = ZoneId.systemDefault(),
): Long {
    val target = LocalDate.ofEpochDay(plannedDateEpochDay)
        .atTime(LocalTime.of(8, 0))
        .atZone(zoneId)
        .toInstant()
        .toEpochMilli()
    return (target - nowEpochMillis).coerceAtLeast(IMMEDIATE_REMINDER_DELAY_MILLIS)
}

private fun HikePlan.toReminderWorkData(): Data {
    return Data.Builder()
        .putLong(HikePlanReminderWorker.KEY_PLAN_ID, id)
        .putString(HikePlanReminderWorker.KEY_ROUTE_NAME, routeName)
        .putLong(HikePlanReminderWorker.KEY_PLANNED_DATE_EPOCH_DAY, plannedDateEpochDay)
        .build()
}

private const val IMMEDIATE_REMINDER_DELAY_MILLIS = 1_000L
