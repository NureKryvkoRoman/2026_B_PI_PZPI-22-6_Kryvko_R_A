package ua.nure.kryvko.hikeway.feature.routesearch

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListScope
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.Card
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.semantics.testTag
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import ua.nure.kryvko.hikeway.R
import ua.nure.kryvko.hikeway.core.model.Difficulty
import ua.nure.kryvko.hikeway.core.model.PointOfInterest
import ua.nure.kryvko.hikeway.core.model.Route
import ua.nure.kryvko.hikeway.core.model.Terrain
import ua.nure.kryvko.hikeway.domain.routes.RouteSearchCriteria
import ua.nure.kryvko.hikeway.domain.savedroutes.savedRouteKey
import ua.nure.kryvko.hikeway.ui.common.CollapsibleSectionHeader
import java.util.Locale

@Composable
fun RouteHomePanel(
    state: RouteSearchUiState,
    username: String,
    recommendedExpanded: Boolean,
    popularNearbyExpanded: Boolean,
    onRecommendedExpandedChange: (Boolean) -> Unit,
    onPopularNearbyExpandedChange: (Boolean) -> Unit,
    onRefreshRecommended: () -> Unit = {},
    onRouteClick: (Route) -> Unit,
    onPoiClick: (Long) -> Unit,
    onFilterClick: () -> Unit,
    onSearchSubmit: (String) -> Unit = {},
    savedRouteKeys: Set<String> = emptySet(),
    onToggleSavedRoute: (Route) -> Unit = {},
    contentBottomPadding: Dp = 16.dp,
    modifier: Modifier = Modifier,
) {
    LazyColumn(
        modifier = modifier.fillMaxSize(),
        contentPadding = PaddingValues(
            start = 16.dp,
            top = 16.dp,
            end = 16.dp,
            bottom = contentBottomPadding,
        ),
        verticalArrangement = Arrangement.spacedBy(18.dp),
    ) {
        item {
            Greeter(username = username)
        }
        item {
            HomeSearchBar(onSearchSubmit = onSearchSubmit)
        }
        item {
            CollapsibleSectionHeader(
                title = stringResource(R.string.home_recommended_routes),
                expanded = recommendedExpanded,
                onExpandedChange = onRecommendedExpandedChange,
                actions = {
                    IconButton(
                        onClick = onRefreshRecommended,
                        enabled = !state.isRecommendedLoading,
                    ) {
                        Icon(
                            imageVector = Icons.Default.Refresh,
                            contentDescription = stringResource(R.string.cd_refresh_recommendations),
                        )
                    }
                },
            )
        }
        if (recommendedExpanded) {
            item {
                RecommendedRoutesRow(
                    routes = state.recommendedRoutes,
                    isLoading = state.isRecommendedLoading,
                    errorMessage = state.recommendedErrorMessage,
                    onRouteClick = onRouteClick,
                    savedRouteKeys = savedRouteKeys,
                    onToggleSavedRoute = onToggleSavedRoute,
                )
            }
        }
        item {
            CollapsibleSectionHeader(
                title = stringResource(R.string.home_popular_nearby),
                expanded = popularNearbyExpanded,
                onExpandedChange = onPopularNearbyExpandedChange,
            )
        }
        if (popularNearbyExpanded) {
            if (state.pointsOfInterest.isEmpty()) {
                item {
                    Text(
                        stringResource(R.string.home_no_nearby_pois),
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        style = MaterialTheme.typography.bodyMedium,
                    )
                }
            } else {
                items(state.pointsOfInterest, key = { it.id }) { poi ->
                    PoiCard(poi = poi, onClick = { onPoiClick(poi.id) })
                }
            }
        }
        item {
            RouteSearchHeader(
                state = state,
                onFilterClick = onFilterClick,
            )
        }
        if (state.hasAppliedFilters()) {
            item {
                AppliedFilterChips(state = state)
            }
        }
        routeSearchItems(
            state = state,
            onRouteClick = onRouteClick,
            savedRouteKeys = savedRouteKeys,
            onToggleSavedRoute = onToggleSavedRoute,
        )
    }
}

@Composable
private fun Greeter(username: String) {
    val displayName = username.trim()
    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Text(
            if (displayName.isBlank()) {
                stringResource(R.string.greeter_welcome)
            } else {
                stringResource(R.string.greeter_welcome_user, displayName)
            },
            style = MaterialTheme.typography.headlineSmall,
        )
        Text(
            stringResource(R.string.greeter_where_heading),
            style = MaterialTheme.typography.titleMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
    }
}

@Composable
private fun HomeSearchBar(onSearchSubmit: (String) -> Unit) {
    var query by rememberSaveable { mutableStateOf("") }
    fun submit() {
        query.trim().takeIf { it.isNotEmpty() }?.let(onSearchSubmit)
    }
    OutlinedTextField(
        value = query,
        onValueChange = { query = it },
        singleLine = true,
        leadingIcon = {
            Icon(
                imageVector = Icons.Default.Search,
                contentDescription = null,
            )
        },
        trailingIcon = {
            IconButton(onClick = ::submit) {
                Icon(
                    imageVector = Icons.Default.Search,
                    contentDescription = stringResource(R.string.action_search),
                )
            }
        },
        placeholder = { Text(stringResource(R.string.home_search_placeholder)) },
        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
        keyboardActions = KeyboardActions(onSearch = { submit() }),
        modifier = Modifier.fillMaxWidth(),
    )
}

@Composable
private fun RecommendedRoutesRow(
    routes: List<Route>,
    isLoading: Boolean,
    errorMessage: String?,
    onRouteClick: (Route) -> Unit,
    savedRouteKeys: Set<String>,
    onToggleSavedRoute: (Route) -> Unit,
) {
    if (isLoading) {
        CircularProgressIndicator(modifier = Modifier.size(24.dp))
        return
    }
    if (errorMessage != null) {
        Text(
            errorMessage,
            color = MaterialTheme.colorScheme.error,
            style = MaterialTheme.typography.bodyMedium,
        )
        return
    }
    if (routes.isEmpty()) {
        Text(
            stringResource(R.string.home_no_recommended_routes),
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            style = MaterialTheme.typography.bodyMedium,
        )
        return
    }
    LazyRow(
        horizontalArrangement = Arrangement.spacedBy(12.dp),
        contentPadding = PaddingValues(end = 16.dp),
    ) {
        items(routes, key = { it.routeListKey() }) { route ->
            RouteCard(
                route = route,
                isSaved = route.savedRouteKey() in savedRouteKeys,
                onClick = { onRouteClick(route) },
                onToggleSaved = { onToggleSavedRoute(route) },
                modifier = Modifier.size(width = 240.dp, height = 300.dp),
            )
        }
    }
}

@Composable
internal fun PoiCard(poi: PointOfInterest, onClick: () -> Unit) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
    ) {
        Column(
            modifier = Modifier.padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp),
        ) {
            Text(poi.name, style = MaterialTheme.typography.titleSmall)
            Text(
                poi.description,
                style = MaterialTheme.typography.bodyMedium,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis,
            )
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                if (poi.ratingCount > 0) {
                    Text(
                        stringResource(
                            R.string.format_rating,
                            "%.1f".format(poi.averageRating),
                            poi.ratingCount,
                        ),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.primary,
                    )
                }
                poi.distanceMeters?.let { distance ->
                    Text(
                        if (distance >= 1_000.0) {
                            stringResource(
                                R.string.format_distance_away_km,
                                "%.1f".format(distance / 1_000.0),
                            )
                        } else {
                            stringResource(R.string.format_distance_away_m, distance.toInt())
                        },
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }
        }
    }
}

@Composable
private fun RouteSearchHeader(
    state: RouteSearchUiState,
    onFilterClick: () -> Unit,
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(
            stringResource(R.string.home_route_search),
            style = MaterialTheme.typography.titleMedium,
        )
        FilterIconButton(
            state = state,
            onFilterClick = onFilterClick,
        )
    }
}

@Composable
@OptIn(ExperimentalLayoutApi::class)
private fun AppliedFilterChips(state: RouteSearchUiState) {
    FlowRow(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        appliedFilterLabels(state).forEach { label ->
            Surface(
                color = MaterialTheme.colorScheme.surfaceVariant,
                contentColor = MaterialTheme.colorScheme.onSurfaceVariant,
                shape = RoundedCornerShape(8.dp),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                modifier = Modifier.semantics { testTag = APPLIED_FILTER_CHIP_TAG },
            ) {
                Text(
                    text = label,
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                    style = MaterialTheme.typography.labelSmall,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
            }
        }
    }
}

@Composable
private fun appliedFilterLabels(state: RouteSearchUiState): List<String> {
    val criteria = state.appliedCriteria
    return buildList {
        criteria.distanceKm?.let { range ->
            add(
                stringResource(
                    R.string.route_filter_chip_distance,
                    range.start.formatFilterNumber(),
                    range.endInclusive.formatFilterNumber(),
                )
            )
        }
        criteria.estimatedTimeMinutes?.let { range ->
            add(stringResource(R.string.route_filter_chip_duration, range.first, range.last))
        }
        criteria.maxProximityKm?.let { proximity ->
            add(
                stringResource(
                    R.string.route_filter_chip_proximity,
                    proximity.formatFilterNumber(),
                )
            )
        }
        Difficulty.entries
            .filter { it in criteria.difficulties }
            .forEach { add(it.label()) }
        Terrain.entries
            .filter { it in criteria.terrains }
            .forEach { add(it.label()) }
        if (state.appliedOrigin != null) {
            add(stringResource(R.string.route_filter_chip_selected_map_point))
        }
    }
}

private fun LazyListScope.routeSearchItems(
    state: RouteSearchUiState,
    onRouteClick: (Route) -> Unit,
    savedRouteKeys: Set<String>,
    onToggleSavedRoute: (Route) -> Unit,
) {
    when {
        state.isLoading -> item {
            CircularProgressIndicator(modifier = Modifier.padding(16.dp))
        }

        state.errorMessage != null -> item {
            Text(
                state.errorMessage,
                modifier = Modifier.padding(vertical = 16.dp),
                color = MaterialTheme.colorScheme.error,
            )
        }

        state.routes.isEmpty() -> item {
            Text(
                stringResource(R.string.route_search_no_matches),
                modifier = Modifier.padding(vertical = 16.dp),
            )
        }

        else -> {
            item {
                Text(
                    stringResource(R.string.format_routes_found, state.routes.size),
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            items(state.routes, key = { it.routeListKey() }) { route ->
                RouteCard(
                    route = route,
                    isSaved = route.savedRouteKey() in savedRouteKeys,
                    onClick = { onRouteClick(route) },
                    onToggleSaved = { onToggleSavedRoute(route) },
                )
            }
        }
    }
}

private fun RouteSearchUiState.hasAppliedFilters(): Boolean {
    return appliedCriteria != RouteSearchCriteria() || appliedOrigin != null
}

@Composable
private fun FilterIconButton(
    state: RouteSearchUiState,
    onFilterClick: () -> Unit,
) {
    val hasAppliedFilters = state.hasAppliedFilters()
    IconButton(
        onClick = onFilterClick,
        modifier = Modifier
            .size(48.dp)
            .border(
                width = 1.dp,
                color = MaterialTheme.colorScheme.outline,
                shape = RoundedCornerShape(8.dp),
            ),
    ) {
        Icon(
            painter = painterResource(
                if (hasAppliedFilters) {
                    R.drawable.ic_filters_active
                } else {
                    R.drawable.ic_filters_inactive
                }
            ),
            contentDescription = stringResource(R.string.cd_filters),
            tint = if (hasAppliedFilters) {
                MaterialTheme.colorScheme.primary
            } else {
                MaterialTheme.colorScheme.onSurfaceVariant
            },
            modifier = Modifier
                .size(45.dp)
                .semantics {
                    testTag = if (hasAppliedFilters) {
                        "filters-active-icon"
                    } else {
                        "filters-inactive-icon"
                    }
                },
        )
    }
}

private fun Route.routeListKey(): String = savedRouteKey()

@Composable
internal fun RouteCard(
    route: Route,
    isSaved: Boolean = false,
    onClick: () -> Unit,
    onToggleSaved: () -> Unit = {},
    showSaveAction: Boolean = true,
    modifier: Modifier = Modifier.fillMaxWidth(),
) {
    val routeRatingContentDescription = stringResource(
        R.string.format_rating,
        "%.1f".format(Locale.US, route.averageRating),
        route.ratingCount,
    )
    Card(
        modifier = modifier
            .clickable(onClick = onClick)
    ) {
        Column {
            Box {
                RouteThumbnail(
                    route = route,
                    modifier = Modifier
                        .fillMaxWidth()
                        .aspectRatio(16f / 9f),
                )
                Surface(
                    color = MaterialTheme.colorScheme.secondaryContainer,
                    contentColor = MaterialTheme.colorScheme.onSecondaryContainer,
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier
                        .align(Alignment.TopStart)
                        .padding(8.dp),
                ) {
                    Text(
                        route.difficulty.label(),
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                        style = MaterialTheme.typography.labelMedium,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                }
                Row(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .padding(6.dp),
                ) {
                    RouteRatingStub(
                        rating = "%.1f".format(Locale.US, route.averageRating),
                        modifier = Modifier
                            .semantics {
                                contentDescription = routeRatingContentDescription
                            },
                    )
                    if (showSaveAction) {
                        Surface(
                            color = MaterialTheme.colorScheme.surface.copy(alpha = 0.9f),
                            contentColor = if (isSaved) {
                                MaterialTheme.colorScheme.primary
                            } else {
                                MaterialTheme.colorScheme.onSurfaceVariant
                            },
                            shape = RoundedCornerShape(8.dp),
                        ) {
                            IconButton(
                                onClick = onToggleSaved,
                                modifier = Modifier.size(40.dp),
                            ) {
                                Icon(
                                    painter = painterResource(
                                        if (isSaved) {
                                            R.drawable.ic_nav_saved
                                        } else {
                                            R.drawable.ic_nav_saved_inactive
                                        }
                                    ),
                                    contentDescription = stringResource(
                                        if (isSaved) {
                                            R.string.cd_remove_saved_route
                                        } else {
                                            R.string.cd_save_route_for_later
                                        }
                                    ),
                                )
                            }
                        }
                    }
                }
            }
            Column(
                modifier = Modifier.padding(12.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp),
            ) {
                Text(
                    route.name,
                    style = MaterialTheme.typography.titleSmall,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
                Text(
                    route.description,
                    style = MaterialTheme.typography.bodyMedium,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis,
                )
                Text(
                    routeCardShortDetails(route),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                Surface(
                    color = MaterialTheme.colorScheme.primaryContainer,
                    contentColor = MaterialTheme.colorScheme.onPrimaryContainer,
                    shape = RoundedCornerShape(8.dp),
                ) {
                    Text(
                        route.terrain.label(),
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                        style = MaterialTheme.typography.labelSmall,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                }
            }
        }
    }
}

@Composable
internal fun RouteRatingStub(
    rating: String,
    modifier: Modifier = Modifier,
) {
    Surface(
        color = MaterialTheme.colorScheme.surface.copy(alpha = 0.9f),
        contentColor = MaterialTheme.colorScheme.primary,
        shape = RoundedCornerShape(8.dp),
        modifier = modifier,
    ) {
        Row(
            horizontalArrangement = Arrangement.spacedBy(4.dp),
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 8.dp),
        ) {
            Text(
                text = rating,
                style = MaterialTheme.typography.labelMedium,
            )
            Icon(
                imageVector = Icons.Filled.Star,
                contentDescription = null,
                modifier = Modifier.size(18.dp),
            )
        }
    }
}

@Composable
private fun routeCardShortDetails(route: Route): String {
    val distance = stringResource(
        R.string.format_distance_short_km,
        "%.1f".format(Locale.US, route.distanceKm),
    )
    val duration = formatShortDuration(route.estimatedTimeMinutes)
    val elevation = stringResource(R.string.format_elevation_short_m, route.elevationGainMeters)
    return stringResource(R.string.format_route_card_short_details, distance, duration, elevation)
}

@Composable
private fun RouteThumbnail(
    route: Route,
    modifier: Modifier = Modifier,
) {
    val backgroundColor = MaterialTheme.colorScheme.surfaceVariant
    val gridColor = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.55f)
    val routeColor = MaterialTheme.colorScheme.primary
    val startColor = MaterialTheme.colorScheme.tertiary
    val finishColor = MaterialTheme.colorScheme.error
    Canvas(modifier = modifier) {
        drawRect(backgroundColor)
        val gridSpacing = 24.dp.toPx()
        var x = gridSpacing
        while (x < size.width) {
            drawLine(
                color = gridColor,
                start = Offset(x, 0f),
                end = Offset(x, size.height),
                strokeWidth = 1.dp.toPx(),
            )
            x += gridSpacing
        }
        var y = gridSpacing
        while (y < size.height) {
            drawLine(
                color = gridColor,
                start = Offset(0f, y),
                end = Offset(size.width, y),
                strokeWidth = 1.dp.toPx(),
            )
            y += gridSpacing
        }

        val points = route.geometry.points
        val padding = 18.dp.toPx()
        val drawableWidth = (size.width - padding * 2).coerceAtLeast(1f)
        val drawableHeight = (size.height - padding * 2).coerceAtLeast(1f)
        if (points.size < 2) {
            val center = Offset(size.width / 2f, size.height / 2f)
            drawCircle(routeColor, radius = 7.dp.toPx(), center = center)
            return@Canvas
        }

        val minLon = points.minOf { it.longitude }
        val maxLon = points.maxOf { it.longitude }
        val minLat = points.minOf { it.latitude }
        val maxLat = points.maxOf { it.latitude }
        val lonRange = (maxLon - minLon).takeIf { it > 0.0 } ?: 1.0
        val latRange = (maxLat - minLat).takeIf { it > 0.0 } ?: 1.0
        val offsets = points.map { point ->
            val normalizedX = ((point.longitude - minLon) / lonRange).toFloat()
            val normalizedY = ((point.latitude - minLat) / latRange).toFloat()
            Offset(
                x = padding + normalizedX * drawableWidth,
                y = padding + (1f - normalizedY) * drawableHeight,
            )
        }
        offsets.zipWithNext().forEach { (start, end) ->
            drawLine(
                color = routeColor,
                start = start,
                end = end,
                strokeWidth = 4.dp.toPx(),
                cap = StrokeCap.Round,
            )
        }
        drawCircle(startColor, radius = 5.dp.toPx(), center = offsets.first())
        drawCircle(finishColor, radius = 5.dp.toPx(), center = offsets.last())
    }
}

@Composable
private fun formatShortDuration(minutes: Int): String {
    return if (minutes < 60) {
        stringResource(R.string.format_duration_short_min, minutes)
    } else {
        val hours = minutes / 60
        val remainingMinutes = minutes % 60
        if (remainingMinutes == 0) {
            stringResource(R.string.format_duration_short_hour, hours)
        } else {
            stringResource(R.string.format_duration_short_hour_min, hours, remainingMinutes)
        }
    }
}

private fun Double.formatFilterNumber(): String {
    return if (this % 1.0 == 0.0) {
        toInt().toString()
    } else {
        "%.1f".format(Locale.US, this)
    }
}

private const val APPLIED_FILTER_CHIP_TAG = "applied-filter-chip"
