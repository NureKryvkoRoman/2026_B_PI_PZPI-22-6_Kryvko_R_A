package ua.nure.kryvko.hikeway.data.savedroutes.local

import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.map
import ua.nure.kryvko.hikeway.core.model.Difficulty
import ua.nure.kryvko.hikeway.core.model.Route
import ua.nure.kryvko.hikeway.core.model.RouteGeometry
import ua.nure.kryvko.hikeway.core.model.Terrain
import ua.nure.kryvko.hikeway.data.geojson.GeoJsonLineStringCodec
import ua.nure.kryvko.hikeway.domain.auth.CurrentUserProvider
import ua.nure.kryvko.hikeway.domain.savedroutes.SavedRouteRepository
import ua.nure.kryvko.hikeway.domain.savedroutes.savedRouteKey

class RoomSavedRouteRepository(
    private val dao: SavedRouteDao,
    private val currentUserProvider: CurrentUserProvider,
) : SavedRouteRepository {
    @OptIn(ExperimentalCoroutinesApi::class)
    override fun observeAll(): Flow<List<Route>> {
        return currentUserProvider.currentUserId.flatMapLatest { ownerUserId ->
            if (ownerUserId == null) {
                flowOf(emptyList())
            } else {
                dao.observeAll(ownerUserId).map { routes -> routes.map { it.toDomain() } }
            }
        }
    }

    override suspend fun save(route: Route) {
        dao.upsert(route.toSavedRouteEntity(currentUserProvider.requireCurrentUserId()))
    }

    override suspend fun remove(route: Route) {
        dao.delete(currentUserProvider.requireCurrentUserId(), route.savedRouteKey())
    }

    override suspend fun isSaved(route: Route): Boolean {
        val ownerUserId = currentUserProvider.currentUserId.value ?: return false
        return dao.exists(ownerUserId, route.savedRouteKey())
    }
}

fun Route.toSavedRouteEntity(
    ownerUserId: String,
    savedAtEpochMillis: Long = System.currentTimeMillis(),
) = SavedRouteEntity(
    ownerUserId = ownerUserId,
    routeKey = savedRouteKey(),
    routeId = id,
    name = name,
    description = description,
    distanceKm = distanceKm,
    estimatedTimeMinutes = estimatedTimeMinutes,
    difficulty = difficulty.name,
    elevationGainMeters = elevationGainMeters,
    terrain = terrain.name,
    geometryGeoJson = GeoJsonLineStringCodec.encode(geometry.points),
    savedAtEpochMillis = savedAtEpochMillis,
)

fun SavedRouteEntity.toDomain() = Route(
    id = routeId,
    name = name,
    description = description,
    distanceKm = distanceKm,
    estimatedTimeMinutes = estimatedTimeMinutes,
    difficulty = Difficulty.valueOf(difficulty),
    elevationGainMeters = elevationGainMeters,
    terrain = Terrain.valueOf(terrain),
    geometry = RouteGeometry(GeoJsonLineStringCodec.decode(geometryGeoJson)),
)
