package ua.nure.kryvko.hikeway.data.achievements.local

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "achievements",
    indices = [Index(value = ["ownerUserId", "code"], unique = true)],
)
data class AchievementEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val ownerUserId: String,
    val serverId: Long?,
    val code: String,
    val progressValue: Double,
    val targetValue: Double,
    val completedAtEpochMillis: Long?,
    val updatedAtEpochMillis: Long,
)
