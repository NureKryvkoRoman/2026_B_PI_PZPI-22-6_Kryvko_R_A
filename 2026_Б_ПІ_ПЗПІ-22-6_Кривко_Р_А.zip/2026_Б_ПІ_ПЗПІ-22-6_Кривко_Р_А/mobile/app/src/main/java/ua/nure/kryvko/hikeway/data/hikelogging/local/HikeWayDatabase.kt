package ua.nure.kryvko.hikeway.data.hikelogging.local

import androidx.room.Database
import androidx.room.RoomDatabase
import ua.nure.kryvko.hikeway.data.achievements.local.AchievementDao
import ua.nure.kryvko.hikeway.data.achievements.local.AchievementEntity
import ua.nure.kryvko.hikeway.data.offlinemaps.local.RouteMapDownloadDao
import ua.nure.kryvko.hikeway.data.offlinemaps.local.RouteMapDownloadEntity
import ua.nure.kryvko.hikeway.data.routepicking.local.ActiveRouteTrackingSessionDao
import ua.nure.kryvko.hikeway.data.routepicking.local.ActiveRouteTrackingSessionEntity
import ua.nure.kryvko.hikeway.data.safety.local.EmergencyContactDao
import ua.nure.kryvko.hikeway.data.safety.local.EmergencyContactEntity
import ua.nure.kryvko.hikeway.data.savedroutes.local.SavedRouteDao
import ua.nure.kryvko.hikeway.data.savedroutes.local.SavedRouteEntity
import ua.nure.kryvko.hikeway.data.hikeplans.local.HikePlanDao
import ua.nure.kryvko.hikeway.data.hikeplans.local.HikePlanEntity
import ua.nure.kryvko.hikeway.data.routes.local.RouteDao
import ua.nure.kryvko.hikeway.data.routes.local.RouteEntity
import ua.nure.kryvko.hikeway.data.sync.SyncConflictDao
import ua.nure.kryvko.hikeway.data.sync.SyncConflictEntity

@Database(
    entities = [
        HikeLogEntity::class,
        RouteEntity::class,
        SyncConflictEntity::class,
        SavedRouteEntity::class,
        HikePlanEntity::class,
        RouteMapDownloadEntity::class,
        EmergencyContactEntity::class,
        ActiveRouteTrackingSessionEntity::class,
        AchievementEntity::class,
    ],
    version = 14,
    exportSchema = true,
)
abstract class HikeWayDatabase : RoomDatabase() {
    abstract fun hikeLogDao(): HikeLogDao
    abstract fun routeDao(): RouteDao
    abstract fun syncConflictDao(): SyncConflictDao
    abstract fun savedRouteDao(): SavedRouteDao
    abstract fun hikePlanDao(): HikePlanDao
    abstract fun routeMapDownloadDao(): RouteMapDownloadDao
    abstract fun emergencyContactDao(): EmergencyContactDao
    abstract fun activeRouteTrackingSessionDao(): ActiveRouteTrackingSessionDao
    abstract fun achievementDao(): AchievementDao
}
