package ua.nure.kryvko.hikeway.data.hikeplans.reminders

import android.Manifest
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import androidx.hilt.work.HiltWorker
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import dagger.assisted.Assisted
import dagger.assisted.AssistedInject
import ua.nure.kryvko.hikeway.MainActivity
import ua.nure.kryvko.hikeway.R

@HiltWorker
class HikePlanReminderWorker @AssistedInject constructor(
    @Assisted private val context: Context,
    @Assisted parameters: WorkerParameters,
) : CoroutineWorker(context, parameters) {
    override suspend fun doWork(): Result {
        if (!canPostNotifications()) return Result.success()
        HikePlanNotificationChannels.ensureReminderChannel(context)
        val planId = inputData.getLong(KEY_PLAN_ID, 0L)
        val routeName = inputData.getString(KEY_ROUTE_NAME).orEmpty().ifBlank { "Your hike" }
        val notification = NotificationCompat.Builder(
            context,
            HikePlanNotificationChannels.REMINDERS_CHANNEL_ID,
        )
            .setSmallIcon(R.drawable.ic_launcher_foreground)
            .setContentTitle("Hike planned today")
            .setContentText("$routeName is planned for today.")
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .setAutoCancel(true)
            .setContentIntent(openAppIntent(planId))
            .build()

        runCatching {
            NotificationManagerCompat.from(context).notify(planId.toInt(), notification)
        }
        return Result.success()
    }

    private fun canPostNotifications(): Boolean {
        return Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU ||
            ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.POST_NOTIFICATIONS,
            ) == PackageManager.PERMISSION_GRANTED
    }

    private fun openAppIntent(planId: Long): PendingIntent {
        val intent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        return PendingIntent.getActivity(
            context,
            planId.toInt(),
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )
    }

    companion object {
        const val KEY_PLAN_ID = "planId"
        const val KEY_ROUTE_NAME = "routeName"
        const val KEY_PLANNED_DATE_EPOCH_DAY = "plannedDateEpochDay"
    }
}
