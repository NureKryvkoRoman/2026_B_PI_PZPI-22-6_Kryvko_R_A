package ua.nure.kryvko.hikeway.data.hikeplans.local

import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.map
import ua.nure.kryvko.hikeway.core.model.Route
import ua.nure.kryvko.hikeway.domain.auth.CurrentUserProvider
import ua.nure.kryvko.hikeway.domain.hikeplans.HikePlan
import ua.nure.kryvko.hikeway.domain.hikeplans.HikePlanChecklistItem
import ua.nure.kryvko.hikeway.domain.hikeplans.HikePlanRepository

class RoomHikePlanRepository(
    private val dao: HikePlanDao,
    private val currentUserProvider: CurrentUserProvider,
    private val gson: Gson,
) : HikePlanRepository {
    @OptIn(ExperimentalCoroutinesApi::class)
    override fun observeAll(): Flow<List<HikePlan>> {
        return currentUserProvider.currentUserId.flatMapLatest { ownerUserId ->
            if (ownerUserId == null) {
                flowOf(emptyList())
            } else {
                dao.observeAll(ownerUserId).map { plans -> plans.map { it.toDomain(gson) } }
            }
        }
    }

    @OptIn(ExperimentalCoroutinesApi::class)
    override fun observeById(id: Long): Flow<HikePlan?> {
        return currentUserProvider.currentUserId.flatMapLatest { ownerUserId ->
            if (ownerUserId == null) {
                flowOf(null)
            } else {
                dao.observeById(ownerUserId, id).map { it?.toDomain(gson) }
            }
        }
    }

    override suspend fun save(plan: HikePlan): Long {
        val now = System.currentTimeMillis()
        return dao.upsert(
            plan.toEntity(
                ownerUserId = currentUserProvider.requireCurrentUserId(),
                gson = gson,
                createdAtEpochMillis = plan.createdAtEpochMillis.takeIf { it > 0 } ?: now,
                updatedAtEpochMillis = now,
            )
        )
    }

    override suspend fun delete(id: Long) {
        dao.delete(currentUserProvider.requireCurrentUserId(), id)
    }
}

fun HikePlan.toEntity(
    ownerUserId: String,
    gson: Gson,
    createdAtEpochMillis: Long,
    updatedAtEpochMillis: Long,
) = HikePlanEntity(
    id = id,
    ownerUserId = ownerUserId,
    routeId = routeId,
    routeName = routeName,
    plannedDateEpochDay = plannedDateEpochDay,
    checklistJson = gson.toJson(checklist),
    routeSnapshotJson = routeSnapshot?.let { gson.toJson(it) },
    createdAtEpochMillis = createdAtEpochMillis,
    updatedAtEpochMillis = updatedAtEpochMillis,
)

fun HikePlanEntity.toDomain(gson: Gson) = HikePlan(
    id = id,
    routeId = routeId,
    routeName = routeName,
    plannedDateEpochDay = plannedDateEpochDay,
    checklist = gson.fromJson(checklistJson, checklistListType),
    routeSnapshot = routeSnapshotJson?.takeIf { it.isNotBlank() }?.let {
        gson.fromJson(it, Route::class.java)
    },
    createdAtEpochMillis = createdAtEpochMillis,
    updatedAtEpochMillis = updatedAtEpochMillis,
)

private val checklistListType = object : TypeToken<List<HikePlanChecklistItem>>() {}.type
