package ua.nure.kryvko.hikeway.data.offlinemaps.local

import ua.nure.kryvko.hikeway.core.model.Route
import ua.nure.kryvko.hikeway.data.geojson.GeoJsonLineStringCodec
import ua.nure.kryvko.hikeway.domain.offlinemaps.RouteMapBounds
import ua.nure.kryvko.hikeway.domain.offlinemaps.RouteMapDownload
import ua.nure.kryvko.hikeway.domain.offlinemaps.RouteMapDownloadEstimate
import ua.nure.kryvko.hikeway.domain.offlinemaps.RouteMapDownloadStatus
import ua.nure.kryvko.hikeway.domain.savedroutes.savedRouteKey

fun Route.toPendingRouteMapDownloadEntity(
    ownerUserId: String,
    estimate: RouteMapDownloadEstimate,
    now: Long,
    existing: RouteMapDownloadEntity? = null,
) = RouteMapDownloadEntity(
    id = existing?.id ?: 0L,
    ownerUserId = ownerUserId,
    routeKey = savedRouteKey(),
    routeId = id,
    routeName = name,
    routeGeometryGeoJson = GeoJsonLineStringCodec.encode(geometry.points),
    north = estimate.bounds.north,
    east = estimate.bounds.east,
    south = estimate.bounds.south,
    west = estimate.bounds.west,
    minZoom = estimate.minZoom,
    maxZoom = estimate.maxZoom,
    mapLibreRegionId = existing?.mapLibreRegionId,
    status = RouteMapDownloadStatus.PENDING.name,
    completedResourceCount = 0L,
    requiredResourceCount = null,
    completedResourceSizeBytes = 0L,
    completedTileCount = 0L,
    completedTileSizeBytes = 0L,
    estimatedMinBytes = estimate.minBytes,
    estimatedMaxBytes = estimate.maxBytes,
    errorMessage = null,
    createdAtEpochMillis = existing?.createdAtEpochMillis ?: now,
    updatedAtEpochMillis = now,
)

fun RouteMapDownloadEntity.toDomain() = RouteMapDownload(
    id = id,
    routeKey = routeKey,
    routeId = routeId,
    routeName = routeName,
    routeGeometry = GeoJsonLineStringCodec.decode(routeGeometryGeoJson),
    bounds = RouteMapBounds(north = north, east = east, south = south, west = west),
    minZoom = minZoom,
    maxZoom = maxZoom,
    mapLibreRegionId = mapLibreRegionId,
    status = RouteMapDownloadStatus.valueOf(status),
    completedResourceCount = completedResourceCount,
    requiredResourceCount = requiredResourceCount,
    completedResourceSizeBytes = completedResourceSizeBytes,
    completedTileCount = completedTileCount,
    completedTileSizeBytes = completedTileSizeBytes,
    estimatedMinBytes = estimatedMinBytes,
    estimatedMaxBytes = estimatedMaxBytes,
    errorMessage = errorMessage,
    createdAtEpochMillis = createdAtEpochMillis,
    updatedAtEpochMillis = updatedAtEpochMillis,
)
