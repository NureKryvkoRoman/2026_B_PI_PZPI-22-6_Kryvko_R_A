package ua.nure.kryvko.hikeway.feature.search

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import ua.nure.kryvko.hikeway.core.model.PointOfInterest
import ua.nure.kryvko.hikeway.core.model.Route
import ua.nure.kryvko.hikeway.domain.search.SearchHikeContentUseCase

data class SearchResultsUiState(
    val query: String = "",
    val routes: List<Route> = emptyList(),
    val pointsOfInterest: List<PointOfInterest> = emptyList(),
    val isLoading: Boolean = false,
    val errorMessage: String? = null,
)

@HiltViewModel
class SearchResultsViewModel @Inject constructor(
    private val searchHikeContent: SearchHikeContentUseCase,
) : ViewModel() {
    private val _uiState = MutableStateFlow(SearchResultsUiState())
    val uiState: StateFlow<SearchResultsUiState> = _uiState.asStateFlow()
    private var searchJob: Job? = null

    fun updateQuery(query: String) {
        _uiState.update { it.copy(query = query) }
    }

    fun submitCurrentQuery() {
        search(_uiState.value.query)
    }

    fun retry() {
        search(_uiState.value.query)
    }

    fun search(query: String) {
        val trimmed = query.trim()
        if (trimmed.isEmpty()) {
            _uiState.update { it.copy(query = query, errorMessage = null) }
            return
        }
        searchJob?.cancel()
        _uiState.update {
            it.copy(
                query = trimmed,
                isLoading = true,
                errorMessage = null,
            )
        }
        searchJob = viewModelScope.launch {
            runCatching { searchHikeContent(trimmed) }
                .onSuccess { results ->
                    _uiState.update {
                        it.copy(
                            routes = results.routes,
                            pointsOfInterest = results.pointsOfInterest,
                            isLoading = false,
                            errorMessage = null,
                        )
                    }
                }
                .onFailure { error ->
                    _uiState.update {
                        it.copy(
                            isLoading = false,
                            errorMessage = error.message ?: "Search is unavailable.",
                        )
                    }
                }
        }
    }
}
