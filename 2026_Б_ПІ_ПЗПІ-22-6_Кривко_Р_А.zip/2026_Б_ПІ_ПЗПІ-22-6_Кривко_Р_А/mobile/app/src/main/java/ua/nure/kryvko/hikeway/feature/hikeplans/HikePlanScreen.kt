package ua.nure.kryvko.hikeway.feature.hikeplans

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Button
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DatePicker
import androidx.compose.material3.DatePickerDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.SelectableDates
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberDatePickerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import ua.nure.kryvko.hikeway.R
import ua.nure.kryvko.hikeway.domain.hikeplans.HikePlanChecklistItem
import ua.nure.kryvko.hikeway.domain.weather.HikePlanWeather
import ua.nure.kryvko.hikeway.domain.weather.HourlyPlanWeather
import ua.nure.kryvko.hikeway.domain.weather.WeatherRiskUiModel
import ua.nure.kryvko.hikeway.ui.common.CollapsibleSectionHeader
import java.time.Instant
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.LocalTime
import java.time.ZoneOffset
import java.time.format.DateTimeFormatter

@Composable
fun HikePlanScreen(
    state: HikePlanDraftUiState,
    onBack: () -> Unit,
    onSelectDate: (Long) -> Unit,
    onAddChecklistItem: (String) -> Unit,
    onUpdateChecklistItem: (String, String) -> Unit,
    onToggleChecklistItem: (String, Boolean) -> Unit,
    onDeleteChecklistItem: (String) -> Unit,
    onSave: () -> Unit,
    onDelete: () -> Unit,
    onStartRoute: () -> Unit,
    onRetryWeather: () -> Unit,
) {
    BackHandler(onBack = onBack)
    var newItemText by remember { mutableStateOf("") }
    var showDatePicker by remember { mutableStateOf(false) }
    var weatherExpanded by rememberSaveable { mutableStateOf(true) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .windowInsetsPadding(WindowInsets.safeDrawing)
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            IconButton(onClick = onBack) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                    contentDescription = stringResource(R.string.action_back),
                )
            }
            Text(
                stringResource(R.string.hike_plan_title),
                modifier = Modifier.weight(1f),
                style = MaterialTheme.typography.headlineSmall,
            )
            if (state.planId != 0L) {
                IconButton(onClick = onDelete) {
                    Icon(
                        imageVector = Icons.Default.Delete,
                        contentDescription = stringResource(R.string.cd_delete_hike_plan),
                    )
                }
            }
        }

        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(state.routeName, style = MaterialTheme.typography.titleLarge)
            OutlinedButton(onClick = { showDatePicker = true }) {
                Text(
                    stringResource(
                        R.string.format_planned_date,
                        formatPlannedDate(state.plannedDateEpochDay)
                    )
                )
            }
        }

        PlannerSummary(
            weatherState = state.weatherState,
            expanded = weatherExpanded,
            onExpandedChange = { weatherExpanded = it },
            onRetryWeather = onRetryWeather,
        )

        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(
                stringResource(R.string.hike_plan_equipment_checklist),
                style = MaterialTheme.typography.titleMedium
            )
            if (state.checklist.isEmpty()) {
                Text(stringResource(R.string.hike_plan_no_checklist_items))
            } else {
                state.checklist.forEach { item ->
                    ChecklistItemRow(
                        item = item,
                        onTextChange = { onUpdateChecklistItem(item.id, it) },
                        onCheckedChange = { onToggleChecklistItem(item.id, it) },
                        onDelete = { onDeleteChecklistItem(item.id) },
                    )
                }
            }
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                OutlinedTextField(
                    value = newItemText,
                    onValueChange = { newItemText = it },
                    modifier = Modifier.weight(1f),
                    label = { Text(stringResource(R.string.hike_plan_checklist_item_label)) },
                    singleLine = true,
                )
                IconButton(
                    onClick = {
                        onAddChecklistItem(newItemText)
                        newItemText = ""
                    },
                ) {
                    Icon(
                        imageVector = Icons.Default.Add,
                        contentDescription = stringResource(R.string.cd_add_checklist_item),
                    )
                }
            }
        }

        state.errorMessage?.let {
            Text(it, color = MaterialTheme.colorScheme.error)
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            OutlinedButton(
                onClick = onSave,
                modifier = Modifier.weight(1f),
                enabled = !state.isSaving && state.canStart,
            ) {
                if (state.isSaving) {
                    CircularProgressIndicator()
                } else {
                    Text(stringResource(R.string.hike_plan_save))
                }
            }
            Button(
                onClick = onStartRoute,
                modifier = Modifier.weight(1f),
                enabled = !state.isSaving && state.canStart,
            ) {
                Text(stringResource(R.string.hike_plan_start_route))
            }
        }

        if (!state.canStart) {
            Text(
                stringResource(R.string.hike_plan_route_data_unavailable),
                color = MaterialTheme.colorScheme.error,
            )
        }
    }

    if (showDatePicker) {
        HikePlanDatePickerDialog(
            selectedEpochDay = state.plannedDateEpochDay,
            onDismiss = { showDatePicker = false },
            onSelectDate = {
                onSelectDate(it)
                showDatePicker = false
            },
        )
    }
}

@Composable
private fun PlannerSummary(
    weatherState: HikePlanWeatherState,
    expanded: Boolean,
    onExpandedChange: (Boolean) -> Unit,
    onRetryWeather: () -> Unit,
) {
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        CollapsibleSectionHeader(
            title = stringResource(R.string.hike_plan_weather),
            expanded = expanded,
            onExpandedChange = onExpandedChange,
        )
        if (!expanded) return@Column

        when (weatherState) {
            HikePlanWeatherState.Idle -> Text(stringResource(R.string.hike_plan_weather_unavailable))
            HikePlanWeatherState.Loading -> Row(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                CircularProgressIndicator()
                Text(stringResource(R.string.hike_plan_weather_loading))
            }

            is HikePlanWeatherState.Error -> WeatherError(
                message = weatherState.message,
                onRetryWeather = onRetryWeather,
            )

            is HikePlanWeatherState.Loaded -> WeatherDetails(weatherState.weather)
            is HikePlanWeatherState.Stale -> {
                Text(weatherState.message, color = MaterialTheme.colorScheme.error)
                WeatherDetails(weatherState.weather)
                OutlinedButton(onClick = onRetryWeather) {
                    Text(stringResource(R.string.action_retry))
                }
            }
        }
    }
}

@Composable
private fun WeatherError(
    message: String,
    onRetryWeather: () -> Unit,
) {
    Text(message, color = MaterialTheme.colorScheme.error)
    OutlinedButton(onClick = onRetryWeather) {
        Text(stringResource(R.string.action_retry))
    }
}

@Composable
private fun WeatherDetails(weather: HikePlanWeather) {
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        val summary = weather.summary
        Text(
            stringResource(
                R.string.format_weather_summary,
                localizedWeatherCondition(summary.condition),
                formatTemperatureRange(summary.temperatureMinC, summary.temperatureMaxC),
                summary.precipitationProbabilityMaxPercent ?: 0,
            )
        )
        summary.precipitationSumMm?.let {
            Text(stringResource(R.string.format_precipitation_sum, formatDecimal(it)))
        }
        summary.windGustsMaxKmh?.let {
            Text(stringResource(R.string.format_wind_gusts, formatDecimal(it)))
        }

        Text(
            stringResource(R.string.hike_plan_daylight),
            style = MaterialTheme.typography.titleMedium
        )
        summary.sunrise?.let { Text(stringResource(R.string.format_sunrise, formatTime(it))) }
            ?: Text(stringResource(R.string.hike_plan_daylight_unavailable))
        summary.sunset?.let { Text(stringResource(R.string.format_sunset, formatTime(it))) }
            ?: Text(stringResource(R.string.hike_plan_daylight_unavailable))

        Text(
            stringResource(R.string.hike_plan_recommended_start),
            style = MaterialTheme.typography.titleMedium
        )
        val recommendation = weather.recommendation
        if (recommendation.recommendedStartTime != null) {
            Text(
                stringResource(
                    R.string.format_recommended_window,
                    formatDateTimeTime(recommendation.recommendedStartTime),
                    recommendation.expectedReturnTime?.let(::formatDateTimeTime)
                        ?: stringResource(R.string.hike_plan_return_time_unavailable),
                )
            )
        } else {
            Text(
                localizedRecommendationExplanation(recommendation.explanation),
                color = MaterialTheme.colorScheme.error,
            )
        }
        recommendation.explanation?.takeIf { recommendation.recommendedStartTime != null }?.let {
            Text(localizedRecommendationExplanation(it))
        }

        if (weather.risks.isNotEmpty()) {
            Text(
                stringResource(R.string.hike_plan_weather_risks),
                style = MaterialTheme.typography.titleMedium
            )
            FlowRow(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                weather.risks.forEach { risk ->
                    AssistChip(
                        onClick = {},
                        label = { Text(localizedWeatherRisk(risk)) },
                    )
                }
            }
        }

        WeatherHourlyTimeline(
            hourly = weather.hourlyForecast,
            start = recommendation.recommendedStartTime,
            end = recommendation.expectedReturnTime,
        )

        Text(
            stringResource(
                R.string.format_weather_source,
                weather.dataSource,
                formatInstant(weather.lastUpdated),
            ),
            style = MaterialTheme.typography.bodySmall,
        )
    }
}

@Composable
private fun localizedWeatherCondition(condition: String?): String {
    return when (condition) {
        "CLEAR" -> stringResource(R.string.weather_condition_clear)
        "PARTLY_CLOUDY" -> stringResource(R.string.weather_condition_partly_cloudy)
        "FOG" -> stringResource(R.string.weather_condition_fog)
        "DRIZZLE" -> stringResource(R.string.weather_condition_drizzle)
        "RAIN" -> stringResource(R.string.weather_condition_rain)
        "SNOW" -> stringResource(R.string.weather_condition_snow)
        "THUNDERSTORM" -> stringResource(R.string.weather_condition_thunderstorm)
        else -> stringResource(R.string.weather_condition_forecast)
    }
}

@Composable
private fun localizedRecommendationExplanation(explanation: String?): String {
    return when (explanation) {
        "DAYLIGHT_INFORMATION_UNAVAILABLE" -> stringResource(R.string.weather_recommendation_daylight_unavailable)
        "NO_DAYLIGHT_WINDOW_FITS_ROUTE_DURATION" -> stringResource(R.string.weather_recommendation_no_daylight_window)
        "RECOMMENDED_WINDOW_AVOIDS_NIGHTTIME_AND_HIGH_RISK_FORECAST_HOURS" ->
            stringResource(R.string.weather_recommendation_avoids_nighttime_and_risk)
        "NO_SUITABLE_WEATHER_WINDOW_AVAILABLE" -> stringResource(R.string.weather_recommendation_no_suitable_window)
        else -> stringResource(R.string.hike_plan_recommended_start_unavailable)
    }
}

@Composable
private fun localizedWeatherRisk(risk: WeatherRiskUiModel): String {
    return when (risk.message) {
        "HIGH_CHANCE_OF_HEAVY_PRECIPITATION" -> stringResource(R.string.weather_risk_heavy_precipitation)
        "STRONG_WIND_GUSTS_EXPECTED" -> stringResource(R.string.weather_risk_strong_wind)
        "HIGH_UV_EXPOSURE_EXPECTED" -> stringResource(R.string.weather_risk_high_uv)
        "DAYLIGHT_WINDOW_IS_SHORT" -> stringResource(R.string.weather_risk_short_daylight)
        "VISIBILITY_MAY_BE_POOR" -> stringResource(R.string.weather_risk_poor_visibility)
        "TEMPERATURE_MAY_BE_UNSAFE_FOR_HIKING" -> stringResource(R.string.weather_risk_unsafe_temperature)
        "FREEZING_CONDITIONS_MAY_AFFECT_ROUTE" -> stringResource(R.string.weather_risk_freezing_conditions)
        "THUNDERSTORM_LIKE_WEATHER_POSSIBLE" -> stringResource(R.string.weather_risk_thunderstorm)
        else -> stringResource(R.string.weather_risk_unknown)
    }
}

@Composable
private fun WeatherHourlyTimeline(
    hourly: List<HourlyPlanWeather>,
    start: LocalDateTime?,
    end: LocalDateTime?,
) {
    val window = if (start != null && end != null) {
        hourly.filter { !it.time.isBefore(start) && it.time.isBefore(end) }
    } else {
        hourly.take(6)
    }.take(6)
    if (window.isEmpty()) return

    Text(
        stringResource(R.string.hike_plan_hourly_forecast),
        style = MaterialTheme.typography.titleMedium
    )
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        window.forEach { hour ->
            Box(modifier = Modifier.weight(1f)) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(formatDateTimeTime(hour.time), style = MaterialTheme.typography.bodySmall)
                    Text(hour.temperatureC?.let { "${it.toInt()} C" } ?: "--")
                    Text("${hour.precipitationProbabilityPercent ?: 0}%")
                }
            }
        }
    }
}

@Composable
private fun ChecklistItemRow(
    item: HikePlanChecklistItem,
    onTextChange: (String) -> Unit,
    onCheckedChange: (Boolean) -> Unit,
    onDelete: () -> Unit,
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Checkbox(
            checked = item.checked,
            onCheckedChange = onCheckedChange,
        )
        OutlinedTextField(
            value = item.text,
            onValueChange = onTextChange,
            modifier = Modifier.weight(1f),
            singleLine = true,
        )
        IconButton(onClick = onDelete) {
            Icon(
                imageVector = Icons.Default.Delete,
                contentDescription = stringResource(R.string.cd_delete_checklist_item),
            )
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun HikePlanDatePickerDialog(
    selectedEpochDay: Long,
    onDismiss: () -> Unit,
    onSelectDate: (Long) -> Unit,
) {
    val todayEpochDay = LocalDate.now().toEpochDay()
    val datePickerState = rememberDatePickerState(
        initialSelectedDateMillis = epochDayToUtcMillis(selectedEpochDay),
        selectableDates = object : SelectableDates {
            override fun isSelectableDate(utcTimeMillis: Long): Boolean {
                return utcMillisToEpochDay(utcTimeMillis) >= todayEpochDay
            }

            override fun isSelectableYear(year: Int): Boolean {
                return year >= LocalDate.now().year
            }
        },
    )
    DatePickerDialog(
        onDismissRequest = onDismiss,
        confirmButton = {
            TextButton(
                onClick = {
                    datePickerState.selectedDateMillis
                        ?.let { onSelectDate(utcMillisToEpochDay(it)) }
                },
                enabled = datePickerState.selectedDateMillis != null,
            ) {
                Text(stringResource(R.string.action_apply))
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text(stringResource(R.string.action_cancel))
            }
        },
    ) {
        DatePicker(state = datePickerState)
    }
}

internal fun formatPlannedDate(epochDay: Long): String {
    return LocalDate.ofEpochDay(epochDay).format(DateTimeFormatter.ISO_LOCAL_DATE)
}

private fun formatTime(time: LocalTime): String {
    return time.format(DateTimeFormatter.ofPattern("HH:mm"))
}

private fun formatDateTimeTime(time: LocalDateTime): String {
    return time.toLocalTime().format(DateTimeFormatter.ofPattern("HH:mm"))
}

private fun formatInstant(instant: Instant): String {
    return DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm")
        .withZone(java.time.ZoneId.systemDefault())
        .format(instant)
}

private fun formatTemperatureRange(min: Double?, max: Double?): String {
    return when {
        min != null && max != null -> "${min.toInt()}-${max.toInt()} C"
        max != null -> "${max.toInt()} C"
        min != null -> "${min.toInt()} C"
        else -> "--"
    }
}

private fun formatDecimal(value: Double): String {
    return if (value % 1.0 == 0.0) value.toInt().toString() else "%.1f".format(value)
}

private fun epochDayToUtcMillis(epochDay: Long): Long {
    return LocalDate.ofEpochDay(epochDay).atStartOfDay(ZoneOffset.UTC).toInstant().toEpochMilli()
}

private fun utcMillisToEpochDay(utcTimeMillis: Long): Long {
    return Instant.ofEpochMilli(utcTimeMillis).atZone(ZoneOffset.UTC).toLocalDate().toEpochDay()
}
