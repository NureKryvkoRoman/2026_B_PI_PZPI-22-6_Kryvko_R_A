package ua.nure.kryvko.hikeway.data.offlinemaps

import android.content.Context
import android.util.DisplayMetrics
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import org.maplibre.android.geometry.LatLngBounds
import org.maplibre.android.offline.OfflineManager
import org.maplibre.android.offline.OfflineRegion
import org.maplibre.android.offline.OfflineRegionError
import org.maplibre.android.offline.OfflineRegionStatus
import org.maplibre.android.offline.OfflineTilePyramidRegionDefinition
import org.json.JSONObject
import ua.nure.kryvko.hikeway.core.model.Route
import ua.nure.kryvko.hikeway.data.offlinemaps.local.RouteMapDownloadDao
import ua.nure.kryvko.hikeway.data.offlinemaps.local.RouteMapDownloadEntity
import ua.nure.kryvko.hikeway.data.offlinemaps.local.toDomain
import ua.nure.kryvko.hikeway.data.offlinemaps.local.toPendingRouteMapDownloadEntity
import ua.nure.kryvko.hikeway.domain.auth.CurrentUserProvider
import ua.nure.kryvko.hikeway.domain.offlinemaps.RouteMapBounds
import ua.nure.kryvko.hikeway.domain.offlinemaps.RouteMapDownload
import ua.nure.kryvko.hikeway.domain.offlinemaps.RouteMapDownloadEstimate
import ua.nure.kryvko.hikeway.domain.offlinemaps.RouteMapDownloadRepository
import ua.nure.kryvko.hikeway.domain.offlinemaps.RouteMapDownloadStatus
import ua.nure.kryvko.hikeway.domain.offlinemaps.estimateRouteMapDownload
import ua.nure.kryvko.hikeway.domain.savedroutes.savedRouteKey
import javax.inject.Inject
import javax.inject.Singleton
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

@Singleton
class MapLibreRouteMapDownloadRepository @Inject constructor(
    @ApplicationContext context: Context,
    private val dao: RouteMapDownloadDao,
    private val currentUserProvider: CurrentUserProvider,
) : RouteMapDownloadRepository {
    private val appContext = context.applicationContext
    private val offlineManager = OfflineManager.getInstance(appContext)
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    @OptIn(ExperimentalCoroutinesApi::class)
    override fun observeAll(): Flow<List<RouteMapDownload>> {
        return currentUserProvider.currentUserId.flatMapLatest { ownerUserId ->
            if (ownerUserId == null) {
                flowOf(emptyList())
            } else {
                dao.observeAll(ownerUserId).map { downloads -> downloads.map { it.toDomain() } }
            }
        }
    }

    @OptIn(ExperimentalCoroutinesApi::class)
    override fun observeByRoute(route: Route): Flow<RouteMapDownload?> {
        return currentUserProvider.currentUserId.flatMapLatest { ownerUserId ->
            if (ownerUserId == null) {
                flowOf(null)
            } else {
                dao.observeByRouteKey(ownerUserId, route.savedRouteKey()).map { it?.toDomain() }
            }
        }
    }

    override fun estimate(route: Route): RouteMapDownloadEstimate = estimateRouteMapDownload(route)

    override suspend fun start(route: Route) {
        val ownerUserId = currentUserProvider.requireCurrentUserId()
        val estimate = estimate(route)
        val existing = dao.findByRouteKey(ownerUserId, route.savedRouteKey())
        existing?.mapLibreRegionId?.let { regionId ->
            runCatching { getRegion(regionId).deleteAwait() }
        }
        val now = System.currentTimeMillis()
        val pending = route.toPendingRouteMapDownloadEntity(
            ownerUserId = ownerUserId,
            estimate = estimate,
            now = now,
            existing = existing?.copy(mapLibreRegionId = null),
        )
        val id = dao.upsert(pending)
        val stored = pending.copy(id = if (pending.id == 0L) id else pending.id)
        val region = runCatching {
            offlineManager.createRegionAwait(
                definition = estimate.toRegionDefinition(appContext.resources.displayMetrics),
                metadata = offlineMetadata(stored).toByteArray(Charsets.UTF_8),
            )
        }.getOrElse { error ->
            dao.update(
                stored.copy(
                    status = RouteMapDownloadStatus.FAILED.name,
                    errorMessage = error.message ?: "Could not create offline map region.",
                    updatedAtEpochMillis = System.currentTimeMillis(),
                )
            )
            return
        }
        val downloading = stored.copy(
            mapLibreRegionId = region.id,
            status = RouteMapDownloadStatus.DOWNLOADING.name,
            updatedAtEpochMillis = System.currentTimeMillis(),
        )
        dao.update(downloading)
        attachObserver(ownerUserId, downloading, region)
        region.setDownloadState(OfflineRegion.STATE_ACTIVE)
        region.getStatusAwait()
            .let { status -> dao.update(downloading.withStatus(status)) }
    }

    override suspend fun delete(download: RouteMapDownload) {
        val ownerUserId = currentUserProvider.requireCurrentUserId()
        download.mapLibreRegionId?.let { regionId ->
            runCatching { getRegion(regionId).deleteAwait() }
        }
        dao.delete(ownerUserId, download.id)
    }

    override suspend fun refreshStatuses() {
        val ownerUserId = currentUserProvider.currentUserId.value ?: return
        val downloads = dao.getAll(ownerUserId)
        downloads.forEach { download ->
            val regionId = download.mapLibreRegionId ?: return@forEach
            runCatching { getRegion(regionId) }
                .onSuccess { region ->
                    attachObserver(ownerUserId, download, region)
                    dao.update(download.withStatus(region.getStatusAwait()))
                }
                .onFailure { error ->
                    dao.update(
                        download.copy(
                            status = RouteMapDownloadStatus.FAILED.name,
                            errorMessage = error.message ?: "Offline map region is unavailable.",
                            updatedAtEpochMillis = System.currentTimeMillis(),
                        )
                    )
                }
        }
    }

    private fun attachObserver(ownerUserId: String, download: RouteMapDownloadEntity, region: OfflineRegion) {
        region.setDeliverInactiveMessages(true)
        region.setObserver(
            object : OfflineRegion.OfflineRegionObserver {
                override fun onStatusChanged(status: OfflineRegionStatus) {
                    scope.launch {
                        val latest = dao.findByRegionId(ownerUserId, region.id) ?: download
                        dao.update(latest.withStatus(status))
                    }
                }

                override fun onError(error: OfflineRegionError) {
                    scope.launch {
                        val latest = dao.findByRegionId(ownerUserId, region.id) ?: download
                        dao.update(
                            latest.copy(
                                status = RouteMapDownloadStatus.FAILED.name,
                                errorMessage = error.message,
                                updatedAtEpochMillis = System.currentTimeMillis(),
                            )
                        )
                    }
                }

                override fun mapboxTileCountLimitExceeded(limit: Long) {
                    scope.launch {
                        val latest = dao.findByRegionId(ownerUserId, region.id) ?: download
                        dao.update(
                            latest.copy(
                                status = RouteMapDownloadStatus.FAILED.name,
                                errorMessage = "Offline tile limit exceeded: $limit.",
                                updatedAtEpochMillis = System.currentTimeMillis(),
                            )
                        )
                    }
                }
            }
        )
    }

    private suspend fun getRegion(regionId: Long): OfflineRegion = suspendCancellableCoroutine { continuation ->
        offlineManager.getOfflineRegion(
            regionId,
            object : OfflineManager.GetOfflineRegionCallback {
                override fun onRegion(offlineRegion: OfflineRegion) {
                    continuation.resume(offlineRegion)
                }

                override fun onRegionNotFound() {
                    continuation.resumeWithException(IllegalStateException("Offline map region not found."))
                }

                override fun onError(error: String) {
                    continuation.resumeWithException(IllegalStateException(error))
                }
            }
        )
    }

    private fun RouteMapDownloadEstimate.toRegionDefinition(displayMetrics: DisplayMetrics) =
        OfflineTilePyramidRegionDefinition(
            MAP_STYLE_URL,
            bounds.toLatLngBounds(),
            minZoom,
            maxZoom,
            displayMetrics.density,
            false,
        )

    private fun RouteMapBounds.toLatLngBounds(): LatLngBounds {
        return LatLngBounds.from(north, east, south, west)
    }
}

private const val MAP_STYLE_URL = "https://tiles.openfreemap.org/styles/liberty"

private fun offlineMetadata(download: RouteMapDownloadEntity): String {
    return JSONObject()
        .put("hikeWayDownloadId", download.id)
        .put("routeKey", download.routeKey)
        .put("routeName", download.routeName)
        .put("minZoom", download.minZoom)
        .put("maxZoom", download.maxZoom)
        .toString()
}

private fun RouteMapDownloadEntity.withStatus(status: OfflineRegionStatus): RouteMapDownloadEntity {
    return copy(
        status = if (status.isComplete) {
            RouteMapDownloadStatus.READY.name
        } else if (status.downloadState == OfflineRegion.STATE_ACTIVE) {
            RouteMapDownloadStatus.DOWNLOADING.name
        } else {
            this.status
        },
        completedResourceCount = status.completedResourceCount,
        requiredResourceCount = status.requiredResourceCount.takeIf {
            status.isRequiredResourceCountPrecise && it > 0L
        },
        completedResourceSizeBytes = status.completedResourceSize,
        completedTileCount = status.completedTileCount,
        completedTileSizeBytes = status.completedTileSize,
        errorMessage = null,
        updatedAtEpochMillis = System.currentTimeMillis(),
    )
}

private suspend fun OfflineManager.createRegionAwait(
    definition: OfflineTilePyramidRegionDefinition,
    metadata: ByteArray,
): OfflineRegion = suspendCancellableCoroutine { continuation ->
    createOfflineRegion(
        definition,
        metadata,
        object : OfflineManager.CreateOfflineRegionCallback {
            override fun onCreate(offlineRegion: OfflineRegion) {
                continuation.resume(offlineRegion)
            }

            override fun onError(error: String) {
                continuation.resumeWithException(IllegalStateException(error))
            }
        }
    )
}

private suspend fun OfflineRegion.getStatusAwait(): OfflineRegionStatus =
    suspendCancellableCoroutine { continuation ->
        getStatus(
            object : OfflineRegion.OfflineRegionStatusCallback {
                override fun onStatus(status: OfflineRegionStatus?) {
                    if (status == null) {
                        continuation.resumeWithException(IllegalStateException("Offline map status is unavailable."))
                    } else {
                        continuation.resume(status)
                    }
                }

                override fun onError(error: String?) {
                    continuation.resumeWithException(IllegalStateException(error ?: "Offline map status error."))
                }
            }
        )
    }

private suspend fun OfflineRegion.deleteAwait(): Unit = suspendCancellableCoroutine { continuation ->
    delete(
        object : OfflineRegion.OfflineRegionDeleteCallback {
            override fun onDelete() {
                continuation.resume(Unit)
            }

            override fun onError(error: String) {
                continuation.resumeWithException(IllegalStateException(error))
            }
        }
    )
}
