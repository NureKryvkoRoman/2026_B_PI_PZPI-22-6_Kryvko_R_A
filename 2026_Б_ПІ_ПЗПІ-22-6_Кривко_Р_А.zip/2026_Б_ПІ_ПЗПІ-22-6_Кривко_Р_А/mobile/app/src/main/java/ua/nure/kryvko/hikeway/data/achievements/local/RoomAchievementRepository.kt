package ua.nure.kryvko.hikeway.data.achievements.local

import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.combine
import ua.nure.kryvko.hikeway.data.hikelogging.local.HikeLogDao
import ua.nure.kryvko.hikeway.data.routes.local.RouteDao
import ua.nure.kryvko.hikeway.domain.achievements.Achievement
import ua.nure.kryvko.hikeway.domain.achievements.AchievementProgressMetric
import ua.nure.kryvko.hikeway.domain.achievements.AchievementRepository
import ua.nure.kryvko.hikeway.domain.achievements.DefaultAchievementDefinitions
import ua.nure.kryvko.hikeway.domain.auth.CurrentUserProvider

class RoomAchievementRepository(
    private val achievementDao: AchievementDao,
    private val hikeLogDao: HikeLogDao,
    private val routeDao: RouteDao,
    private val currentUserProvider: CurrentUserProvider,
) : AchievementRepository {
    override fun observeAchievements(): Flow<List<Achievement>> {
        val ownerUserId = currentUserProvider.requireCurrentUserId()
        return combine(
            achievementDao.observeAll(ownerUserId),
            hikeLogDao.observeFinishedCount(ownerUserId),
            hikeLogDao.observeTotalDistanceKm(ownerUserId),
            hikeLogDao.observeMaxDistanceKm(ownerUserId),
            routeDao.observeCreatedCount(ownerUserId),
        ) { completedRows, finishedHikes, totalDistanceKm, maxDistanceKm, routesCreated ->
            val byCode = completedRows.associateBy { it.code }
            DefaultAchievementDefinitions.map { definition ->
                val completed = byCode[definition.code]
                val localProgress = when (definition.metric) {
                    AchievementProgressMetric.FINISHED_HIKES -> finishedHikes.toDouble()
                    AchievementProgressMetric.TOTAL_DISTANCE_KM -> totalDistanceKm
                    AchievementProgressMetric.SINGLE_HIKE_DISTANCE_KM -> maxDistanceKm
                    AchievementProgressMetric.ROUTES_CREATED -> routesCreated.toDouble()
                }
                Achievement(
                    code = definition.code,
                    titleResId = definition.titleResId,
                    descriptionResId = definition.descriptionResId,
                    progressValue = completed?.progressValue ?: localProgress,
                    targetValue = completed?.targetValue ?: definition.targetValue,
                    kind = definition.kind,
                    completedAtEpochMillis = completed?.completedAtEpochMillis,
                )
            }
        }
    }
}
