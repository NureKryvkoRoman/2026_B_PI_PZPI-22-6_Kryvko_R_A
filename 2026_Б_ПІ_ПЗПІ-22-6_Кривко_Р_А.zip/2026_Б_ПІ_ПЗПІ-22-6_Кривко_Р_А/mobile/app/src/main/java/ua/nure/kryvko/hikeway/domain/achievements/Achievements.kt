package ua.nure.kryvko.hikeway.domain.achievements

import androidx.annotation.StringRes
import kotlinx.coroutines.flow.Flow
import ua.nure.kryvko.hikeway.R

enum class AchievementProgressKind {
    COUNT,
    DISTANCE_KM,
}

enum class AchievementProgressMetric {
    FINISHED_HIKES,
    TOTAL_DISTANCE_KM,
    SINGLE_HIKE_DISTANCE_KM,
    ROUTES_CREATED,
}

data class AchievementDefinition(
    val code: String,
    @param:StringRes val titleResId: Int,
    @param:StringRes val descriptionResId: Int,
    val targetValue: Double,
    val kind: AchievementProgressKind,
    val metric: AchievementProgressMetric,
)

data class Achievement(
    val code: String,
    @param:StringRes val titleResId: Int,
    @param:StringRes val descriptionResId: Int,
    val progressValue: Double,
    val targetValue: Double,
    val kind: AchievementProgressKind,
    val completedAtEpochMillis: Long?,
) {
    val isCompleted: Boolean
        get() = completedAtEpochMillis != null
}

interface AchievementRepository {
    fun observeAchievements(): Flow<List<Achievement>>
}

val DefaultAchievementDefinitions = listOf(
    AchievementDefinition(
        code = "FIRST_HIKE",
        titleResId = R.string.achievement_first_hike_title,
        descriptionResId = R.string.achievement_first_hike_description,
        targetValue = 1.0,
        kind = AchievementProgressKind.COUNT,
        metric = AchievementProgressMetric.FINISHED_HIKES,
    ),
    AchievementDefinition(
        code = "FIRST_10K_HIKE",
        titleResId = R.string.achievement_first_10k_hike_title,
        descriptionResId = R.string.achievement_first_10k_hike_description,
        targetValue = 10.0,
        kind = AchievementProgressKind.DISTANCE_KM,
        metric = AchievementProgressMetric.SINGLE_HIKE_DISTANCE_KM,
    ),
    AchievementDefinition(
        code = "TOTAL_50K_HIKED",
        titleResId = R.string.achievement_total_50k_hiked_title,
        descriptionResId = R.string.achievement_total_50k_hiked_description,
        targetValue = 50.0,
        kind = AchievementProgressKind.DISTANCE_KM,
        metric = AchievementProgressMetric.TOTAL_DISTANCE_KM,
    ),
    AchievementDefinition(
        code = "FIVE_HIKES_FINISHED",
        titleResId = R.string.achievement_five_hikes_finished_title,
        descriptionResId = R.string.achievement_five_hikes_finished_description,
        targetValue = 5.0,
        kind = AchievementProgressKind.COUNT,
        metric = AchievementProgressMetric.FINISHED_HIKES,
    ),
    AchievementDefinition(
        code = "FIRST_ROUTE_CREATED",
        titleResId = R.string.achievement_first_route_created_title,
        descriptionResId = R.string.achievement_first_route_created_description,
        targetValue = 1.0,
        kind = AchievementProgressKind.COUNT,
        metric = AchievementProgressMetric.ROUTES_CREATED,
    ),
)
