package ua.nure.kryvko.hikeway.data.routes.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface RouteDao {
    @Insert
    suspend fun insert(route: RouteEntity): Long

    @Query("SELECT * FROM routes WHERE ownerUserId = :ownerUserId AND deleted = 0 ORDER BY id DESC")
    suspend fun getAll(ownerUserId: String): List<RouteEntity>

    @Query("SELECT * FROM routes WHERE ownerUserId = :ownerUserId AND deleted = 0 ORDER BY id DESC")
    fun observeAll(ownerUserId: String): Flow<List<RouteEntity>>

    @Query("SELECT COUNT(*) FROM routes WHERE ownerUserId = :ownerUserId AND deleted = 0")
    fun observeCreatedCount(ownerUserId: String): Flow<Int>

    @Query("SELECT * FROM routes WHERE ownerUserId = :ownerUserId AND syncState != 'SYNCED'")
    suspend fun getPending(ownerUserId: String): List<RouteEntity>

    @Query("SELECT * FROM routes WHERE ownerUserId = :ownerUserId AND clientId = :clientId LIMIT 1")
    suspend fun findByClientId(ownerUserId: String, clientId: String): RouteEntity?

    @Query("SELECT * FROM routes WHERE ownerUserId = :ownerUserId AND serverId = :serverId LIMIT 1")
    suspend fun findByServerId(ownerUserId: String, serverId: Long): RouteEntity?

    @Query("SELECT * FROM routes WHERE ownerUserId = :ownerUserId AND id = :id LIMIT 1")
    suspend fun findById(ownerUserId: String, id: Long): RouteEntity?

    @Query("DELETE FROM routes WHERE ownerUserId = :ownerUserId AND id = :id")
    suspend fun hardDeleteById(ownerUserId: String, id: Long)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(route: RouteEntity): Long

    @Update
    suspend fun update(route: RouteEntity)
}
