package ua.nure.kryvko.hikeway.data.profile.remote

import com.google.gson.Gson
import ua.nure.kryvko.hikeway.data.services.backend.ProfileService
import ua.nure.kryvko.hikeway.data.services.backend.toDomain
import ua.nure.kryvko.hikeway.data.services.backend.toDto
import ua.nure.kryvko.hikeway.data.services.network.toApiException
import ua.nure.kryvko.hikeway.domain.profile.ProfileRepository
import ua.nure.kryvko.hikeway.domain.profile.UpdateUserProfileRequest
import ua.nure.kryvko.hikeway.domain.profile.UserProfile

class RemoteProfileRepository(
    private val service: ProfileService,
    private val gson: Gson,
) : ProfileRepository {
    override suspend fun currentProfile(): UserProfile {
        return runCatching { service.currentProfile().toDomain() }
            .getOrElse { throw it.toApiException(gson, "Profile is unavailable.") }
    }

    override suspend fun updateProfile(request: UpdateUserProfileRequest): UserProfile {
        return runCatching { service.updateProfile(request.toDto()).toDomain() }
            .getOrElse { throw it.toApiException(gson, "Could not save profile.") }
    }
}
