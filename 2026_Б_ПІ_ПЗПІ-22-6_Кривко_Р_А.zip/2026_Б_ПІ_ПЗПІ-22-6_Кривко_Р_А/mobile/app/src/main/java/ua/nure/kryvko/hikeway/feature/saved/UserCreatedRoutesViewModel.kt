package ua.nure.kryvko.hikeway.feature.saved

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import ua.nure.kryvko.hikeway.core.model.Route
import ua.nure.kryvko.hikeway.domain.routes.ObserveUserCreatedRoutesUseCase

data class UserCreatedRoutesUiState(
    val routes: List<Route> = emptyList(),
    val isLoading: Boolean = true,
    val errorMessage: String? = null,
)

@HiltViewModel
class UserCreatedRoutesViewModel @Inject constructor(
    private val observeUserCreatedRoutes: ObserveUserCreatedRoutesUseCase,
) : ViewModel() {
    private val _uiState = MutableStateFlow(UserCreatedRoutesUiState())
    val uiState: StateFlow<UserCreatedRoutesUiState> = _uiState.asStateFlow()

    init {
        viewModelScope.launch {
            observeUserCreatedRoutes()
                .catch {
                    _uiState.update {
                        it.copy(
                            isLoading = false,
                            errorMessage = "Could not load user-created routes.",
                        )
                    }
                }
                .collect { routes ->
                    _uiState.update {
                        it.copy(
                            routes = routes,
                            isLoading = false,
                            errorMessage = null,
                        )
                    }
                }
        }
    }
}
