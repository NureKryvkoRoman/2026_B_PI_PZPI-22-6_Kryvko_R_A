package ua.nure.kryvko.hikeway.feature.safety

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import ua.nure.kryvko.hikeway.core.model.GeoPoint
import ua.nure.kryvko.hikeway.core.model.Route
import ua.nure.kryvko.hikeway.domain.routes.GetCurrentLocationUseCase
import ua.nure.kryvko.hikeway.domain.safety.BuildSosSmsMessageUseCase
import ua.nure.kryvko.hikeway.domain.safety.DeletePrimaryEmergencyContactUseCase
import ua.nure.kryvko.hikeway.domain.safety.EmergencyContact
import ua.nure.kryvko.hikeway.domain.safety.ObservePrimaryEmergencyContactUseCase
import ua.nure.kryvko.hikeway.domain.safety.SavePrimaryEmergencyContactUseCase
import ua.nure.kryvko.hikeway.domain.safety.SosSmsMessage

data class EmergencyContactsUiState(
    val contact: EmergencyContact? = null,
    val name: String = "",
    val phoneNumber: String = "",
    val isLoading: Boolean = true,
    val isSaving: Boolean = false,
    val validationError: String? = null,
    val message: String? = null,
    val isSosConfirmationVisible: Boolean = false,
    val pendingSosMessage: SosSmsMessage? = null,
)

@HiltViewModel
class EmergencyContactsViewModel @Inject constructor(
    private val observePrimaryContact: ObservePrimaryEmergencyContactUseCase,
    private val savePrimaryContact: SavePrimaryEmergencyContactUseCase,
    private val deletePrimaryContact: DeletePrimaryEmergencyContactUseCase,
    private val getCurrentLocation: GetCurrentLocationUseCase,
    private val buildSosSmsMessage: BuildSosSmsMessageUseCase,
) : ViewModel() {
    private val _uiState = MutableStateFlow(EmergencyContactsUiState())
    val uiState: StateFlow<EmergencyContactsUiState> = _uiState.asStateFlow()

    init {
        viewModelScope.launch {
            observePrimaryContact()
                .catch {
                    _uiState.update {
                        it.copy(
                            isLoading = false,
                            message = "Could not load emergency contact.",
                        )
                    }
                }
                .collect { contact ->
                    _uiState.update {
                        it.copy(
                            contact = contact,
                            name = contact?.name.orEmpty(),
                            phoneNumber = contact?.phoneNumber.orEmpty(),
                            isLoading = false,
                            validationError = null,
                        )
                    }
                }
        }
    }

    fun updateName(name: String) {
        _uiState.update { it.copy(name = name, validationError = null, message = null) }
    }

    fun updatePhoneNumber(phoneNumber: String) {
        _uiState.update { it.copy(phoneNumber = phoneNumber, validationError = null, message = null) }
    }

    fun save() {
        val state = _uiState.value
        if (state.phoneNumber.isBlank()) {
            _uiState.update { it.copy(validationError = "Phone number is required.") }
            return
        }
        viewModelScope.launch {
            _uiState.update { it.copy(isSaving = true, validationError = null, message = null) }
            runCatching {
                savePrimaryContact(state.name, state.phoneNumber)
            }.onSuccess {
                _uiState.update {
                    it.copy(isSaving = false, message = "Emergency contact saved.")
                }
            }.onFailure {
                _uiState.update {
                    it.copy(
                        isSaving = false,
                        message = "Could not save emergency contact.",
                    )
                }
            }
        }
    }

    fun delete() {
        viewModelScope.launch {
            runCatching { deletePrimaryContact() }
                .onSuccess {
                    _uiState.update {
                        it.copy(
                            name = "",
                            phoneNumber = "",
                            message = "Emergency contact deleted.",
                            validationError = null,
                        )
                    }
                }
                .onFailure {
                    _uiState.update { it.copy(message = "Could not delete emergency contact.") }
                }
        }
    }

    fun requestSosConfirmation() {
        if (_uiState.value.contact == null) {
            _uiState.update {
                it.copy(message = "Add an emergency contact in Profile before sending SOS.")
            }
            return
        }
        _uiState.update {
            it.copy(isSosConfirmationVisible = true, message = null)
        }
    }

    fun dismissSosConfirmation() {
        _uiState.update { it.copy(isSosConfirmationVisible = false) }
    }

    fun confirmSos(username: String, route: Route, currentPosition: GeoPoint?) {
        val contact = _uiState.value.contact
        if (contact == null) {
            _uiState.update {
                it.copy(
                    isSosConfirmationVisible = false,
                    message = "Add an emergency contact in Profile before sending SOS.",
                )
            }
            return
        }
        viewModelScope.launch {
            val location = currentPosition ?: runCatching { getCurrentLocation() }.getOrNull()
            val message = buildSosSmsMessage(contact, username, route, location)
            _uiState.update {
                it.copy(
                    isSosConfirmationVisible = false,
                    pendingSosMessage = message,
                )
            }
        }
    }

    fun consumePendingSosMessage() {
        _uiState.update { it.copy(pendingSosMessage = null) }
    }

    fun clearMessage() {
        _uiState.update { it.copy(message = null) }
    }
}
