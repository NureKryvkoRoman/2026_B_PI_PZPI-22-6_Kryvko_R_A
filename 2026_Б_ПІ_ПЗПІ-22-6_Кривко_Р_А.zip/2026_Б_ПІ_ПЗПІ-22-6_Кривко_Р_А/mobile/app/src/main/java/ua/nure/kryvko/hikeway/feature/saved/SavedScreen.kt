package ua.nure.kryvko.hikeway.feature.saved

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.annotation.StringRes
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.Card
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.PrimaryScrollableTabRow
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import ua.nure.kryvko.hikeway.R
import ua.nure.kryvko.hikeway.core.model.Route
import ua.nure.kryvko.hikeway.core.model.RouteVisibility
import ua.nure.kryvko.hikeway.domain.hikeplans.HikePlan
import ua.nure.kryvko.hikeway.domain.offlinemaps.RouteMapDownload
import ua.nure.kryvko.hikeway.domain.offlinemaps.RouteMapDownloadStatus
import ua.nure.kryvko.hikeway.feature.completedhikes.CompletedHikesScreen
import ua.nure.kryvko.hikeway.feature.completedhikes.CompletedHikesViewModel
import ua.nure.kryvko.hikeway.feature.hikeplans.HikePlansViewModel
import ua.nure.kryvko.hikeway.feature.hikeplans.formatPlannedDate
import ua.nure.kryvko.hikeway.feature.routesearch.label
import java.util.Locale

@Composable
@OptIn(ExperimentalMaterial3Api::class)
fun SavedScreen(
    completedHikesViewModel: CompletedHikesViewModel,
    savedRoutesViewModel: SavedRoutesViewModel,
    userCreatedRoutesViewModel: UserCreatedRoutesViewModel,
    savedMapsViewModel: SavedMapsViewModel,
    hikePlansViewModel: HikePlansViewModel,
    selectedTab: SavedTab,
    onTabSelected: (SavedTab) -> Unit,
    onRouteClick: (Route) -> Unit,
    onOriginalRouteClick: (Route) -> Unit = onRouteClick,
    onHikePlanClick: (HikePlan) -> Unit,
) {
    Column(modifier = Modifier.fillMaxSize()) {
        PrimaryScrollableTabRow(selectedTabIndex = selectedTab.ordinal) {
            SavedTab.entries.forEach { tab ->
                Tab(
                    selected = selectedTab == tab,
                    onClick = { onTabSelected(tab) },
                    text = { Text(stringResource(tab.labelRes)) },
                )
            }
        }
        when (selectedTab) {
            SavedTab.FINISHED_HIKES -> CompletedHikesScreen(
                viewModel = completedHikesViewModel,
                onViewOriginalRoute = onOriginalRouteClick,
            )
            SavedTab.USER_CREATED_ROUTES -> UserCreatedRoutesList(
                viewModel = userCreatedRoutesViewModel,
                onRouteClick = onRouteClick,
            )
            SavedTab.SAVED_ROUTES -> SavedRoutesList(
                viewModel = savedRoutesViewModel,
                onRouteClick = onRouteClick,
            )
            SavedTab.HIKE_PLANS -> HikePlansList(
                viewModel = hikePlansViewModel,
                onHikePlanClick = onHikePlanClick,
            )
            SavedTab.SAVED_MAPS -> SavedMapsList(savedMapsViewModel)
        }
    }
}

@Composable
private fun SavedRoutesList(
    viewModel: SavedRoutesViewModel,
    onRouteClick: (Route) -> Unit,
) {
    val state by viewModel.uiState.collectAsState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Text(stringResource(R.string.saved_routes), style = MaterialTheme.typography.headlineSmall)
        when {
            state.isLoading -> Box(
                modifier = Modifier.fillMaxSize(),
                contentAlignment = Alignment.Center,
            ) {
                CircularProgressIndicator()
            }
            state.errorMessage != null -> Text(
                state.errorMessage.orEmpty(),
                color = MaterialTheme.colorScheme.error,
            )
            state.routes.isEmpty() -> Text(stringResource(R.string.saved_no_routes))
            else -> LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(state.routes, key = { route -> route.id }) { route ->
                    SavedRouteCard(
                        route = route,
                        onClick = { onRouteClick(route) },
                        onRemove = { viewModel.remove(route) },
                    )
                }
            }
        }
    }
}

@Composable
private fun SavedRouteCard(
    route: Route,
    onClick: () -> Unit,
    onRemove: () -> Unit,
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick),
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Column(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(4.dp),
            ) {
                Text(route.name, style = MaterialTheme.typography.titleSmall)
                Text(
                    stringResource(
                        R.string.format_route_card_details,
                        route.distanceKm.toString(),
                        route.estimatedTimeMinutes,
                        route.elevationGainMeters,
                    ),
                    style = MaterialTheme.typography.bodySmall,
                )
                Text(
                    stringResource(
                        R.string.format_route_card_labels,
                        route.difficulty.label(),
                        route.terrain.label(),
                    ),
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.primary,
                )
            }
            IconButton(onClick = onRemove) {
                Icon(
                    imageVector = Icons.Default.Delete,
                    contentDescription = stringResource(R.string.cd_remove_saved_route),
                )
            }
        }
    }
}

@Composable
private fun HikePlansList(
    viewModel: HikePlansViewModel,
    onHikePlanClick: (HikePlan) -> Unit,
) {
    val state by viewModel.uiState.collectAsState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Text(stringResource(R.string.saved_hike_plans), style = MaterialTheme.typography.headlineSmall)
        when {
            state.isLoading -> Box(
                modifier = Modifier.fillMaxSize(),
                contentAlignment = Alignment.Center,
            ) {
                CircularProgressIndicator()
            }
            state.errorMessage != null -> Text(
                state.errorMessage.orEmpty(),
                color = MaterialTheme.colorScheme.error,
            )
            state.plans.isEmpty() -> Text(stringResource(R.string.saved_no_hike_plans))
            else -> LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(state.plans, key = { plan -> plan.id }) { plan ->
                    HikePlanCard(
                        plan = plan,
                        onClick = { onHikePlanClick(plan) },
                        onDelete = { viewModel.delete(plan.id) },
                    )
                }
            }
        }
    }
}

@Composable
private fun HikePlanCard(
    plan: HikePlan,
    onClick: () -> Unit,
    onDelete: () -> Unit,
) {
    val packedCount = plan.checklist.count { it.checked }
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick),
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Column(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(4.dp),
            ) {
                Text(plan.routeName, style = MaterialTheme.typography.titleSmall)
                Text(
                    stringResource(R.string.format_planned_date, formatPlannedDate(plan.plannedDateEpochDay)),
                    style = MaterialTheme.typography.bodySmall,
                )
                Text(
                    stringResource(R.string.format_packed_checklist, packedCount, plan.checklist.size),
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.primary,
                )
            }
            IconButton(onClick = onDelete) {
                Icon(
                    imageVector = Icons.Default.Delete,
                    contentDescription = stringResource(R.string.cd_delete_hike_plan),
                )
            }
        }
    }
}

@Composable
private fun UserCreatedRoutesList(
    viewModel: UserCreatedRoutesViewModel,
    onRouteClick: (Route) -> Unit,
) {
    val state by viewModel.uiState.collectAsState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Text(stringResource(R.string.saved_user_created_routes), style = MaterialTheme.typography.headlineSmall)
        when {
            state.isLoading -> Box(
                modifier = Modifier.fillMaxSize(),
                contentAlignment = Alignment.Center,
            ) {
                CircularProgressIndicator()
            }
            state.errorMessage != null -> Text(
                state.errorMessage.orEmpty(),
                color = MaterialTheme.colorScheme.error,
            )
            state.routes.isEmpty() -> Text(stringResource(R.string.saved_no_user_created_routes))
            else -> LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(state.routes, key = { route -> route.id }) { route ->
                    UserCreatedRouteCard(
                        route = route,
                        onClick = { onRouteClick(route) },
                    )
                }
            }
        }
    }
}

@Composable
private fun UserCreatedRouteCard(
    route: Route,
    onClick: () -> Unit,
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick),
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp),
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text(
                    route.name,
                    modifier = Modifier.weight(1f),
                    style = MaterialTheme.typography.titleSmall,
                )
                Text(
                    route.visibility.label(),
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.primary,
                )
            }
            Text(
                stringResource(
                    R.string.format_route_card_details,
                    route.distanceKm.formatDistance(),
                    route.estimatedTimeMinutes,
                    route.elevationGainMeters,
                ),
                style = MaterialTheme.typography.bodySmall,
            )
            Text(
                stringResource(
                    R.string.format_route_card_labels,
                    route.difficulty.label(),
                    route.terrain.label(),
                ),
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.primary,
            )
        }
    }
}

@Composable
private fun RouteVisibility.label(): String {
    return when (this) {
        RouteVisibility.PRIVATE -> stringResource(R.string.route_visibility_private)
        RouteVisibility.PUBLIC -> stringResource(R.string.route_visibility_public)
    }
}

@Composable
private fun SavedMapsList(viewModel: SavedMapsViewModel) {
    val state by viewModel.uiState.collectAsState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Text(stringResource(R.string.saved_maps), style = MaterialTheme.typography.headlineSmall)
        state.errorMessage?.let {
            Text(it, color = MaterialTheme.colorScheme.error)
        }
        when {
            state.isLoading -> Box(
                modifier = Modifier.fillMaxSize(),
                contentAlignment = Alignment.Center,
            ) {
                CircularProgressIndicator()
            }
            state.downloads.isEmpty() -> Text(stringResource(R.string.saved_no_maps))
            else -> LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(state.downloads, key = { download -> download.id }) { download ->
                    SavedMapCard(
                        download = download,
                        isDeleting = download.id in state.deletingIds,
                        onDelete = { viewModel.delete(download) },
                    )
                }
            }
        }
    }
}

@Composable
private fun SavedMapCard(
    download: RouteMapDownload,
    isDeleting: Boolean,
    onDelete: () -> Unit,
) {
    Card(modifier = Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Column(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(6.dp),
            ) {
                Text(download.routeName, style = MaterialTheme.typography.titleSmall)
                Text(download.status.label(), style = MaterialTheme.typography.labelMedium)
                download.progressFraction?.let { progress ->
                    LinearProgressIndicator(
                        progress = { progress },
                        modifier = Modifier.fillMaxWidth(),
                    )
                }
                Text(
                    stringResource(
                        R.string.format_downloaded_bytes,
                        download.completedResourceSizeBytes.formatBytes(),
                    ),
                    style = MaterialTheme.typography.bodySmall,
                )
                download.errorMessage?.let {
                    Text(it, color = MaterialTheme.colorScheme.error)
                }
            }
            IconButton(onClick = onDelete, enabled = !isDeleting) {
                Icon(
                    imageVector = Icons.Default.Delete,
                    contentDescription = stringResource(R.string.cd_delete_saved_map),
                )
            }
        }
    }
}

@Composable
private fun RouteMapDownloadStatus.label(): String {
    return when (this) {
        RouteMapDownloadStatus.PENDING -> stringResource(R.string.offline_status_pending)
        RouteMapDownloadStatus.DOWNLOADING -> stringResource(R.string.offline_status_downloading)
        RouteMapDownloadStatus.READY -> stringResource(R.string.offline_status_ready)
        RouteMapDownloadStatus.FAILED -> stringResource(R.string.offline_status_failed)
    }
}

private fun Long.formatBytes(): String {
    if (this <= 0L) return "0 MB"
    val mb = this.toDouble() / (1024.0 * 1024.0)
    return if (mb < 1.0) {
        "${(this / 1024L).coerceAtLeast(1L)} KB"
    } else {
        "%.1f MB".format(mb)
    }
}

private fun Double.formatDistance(): String {
    return "%.2f".format(Locale.US, this)
}

enum class SavedTab(@param:StringRes val labelRes: Int) {
    FINISHED_HIKES(R.string.saved_completed_hikes),
    USER_CREATED_ROUTES(R.string.saved_user_created_routes),
    SAVED_ROUTES(R.string.saved_routes),
    HIKE_PLANS(R.string.saved_hike_plans),
    SAVED_MAPS(R.string.saved_maps),
}
