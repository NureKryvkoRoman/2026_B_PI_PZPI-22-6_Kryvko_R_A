package ua.nure.kryvko.hikeway.feature.profile

import androidx.annotation.StringRes
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import ua.nure.kryvko.hikeway.domain.achievements.Achievement
import ua.nure.kryvko.hikeway.domain.achievements.AchievementRepository
import ua.nure.kryvko.hikeway.domain.achievements.DefaultAchievementDefinitions
import ua.nure.kryvko.hikeway.data.sync.SyncCoordinator

data class AchievementsUiState(
    val activeUserId: String? = null,
    val achievements: List<Achievement> = emptyList(),
    val isLoading: Boolean = false,
    val errorMessage: String? = null,
)

data class AchievementToastEvent(
    @param:StringRes val titleResId: Int,
)

@HiltViewModel
class AchievementsViewModel @Inject constructor(
    private val repository: AchievementRepository,
    private val syncCoordinator: SyncCoordinator,
) : ViewModel() {
    private val _uiState = MutableStateFlow(AchievementsUiState())
    val uiState: StateFlow<AchievementsUiState> = _uiState.asStateFlow()

    private val _toastEvents = MutableSharedFlow<AchievementToastEvent>(extraBufferCapacity = 1)
    val toastEvents: SharedFlow<AchievementToastEvent> = _toastEvents.asSharedFlow()

    private var observeJob: Job? = null

    init {
        viewModelScope.launch {
            syncCoordinator.newlyCompletedAchievements.collect { achievements ->
                achievements.forEach { achievement ->
                    val definition = DefaultAchievementDefinitions.firstOrNull { it.code == achievement.code }
                    if (definition != null) {
                        _toastEvents.emit(AchievementToastEvent(definition.titleResId))
                    }
                }
            }
        }
    }

    fun loadForUser(userId: String) {
        if (userId.isBlank()) {
            observeJob?.cancel()
            _uiState.value = AchievementsUiState()
            return
        }
        if (_uiState.value.activeUserId == userId && observeJob?.isActive == true) {
            return
        }
        observeJob?.cancel()
        _uiState.value = AchievementsUiState(activeUserId = userId, isLoading = true)
        observeJob = viewModelScope.launch {
            runCatching {
                repository.observeAchievements().collect { achievements ->
                    _uiState.update {
                        it.copy(
                            achievements = achievements,
                            isLoading = false,
                            errorMessage = null,
                        )
                    }
                }
            }.onFailure { error ->
                _uiState.update {
                    it.copy(
                        isLoading = false,
                        errorMessage = error.message ?: "Achievements are unavailable.",
                    )
                }
            }
        }
    }
}
