package ua.nure.kryvko.hikeway.domain.hikeplans

import kotlinx.coroutines.flow.Flow
import javax.inject.Inject
import ua.nure.kryvko.hikeway.core.model.Route

data class HikePlan(
    val id: Long = 0,
    val routeId: Long,
    val routeName: String,
    val plannedDateEpochDay: Long,
    val checklist: List<HikePlanChecklistItem>,
    val routeSnapshot: Route? = null,
    val createdAtEpochMillis: Long = 0,
    val updatedAtEpochMillis: Long = 0,
)

data class HikePlanChecklistItem(
    val id: String,
    val text: String,
    val checked: Boolean,
)

interface HikePlanRepository {
    fun observeAll(): Flow<List<HikePlan>>
    fun observeById(id: Long): Flow<HikePlan?>
    suspend fun save(plan: HikePlan): Long
    suspend fun delete(id: Long)
}

interface HikePlanReminderScheduler {
    fun schedule(plan: HikePlan)
    fun cancel(planId: Long)
}

class NoOpHikePlanReminderScheduler @Inject constructor() : HikePlanReminderScheduler {
    override fun schedule(plan: HikePlan) = Unit
    override fun cancel(planId: Long) = Unit
}

class ObserveHikePlansUseCase @Inject constructor(
    private val repository: HikePlanRepository,
) {
    operator fun invoke(): Flow<List<HikePlan>> = repository.observeAll()
}

class ObserveHikePlanUseCase @Inject constructor(
    private val repository: HikePlanRepository,
) {
    operator fun invoke(id: Long): Flow<HikePlan?> = repository.observeById(id)
}

class SaveHikePlanUseCase @Inject constructor(
    private val repository: HikePlanRepository,
) {
    suspend operator fun invoke(plan: HikePlan): Long = repository.save(plan)
}

class DeleteHikePlanUseCase @Inject constructor(
    private val repository: HikePlanRepository,
) {
    suspend operator fun invoke(id: Long) = repository.delete(id)
}
