package ua.nure.kryvko.hikeway.feature.routesearch

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import ua.nure.kryvko.hikeway.R
import ua.nure.kryvko.hikeway.core.model.GeoPoint
import ua.nure.kryvko.hikeway.core.model.Route
import ua.nure.kryvko.hikeway.feature.navigation.TrackingStatusOverlay
import ua.nure.kryvko.hikeway.feature.pois.PoiOverviewPopup
import ua.nure.kryvko.hikeway.ui.map.MapCenterMode
import ua.nure.kryvko.hikeway.ui.map.MapContextAction
import ua.nure.kryvko.hikeway.ui.map.MapContextMenu

@Composable
fun RouteSearchScreen(
    viewModel: RouteSearchViewModel,
    username: String,
    savedRouteKeys: Set<String> = emptySet(),
    onToggleSavedRoute: (Route) -> Unit = {},
    onCreateRoute: () -> Unit = {},
    onPoiClick: () -> Unit = {},
    onSearchSubmit: (String) -> Unit = {},
) {
    val state by viewModel.uiState.collectAsState()
    var showFilters by remember { mutableStateOf(false) }
    var recommendedExpanded by rememberSaveable { mutableStateOf(true) }
    var popularNearbyExpanded by rememberSaveable { mutableStateOf(true) }

    Box(modifier = Modifier.fillMaxSize()) {
        RouteHomePanel(
            state = state,
            username = username,
            recommendedExpanded = recommendedExpanded,
            popularNearbyExpanded = popularNearbyExpanded,
            onRecommendedExpandedChange = { recommendedExpanded = it },
            onPopularNearbyExpandedChange = { popularNearbyExpanded = it },
            onRefreshRecommended = viewModel::loadRecommendedRoutes,
            onRouteClick = viewModel::previewRoute,
            onPoiClick = { poiId ->
                viewModel.selectPoi(poiId)
                onPoiClick()
            },
            onSearchSubmit = onSearchSubmit,
            onFilterClick = { showFilters = true },
            savedRouteKeys = savedRouteKeys,
            onToggleSavedRoute = onToggleSavedRoute,
            contentBottomPadding = 96.dp,
            modifier = Modifier.fillMaxSize(),
        )
        FloatingActionButton(
            onClick = onCreateRoute,
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(16.dp),
        ) {
            Icon(
                imageVector = Icons.Default.Add,
                contentDescription = stringResource(R.string.create_route_title),
            )
        }
    }

    if (showFilters) {
        FilterDialog(
            criteria = state.draftCriteria,
            onCriteriaChange = viewModel::updateDraft,
            onDifficultyToggle = viewModel::toggleDifficulty,
            onTerrainToggle = viewModel::toggleTerrain,
            onClear = {
                viewModel.clearFilters()
                showFilters = false
            },
            onApply = {
                viewModel.applyFilters()
                showFilters = false
            },
            onDismiss = { showFilters = false },
        )
    }
}

@Composable
fun RoutesMapScreen(
    viewModel: RouteSearchViewModel,
    onCreateRoute: () -> Unit = {},
    onCreateRouteFromPoint: (GeoPoint) -> Unit = {},
    onEditPoi: () -> Unit = {},
    onViewPoiComments: () -> Unit = {},
    isAdmin: Boolean = false,
    sosMessage: String? = null,
    isSosConfirmationVisible: Boolean = false,
    onSosClick: () -> Unit = {},
    onDismissSosMessage: () -> Unit = {},
    onDismissSosConfirmation: () -> Unit = {},
    onConfirmSos: (Route, GeoPoint?) -> Unit = { _, _ -> },
    onFindRoutesNearby: () -> Unit = {},
) {
    val state by viewModel.uiState.collectAsState()
    val pickingSession = state.pickingSession
    val previewRoute = state.previewRoute
    val mapContextPoint = state.mapContextPoint

    BackHandler(enabled = mapContextPoint != null) {
        viewModel.dismissMapContext()
    }

    Box(modifier = Modifier.fillMaxSize()) {
        RoutesMap(
            routes = when {
                pickingSession != null -> listOf(pickingSession.route)
                previewRoute != null -> listOf(previewRoute)
                else -> state.routes
            },
            walkedPath = pickingSession?.walkedPath ?: emptyList(),
            userPosition = pickingSession?.userPosition,
            userBearingDegrees = pickingSession?.bearingDegrees ?: 0.0,
            pointsOfInterest = state.pointsOfInterest,
            contextPoint = state.mapContextPoint ?: state.poiCreationPoint,
            mapCenter = state.mapCenter,
            mapCenterRequestId = state.mapCenterRequestId,
            onCenterLocation = viewModel::centerOnCurrentLocation,
            onPoiClick = viewModel::selectPoi,
            onMapClick = if (state.mapContextPoint != null) {
                viewModel::dismissMapContext
            } else {
                null
            },
            onMapLongClick = if (pickingSession == null && previewRoute == null) {
                viewModel::openMapContext
            } else {
                null
            },
            onMapViewportChanged = viewModel::onMapViewportChanged,
            centerMode = previewRoute
                ?.takeIf { pickingSession == null }
                ?.let { MapCenterMode.RouteStart(it.geometry.points) }
                ?: MapCenterMode.CurrentLocation,
            highlightedMode = pickingSession != null || previewRoute != null,
        )
        if (pickingSession != null) {
            IconButton(
                onClick = onSosClick,
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .padding(16.dp),
            ) {
                Icon(
                    imageVector = Icons.Default.Warning,
                    contentDescription = stringResource(R.string.cd_send_sos),
                    tint = MaterialTheme.colorScheme.error,
                )
            }
            TrackingStatusOverlay(
                session = pickingSession,
                saveErrorMessage = state.saveErrorMessage,
                onPause = viewModel::pauseRoute,
                onUnpause = viewModel::unpauseRoute,
                onFinish = viewModel::finishRoute,
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .padding(top = 16.dp),
            )
        }
        state.selectedPoi?.let { poi ->
            PoiOverviewPopup(
                poi = poi,
                onDismiss = viewModel::dismissPoi,
                onRate = viewModel::ratePoi,
                isLoading = state.isPoiLoading,
                isActionInProgress = state.isPoiActionInProgress,
                errorMessage = state.poiErrorMessage,
                onRemoveRating = viewModel::removePoiRating,
                onUploadPhoto = viewModel::uploadPoiPhoto,
                onUpdatePhoto = viewModel::updatePoiPhoto,
                onDeletePhoto = viewModel::deletePoiPhoto,
                onEditPoi = onEditPoi,
                onViewComments = onViewPoiComments,
                isAdmin = isAdmin,
                modifier = Modifier.align(Alignment.TopCenter),
            )
        }
        mapContextPoint?.let { point ->
            MapContextMenu(
                point = point,
                actions = listOf(
                    MapContextAction(
                        label = stringResource(R.string.map_context_find_routes_nearby),
                        onClick = {
                            viewModel.findRoutesNearContextPoint()
                            onFindRoutesNearby()
                        },
                    ),
                    MapContextAction(
                        label = stringResource(R.string.map_context_add_poi),
                        onClick = viewModel::startPoiCreationFromContext,
                    ),
                    MapContextAction(
                        label = stringResource(R.string.map_context_create_route_from_here),
                        onClick = {
                            viewModel.dismissMapContext()
                            onCreateRouteFromPoint(point)
                        },
                    )
                ),
                modifier = Modifier.align(Alignment.TopCenter),
            )
        }
    }

    state.poiCreationPoint?.let { point ->
        CreatePoiDialog(
            point = point,
            name = state.poiCreationName,
            description = state.poiCreationDescription,
            isSaving = state.isPoiCreationSaving,
            errorMessage = state.poiCreationErrorMessage,
            onNameChange = viewModel::updatePoiCreationName,
            onDescriptionChange = viewModel::updatePoiCreationDescription,
            onSave = viewModel::createPoi,
            onDismiss = viewModel::cancelPoiCreation,
        )
    }

    sosMessage?.let { message ->
        AlertDialog(
            onDismissRequest = onDismissSosMessage,
            title = { Text(stringResource(R.string.sos_title)) },
            text = { Text(message) },
            confirmButton = {
                TextButton(onClick = onDismissSosMessage) {
                    Text(stringResource(R.string.action_ok))
                }
            },
        )
    }

    if (isSosConfirmationVisible) {
        AlertDialog(
            onDismissRequest = onDismissSosConfirmation,
            title = { Text(stringResource(R.string.sos_confirm_title)) },
            text = { Text(stringResource(R.string.sos_confirm_message)) },
            confirmButton = {
                Button(
                    onClick = {
                        pickingSession?.let { session ->
                            onConfirmSos(session.route, session.userPosition)
                        }
                    },
                ) {
                    Text(stringResource(R.string.sos_send))
                }
            },
            dismissButton = {
                TextButton(onClick = onDismissSosConfirmation) {
                    Text(stringResource(R.string.action_cancel))
                }
            },
        )
    }
}
