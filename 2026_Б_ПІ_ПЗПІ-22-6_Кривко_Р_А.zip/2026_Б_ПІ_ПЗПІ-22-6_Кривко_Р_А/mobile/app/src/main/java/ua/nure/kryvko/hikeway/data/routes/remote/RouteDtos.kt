package ua.nure.kryvko.hikeway.data.routes.remote

import java.time.Instant
import ua.nure.kryvko.hikeway.core.model.Difficulty
import ua.nure.kryvko.hikeway.core.model.GeoPoint
import ua.nure.kryvko.hikeway.core.model.Route
import ua.nure.kryvko.hikeway.core.model.RouteComment
import ua.nure.kryvko.hikeway.core.model.RouteGeometry
import ua.nure.kryvko.hikeway.core.model.RouteRating
import ua.nure.kryvko.hikeway.core.model.RouteVisibility
import ua.nure.kryvko.hikeway.core.model.Terrain

data class PageResponseDto<T>(
    val items: List<T>,
    val page: Int,
    val size: Int,
    val totalElements: Long,
    val totalPages: Int,
)

data class GeoJsonLineStringDto(
    val type: String,
    val coordinates: List<List<Double>>,
)

data class RouteSummaryDto(
    val id: Long,
    val name: String,
    val description: String,
    val distanceKm: Double,
    val estimatedTimeMinutes: Int,
    val difficulty: String,
    val elevationGain: Int,
    val terrain: String,
    val geometry: GeoJsonLineStringDto,
    val createdBy: String? = null,
    val clientId: String? = null,
    val visibility: String? = null,
    val averageRating: Double = 0.0,
    val ratingCount: Long = 0,
    val userRating: Int? = null,
)

data class RouteDetailDto(
    val id: Long,
    val name: String,
    val description: String,
    val distanceKm: Double,
    val estimatedTimeMinutes: Int,
    val difficulty: String,
    val elevationGain: Int,
    val terrain: String,
    val createdBy: String? = null,
    val clientId: String? = null,
    val visibility: String? = null,
    val averageRating: Double = 0.0,
    val ratingCount: Long = 0,
    val userRating: Int? = null,
)

data class RouteRatingDto(
    val averageRating: Double,
    val ratingCount: Long,
    val userRating: Int?,
)

data class RouteCommentDto(
    val id: Long,
    val authorId: String,
    val authorDisplayName: String,
    val ownedByCurrentUser: Boolean,
    val text: String,
    val createdAt: String?,
    val updatedAt: String?,
)

data class RouteRatingRequestDto(val score: Int)
data class RouteCommentRequestDto(val text: String)

fun RouteSummaryDto.toDomain(): Route = Route(
    id = id,
    name = name,
    description = description,
    distanceKm = distanceKm,
    estimatedTimeMinutes = estimatedTimeMinutes,
    difficulty = Difficulty.valueOf(difficulty),
    elevationGainMeters = elevationGain,
    terrain = Terrain.valueOf(terrain),
    geometry = RouteGeometry(
        geometry.coordinates.mapNotNull { coordinate ->
            if (coordinate.size < 2) {
                null
            } else {
                GeoPoint(
                    longitude = coordinate[0],
                    latitude = coordinate[1],
                )
            }
        }
    ),
    clientId = clientId,
    serverId = id,
    createdBy = createdBy,
    visibility = visibility?.let(RouteVisibility::valueOf) ?: RouteVisibility.PUBLIC,
    averageRating = averageRating,
    ratingCount = ratingCount,
    userRating = userRating,
)

fun RouteDetailDto.toDomain(geometry: GeoJsonLineStringDto): Route = Route(
    id = id,
    name = name,
    description = description,
    distanceKm = distanceKm,
    estimatedTimeMinutes = estimatedTimeMinutes,
    difficulty = Difficulty.valueOf(difficulty),
    elevationGainMeters = elevationGain,
    terrain = Terrain.valueOf(terrain),
    geometry = RouteGeometry(
        geometry.coordinates.mapNotNull { coordinate ->
            if (coordinate.size < 2) {
                null
            } else {
                GeoPoint(
                    longitude = coordinate[0],
                    latitude = coordinate[1],
                )
            }
        }
    ),
    clientId = clientId,
    serverId = id,
    createdBy = createdBy,
    visibility = visibility?.let(RouteVisibility::valueOf) ?: RouteVisibility.PUBLIC,
    averageRating = averageRating,
    ratingCount = ratingCount,
    userRating = userRating,
)

fun RouteRatingDto.toDomain(): RouteRating = RouteRating(
    averageRating = averageRating,
    ratingCount = ratingCount,
    userRating = userRating,
)

fun RouteCommentDto.toDomain(): RouteComment = RouteComment(
    id = id,
    authorId = authorId,
    authorDisplayName = authorDisplayName,
    ownedByCurrentUser = ownedByCurrentUser,
    text = text,
    createdAt = createdAt.toInstantOrNull(),
    updatedAt = updatedAt.toInstantOrNull(),
)

private fun String?.toInstantOrNull(): Instant? {
    return this?.let { runCatching { Instant.parse(it) }.getOrNull() }
}
