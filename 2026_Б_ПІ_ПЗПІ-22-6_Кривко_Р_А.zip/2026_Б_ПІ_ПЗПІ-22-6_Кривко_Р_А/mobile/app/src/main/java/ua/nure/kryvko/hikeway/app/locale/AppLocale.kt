package ua.nure.kryvko.hikeway.app.locale

import android.app.LocaleManager
import android.content.Context
import android.content.ContextWrapper
import android.content.res.Configuration
import android.os.Build
import android.os.LocaleList
import java.util.Locale

const val DEFAULT_LANGUAGE_TAG = "en"

fun Context.savedLanguageTag(): String {
    return getSharedPreferences(LOCALE_PREFERENCES_NAME, Context.MODE_PRIVATE)
        .getString(KEY_LANGUAGE_TAG, DEFAULT_LANGUAGE_TAG)
        ?: DEFAULT_LANGUAGE_TAG
}

fun Context.saveLanguageTag(languageTag: String) {
    getSharedPreferences(LOCALE_PREFERENCES_NAME, Context.MODE_PRIVATE)
        .edit()
        .putString(KEY_LANGUAGE_TAG, languageTag)
        .apply()
}

fun Context.applySavedLocale(): Context {
    return createLocalizedContext(savedLanguageTag())
}

fun Context.createLocalizedContext(languageTag: String): Context {
    val locale = Locale.forLanguageTag(languageTag)
    Locale.setDefault(locale)
    val configuration = Configuration(resources.configuration)
    configuration.setLocale(locale)
    configuration.setLocales(LocaleList(locale))
    return createConfigurationContext(configuration)
}

fun Context.updateApplicationLocale(languageTag: String) {
    saveLanguageTag(languageTag)
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
        getSystemService(LocaleManager::class.java).applicationLocales =
            LocaleList.forLanguageTags(languageTag)
    }
}

class LocalizedContextWrapper(base: Context) : ContextWrapper(base.applySavedLocale())

private const val LOCALE_PREFERENCES_NAME = "app_locale"
private const val KEY_LANGUAGE_TAG = "language_tag"
