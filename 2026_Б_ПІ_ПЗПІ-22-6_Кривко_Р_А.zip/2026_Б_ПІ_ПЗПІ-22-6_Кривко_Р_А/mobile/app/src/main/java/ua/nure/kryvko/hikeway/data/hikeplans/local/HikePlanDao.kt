package ua.nure.kryvko.hikeway.data.hikeplans.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface HikePlanDao {
    @Query(
        "SELECT * FROM hike_plans WHERE ownerUserId = :ownerUserId " +
            "ORDER BY plannedDateEpochDay ASC, updatedAtEpochMillis DESC"
    )
    fun observeAll(ownerUserId: String): Flow<List<HikePlanEntity>>

    @Query("SELECT * FROM hike_plans WHERE ownerUserId = :ownerUserId AND id = :id LIMIT 1")
    fun observeById(ownerUserId: String, id: Long): Flow<HikePlanEntity?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(plan: HikePlanEntity): Long

    @Query("DELETE FROM hike_plans WHERE ownerUserId = :ownerUserId AND id = :id")
    suspend fun delete(ownerUserId: String, id: Long)
}
