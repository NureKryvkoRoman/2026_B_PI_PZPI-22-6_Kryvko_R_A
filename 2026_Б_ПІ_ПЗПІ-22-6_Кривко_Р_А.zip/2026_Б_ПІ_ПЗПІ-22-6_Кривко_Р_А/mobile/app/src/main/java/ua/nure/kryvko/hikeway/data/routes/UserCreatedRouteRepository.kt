package ua.nure.kryvko.hikeway.data.routes

import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import ua.nure.kryvko.hikeway.core.model.Route
import ua.nure.kryvko.hikeway.data.routes.local.RoomRouteRepository
import ua.nure.kryvko.hikeway.data.routes.remote.RemoteRouteRepository
import ua.nure.kryvko.hikeway.domain.routes.CustomRouteRepository

class UserCreatedRouteRepository(
    private val localRepository: RoomRouteRepository,
    private val remoteRepository: RemoteRouteRepository,
) : CustomRouteRepository {
    override fun observeAll(): Flow<List<Route>> {
        return localRepository.observeAll().map { localRoutes ->
            mergeRoutes(
                remoteRoutes = remoteRepository.currentUserRoutes(),
                localRoutes = localRoutes,
            )
        }
    }

    override suspend fun save(route: Route): Long = localRepository.save(route)

    override suspend fun publish(route: Route): Route = localRepository.publish(route)

    override suspend fun delete(route: Route) = localRepository.delete(route)
}

internal fun mergeRoutes(
    remoteRoutes: List<Route>,
    localRoutes: List<Route>,
): List<Route> {
    val routesByKey = linkedMapOf<String, Route>()
    remoteRoutes.forEach { route -> routesByKey[route.routeMergeKey()] = route }
    localRoutes.forEach { route -> routesByKey[route.routeMergeKey()] = route }
    return routesByKey.values.toList()
}

private fun Route.routeMergeKey(): String {
    return clientId?.let { "client:$it" }
        ?: serverId?.let { "server:$it" }
        ?: "local:$id"
}
